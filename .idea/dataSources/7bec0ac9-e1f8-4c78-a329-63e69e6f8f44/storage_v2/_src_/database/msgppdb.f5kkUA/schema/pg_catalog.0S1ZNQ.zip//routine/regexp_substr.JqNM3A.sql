create function regexp_substr(text, text, integer, integer) returns text
    immutable
    language sql
as
$$
    select regexp_substr($1, $2, $3, $4, '')
$$;

comment on function regexp_substr(text, text, integer, integer) is 'extracts the occurrence''th text matching regular expression from starting position';

