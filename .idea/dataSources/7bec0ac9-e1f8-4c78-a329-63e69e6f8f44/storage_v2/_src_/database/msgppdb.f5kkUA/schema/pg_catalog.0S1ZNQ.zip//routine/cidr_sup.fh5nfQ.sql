create function cidr_sup(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_sup($1::inet, $2::inet)
$$;

