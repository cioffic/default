create function cidr_supeq(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_supeq($1::inet, $2::inet)
$$;

