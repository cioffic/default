create function log(numeric) returns numeric
    immutable
    language sql
as
$$
    select pg_catalog.log(10, $1)
$$;

comment on function log(numeric) is 'logarithm base 10 of n';

