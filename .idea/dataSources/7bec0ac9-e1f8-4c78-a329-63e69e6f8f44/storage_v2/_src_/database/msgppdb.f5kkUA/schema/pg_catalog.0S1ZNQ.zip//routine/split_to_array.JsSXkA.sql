create function split_to_array(text) returns super
    immutable
    language sql
as
$$
    select split_to_array($1, ',')
$$;

comment on function split_to_array(text) is 'convert a string to an array of string';

