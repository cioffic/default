create function regexp_instr(text, text, integer) returns integer
    immutable
    language sql
as
$$
    select regexp_instr($1, $2, $3, 1, 0, '')
$$;

comment on function regexp_instr(text, text, integer) is 'return beginning of first matched regular expression from starting position';

