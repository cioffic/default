create function timetz_eq_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_eq_timetz($2, $1)
$$;

comment on function timetz_eq_time(time with time zone, time) is 'equal';

