create function timetz_cmp_time(time with time zone, time without time zone) returns integer
    stable
    language sql
as
$$
    select -time_cmp_timetz($2, $1)
$$;

comment on function timetz_cmp_time(time with time zone, time) is 'less-equal-greater';

