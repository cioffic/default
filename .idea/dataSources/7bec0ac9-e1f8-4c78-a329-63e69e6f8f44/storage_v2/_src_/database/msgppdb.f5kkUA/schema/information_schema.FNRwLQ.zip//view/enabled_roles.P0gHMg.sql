create view enabled_roles(role_name) as
SELECT g.groname::information_schema.sql_identifier AS role_name
FROM pg_group g,
     pg_user u
WHERE (u.usesysid = ANY (g.grolist))
  AND u.usename = "current_user"()::name;

alter table enabled_roles
    owner to rdsdb;

