create function regexp_instr(text, text, integer, integer, integer) returns integer
    immutable
    language sql
as
$$
    select regexp_instr($1, $2, $3, $4, $5, '')
$$;

comment on function regexp_instr(text, text, integer, integer, integer) is 'return beginning of the occurrence''th matched regular expression from starting position';

