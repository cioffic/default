create function bit_length(bit) returns integer
    immutable
    language sql
as
$$
    select pg_catalog.length($1)
$$;

comment on function bit_length(bit) is 'length in bits';

