create function regexp_count(text, text) returns integer
    immutable
    language sql
as
$$
    select regexp_count($1, $2, 1)
$$;

comment on function regexp_count(text, text) is 'return the number of matched regular expression';

