create function cidr_lt(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_lt($1::inet, $2::inet)
$$;

