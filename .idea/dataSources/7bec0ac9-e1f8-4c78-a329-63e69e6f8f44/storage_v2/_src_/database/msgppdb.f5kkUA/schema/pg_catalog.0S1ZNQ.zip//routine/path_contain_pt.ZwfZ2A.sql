create function path_contain_pt("path", point) returns boolean
    immutable
    language sql
as
$$
    select pg_catalog.on_ppath($2, $1)
$$;

comment on function path_contain_pt("path", point) is 'path contains point?';

