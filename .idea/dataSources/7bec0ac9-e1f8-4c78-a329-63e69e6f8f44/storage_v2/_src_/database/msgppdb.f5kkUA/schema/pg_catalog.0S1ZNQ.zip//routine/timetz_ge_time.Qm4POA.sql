create function timetz_ge_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_le_timetz($2, $1)
$$;

comment on function timetz_ge_time(time with time zone, time) is 'greater-than-or-equal';

