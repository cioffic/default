create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) returns boolean
    stable
    language sql
as
$$
    select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;

comment on function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) is 'SQL92 interval comparison';

