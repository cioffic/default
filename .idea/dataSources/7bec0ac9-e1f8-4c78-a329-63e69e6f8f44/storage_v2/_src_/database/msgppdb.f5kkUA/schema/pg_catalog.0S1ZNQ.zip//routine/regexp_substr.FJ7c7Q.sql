create function regexp_substr(text, text, integer) returns text
    immutable
    language sql
as
$$
    select regexp_substr($1, $2, $3, 1, '')
$$;

comment on function regexp_substr(text, text, integer) is 'extracts first text matching regular expression from starting position';

