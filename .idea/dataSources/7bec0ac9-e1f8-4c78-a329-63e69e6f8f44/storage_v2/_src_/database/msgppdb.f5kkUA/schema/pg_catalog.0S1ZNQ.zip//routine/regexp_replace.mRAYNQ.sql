create function regexp_replace(text, text) returns text
    immutable
    language sql
as
$$
    select regexp_replace($1, $2, '', 1, '')
$$;

comment on function regexp_replace(text, text) is 'replace all occurrences of regular expression in string';

