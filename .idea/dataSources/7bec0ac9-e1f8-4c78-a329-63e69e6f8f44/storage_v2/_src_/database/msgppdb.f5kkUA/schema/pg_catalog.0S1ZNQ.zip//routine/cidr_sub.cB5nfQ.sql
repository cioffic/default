create function cidr_sub(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_sub($1::inet, $2::inet)
$$;

