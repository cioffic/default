create function fn_uuid() returns character varying
    volatile
    language plpythonu
as
$$
 	import uuid
	return '99999999'+uuid.uuid1().__str__()
$$;

