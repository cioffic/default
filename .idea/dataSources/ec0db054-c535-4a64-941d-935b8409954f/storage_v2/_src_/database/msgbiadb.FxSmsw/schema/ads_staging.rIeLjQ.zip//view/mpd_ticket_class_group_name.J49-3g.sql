CREATE VIEW ads_staging.mpd_ticket_class_group_name AS
SELECT *
FROM mapping_tables.mpd_ticket_class_group_name
WITH NO SCHEMA BINDING;

alter table mpd_ticket_class_group_name
    owner to etluser;

