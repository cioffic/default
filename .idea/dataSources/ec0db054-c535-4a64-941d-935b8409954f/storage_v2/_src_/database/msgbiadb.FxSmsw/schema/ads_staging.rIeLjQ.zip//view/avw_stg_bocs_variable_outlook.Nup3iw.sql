create or replace view ads_staging.avw_stg_bocs_variable_outlook as
--CREATE TABLE ads_staging.avw_stg_bocs_variable_outlook AS
select *
from (
         select *,
                row_number() OVER (PARTITION BY eventcode,recordtypename ORDER BY "$path" DESC) rnk,
                ads_staging.f_s3_parse_athena_filename("$path") as                              ads_source_file
         from ext_staging.stg_bocs_variable_outlook
--where "$path" = (select max("$path") from ext_staging.stg_bocs_variable_outlook)
     )
where rnk = 1
with no schema binding;

alter table avw_stg_bocs_variable_outlook
    owner to ads_staging;

