create or replace view ads_staging.avw_stg_ig_meal_period_dim as
select *,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'IG'                                            as ads_source
--substring(ads_source_file, len(ads_source_file)-11,8) loaddate
from ext_staging.stg_ig_meal_period_dim
with no schema binding;

alter table avw_stg_ig_meal_period_dim
    owner to ads_staging;

