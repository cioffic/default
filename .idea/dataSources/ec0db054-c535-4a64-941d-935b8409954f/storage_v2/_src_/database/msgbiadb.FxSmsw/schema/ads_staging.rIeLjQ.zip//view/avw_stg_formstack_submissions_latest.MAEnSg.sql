create or replace view ads_staging.avw_stg_formstack_submissions_latest
    --create table ads_staging.avw_stg_formstack_submissions_latest
as
select *
from (
         select id,
                "timestamp",
                user_agent,
                payment_status,
                latitude,
                longitude,
                read,
                ads_staging.f_s3_parse_athena_filename("$path")                                          as ads_source_file,
                'FORMSTACK'                                                                              as ads_source,
                TIMESTAMPTZ 'epoch' +
                left(right(ads_source_file, 15), 10)::bigint * interval '1 second'                       as load_datetime_gmt,
                row_number() over (partition by id order by ads_source_file desc)                        as rank
         from ext_staging.stg_formstack_submissions
     )
where rank = 1
with no schema binding;

alter table avw_stg_formstack_submissions_latest
    owner to ads_staging;

