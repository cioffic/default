CREATE OR REPLACE VIEW ads_staging.avw_stg_wifi_client_sessions
AS
SELECT client_username,
       client_ip_address,
       client_mac_address,
       cast(split_part(association_time, ' ', 3) || '-' || split_part(association_time, ' ', 2) || '-' ||
            split_part(association_time, ' ', 6) as timestamp)                                                as association_start_date,
       association_time,
       cast(split_part(association_time, ' ', 3) || '-' || split_part(association_time, ' ', 2) || '-' ||
            split_part(association_time, ' ', 6) || ' ' ||
            split_part(association_time, ' ', 4) as timestamp)                                                as association_start_time,
       cast(split_part(association_time, ' ', 3) || '-' || split_part(association_time, ' ', 2) || '-' ||
            split_part(association_time, ' ', 6) || ' ' || split_part(association_time, ' ', 4) as timestamp) +
       cast(session_duration as interval)                                                                     as association_end_time,
       vendor,
       ap_name,
       radio_type,
       device_name,
       map_location,
       ssid,
       profile,
       vlan_id,
       protocol,
       session_duration,
       policy_type,
       avg_session_throughput_kbps,
       ads_staging.f_s3_parse_athena_filename("$path")                                                        AS ads_source_file


FROM ext_staging.stg_wifi_client_sessions
WITH NO SCHEMA BINDING;

alter table avw_stg_wifi_client_sessions
    owner to ads_staging;

