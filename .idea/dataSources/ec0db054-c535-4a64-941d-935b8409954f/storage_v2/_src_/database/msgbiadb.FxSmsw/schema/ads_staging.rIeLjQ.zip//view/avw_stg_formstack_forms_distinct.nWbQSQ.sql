create or replace view ads_staging.avw_stg_formstack_forms_distinct
as
select *
from (
         select id,
                created :: datetime,
                folder,
                updated :: datetime,
                name,
                last_submission_time :: datetime,
                url,
                inactive,
                ads_staging.f_s3_parse_athena_filename("$path")                   as ads_source_file,
                row_number() over (partition by id order by ads_source_file desc) as rank
         from ext_staging.stg_formstack_forms)
where rank = 1
with no schema binding;

alter table avw_stg_formstack_forms_distinct
    owner to ads_staging;

