create view v_get_view_priv_by_user(schemaname, viewname, usename, sel, ins, upd, del, ref) as
SELECT derived_table1.schemaname,
       derived_table1.viewname,
       derived_table1.usename,
       derived_table1.sel,
       derived_table1.ins,
       derived_table1.upd,
       derived_table1.del,
       derived_table1.ref
FROM (SELECT objs.schemaname,
             objs.viewname,
             usrs.usename,
             has_table_privilege(usrs.usename, objs.obj, 'select'::character varying::text)     AS sel,
             has_table_privilege(usrs.usename, objs.obj, 'insert'::character varying::text)     AS ins,
             has_table_privilege(usrs.usename, objs.obj, 'update'::character varying::text)     AS upd,
             has_table_privilege(usrs.usename, objs.obj, 'delete'::character varying::text)     AS del,
             has_table_privilege(usrs.usename, objs.obj, 'references'::character varying::text) AS ref
      FROM (SELECT pg_views.schemaname,
                   pg_views.viewname,
                   (quote_ident(pg_views.schemaname::character varying::text) || '.'::character varying::text) ||
                   quote_ident(pg_views.viewname::character varying::text) AS obj
            FROM pg_views) objs
               JOIN (SELECT pg_user.usename,
                            pg_user.usesysid,
                            pg_user.usecreatedb,
                            pg_user.usesuper,
                            pg_user.usecatupd,
                            pg_user.passwd,
                            pg_user.valuntil,
                            pg_user.useconfig
                     FROM pg_user) usrs ON 1 = 1
      ORDER BY objs.obj) derived_table1
WHERE derived_table1.sel = true
   OR derived_table1.ins = true
   OR derived_table1.upd = true
   OR derived_table1.del = true
   OR derived_table1.ref = true;

alter table v_get_view_priv_by_user
    owner to msgadmin;

