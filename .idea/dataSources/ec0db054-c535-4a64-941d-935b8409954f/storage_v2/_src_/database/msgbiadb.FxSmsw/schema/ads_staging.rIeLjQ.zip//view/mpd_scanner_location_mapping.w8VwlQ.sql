create view mpd_scanner_location_mapping
            (arena_gate_desc, network_ip, association_start_date, association_start_time, association_end_time, ap_name,
             scanner_location)
as
SELECT cte.arena_gate_desc,
       cte.network_ip,
       cte.association_start_date,
       min(cte.association_start_time) AS association_start_time,
       "max"(cte.association_end_time) AS association_end_time,
       cte.ap_name,
       cte.scanner_location
FROM (SELECT tmp_bulk_scanner_location_mapping.arena_gate_desc,
             tmp_bulk_scanner_location_mapping.network_ip,
             tmp_bulk_scanner_location_mapping.association_start_date,
             tmp_bulk_scanner_location_mapping.association_start_time,
             tmp_bulk_scanner_location_mapping.association_end_time,
             tmp_bulk_scanner_location_mapping.ap_name,
             tmp_bulk_scanner_location_mapping.scanner_location,
             CASE
                 WHEN tmp_bulk_scanner_location_mapping.ap_name::text =
                      (lead(tmp_bulk_scanner_location_mapping.ap_name::text)
                       OVER (
                           PARTITION BY tmp_bulk_scanner_location_mapping.network_ip, tmp_bulk_scanner_location_mapping.association_start_date
                           ORDER BY tmp_bulk_scanner_location_mapping.association_start_time DESC)) THEN 'Repeat'::text
                 ELSE 'New'::text
                 END AS lag_new_repeat_flag,
             CASE
                 WHEN tmp_bulk_scanner_location_mapping.ap_name::text =
                      (lead(tmp_bulk_scanner_location_mapping.ap_name::text)
                       OVER (
                           PARTITION BY tmp_bulk_scanner_location_mapping.network_ip, tmp_bulk_scanner_location_mapping.association_start_date
                           ORDER BY tmp_bulk_scanner_location_mapping.association_start_time)) THEN 'Repeat'::text
                 ELSE 'New'::text
                 END AS lead_new_repeat_flag
      FROM ads_staging.tmp_bulk_scanner_location_mapping) cte
WHERE cte.lag_new_repeat_flag = 'New'::text
   OR cte.lead_new_repeat_flag = 'New'::text
GROUP BY cte.arena_gate_desc, cte.network_ip, cte.association_start_date, cte.ap_name, cte.scanner_location
ORDER BY cte.network_ip, cte.association_start_date, min(cte.association_start_time);

alter table mpd_scanner_location_mapping
    owner to etluser;

