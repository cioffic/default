CREATE OR REPLACE VIEW ads_staging.vw_medallia_event_mapping AS
SELECT DISTINCT event_plan.tm_event_date                                AS report_run_date,
                event_plan.tm_arena_name,
                event_plan.tm_event_name,
                event_plan.tm_event_name_long,
                COALESCE(
                        CASE
                            WHEN event_plan.tm_primary_act::text = 'NA'::character varying::text
                                THEN NULL::character varying
                            ELSE event_plan.tm_primary_act
                            END,
                        CASE
                            WHEN event_plan.tm_primary_act::text = ''::character varying::text
                                THEN NULL::character varying
                            ELSE event_plan.tm_primary_act
                            END, event_plan.tm_event_name_long)         AS mdb_attraction_name,
                event_plan.event_business_unit,
                event_plan.inet_event_id                                AS event_inventory_id,
                CASE
                    WHEN event_plan.tm_arena_name::text = 'MSG ARENA'::character varying::text
                        OR event_plan.tm_arena_name::text = 'HULU THEATER AT MSG'::character varying::text
                        THEN 'MADISONSQGDN'::character varying
                    WHEN event_plan.tm_arena_name::text = 'RADIO CITY MUSIC HALL'::character varying::text
                        THEN 'RADIOCITY'::character varying
                    WHEN event_plan.tm_arena_name::text = 'BEACON THEATRE'::character varying::text
                        THEN 'NYCBEACON'::character varying
                    ELSE NULL::character varying
                    END::character varying(255)                         AS accessmanager_id,
                CASE
                    WHEN COALESCE(event_plan.tm_season_name, ' '::character varying)::text =
                         '2018 Radio City Tours'::character varying::text
                        OR COALESCE(event_plan.tm_season_name, ' '::character varying)::text =
                           '2018 MSG Tours'::character varying::text
                        OR COALESCE(event_plan.tm_season_name, ' '::character varying)::text =
                           '2018-2019 MSG TOURS'::character varying::text
                        THEN 'TOURS'::character varying
                    WHEN upper(event_plan.tm_org_name::text) = 'RANGERS'::character varying::text
                        OR upper(event_plan.tm_org_name::text) = 'KNICKS'::character varying::text
                        OR upper(event_plan.tm_org_name::text) = 'D LEAGUE'::character varying::text
                        OR upper(event_plan.tm_org_name::text) = 'LIBERTY'::character varying::text
                        THEN 'SPORTS'::character varying
                    ELSE 'LIVE'::character varying
                    END::character varying(30)                          AS live_vs_sports_event_flag,
                COALESCE(em.enable_flag, 'X'::character varying)        AS enable_flag,
                ((('select \''::character varying::text || event_plan.inet_event_id::text) ||
                  '\' AS event_inventory_id, \''::character varying::text) || em.enable_flag::text) ||
                '\' as enable_flag union all '::character varying::text AS command,
                event_plan.event_plan_id,
                event_plan.primary_event_plan_id,
                event_plan.report_event_flag,
                event_plan.tm_event_time,
                event_plan.tm_plan_event_id,
                CASE
                    WHEN COALESCE(em.medallia_event_name, ''::character varying)::text = ''::text
                        THEN nvl(he.event_name_long, event_plan.tm_event_name_long)
                    ELSE em.medallia_event_name
                    END                                                 AS medallia_event_name,
                he.event_name_long                                      as tm_host_event_name_long,
                tm_event_status
FROM ads_main.d_event_plan event_plan
         LEFT JOIN ads_staging.mpd_medallia_event_mapping em ON event_plan.inet_event_id::text = em.inet_event_id::text
         LEFT JOIN --ads_sandbox.avw_stg_tm_host_events_20191230 --ads_sandbox.avw_stg_tm_host_events_20191127 
    (
        select *
        from (
                 select RIGHT(event_url, 16)                                                             as inet_id,
                        event_name_long,
                        pulldatetime,
                        row_number() over (partition by RIGHT(event_url, 16) order by pulldatetime desc) as rn
                 from --ads_sandbox.avw_stg_tm_host_events_20191230 
                      --ads_sandbox.avw_stg_tm_host_events_20200129
                      --ads_sandbox.avw_stg_tm_host_events_20200227
                      ads_staging.avw_stg_tm_host_events_20210216
             )
        where rn = 1
    ) he ON event_plan.inet_event_id = inet_id
WHERE (event_plan.tm_arena_name::text = 'MSG ARENA'::character varying::text
    OR event_plan.tm_arena_name::text = 'HULU THEATER AT MSG'::character varying::text
    OR event_plan.tm_arena_name::text = 'RADIO CITY MUSIC HALL'::character varying::text
    OR event_plan.tm_arena_name::text = 'BEACON THEATRE'::character varying::text
    OR event_plan.tm_arena_name::text = 'THE CHICAGO THEATRE'::character varying::text
    OR event_plan.tm_arena_name::text = 'THE FORUM'::character varying::text
    )
  AND CASE
          WHEN event_plan.inet_event_id::text = ''::character varying::text THEN NULL::character varying
          ELSE event_plan.inet_event_id
    END IS NOT NULL
  AND CASE
          WHEN event_plan.tm_event_name_long::text = ''::character varying::text THEN NULL::character varying
          ELSE event_plan.tm_event_name_long
    END IS NOT NULL
  AND event_plan.tm_season_name::text <> 'TRS 2019 Radio City Tours'::character varying::text
  AND event_plan.tm_season_name::text <> 'TRS 2018-19 MSG TOURS'::character varying::text

WITH NO SCHEMA BINDING;

alter table vw_medallia_event_mapping
    owner to etluser;

