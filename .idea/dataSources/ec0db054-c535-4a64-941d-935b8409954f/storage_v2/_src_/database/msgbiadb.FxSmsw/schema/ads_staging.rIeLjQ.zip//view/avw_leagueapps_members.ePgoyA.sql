create or replace view ads_staging.avw_leagueapps_members
as
select c.ads_source,
       c.site_name,
       a.userid                                                                                      as member_user_id,
       a.username                                                                                    as member_user_name,
       a.site_id                                                                                     as member_site_id,
       a.firstname                                                                                   as member_first_name,
       a.lastname                                                                                    as member_lastname,
       a.email                                                                                       as member_email,
       a.address1                                                                                    as member_address1,
       a.city                                                                                        as member_city,
       a.state                                                                                       as member_state,
       a.mobilephone                                                                                 as member_mobile_phone,
       a.birthdate                                                                                   as member_birthdate_epoch,
       TIMESTAMPTZ 'epoch' + a.birthdate::bigint / 1000 * interval '1 second'                        as member_birthdate,
       a.gender                                                                                      as member_gender,
       a.datejoined                                                                                  as member_date_joined_epoch,
       TIMESTAMPTZ 'epoch' + a.datejoined::bigint / 1000 * interval '1 second'                       as member_date_joined,
       a.groupid                                                                                     as member_group_id,
       a.groupname                                                                                   as member_group_name,
       a.lastlogin                                                                                   as member_last_login_epoch,
       TIMESTAMPTZ 'epoch' + a.lastlogin::bigint / 1000 * interval '1 second'                        as member_last_login,
       a.lastupdated                                                                                 as member_last_updated_epoch,
       TIMESTAMPTZ 'epoch' + a.lastupdated::bigint / 1000 * interval '1 second'                      as member_last_updated,
       a.newsletteroptin                                                                             as member_news_letter_option,
       a.orgaccountrole                                                                              as member_org_account_role,
       a.type                                                                                        as member_type,
       a.zipcode                                                                                     as member_zip_code,
       a.src_file_name                                                                               as member_src_file_name,
       TIMESTAMPTZ 'epoch' + left(right(member_src_file_name, 14), 10)::bigint *
                             interval '1 second'                                                     as member_load_datetime_gmt
--b.amountpaid registration_amount_paid,
--b.birthdate registration_birth_date,
--b.created registration_created_epoch,
--TIMESTAMPTZ 'epoch' + b.created::bigint/1000 * interval '1 second'  as registration_created,
--b.firstname registration_first_name,
--b.gender registration_gender,
--b.groupid registration_group_id,
--b.groupname registration_group_name,
--b.invoiceid registration_invoice_id,
--b.lastname registration_last_name,
--b.lastupdated registration_last_updated_epoch,
--TIMESTAMPTZ 'epoch' + b.lastupdated::bigint/1000 * interval '1 second'  as registration_last_updated,
--b.outstandingbalance registration_outstanding_balance,
--b.parentemail registration_parent_email,
--b.parentfirstname registration_parent_first_name,
--b.parentlastname registration_parent_last_name,
--b.parentphone registration_parent_phone,
--b.parentuserid registration_parent_user_id,
--b.paymentstatus registration_payment_status,
--b.price registration_price,
--b.programid registration_program_id,
--b.programname registration_program_name,
--b.programstartdate registration_program_start_date_epoch,
--TIMESTAMPTZ 'epoch' + b.programstartdate::bigint/1000 * interval '1 second'  as registration_program_start_date,
--b.programstate registration_program_state,
--b.programtype registration_program_type,
--b.registrationid registration_id,
--b.registrationstatus registration_status,
--b.role registration_role,
--b.sitename registration_site_name,
--b.sport registration_sports,
--b.sportid registration_sports_id,
--b.team  registration_team,
--b.totalamountdue registration_total_amount_due,
--b.userid registration_user_id,
--b.usertype registration_user_type,
--b.waiveracceptedtimestamp registration_waiver_accepted_epoch,
--TIMESTAMPTZ 'epoch' + b.waiveracceptedtimestamp::bigint/1000 * interval '1 second'  as waiver_accepted_time,
--b.zipcode registration_zip_code,
--b.site_id registration_site_id,
--b.src_file_name registration_src_file_name

from league_apps.leagueapps_members as a
         inner join ext_staging.mpd_leagueapps_site c
                    on a.site_id = c.site_id
    --left join ext_staging.stg_leagueapps_registrations as b
--on a.userid = b.userid
--and a.site_id = b.site_id
with no schema binding;

alter table avw_leagueapps_members
    owner to ads_staging;

