create or replace view ads_staging.avw_stg_ig_configuration as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'IG' as ads_source
from ext_staging.stg_ig_configuration
with no schema binding;

alter table avw_stg_ig_configuration
    owner to ads_staging;

