create view v_check_diskspace_usage
            (dbase_name, schemaname, tablename, tbl_oid, megabytes, rowcount, unsorted_rowcount, pct_unsorted,
             recommendation) as
SELECT info.dbase_name,
       info.schemaname,
       info.tablename,
       info.tbl_oid,
       info.megabytes,
       info.rowcount,
       info.unsorted_rowcount,
       info.pct_unsorted,
       CASE
           WHEN info.rowcount = 0 THEN 'n/a'::text
           WHEN info.pct_unsorted >= 20::numeric(20, 2) THEN 'VACUUM SORT recommended'::text
           ELSE 'n/a'::text
           END AS recommendation
FROM (SELECT btrim(pgdb.datname::text) AS dbase_name,
             btrim(pgn.nspname::text)  AS schemaname,
             btrim(pgc.relname::text)  AS tablename,
             a.id                      AS tbl_oid,
             b.mbytes                  AS megabytes,
             CASE
                 WHEN pgc.reldiststyle = 8 THEN a.rows_all_dist
                 ELSE a."rows"
                 END                   AS rowcount,
             CASE
                 WHEN pgc.reldiststyle = 8 THEN a.unsorted_rows_all_dist
                 ELSE a.unsorted_rows
                 END                   AS unsorted_rowcount,
             CASE
                 WHEN pgc.reldiststyle = 8 THEN
                     CASE
                         WHEN det.n_sortkeys = 0 OR det.n_sortkeys IS NULL AND 0 IS NULL THEN NULL::numeric
                         ELSE
                             CASE
                                 WHEN a.rows_all_dist = 0 OR a.rows_all_dist IS NULL AND 0 IS NULL THEN 0::numeric
                                 ELSE a.unsorted_rows_all_dist::numeric::numeric(32, 0) / a.rows_all_dist::numeric * 100::numeric
                                 END
                         END::numeric(20, 2)
                 ELSE
                     CASE
                         WHEN det.n_sortkeys = 0 OR det.n_sortkeys IS NULL AND 0 IS NULL THEN NULL::numeric
                         ELSE
                             CASE
                                 WHEN a."rows" = 0 OR a."rows" IS NULL AND 0 IS NULL THEN 0::numeric
                                 ELSE a.unsorted_rows::numeric::numeric(32, 0) / a."rows"::numeric * 100::numeric
                                 END
                         END::numeric(20, 2)
                 END                   AS pct_unsorted
      FROM (SELECT stv_tbl_perm.db_id,
                   stv_tbl_perm.id,
                   stv_tbl_perm.name,
                   "max"(stv_tbl_perm."rows")                                   AS rows_all_dist,
                   "max"(stv_tbl_perm."rows") - "max"(stv_tbl_perm.sorted_rows) AS unsorted_rows_all_dist,
                   sum(stv_tbl_perm."rows")                                     AS "rows",
                   sum(stv_tbl_perm."rows") - sum(stv_tbl_perm.sorted_rows)     AS unsorted_rows
            FROM stv_tbl_perm
            GROUP BY stv_tbl_perm.db_id, stv_tbl_perm.id, stv_tbl_perm.name) a
               JOIN pg_class pgc ON pgc.oid = a.id::oid
               JOIN pg_namespace pgn ON pgn.oid = pgc.relnamespace
               JOIN pg_database pgdb ON pgdb.oid = a.db_id::oid
               JOIN (SELECT pg_attribute.attrelid,
                            min(
                                    CASE
                                        WHEN pg_attribute.attisdistkey = true THEN pg_attribute.attname
                                        ELSE NULL::name
                                        END::text)                                                AS "distkey",
                            min(
                                    CASE
                                        WHEN pg_attribute.attsortkeyord = 1 THEN pg_attribute.attname
                                        ELSE NULL::name
                                        END::text)                                                AS head_sort,
                            "max"(pg_attribute.attsortkeyord)                                     AS n_sortkeys,
                            "max"(pg_attribute.attencodingtype)                                   AS max_enc,
                            sum(
                                    CASE
                                        WHEN pg_attribute.attencodingtype <> 0 THEN 1
                                        ELSE 0
                                        END)::numeric::numeric(20, 3) /
                            count(pg_attribute.attencodingtype)::numeric::numeric(20, 3) * 100.00 AS pct_enc
                     FROM pg_attribute
                     GROUP BY pg_attribute.attrelid) det ON det.attrelid = a.id::oid
               LEFT JOIN (SELECT stv_blocklist.tbl, count(*) AS mbytes
                          FROM stv_blocklist
                          GROUP BY stv_blocklist.tbl) b ON a.id = b.tbl
      WHERE pgc.relowner > 1) info;

alter table v_check_diskspace_usage
    owner to msgadmin;

