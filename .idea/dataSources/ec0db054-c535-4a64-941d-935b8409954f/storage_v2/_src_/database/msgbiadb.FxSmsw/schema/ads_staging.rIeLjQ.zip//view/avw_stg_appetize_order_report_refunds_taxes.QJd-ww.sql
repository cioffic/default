CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_refunds_taxes AS
SELECT a.order_id,
       refunds.product_id,
       refunds.order_items_id,
       payments.payment_index,
       payments.taxes.inclusive_tax_amount,
       payments.taxes.exclusive_tax_amount

FROM appetize.api_orders_report a
         LEFT JOIN a.refunds refunds
                   ON TRUE
         LEFT JOIN refunds.payments payments
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_refunds_taxes
    owner to ads_staging;

