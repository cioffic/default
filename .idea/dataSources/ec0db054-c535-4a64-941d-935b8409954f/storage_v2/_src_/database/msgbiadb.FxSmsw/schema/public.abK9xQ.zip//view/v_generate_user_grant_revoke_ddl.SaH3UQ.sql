create view v_generate_user_grant_revoke_ddl
            (objowner, schemaname, objname, objtype, grantor, grantee, ddltype, grantseq, objseq, ddl) as
(SELECT objprivs.objowner,
        objprivs.schemaname,
        objprivs.objname,
        objprivs.objtype,
        objprivs.grantor,
        objprivs.grantee,
        'grant'::character varying                                  AS ddltype,
        objprivs.grantseq,
        CASE
            WHEN objprivs.objtype::text = 'database'::character varying::text OR
                 objprivs.objtype IS NULL AND 'database' IS NULL THEN 0
            WHEN objprivs.objtype::text = 'schema'::character varying::text OR
                 objprivs.objtype IS NULL AND 'schema' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'language'::character varying::text OR
                 objprivs.objtype IS NULL AND 'language' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'table'::character varying::text OR
                 objprivs.objtype IS NULL AND 'table' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'view'::character varying::text OR objprivs.objtype IS NULL AND 'view' IS NULL
                THEN 2
            WHEN objprivs.objtype::text = 'function'::character varying::text OR
                 objprivs.objtype IS NULL AND 'function' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'procedure'::character varying::text OR
                 objprivs.objtype IS NULL AND 'procedure' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'default acl'::character varying::text OR
                 objprivs.objtype IS NULL AND 'default acl' IS NULL THEN 3
            ELSE NULL::integer
            END                                                     AS objseq,
        ((
                 CASE
                     WHEN objprivs.grantor::bpchar <> "current_user"() AND
                          objprivs.grantor::text <> 'rdsdb'::character varying::text AND
                          objprivs.objtype::text <> 'default acl'::character varying::text THEN (
                             ('SET SESSION AUTHORIZATION '::character varying::text ||
                              quote_ident(objprivs.grantor::text)) || ';'::character varying::text)::character varying
                     ELSE ''::character varying
                     END::character varying(4000)::text ||
                 CASE
                     WHEN objprivs.privilege::text = 'arwdRxt'::character varying::text OR
                          objprivs.privilege::text = 'a*r*w*d*R*x*t*'::character varying::text THEN ((((
                                                                                                               CASE
                                                                                                                   WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                       THEN (
                                                                                                                           ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                            quote_ident(objprivs.grantor::text)) ||
                                                                                                                           COALESCE(
                                                                                                                                       (' in schema '::character varying::text ||
                                                                                                                                        quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                       ' '::character varying::text,
                                                                                                                                       ' '::character varying::text))::character varying
                                                                                                                   ELSE ''::character varying
                                                                                                                   END::character varying(4000)::text ||
                                                                                                               'GRANT ALL on '::character varying::text) ||
                                                                                                       objprivs.fullobjname::text) ||
                                                                                                      ' to '::character varying::text) ||
                                                                                                     objprivs.splitgrantee::text) ||
                                                                                                    CASE
                                                                                                        WHEN objprivs.privilege::text = 'a*r*w*d*R*x*t*'::character varying::text
                                                                                                            THEN ' with grant option;'::character varying
                                                                                                        ELSE ';'::character varying
                                                                                                        END::character varying(4000)::text
                     WHEN objprivs.privilege::text = 'UC'::character varying::text OR
                          objprivs.privilege::text = 'U*C*'::character varying::text THEN ((((((
                                                                                                       CASE
                                                                                                           WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                               THEN (
                                                                                                                   ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                    quote_ident(objprivs.grantor::text)) ||
                                                                                                                   COALESCE(
                                                                                                                               (' in schema '::character varying::text ||
                                                                                                                                quote_ident(objprivs.schemaname::text)) ||
                                                                                                                               ' '::character varying::text,
                                                                                                                               ' '::character varying::text))::character varying
                                                                                                           ELSE ''::character varying
                                                                                                           END::character varying(4000)::text ||
                                                                                                       'GRANT ALL on '::character varying::text) ||
                                                                                               objprivs.objtype::text) ||
                                                                                              ' '::character varying::text) ||
                                                                                             objprivs.fullobjname::text) ||
                                                                                            ' to '::character varying::text) ||
                                                                                           objprivs.splitgrantee::text) ||
                                                                                          CASE
                                                                                              WHEN objprivs.privilege::text = 'U*C*'::character varying::text
                                                                                                  THEN ' with grant option;'::character varying
                                                                                              ELSE ';'::character varying
                                                                                              END::character varying(4000)::text
                     WHEN objprivs.privilege::text = 'CT'::character varying::text OR
                          objprivs.privilege::text = 'U*C*'::character varying::text THEN ((((((
                                                                                                       CASE
                                                                                                           WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                               THEN (
                                                                                                                   ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                    quote_ident(objprivs.grantor::text)) ||
                                                                                                                   COALESCE(
                                                                                                                               (' in schema '::character varying::text ||
                                                                                                                                quote_ident(objprivs.schemaname::text)) ||
                                                                                                                               ' '::character varying::text,
                                                                                                                               ' '::character varying::text))::character varying
                                                                                                           ELSE ''::character varying
                                                                                                           END::character varying(4000)::text ||
                                                                                                       'GRANT ALL on '::character varying::text) ||
                                                                                               objprivs.objtype::text) ||
                                                                                              ' '::character varying::text) ||
                                                                                             objprivs.fullobjname::text) ||
                                                                                            ' to '::character varying::text) ||
                                                                                           objprivs.splitgrantee::text) ||
                                                                                          CASE
                                                                                              WHEN objprivs.privilege::text = 'C*T*'::character varying::text
                                                                                                  THEN ' with grant option;'::character varying
                                                                                              ELSE ';'::character varying
                                                                                              END::character varying(4000)::text
                     ELSE (((((((((
                                          CASE
                                              WHEN charindex('a'::character varying::text, objprivs.privilege::text) > 0
                                                  THEN (((((
                                                                   CASE
                                                                       WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                           THEN (
                                                                               ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                quote_ident(objprivs.grantor::text)) ||
                                                                               COALESCE(
                                                                                           (' in schema '::character varying::text ||
                                                                                            quote_ident(objprivs.schemaname::text)) ||
                                                                                           ' '::character varying::text,
                                                                                           ' '::character varying::text))::character varying
                                                                       ELSE ''::character varying
                                                                       END::character varying(4000)::text ||
                                                                   'GRANT INSERT on '::character varying::text) ||
                                                           objprivs.fullobjname::text) ||
                                                          ' to '::character varying::text) ||
                                                         objprivs.splitgrantee::text) ||
                                                        CASE
                                                            WHEN charindex('a*'::character varying::text, objprivs.privilege::text) >
                                                                 0 THEN ' with grant option;'::character varying
                                                            ELSE ';'::character varying
                                                            END::character varying(4000)::text)::character varying
                                              ELSE ''::character varying
                                              END::character varying(4000)::text ||
                                          CASE
                                              WHEN charindex('r'::character varying::text, objprivs.privilege::text) > 0
                                                  THEN (((((
                                                                   CASE
                                                                       WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                           THEN (
                                                                               ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                quote_ident(objprivs.grantor::text)) ||
                                                                               COALESCE(
                                                                                           (' in schema '::character varying::text ||
                                                                                            quote_ident(objprivs.schemaname::text)) ||
                                                                                           ' '::character varying::text,
                                                                                           ' '::character varying::text))::character varying
                                                                       ELSE ''::character varying
                                                                       END::character varying(4000)::text ||
                                                                   'GRANT SELECT on '::character varying::text) ||
                                                           objprivs.fullobjname::text) ||
                                                          ' to '::character varying::text) ||
                                                         objprivs.splitgrantee::text) ||
                                                        CASE
                                                            WHEN charindex('r*'::character varying::text, objprivs.privilege::text) >
                                                                 0 THEN ' with grant option;'::character varying
                                                            ELSE ';'::character varying
                                                            END::character varying(4000)::text)::character varying
                                              ELSE ''::character varying
                                              END::character varying(4000)::text) ||
                                  CASE
                                      WHEN charindex('w'::character varying::text, objprivs.privilege::text) > 0 THEN (
                                              ((((
                                                         CASE
                                                             WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                 THEN (
                                                                     ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                      quote_ident(objprivs.grantor::text)) || COALESCE(
                                                                                 (' in schema '::character varying::text ||
                                                                                  quote_ident(objprivs.schemaname::text)) ||
                                                                                 ' '::character varying::text,
                                                                                 ' '::character varying::text))::character varying
                                                             ELSE ''::character varying
                                                             END::character varying(4000)::text ||
                                                         'GRANT UPDATE on '::character varying::text) ||
                                                 objprivs.fullobjname::text) || ' to '::character varying::text) ||
                                               objprivs.splitgrantee::text) ||
                                              CASE
                                                  WHEN charindex('w*'::character varying::text, objprivs.privilege::text) >
                                                       0 THEN ' with grant option;'::character varying
                                                  ELSE ';'::character varying
                                                  END::character varying(4000)::text)::character varying
                                      ELSE ''::character varying
                                      END::character varying(4000)::text) ||
                                 CASE
                                     WHEN charindex('d'::character varying::text, objprivs.privilege::text) > 0 THEN (
                                             ((((
                                                        CASE
                                                            WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                THEN (
                                                                    ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                     quote_ident(objprivs.grantor::text)) || COALESCE(
                                                                                (' in schema '::character varying::text ||
                                                                                 quote_ident(objprivs.schemaname::text)) ||
                                                                                ' '::character varying::text,
                                                                                ' '::character varying::text))::character varying
                                                            ELSE ''::character varying
                                                            END::character varying(4000)::text ||
                                                        'GRANT DELETE on '::character varying::text) ||
                                                objprivs.fullobjname::text) || ' to '::character varying::text) ||
                                              objprivs.splitgrantee::text) ||
                                             CASE
                                                 WHEN charindex('d*'::character varying::text, objprivs.privilege::text) >
                                                      0 THEN ' with grant option;'::character varying
                                                 ELSE ';'::character varying
                                                 END::character varying(4000)::text)::character varying
                                     ELSE ''::character varying
                                     END::character varying(4000)::text) ||
                                CASE
                                    WHEN charindex('R'::character varying::text, objprivs.privilege::text) > 0 THEN (
                                            ((((
                                                       CASE
                                                           WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                               THEN (
                                                                   ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                    quote_ident(objprivs.grantor::text)) || COALESCE(
                                                                               (' in schema '::character varying::text ||
                                                                                quote_ident(objprivs.schemaname::text)) ||
                                                                               ' '::character varying::text,
                                                                               ' '::character varying::text))::character varying
                                                           ELSE ''::character varying
                                                           END::character varying(4000)::text ||
                                                       'GRANT RULE on '::character varying::text) ||
                                               objprivs.fullobjname::text) || ' to '::character varying::text) ||
                                             objprivs.splitgrantee::text) ||
                                            CASE
                                                WHEN charindex('R*'::character varying::text, objprivs.privilege::text) >
                                                     0 THEN ' with grant option;'::character varying
                                                ELSE ';'::character varying
                                                END::character varying(4000)::text)::character varying
                                    ELSE ''::character varying
                                    END::character varying(4000)::text) ||
                               CASE
                                   WHEN charindex('x'::character varying::text, objprivs.privilege::text) > 0 THEN (((((
                                                                                                                               CASE
                                                                                                                                   WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                       THEN (
                                                                                                                                           ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                            quote_ident(objprivs.grantor::text)) ||
                                                                                                                                           COALESCE(
                                                                                                                                                       (' in schema '::character varying::text ||
                                                                                                                                                        quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                       ' '::character varying::text,
                                                                                                                                                       ' '::character varying::text))::character varying
                                                                                                                                   ELSE ''::character varying
                                                                                                                                   END::character varying(4000)::text ||
                                                                                                                               'GRANT REFERENCES on '::character varying::text) ||
                                                                                                                       objprivs.fullobjname::text) ||
                                                                                                                      ' to '::character varying::text) ||
                                                                                                                     objprivs.splitgrantee::text) ||
                                                                                                                    CASE
                                                                                                                        WHEN charindex('x*'::character varying::text, objprivs.privilege::text) >
                                                                                                                             0
                                                                                                                            THEN ' with grant option;'::character varying
                                                                                                                        ELSE ';'::character varying
                                                                                                                        END::character varying(4000)::text)::character varying
                                   ELSE ''::character varying
                                   END::character varying(4000)::text) ||
                              CASE
                                  WHEN charindex('t'::character varying::text, objprivs.privilege::text) > 0 THEN (((((
                                                                                                                              CASE
                                                                                                                                  WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                      THEN (
                                                                                                                                          ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                           quote_ident(objprivs.grantor::text)) ||
                                                                                                                                          COALESCE(
                                                                                                                                                      (' in schema '::character varying::text ||
                                                                                                                                                       quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                      ' '::character varying::text,
                                                                                                                                                      ' '::character varying::text))::character varying
                                                                                                                                  ELSE ''::character varying
                                                                                                                                  END::character varying(4000)::text ||
                                                                                                                              'GRANT TRIGGER on '::character varying::text) ||
                                                                                                                      objprivs.fullobjname::text) ||
                                                                                                                     ' to '::character varying::text) ||
                                                                                                                    objprivs.splitgrantee::text) ||
                                                                                                                   CASE
                                                                                                                       WHEN charindex('t*'::character varying::text, objprivs.privilege::text) >
                                                                                                                            0
                                                                                                                           THEN ' with grant option;'::character varying
                                                                                                                       ELSE ';'::character varying
                                                                                                                       END::character varying(4000)::text)::character varying
                                  ELSE ''::character varying
                                  END::character varying(4000)::text) ||
                             CASE
                                 WHEN charindex('U'::character varying::text, objprivs.privilege::text) > 0 THEN (((((((
                                                                                                                               CASE
                                                                                                                                   WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                       THEN (
                                                                                                                                           ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                            quote_ident(objprivs.grantor::text)) ||
                                                                                                                                           COALESCE(
                                                                                                                                                       (' in schema '::character varying::text ||
                                                                                                                                                        quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                       ' '::character varying::text,
                                                                                                                                                       ' '::character varying::text))::character varying
                                                                                                                                   ELSE ''::character varying
                                                                                                                                   END::character varying(4000)::text ||
                                                                                                                               'GRANT USAGE on '::character varying::text) ||
                                                                                                                       objprivs.objtype::text) ||
                                                                                                                      ' '::character varying::text) ||
                                                                                                                     objprivs.fullobjname::text) ||
                                                                                                                    ' to '::character varying::text) ||
                                                                                                                   objprivs.splitgrantee::text) ||
                                                                                                                  CASE
                                                                                                                      WHEN charindex('U*'::character varying::text, objprivs.privilege::text) >
                                                                                                                           0
                                                                                                                          THEN ' with grant option;'::character varying
                                                                                                                      ELSE ';'::character varying
                                                                                                                      END::character varying(4000)::text)::character varying
                                 ELSE ''::character varying
                                 END::character varying(4000)::text) ||
                            CASE
                                WHEN charindex('C'::character varying::text, objprivs.privilege::text) > 0 THEN (((((((
                                                                                                                              CASE
                                                                                                                                  WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                      THEN (
                                                                                                                                          ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                           quote_ident(objprivs.grantor::text)) ||
                                                                                                                                          COALESCE(
                                                                                                                                                      (' in schema '::character varying::text ||
                                                                                                                                                       quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                      ' '::character varying::text,
                                                                                                                                                      ' '::character varying::text))::character varying
                                                                                                                                  ELSE ''::character varying
                                                                                                                                  END::character varying(4000)::text ||
                                                                                                                              'GRANT CREATE on '::character varying::text) ||
                                                                                                                      objprivs.objtype::text) ||
                                                                                                                     ' '::character varying::text) ||
                                                                                                                    objprivs.fullobjname::text) ||
                                                                                                                   ' to '::character varying::text) ||
                                                                                                                  objprivs.splitgrantee::text) ||
                                                                                                                 CASE
                                                                                                                     WHEN charindex('C*'::character varying::text, objprivs.privilege::text) >
                                                                                                                          0
                                                                                                                         THEN ' with grant option;'::character varying
                                                                                                                     ELSE ';'::character varying
                                                                                                                     END::character varying(4000)::text)::character varying
                                ELSE ''::character varying
                                END::character varying(4000)::text) ||
                           CASE
                               WHEN charindex('T'::character varying::text, objprivs.privilege::text) > 0 THEN (((((((
                                                                                                                             CASE
                                                                                                                                 WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                     THEN (
                                                                                                                                         ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                          quote_ident(objprivs.grantor::text)) ||
                                                                                                                                         COALESCE(
                                                                                                                                                     (' in schema '::character varying::text ||
                                                                                                                                                      quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                     ' '::character varying::text,
                                                                                                                                                     ' '::character varying::text))::character varying
                                                                                                                                 ELSE ''::character varying
                                                                                                                                 END::character varying(4000)::text ||
                                                                                                                             'GRANT TEMP on '::character varying::text) ||
                                                                                                                     objprivs.objtype::text) ||
                                                                                                                    ' '::character varying::text) ||
                                                                                                                   objprivs.fullobjname::text) ||
                                                                                                                  ' to '::character varying::text) ||
                                                                                                                 objprivs.splitgrantee::text) ||
                                                                                                                CASE
                                                                                                                    WHEN charindex('T*'::character varying::text, objprivs.privilege::text) >
                                                                                                                         0
                                                                                                                        THEN ' with grant option;'::character varying
                                                                                                                    ELSE ';'::character varying
                                                                                                                    END::character varying(4000)::text)::character varying
                               ELSE ''::character varying
                               END::character varying(4000)::text) ||
                          CASE
                              WHEN charindex('X'::character varying::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                                           CASE
                                                                                                                               WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                                   THEN (
                                                                                                                                       ('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                                                                                                                        quote_ident(objprivs.grantor::text)) ||
                                                                                                                                       COALESCE(
                                                                                                                                                   (' in schema '::character varying::text ||
                                                                                                                                                    quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                   ' '::character varying::text,
                                                                                                                                                   ' '::character varying::text))::character varying
                                                                                                                               ELSE ''::character varying
                                                                                                                               END::character varying(4000)::text ||
                                                                                                                           'GRANT EXECUTE on '::character varying::text) ||
                                                                                                                   CASE
                                                                                                                       WHEN objprivs.objtype::text = 'default acl'::character varying::text
                                                                                                                           THEN ''::character varying::text
                                                                                                                       ELSE objprivs.objtype::text || ' '::character varying::text
                                                                                                                       END::character varying(4000)::text) ||
                                                                                                                  objprivs.fullobjname::text) ||
                                                                                                                 ' to '::character varying::text) ||
                                                                                                                objprivs.splitgrantee::text) ||
                                                                                                               CASE
                                                                                                                   WHEN charindex('X*'::character varying::text, objprivs.privilege::text) >
                                                                                                                        0
                                                                                                                       THEN ' with grant option;'::character varying
                                                                                                                   ELSE ';'::character varying
                                                                                                                   END::character varying(4000)::text)::character varying
                              ELSE ''::character varying
                              END::character varying(4000)::text
                     END::character varying(4000)::text) ||
         CASE
             WHEN objprivs.grantor::bpchar <> "current_user"() AND
                  objprivs.grantor::text <> 'rdsdb'::character varying::text AND
                  objprivs.objtype::text <> 'default acl'::character varying::text
                 THEN 'RESET SESSION AUTHORIZATION;'::character varying
             ELSE ''::character varying
             END::character varying(4000)::text)::character varying AS ddl
 FROM (SELECT derived_table1.objowner,
              derived_table1.schemaname,
              derived_table1.objname,
              derived_table1.objtype,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                       ''::character varying::text THEN 'PUBLIC'::character varying::text
                  ELSE translate(btrim(split_part(derived_table1.aclstring::text, '='::character varying::text, 1)),
                                 '"'::character varying::text, ''::character varying::text)
                  END::character varying                                                              AS grantee,
              translate(btrim(split_part(derived_table1.aclstring::text, '/'::character varying::text, 2)),
                        '"'::character varying::text, ''::character varying::text)::character varying AS grantor,
              btrim(split_part(split_part(derived_table1.aclstring::text, '='::character varying::text, 2),
                               '/'::character varying::text, 1))::character varying                   AS privilege,
              CASE
                  WHEN derived_table1.objtype::text = 'default acl'::character varying::text THEN derived_table1.objname::text
                  WHEN (derived_table1.objtype::text = 'procedure'::character varying::text OR
                        derived_table1.objtype::text = 'function'::character varying::text) AND
                       regexp_instr(derived_table1.schemaname::text, '[^a-z]'::character varying::text) > 0
                      THEN derived_table1.objname::text
                  WHEN derived_table1.objtype::text = 'procedure'::character varying::text OR
                       derived_table1.objtype::text = 'function'::character varying::text THEN
                          (quote_ident(derived_table1.schemaname::text) || '.'::character varying::text) ||
                          derived_table1.objname::text
                  ELSE COALESCE((quote_ident(derived_table1.schemaname::text) || '.'::character varying::text) ||
                                quote_ident(derived_table1.objname::text), quote_ident(derived_table1.objname::text))
                  END::character varying                                                              AS fullobjname,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                       ''::character varying::text THEN 'PUBLIC'::character varying::text
                  ELSE btrim(split_part(derived_table1.aclstring::text, '='::character varying::text, 1))
                  END::character varying                                                              AS splitgrantee,
              derived_table1.grantseq
       FROM (((((SELECT pg_get_userbyid(b.relowner)::character varying                           AS objowner,
                        btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                        b.relname::character varying                                             AS objname,
                        CASE
                            WHEN b.relkind = 'r'::"char" THEN 'table'::character varying
                            ELSE 'view'::character varying
                            END                                                                  AS objtype,
                        btrim(split_part(array_to_string(b.relacl, ','::character varying::text),
                                         ','::character varying::text, ns.n))::character varying AS aclstring,
                        ns.n                                                                     AS grantseq
                 FROM (SELECT pg_class.oid, generate_series(1, array_upper(pg_class.relacl, 1)) AS n
                       FROM pg_class) ns
                          JOIN pg_class b ON b.oid = ns.oid AND ns.n <= array_upper(b.relacl, 1)
                          JOIN pg_namespace c ON b.relnamespace = c.oid
                 WHERE b.relkind = 'r'::"char"
                    OR b.relkind = 'v'::"char"
                 UNION ALL
                 SELECT pg_get_userbyid(b.nspowner)::character varying                           AS objowner,
                        NULL::character varying                                                  AS schemaname,
                        b.nspname::character varying                                             AS objname,
                        'schema'::character varying                                              AS objtype,
                        btrim(split_part(array_to_string(b.nspacl, ','::character varying::text),
                                         ','::character varying::text, ns.n))::character varying AS aclstring,
                        ns.n                                                                     AS grantseq
                 FROM (SELECT pg_namespace.oid, generate_series(1, array_upper(pg_namespace.nspacl, 1)) AS n
                       FROM pg_namespace) ns
                          JOIN pg_namespace b ON b.oid = ns.oid AND ns.n <= array_upper(b.nspacl, 1))
                UNION ALL
                SELECT pg_get_userbyid(b.datdba)::character varying                             AS objowner,
                       NULL::character varying                                                  AS schemaname,
                       b.datname::character varying                                             AS objname,
                       'database'::character varying                                            AS objtype,
                       btrim(split_part(array_to_string(b.datacl, ','::character varying::text),
                                        ','::character varying::text, ns.n))::character varying AS aclstring,
                       ns.n                                                                     AS grantseq
                FROM (SELECT pg_database.oid, generate_series(1, array_upper(pg_database.datacl, 1)) AS n
                      FROM pg_database) ns
                         JOIN pg_database b ON b.oid = ns.oid AND ns.n <= array_upper(b.datacl, 1))
               UNION ALL
               SELECT pg_get_userbyid(b.proowner)::character varying                           AS objowner,
                      btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                      textin(regprocedureout(b.oid::regprocedure))::character varying          AS objname,
                      CASE
                          WHEN b.prorettype = 0::oid OR b.prorettype IS NULL AND 0 IS NULL
                              THEN 'procedure'::character varying
                          ELSE 'function'::character varying
                          END                                                                  AS objtype,
                      btrim(split_part(array_to_string(b.proacl, ','::character varying::text),
                                       ','::character varying::text, ns.n))::character varying AS aclstring,
                      ns.n                                                                     AS grantseq
               FROM (SELECT pg_proc.oid, generate_series(1, array_upper(pg_proc.proacl, 1)) AS n
                     FROM pg_proc) ns
                        JOIN pg_proc b ON b.oid = ns.oid AND ns.n <= array_upper(b.proacl, 1)
                        JOIN pg_namespace c ON b.pronamespace = c.oid)
              UNION ALL
              SELECT NULL::character varying                                                  AS objowner,
                     NULL::character varying                                                  AS schemaname,
                     b.lanname::character varying                                             AS objname,
                     'language'::character varying                                            AS objtype,
                     btrim(split_part(array_to_string(b.lanacl, ','::character varying::text),
                                      ','::character varying::text, ns.n))::character varying AS aclstring,
                     ns.n                                                                     AS grantseq
              FROM (SELECT pg_language.oid, generate_series(1, array_upper(pg_language.lanacl, 1)) AS n
                    FROM pg_language) ns
                       JOIN pg_language b ON b.oid = ns.oid AND ns.n <= array_upper(b.lanacl, 1))
             UNION ALL
             SELECT pg_get_userbyid(b.defacluser)::character varying                         AS objowner,
                    btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                    CASE
                        WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL
                            THEN 'tables'::character varying
                        WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL
                            THEN 'functions'::character varying
                        WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL
                            THEN 'procedures'::character varying
                        ELSE NULL::character varying
                        END                                                                  AS objname,
                    'default acl'::character varying                                         AS objtype,
                    btrim(split_part(array_to_string(b.defaclacl, ','::character varying::text),
                                     ','::character varying::text, ns.n))::character varying AS aclstring,
                    ns.n                                                                     AS grantseq
             FROM (SELECT pg_default_acl.oid, generate_series(1, array_upper(pg_default_acl.defaclacl, 1)) AS n
                   FROM pg_default_acl) ns
                      JOIN pg_default_acl b ON b.oid = ns.oid AND ns.n <= array_upper(b.defaclacl, 1)
                      LEFT JOIN pg_namespace c ON b.defaclnamespace = c.oid) derived_table1
       WHERE split_part(derived_table1.aclstring::text, '='::character varying::text, 1) <>
             split_part(derived_table1.aclstring::text, '/'::character varying::text, 2)
         AND split_part(derived_table1.aclstring::text, '='::character varying::text, 1) <> 'rdsdb'::character varying::text
         AND NOT (split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                  ''::character varying::text AND
                  split_part(derived_table1.aclstring::text, '/'::character varying::text, 2) =
                  'rdsdb'::character varying::text)) objprivs
 UNION ALL
 SELECT objprivs.objowner,
        objprivs.schemaname,
        objprivs.objname,
        objprivs.objtype,
        objprivs.grantor,
        objprivs.grantee,
        'revoke'::character varying                                 AS ddltype,
        objprivs.grantseq,
        CASE
            WHEN objprivs.objtype::text = 'default acl'::character varying::text OR
                 objprivs.objtype IS NULL AND 'default acl' IS NULL THEN 0
            WHEN objprivs.objtype::text = 'function'::character varying::text OR
                 objprivs.objtype IS NULL AND 'function' IS NULL THEN 0
            WHEN objprivs.objtype::text = 'procedure'::character varying::text OR
                 objprivs.objtype IS NULL AND 'procedure' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'table'::character varying::text OR
                 objprivs.objtype IS NULL AND 'table' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'view'::character varying::text OR objprivs.objtype IS NULL AND 'view' IS NULL
                THEN 1
            WHEN objprivs.objtype::text = 'schema'::character varying::text OR
                 objprivs.objtype IS NULL AND 'schema' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'language'::character varying::text OR
                 objprivs.objtype IS NULL AND 'language' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'database'::character varying::text OR
                 objprivs.objtype IS NULL AND 'database' IS NULL THEN 3
            ELSE NULL::integer
            END                                                     AS objseq,
        ((
                 CASE
                     WHEN objprivs.grantor::bpchar <> "current_user"() AND
                          objprivs.grantor::text <> 'rdsdb'::character varying::text AND
                          objprivs.objtype::text <> 'default acl'::character varying::text AND
                          objprivs.grantor::text <> objprivs.objowner::text THEN (
                             ('SET SESSION AUTHORIZATION '::character varying::text ||
                              quote_ident(objprivs.grantor::text)) || ';'::character varying::text)::character varying
                     ELSE ''::character varying
                     END::character varying(4000)::text ||
                 CASE
                     WHEN objprivs.objtype::text = 'default acl'::character varying::text THEN
                             (((((('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
                                   quote_ident(objprivs.grantor::text)) || COALESCE(
                                              (' in schema '::character varying::text ||
                                               quote_ident(objprivs.schemaname::text)) || ' '::character varying::text,
                                              ' '::character varying::text)) ||
                                 'REVOKE ALL on '::character varying::text) || objprivs.fullobjname::text) ||
                               ' FROM '::character varying::text) || objprivs.splitgrantee::text) ||
                             ';'::character varying::text
                     ELSE (((('REVOKE ALL on '::character varying::text ||
                              CASE
                                  WHEN objprivs.objtype::text = 'table'::character varying::text OR
                                       objprivs.objtype::text = 'view'::character varying::text
                                      THEN ''::character varying::text
                                  ELSE objprivs.objtype::text || ' '::character varying::text
                                  END::character varying(4000)::text) || objprivs.fullobjname::text) ||
                            ' FROM '::character varying::text) || objprivs.splitgrantee::text) || ';'::character varying::text
                     END::character varying(4000)::text) ||
         CASE
             WHEN objprivs.grantor::bpchar <> "current_user"() AND
                  objprivs.grantor::text <> 'rdsdb'::character varying::text AND
                  objprivs.objtype::text <> 'default acl'::character varying::text AND
                  objprivs.grantor::text <> objprivs.objowner::text
                 THEN 'RESET SESSION AUTHORIZATION;'::character varying
             ELSE ''::character varying
             END::character varying(4000)::text)::character varying AS ddl
 FROM (SELECT derived_table1.objowner,
              derived_table1.schemaname,
              derived_table1.objname,
              derived_table1.objtype,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                       ''::character varying::text THEN 'PUBLIC'::character varying::text
                  ELSE translate(btrim(split_part(derived_table1.aclstring::text, '='::character varying::text, 1)),
                                 '"'::character varying::text, ''::character varying::text)
                  END::character varying                                                              AS grantee,
              translate(btrim(split_part(derived_table1.aclstring::text, '/'::character varying::text, 2)),
                        '"'::character varying::text, ''::character varying::text)::character varying AS grantor,
              btrim(split_part(split_part(derived_table1.aclstring::text, '='::character varying::text, 2),
                               '/'::character varying::text, 1))::character varying                   AS privilege,
              CASE
                  WHEN derived_table1.objtype::text = 'default acl'::character varying::text THEN derived_table1.objname::text
                  WHEN (derived_table1.objtype::text = 'procedure'::character varying::text OR
                        derived_table1.objtype::text = 'function'::character varying::text) AND
                       regexp_instr(derived_table1.schemaname::text, '[^a-z]'::character varying::text) > 0
                      THEN derived_table1.objname::text
                  WHEN derived_table1.objtype::text = 'procedure'::character varying::text OR
                       derived_table1.objtype::text = 'function'::character varying::text THEN
                          (quote_ident(derived_table1.schemaname::text) || '.'::character varying::text) ||
                          derived_table1.objname::text
                  ELSE COALESCE((quote_ident(derived_table1.schemaname::text) || '.'::character varying::text) ||
                                quote_ident(derived_table1.objname::text), quote_ident(derived_table1.objname::text))
                  END::character varying                                                              AS fullobjname,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                       ''::character varying::text THEN 'PUBLIC'::character varying::text
                  ELSE btrim(split_part(derived_table1.aclstring::text, '='::character varying::text, 1))
                  END::character varying                                                              AS splitgrantee,
              derived_table1.grantseq
       FROM (((((SELECT pg_get_userbyid(b.relowner)::character varying                           AS objowner,
                        btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                        b.relname::character varying                                             AS objname,
                        CASE
                            WHEN b.relkind = 'r'::"char" THEN 'table'::character varying
                            ELSE 'view'::character varying
                            END                                                                  AS objtype,
                        btrim(split_part(array_to_string(b.relacl, ','::character varying::text),
                                         ','::character varying::text, ns.n))::character varying AS aclstring,
                        ns.n                                                                     AS grantseq
                 FROM (SELECT pg_class.oid, generate_series(1, array_upper(pg_class.relacl, 1)) AS n
                       FROM pg_class) ns
                          JOIN pg_class b ON b.oid = ns.oid AND ns.n <= array_upper(b.relacl, 1)
                          JOIN pg_namespace c ON b.relnamespace = c.oid
                 WHERE b.relkind = 'r'::"char"
                    OR b.relkind = 'v'::"char"
                 UNION ALL
                 SELECT pg_get_userbyid(b.nspowner)::character varying                           AS objowner,
                        NULL::character varying                                                  AS schemaname,
                        b.nspname::character varying                                             AS objname,
                        'schema'::character varying                                              AS objtype,
                        btrim(split_part(array_to_string(b.nspacl, ','::character varying::text),
                                         ','::character varying::text, ns.n))::character varying AS aclstring,
                        ns.n                                                                     AS grantseq
                 FROM (SELECT pg_namespace.oid, generate_series(1, array_upper(pg_namespace.nspacl, 1)) AS n
                       FROM pg_namespace) ns
                          JOIN pg_namespace b ON b.oid = ns.oid AND ns.n <= array_upper(b.nspacl, 1))
                UNION ALL
                SELECT pg_get_userbyid(b.datdba)::character varying                             AS objowner,
                       NULL::character varying                                                  AS schemaname,
                       b.datname::character varying                                             AS objname,
                       'database'::character varying                                            AS objtype,
                       btrim(split_part(array_to_string(b.datacl, ','::character varying::text),
                                        ','::character varying::text, ns.n))::character varying AS aclstring,
                       ns.n                                                                     AS grantseq
                FROM (SELECT pg_database.oid, generate_series(1, array_upper(pg_database.datacl, 1)) AS n
                      FROM pg_database) ns
                         JOIN pg_database b ON b.oid = ns.oid AND ns.n <= array_upper(b.datacl, 1))
               UNION ALL
               SELECT pg_get_userbyid(b.proowner)::character varying                           AS objowner,
                      btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                      textin(regprocedureout(b.oid::regprocedure))::character varying          AS objname,
                      CASE
                          WHEN b.prorettype = 0::oid OR b.prorettype IS NULL AND 0 IS NULL
                              THEN 'procedure'::character varying
                          ELSE 'function'::character varying
                          END                                                                  AS objtype,
                      btrim(split_part(array_to_string(b.proacl, ','::character varying::text),
                                       ','::character varying::text, ns.n))::character varying AS aclstring,
                      ns.n                                                                     AS grantseq
               FROM (SELECT pg_proc.oid, generate_series(1, array_upper(pg_proc.proacl, 1)) AS n
                     FROM pg_proc) ns
                        JOIN pg_proc b ON b.oid = ns.oid AND ns.n <= array_upper(b.proacl, 1)
                        JOIN pg_namespace c ON b.pronamespace = c.oid)
              UNION ALL
              SELECT NULL::character varying                                                  AS objowner,
                     NULL::character varying                                                  AS schemaname,
                     b.lanname::character varying                                             AS objname,
                     'language'::character varying                                            AS objtype,
                     btrim(split_part(array_to_string(b.lanacl, ','::character varying::text),
                                      ','::character varying::text, ns.n))::character varying AS aclstring,
                     ns.n                                                                     AS grantseq
              FROM (SELECT pg_language.oid, generate_series(1, array_upper(pg_language.lanacl, 1)) AS n
                    FROM pg_language) ns
                       JOIN pg_language b ON b.oid = ns.oid AND ns.n <= array_upper(b.lanacl, 1))
             UNION ALL
             SELECT pg_get_userbyid(b.defacluser)::character varying                         AS objowner,
                    btrim(c.nspname::character varying::text)::character varying             AS schemaname,
                    CASE
                        WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL
                            THEN 'tables'::character varying
                        WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL
                            THEN 'functions'::character varying
                        WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL
                            THEN 'procedures'::character varying
                        ELSE NULL::character varying
                        END                                                                  AS objname,
                    'default acl'::character varying                                         AS objtype,
                    btrim(split_part(array_to_string(b.defaclacl, ','::character varying::text),
                                     ','::character varying::text, ns.n))::character varying AS aclstring,
                    ns.n                                                                     AS grantseq
             FROM (SELECT pg_default_acl.oid, generate_series(1, array_upper(pg_default_acl.defaclacl, 1)) AS n
                   FROM pg_default_acl) ns
                      JOIN pg_default_acl b ON b.oid = ns.oid AND ns.n <= array_upper(b.defaclacl, 1)
                      LEFT JOIN pg_namespace c ON b.defaclnamespace = c.oid) derived_table1
       WHERE split_part(derived_table1.aclstring::text, '='::character varying::text, 1) <>
             split_part(derived_table1.aclstring::text, '/'::character varying::text, 2)
         AND split_part(derived_table1.aclstring::text, '='::character varying::text, 1) <> 'rdsdb'::character varying::text
         AND NOT (split_part(derived_table1.aclstring::text, '='::character varying::text, 1) =
                  ''::character varying::text AND
                  split_part(derived_table1.aclstring::text, '/'::character varying::text, 2) =
                  'rdsdb'::character varying::text)) objprivs
 WHERE NOT (objprivs.objtype::text = 'default acl'::character varying::text AND
            objprivs.grantee::text = 'PUBLIC'::character varying::text AND
            objprivs.objname::text = 'functions'::character varying::text))
UNION ALL
SELECT NULL::character varying                                     AS objowner,
       NULL::character varying                                     AS schemaname,
       CASE
           WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL
               THEN 'tables'::character varying
           WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL
               THEN 'functions'::character varying
           WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL
               THEN 'procedures'::character varying
           ELSE NULL::character varying
           END                                                     AS objname,
       'default acl'::character varying                            AS objtype,
       pg_get_userbyid(b.defacluser)::character varying            AS grantor,
       NULL::character varying                                     AS grantee,
       'revoke'::character varying                                 AS ddltype,
       5                                                           AS grantseq,
       5                                                           AS objseq,
       (((((('ALTER DEFAULT PRIVILEGES for user '::character varying::text ||
             quote_ident(pg_get_userbyid(b.defacluser)::character varying::text)) ||
            ' GRANT ALL on '::character varying::text) ||
           CASE
               WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL
                   THEN 'tables'::character varying
               WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL
                   THEN 'functions'::character varying
               WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL
                   THEN 'procedures'::character varying
               ELSE NULL::character varying
               END::text) || ' TO '::character varying::text) ||
         quote_ident(pg_get_userbyid(b.defacluser)::character varying::text)) ||
        CASE
            WHEN b.defaclobjtype = 'f'::"char" THEN ', PUBLIC;'::character varying
            ELSE ';'::character varying
            END::character varying(4000)::text)::character varying AS ddl
FROM pg_default_acl b
WHERE b.defaclacl = '{}'::aclitem[]
   OR b.defaclnamespace = 0::oid AND b.defaclobjtype = 'f'::"char";

alter table v_generate_user_grant_revoke_ddl
    owner to msgadmin;

