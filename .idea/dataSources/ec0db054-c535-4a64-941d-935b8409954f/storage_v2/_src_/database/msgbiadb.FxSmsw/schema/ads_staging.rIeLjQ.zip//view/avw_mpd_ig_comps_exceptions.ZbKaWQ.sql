CREATE OR REPLACE view ads_staging.avw_mpd_ig_comps_exceptions AS
select "$path":: VARCHAR(255)                                                as file_path
     , RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name
     , transaction_date::varchar(255)
     , entity::varchar(255)
     , venue::varchar(255)
     , event_type::varchar(255)
     , event_code::varchar(255)
     , event::varchar(255)
     , amount::varchar(255)
     , check_number::varchar(255)
     , suite_number::varchar(255)
     , department::varchar(255)
     , contact::varchar(255)
     , entity2::varchar(255)
     , dept::varchar(255)
     , account::varchar(255)
     , venue2::varchar(255)
     , event_type2::varchar(255)
     , event2::varchar(255)
     , performace::varchar(255)
     , program_code::varchar(255)
     , reason::varchar(255)
from ext_staging.mpd_ig_comps_exceptions_jimmy_fung_files
with no schema binding;

alter table avw_mpd_ig_comps_exceptions
    owner to ads_staging;

