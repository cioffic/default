CREATE OR replace VIEW ads_staging.avw_stg_appetize_tax_group_report AS
SELECT tax_group_id,
       tax_group_name,
       tax_group_status,
       layout_id,
       layout_name,
       type,
       value,
       is_exclusive,
       is_active,
       --items, 
       --ads_staging.F_s3_parse_athena_filename("$path") AS ads_source_file ,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day
FROM appetize.api_tax_group_report
    --	LEFT JOIN t.items.item --> doesn't have any data to complete this part
--		ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_tax_group_report
    owner to ads_staging;

