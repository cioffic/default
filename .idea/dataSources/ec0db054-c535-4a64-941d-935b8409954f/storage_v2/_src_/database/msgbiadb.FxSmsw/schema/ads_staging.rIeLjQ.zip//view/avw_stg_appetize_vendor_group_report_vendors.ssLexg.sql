CREATE OR replace VIEW ads_staging.avw_stg_appetize_vendor_group_report_vendors AS
SELECT a.vendor_group_id,
       a.vendor_group_name,
       v.vendor_id,
       v.vendor_name,
       v.vendor_is_active,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day

FROM appetize.api_vendor_group_report a
         LEFT JOIN a.vendors v
                   ON TRUE
WITH no SCHEMA binding;

alter table avw_stg_appetize_vendor_group_report_vendors
    owner to ads_staging;

