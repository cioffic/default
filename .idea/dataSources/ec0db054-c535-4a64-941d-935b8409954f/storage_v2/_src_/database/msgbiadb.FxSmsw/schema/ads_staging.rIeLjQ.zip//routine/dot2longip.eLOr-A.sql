create function dot2longip(IP character varying) returns bigint
    volatile
    language plpythonu
as
$$
import ipaddress
return int(ipaddress.IPv4Address(ip))
$$;

