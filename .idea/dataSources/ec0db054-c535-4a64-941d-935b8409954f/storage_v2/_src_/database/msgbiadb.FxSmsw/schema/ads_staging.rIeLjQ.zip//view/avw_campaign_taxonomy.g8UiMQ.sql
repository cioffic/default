CREATE or replace view ads_staging.avw_campaign_taxonomy
as
select year,
       month,
       week_number,
       week_starting,
       media,
       media_category,
       tactic,
       area,
       campaign_id,
       campaign_date,
       campaign_name,
       campaign_name_higher,
       publisher,
       site_id,
       site_social,
       impressions,
       clicks,
       spend,
       video_impressions,
       dcm_clicks,
       dcm_spend,
       viewable_impressions,
       eligible_impressions,
       viewable_impression_distribution,
       pc_viewable_impressions,
       video_views,
       sales,
       revenue,
       ticket_quantity,
       clickable_impressions,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
from ext_staging.stg_cssr_media_perf
with no schema binding;

alter table avw_campaign_taxonomy
    owner to ads_staging;

