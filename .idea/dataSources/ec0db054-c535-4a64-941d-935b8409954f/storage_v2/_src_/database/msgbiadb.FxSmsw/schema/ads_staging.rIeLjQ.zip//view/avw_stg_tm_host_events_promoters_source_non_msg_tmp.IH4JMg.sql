CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_host_events_promoters_source_non_msg_tmp AS
SELECT e._embedded.pulldatetime,
       events.id             discovery_event_id,
       promoters.description promoters_description,
       promoters.id          promoters_id,
       promoters.name        promoters_name
FROM ext_staging.non_msg_venue_eventssource e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events.promoters promoters
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_promoters_source_non_msg_tmp
    owner to ads_staging;

