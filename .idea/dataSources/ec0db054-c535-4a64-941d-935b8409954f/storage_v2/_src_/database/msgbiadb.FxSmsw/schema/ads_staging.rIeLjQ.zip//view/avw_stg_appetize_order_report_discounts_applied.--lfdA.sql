CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_discounts_applied AS
SELECT a.order_id,
       discounts_applied.id     discount_id,
       discounts_applied.name   discount_name,
       discounts_applied.amount discount_amount,
       discounts_applied.code   discount_code
FROM appetize.api_orders_report a
         LEFT JOIN a.discounts_applied discounts_applied
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_discounts_applied
    owner to ads_staging;

