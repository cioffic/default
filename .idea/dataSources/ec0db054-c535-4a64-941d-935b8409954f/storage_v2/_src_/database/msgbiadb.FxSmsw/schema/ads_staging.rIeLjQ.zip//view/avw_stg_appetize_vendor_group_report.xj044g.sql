CREATE OR replace VIEW ads_staging.avw_stg_appetize_vendor_group_report AS
SELECT vendor_group_id,
       vendor_group_name,
       vendor_group_is_active,
       vendor_group_status,
       is_primary,
       layout_id,
       layout_name,
       --vendors, 
       venue_id,
       --ads_staging.F_s3_parse_athena_filename("$path") AS ads_source_file ,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day
FROM appetize.api_vendor_group_report
--WHERE ads_staging.f_s3_parse_athena_filename("$path")=(SELECT MAX(ads_staging.f_s3_parse_athena_filename("$path")) FROM appetize.stg_appetize_vendor_group_report)

        WITH no SCHEMA binding;

alter table avw_stg_appetize_vendor_group_report
    owner to ads_staging;

