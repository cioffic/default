CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_items_taxes AS
SELECT a.order_id,
       items.id                  item_id,

       items_taxes.name          name,
       items_taxes.value_type    value_type,
       items_taxes.tax           tax,
       items_taxes.extendedtax   extended_tax,
       items_taxes.taxtype       tax_type,
       items_taxes.taxgroupname  tax_group_name,
       items_taxes.taxexternalid tax_external_id
FROM appetize.api_orders_report a
         LEFT JOIN a.items items
                   ON TRUE
         LEFT JOIN items.taxes items_taxes
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_items_taxes
    owner to ads_staging;

