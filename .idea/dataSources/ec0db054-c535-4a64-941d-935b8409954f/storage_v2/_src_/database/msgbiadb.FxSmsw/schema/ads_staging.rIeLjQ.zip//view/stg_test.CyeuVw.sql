CREATE VIEW ads_staging.stg_test AS
SELECT *
FROM ads_staging.stg_tm_ticket
WITH NO SCHEMA BINDING;

alter table stg_test
    owner to ads_staging;

