CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_host_events_promoters_source AS
SELECT events.id             discovery_event_id,
       promoters.description promoters_description,
       promoters.id          promoters_id,
       promoters.name        promoters_name,
       e.pt_year             pt_year,
       e.pt_month            pt_month,
       e.pt_day              pt_day
FROM ticketmaster.discoveryapi_events_search e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events.promoters promoters
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_promoters_source
    owner to ads_staging;

