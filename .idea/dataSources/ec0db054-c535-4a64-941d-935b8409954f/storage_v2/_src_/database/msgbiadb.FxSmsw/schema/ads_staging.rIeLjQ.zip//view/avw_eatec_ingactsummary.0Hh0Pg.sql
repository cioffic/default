create or replace view ads_staging.avw_eatec_ingactsummary
as
select item,
       location,
       postdate :: datetime,
       qty1::float,
       qty2 :: float,
       qty3 :: float,
       qty4 :: float,
       qty5 :: float,
       qty6 :: float,
       qty7 :: float,
       qty8:: float,
       value1 :: decimal(12, 4),
       value2 :: decimal(12, 4),
       value3 :: decimal(12, 4),
       value4 :: decimal(12, 4),
       value5 :: decimal(12, 4),
       value6 :: decimal(12, 4),
       value7 :: decimal(12, 4),
       value8 :: decimal(12, 4),
       useq2 :: float,
       useq3 :: float,
       useq4 :: float,
       usev2 :: decimal(12, 4),
       usev3 :: decimal(12, 4),
       usev4 :: decimal(12, 4),
       currentcost :: decimal(12, 4),
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'EATEC'                                         as ads_source
from ext_staging.stg_eatec_ingactsummary
where postdate :: datetime <> '2020-09-23 00:00:00'
with no schema binding;

alter table avw_eatec_ingactsummary
    owner to ads_staging;

