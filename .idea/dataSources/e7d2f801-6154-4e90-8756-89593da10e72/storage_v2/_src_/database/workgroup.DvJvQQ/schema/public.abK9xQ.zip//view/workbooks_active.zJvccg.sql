create view workbooks_active
            (id, name, repository_url, description, created_at, updated_at, owner_id, project_id, view_count, size,
             embedded, thumb_user, refreshable_extracts, extracts_refreshed_at, lock_version, state, version, checksum,
             display_tabs, data_engine_extracts, incrementable_extracts, site_id, revision, repository_data_id,
             repository_extract_data_id, first_published_at, primary_content_url, share_description, show_toolbar,
             extracts_incremented_at, default_view_index, luid, asset_key_id, document_version, content_version,
             last_published_at, data_id, reduced_data_id, published_all_sheets, extract_encryption_state,
             extract_creation_pending, is_deleted)
as
SELECT workbooks.id,
       workbooks.name,
       workbooks.repository_url,
       workbooks.description,
       workbooks.created_at,
       workbooks.updated_at,
       workbooks.owner_id,
       workbooks.project_id,
       workbooks.view_count,
       workbooks.size,
       workbooks.embedded,
       workbooks.thumb_user,
       workbooks.refreshable_extracts,
       workbooks.extracts_refreshed_at,
       workbooks.lock_version,
       workbooks.state,
       workbooks.version,
       workbooks.checksum,
       workbooks.display_tabs,
       workbooks.data_engine_extracts,
       workbooks.incrementable_extracts,
       workbooks.site_id,
       workbooks.revision,
       workbooks.repository_data_id,
       workbooks.repository_extract_data_id,
       workbooks.first_published_at,
       workbooks.primary_content_url,
       workbooks.share_description,
       workbooks.show_toolbar,
       workbooks.extracts_incremented_at,
       workbooks.default_view_index,
       workbooks.luid,
       workbooks.asset_key_id,
       workbooks.document_version,
       workbooks.content_version,
       workbooks.last_published_at,
       workbooks.data_id,
       workbooks.reduced_data_id,
       workbooks.published_all_sheets,
       workbooks.extract_encryption_state,
       workbooks.extract_creation_pending,
       workbooks.is_deleted
FROM workbooks
WHERE workbooks.is_deleted = false;

comment on view workbooks_active is 'SUPPRESS_DOC_OUTPUT Postgres view representing the active (non-deleted) tableau workbooks';

alter table workbooks_active
    owner to rails;

