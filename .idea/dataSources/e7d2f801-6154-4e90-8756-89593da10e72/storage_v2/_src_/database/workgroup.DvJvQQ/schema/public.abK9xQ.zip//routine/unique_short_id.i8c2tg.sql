create function unique_short_id() returns trigger
    language plpgsql
as
$$
DECLARE
  key TEXT;
  qry TEXT;
  found TEXT;
BEGIN
  -- generate the first part of a query as a string with safely
  -- escaped table name, using || to concat the parts
  qry := 'SELECT short_id FROM ' || TG_TABLE_SCHEMA || '.' ||  TG_TABLE_NAME || ' WHERE short_id=';

  LOOP
    key := random_string(6);

    -- Concat the generated key (safely quoted) with the generated query
    -- and run it.
    -- e.g. SELECT short_id FROM nlp.links WHERE short_id = '6Ee9Rk' INTO found
    -- Now "found" will be the duplicated id or NULL.
    EXECUTE qry || quote_literal(key) INTO found;

    -- Check to see if found is NULL.
    -- If we checked to see if found = NULL it would always be FALSE
    -- because (NULL = NULL) is always FALSE.
    IF found IS NULL THEN
      -- If we didn't find a collision then leave the LOOP.
      EXIT;
    END IF;

  END LOOP;

  NEW.short_id = key;

  RETURN NEW;
END;
$$;

alter function unique_short_id() owner to rails;

