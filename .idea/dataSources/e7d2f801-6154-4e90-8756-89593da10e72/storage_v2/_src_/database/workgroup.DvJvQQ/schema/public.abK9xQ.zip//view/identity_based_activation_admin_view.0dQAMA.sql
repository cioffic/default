create view identity_based_activation_admin_view
            (iba_user_id, site_id, device_fingerprint, product_type, user_role, host_name, product_version,
             registration_first_name, registration_last_name, registration_email, registration_date, client_user_name,
             atr_expiration_date, hardware_serial_number, registration_custom_field, machine_os, virtual_machine,
             atr_chain_id, domain_information, date_atr_issued, date_atr_failed, date_last_updated, server_user_name,
             server_email, site_luid, date_activated, date_last_used, date_creator_role_assigned,
             date_creator_role_unassigned, site_name)
as
SELECT urc.user_luid        AS iba_user_id,
       urc.site_id,
       r.device_fingerprint,
       r.product_type,
       sr.display_name      AS user_role,
       r.host_name,
       r.product_version,
       r.registration_first_name,
       r.registration_last_name,
       r.registration_email,
       r.registration_date,
       r.client_user_name,
       r.atr_expiration_date,
       r.hardware_serial_number,
       r.registration_custom_field,
       r.machine_os,
       r.virtual_machine,
       r.atr_chain_id,
       r.domain_information,
       r.date_atr_issued,
       r.date_atr_failed,
       r.date_last_updated,
       urc.system_user_name AS server_user_name,
       r.server_email,
       r.site_luid,
       r.date_activated,
       r.date_last_used,
       urc.date_creator_role_assigned,
       urc.date_creator_role_unassigned,
       s.name               AS site_name
FROM identity_based_activation_reporting r
         LEFT JOIN identity_based_activation_user_role_change urc
                   ON r.iba_user_id::text = urc.user_luid::text AND r.site_id = urc.site_id
         LEFT JOIN site_roles sr ON urc.site_role_id = sr.id
         LEFT JOIN sites s ON r.site_id = s.id
WHERE r.date_activated IS NOT NULL;

comment on view identity_based_activation_admin_view is 'Database view to faciliate Admin Server and Site Views for IBA Reporting.';

comment on column identity_based_activation_admin_view.iba_user_id is 'Generated Id for user for IBA Reporting';

comment on column identity_based_activation_admin_view.site_id is 'Site being used.';

comment on column identity_based_activation_admin_view.device_fingerprint is 'Uniquely identifies device. Built/generated from umn.';

comment on column identity_based_activation_admin_view.product_type is 'Product being used at the client level.';

comment on column identity_based_activation_admin_view.user_role is 'Values: CREATOR, SITE_ADMINISTRATOR, SERVER_ADMINISTRATOR';

comment on column identity_based_activation_admin_view.host_name is 'Computer host name.';

comment on column identity_based_activation_admin_view.product_version is 'application/product version being used at the client level.';

comment on column identity_based_activation_admin_view.registration_first_name is 'Registered user first name';

comment on column identity_based_activation_admin_view.registration_last_name is 'Registered user last name';

comment on column identity_based_activation_admin_view.registration_email is 'Registered user email address';

comment on column identity_based_activation_admin_view.registration_date is 'Date active key was registered.';

comment on column identity_based_activation_admin_view.client_user_name is 'Login/User name from the client level.';

comment on column identity_based_activation_admin_view.atr_expiration_date is 'Expiration date of active key. NULL means permanent.';

comment on column identity_based_activation_admin_view.hardware_serial_number is 'Uniquely identifies company''s hardware asset.';

comment on column identity_based_activation_admin_view.registration_custom_field is 'custom field from registration';

comment on column identity_based_activation_admin_view.machine_os is 'os_architecture';

comment on column identity_based_activation_admin_view.virtual_machine is 'is the machine virtual';

comment on column identity_based_activation_admin_view.atr_chain_id is 'ATR Chain Id';

comment on column identity_based_activation_admin_view.domain_information is 'Computer Active Directory domain.';

comment on column identity_based_activation_admin_view.date_atr_issued is 'date-time when the ATR successfully returned from the server for this user, device, product and site.';

comment on column identity_based_activation_admin_view.date_atr_failed is 'date-time when the ATR successfully returned from the server for this user, device, product and site.';

comment on column identity_based_activation_admin_view.date_last_updated is 'date-time the last time this row was updated in any way for a given user, productType, device and site.';

comment on column identity_based_activation_admin_view.server_user_name is 'User friendly name on the server level.';

comment on column identity_based_activation_admin_view.server_email is 'Email for user on the server level.';

comment on column identity_based_activation_admin_view.site_luid is 'LUID from sites table.';

comment on column identity_based_activation_admin_view.date_activated is 'date-time when the user activated this product from this device for this site for the first time.';

comment on column identity_based_activation_admin_view.date_last_used is 'date-time the last time the user used this product from this device for this site.';

comment on column identity_based_activation_admin_view.date_creator_role_assigned is 'Datetime user was assigned a creator role. Triggered by site role change in the users table.';

comment on column identity_based_activation_admin_view.date_creator_role_unassigned is 'Datetime user was unassigned a creator role. Triggered by site role change in the users table.';

comment on column identity_based_activation_admin_view.site_name is 'The name of the site sourced from the name column in the sites table.';

alter table identity_based_activation_admin_view
    owner to rails;

