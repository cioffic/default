create function check_system_user_id_consistency_between_refresh_token_and_devi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM refresh_token_devices WHERE id = NEW.refresh_token_device_id AND system_user_id = NEW.system_user_id LIMIT 1
        ) THEN
        RAISE EXCEPTION 'system_user_id is not consistent between the device and refresh token';
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_system_user_id_consistency_between_refresh_token_and_devi() owner to rails;

