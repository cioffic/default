create function get_licensing_role_for_site_role()
    returns TABLE(site_role_id integer, licensing_role_id integer, licensing_role_name character varying)
    stable
    language sql
as
$$
    -- Define a static table to map between licensing_roles and site_roles (using names for readability).
    SELECT site_roles.id AS site_role_id, licensing_roles.id AS licensing_role_id, licensing_roles.name AS licensing_role_name
    FROM (VALUES -- site_role_name, licensing_role_name
        ('Unlicensed', 'Unlicensed'),
        ('Guest', 'Guest'),
        ('Support', 'SupportUser'),
        ('Tier_Basic', 'BasicUser'),
        ('Tier_Interactor', 'Interactor'),
        ('Tier_Interactor', 'Publisher'),
        ('Tier_Interactor', 'SiteAdministrator'),
        ('Tier_Author', 'Author'),
        ('Tier_Author', 'SiteAdministratorAuthor')
    ) AS tier_mapping (licensing_role_name, site_role_name)
    JOIN site_roles ON site_roles.name = tier_mapping.site_role_name
    JOIN licensing_roles ON licensing_roles.name = tier_mapping.licensing_role_name
    ;
$$;

alter function get_licensing_role_for_site_role() owner to rails;

