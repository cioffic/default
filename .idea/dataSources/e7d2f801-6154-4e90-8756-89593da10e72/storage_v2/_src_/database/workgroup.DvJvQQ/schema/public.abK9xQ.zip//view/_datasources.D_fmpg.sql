create view _datasources
            (id, name, datasource_url, owner_id, owner_name, created_at, updated_at, size, project_id, project_name,
             server, dbclass, port, username, dbname, owner_type, system_user_id, site_id, domain_id, domain_name)
as
SELECT datasources.id,
       datasources.name,
       datasources.repository_url AS datasource_url,
       datasources.owner_id,
       owner.name                 AS owner_name,
       datasources.created_at,
       datasources.updated_at,
       datasources.size,
       datasources.project_id,
       projects.name              AS project_name,
       data_connections.server,
       data_connections.dbclass,
       data_connections.port,
       data_connections.username,
       data_connections.dbname,
       data_connections.owner_type,
       users.system_user_id,
       data_connections.site_id,
       domains.id                 AS domain_id,
       domains.name               AS domain_name
FROM datasources,
     system_users owner,
     projects,
     data_connections,
     users,
     domains
WHERE datasources.id = data_connections.owner_id
  AND datasources.owner_id = users.id
  AND datasources.project_id = projects.id
  AND data_connections.owner_type::text = 'Datasource'::text
  AND users.system_user_id = owner.id
  AND data_connections.site_id = users.site_id
  AND owner.domain_id = domains.id;

comment on view _datasources is 'Shows all Published datasources on server, along with some associated information.';

comment on column _datasources.id is 'Primary key for the underlying datasources record.';

comment on column _datasources.name is 'The name of the published datasource.';

comment on column _datasources.datasource_url is 'Uniquely identifies a datasource.  More or less consists of a slightly modified name, but not totally obviously, especially in the presence of non-ASCII characters.  Used in URLs meant to access this datasource.';

comment on column _datasources.owner_id is 'The user ID of the owner/uploader of the datasource.';

comment on column _datasources.owner_name is 'The name of the system_user linked to owner_id';

comment on column _datasources.created_at is 'When this record was created.';

comment on column _datasources.updated_at is 'When this record was last updated.';

comment on column _datasources.size is 'The size in bytes of the datasource.';

comment on column _datasources.project_id is 'The associated project ID where the datasource was published.';

comment on column _datasources.project_name is 'The name of the project linked via project_id.';

comment on column _datasources.server is 'DNS server name to connect to (for the associated data_connection record).';

comment on column _datasources.dbclass is 'Type of data connection (ie mysql, postgres, sqlproxy etc) (for the associated data_connection record).';

comment on column _datasources.port is 'TCP port number of the connect (eg. 5432 for postgres) (for the associated data_connection record).';

comment on column _datasources.username is 'Username to use when connecting.';

comment on column _datasources.dbname is 'The database name associated with the linked data_connection record.';

comment on column _datasources.owner_type is '"Datasource"';

comment on column _datasources.system_user_id is 'The system_user linked to the user whose id is owner_id.';

comment on column _datasources.site_id is 'The site that contains this datasource.';

comment on column _datasources.domain_id is 'A foreign key reference to the domain of the owner.';

comment on column _datasources.domain_name is 'The name is either "local" or the name of some Active Directory group.';

alter table _datasources
    owner to rails;

