create view _background_tasks
            (backgrounder_id, id, created_at, completed_at, finish_code, job_type, progress, args, notes, started_at,
             job_name, priority, title, processed_on_worker, subtitle, language, site_id, locale,
             subscriptions_attach_image, subscriptions_attach_pdf)
as
SELECT background_jobs.backgrounder_id,
       background_jobs.id,
       background_jobs.created_at,
       background_jobs.completed_at,
       background_jobs.finish_code,
       background_jobs.job_type,
       background_jobs.progress,
       background_jobs.args,
       background_jobs.notes,
       background_jobs.started_at,
       background_jobs.job_name,
       background_jobs.priority,
       background_jobs.title,
       background_jobs.processed_on_worker,
       background_jobs.subtitle,
       background_jobs.language,
       background_jobs.site_id,
       background_jobs.locale,
       subscriptions.attach_image AS subscriptions_attach_image,
       subscriptions.attach_pdf   AS subscriptions_attach_pdf
FROM background_jobs
         LEFT JOIN tasks ON background_jobs.correlation_id = tasks.id
         LEFT JOIN subscriptions ON tasks.obj_id = subscriptions.id AND tasks.type::text = 'SingleSubscriptionTask'::text
UNION
SELECT async_jobs.worker            AS backgrounder_id,
       async_jobs.id,
       async_jobs.created_at,
       async_jobs.completed_at,
       CASE
           WHEN async_jobs.success = true THEN 0
           ELSE 1
           END                      AS finish_code,
       async_jobs.job_type,
       async_jobs.progress,
       NULL::text                   AS args,
       async_jobs.notes,
       async_jobs.created_at        AS started_at,
       async_jobs.job_type          AS job_name,
       0                            AS priority,
       NULL::character varying(255) AS title,
       async_jobs.worker            AS processed_on_worker,
       NULL::character varying(255) AS subtitle,
       NULL::character varying(255) AS language,
       async_jobs.site_id,
       NULL::character varying(255) AS locale,
       NULL::boolean                AS subscriptions_attach_image,
       NULL::boolean                AS subscriptions_attach_pdf
FROM async_jobs;

comment on view _background_tasks is 'This view combines the important contents of both the background_jobs table and the async_jobs table to give an overall picture of jobs that were given to a backgrounder process.';

comment on column _background_tasks.backgrounder_id is 'The id of the backgrounder process that did the work.';

comment on column _background_tasks.id is 'The primary key of either the background_jobs record or the async_jobs record, depending on where this record is coming from.';

comment on column _background_tasks.created_at is 'When this record was created.';

comment on column _background_tasks.completed_at is 'When the job finished execution. When set, this should generally agree with the updated_at field.';

comment on column _background_tasks.finish_code is 'Completion status for the job. Will be 0 for success, 1 for failure, and 2 for cancelled.';

comment on column _background_tasks.job_type is 'The type of job being run.  This looks a bit odd because it comes from a serialized symbol.';

comment on column _background_tasks.progress is 'Can be used to indicate percent complete for the job, but in most cases simply gets set to 100 when the job is completed.';

comment on column _background_tasks.args is 'Used as a means of passing parameters about the background job.  This information is stored in a special serialized format, and thus is not easily readable.';

comment on column _background_tasks.notes is 'Can be used to store additional information about the running of the job.';

comment on column _background_tasks.started_at is 'When the execution of the job was started.  This is not generally the same as created_at, because it may take some time before a backgrounder "notices" the newly created record and begins to process it.';

comment on column _background_tasks.job_name is 'A nice readable name for this type of job.';

comment on column _background_tasks.priority is 'Controls which background_jobs records are processed first.  The highest priority is 0, and the lowest is 100.  Integer values in between are also valid.';

comment on column _background_tasks.title is 'Can be used to provide some additional information about the job.';

comment on column _background_tasks.processed_on_worker is 'Identifies the machine on which the job is run.';

comment on column _background_tasks.subtitle is 'Can be used to provide some additional information about the job.';

comment on column _background_tasks.language is 'The language for the job is listed here.';

comment on column _background_tasks.site_id is 'Links to a site, if one is relevant, otherwise it is left NULL.';

comment on column _background_tasks.locale is 'The locale for the job is listed here.';

comment on column _background_tasks.subscriptions_attach_image is 'Boolean that represents whether to attach images to a subscription background_job. Will be NULL if the background_job is not a subscription.';

comment on column _background_tasks.subscriptions_attach_pdf is 'Boolean that represents whether to attach a PDF to a subscription background_job. Will be NULL if the background_job is not a subscription.';

alter table _background_tasks
    owner to rails;

