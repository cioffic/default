create view flows_active
            (id, name, luid, owner_id, project_id, site_id, data_id, reduced_data_id, created_at, updated_at,
             description, lock_version, size, embedded, asset_key_id, thumbnail_id, last_published_at, content_version,
             document_version, file_type, graph_image_id, encryption_key_id, data_engine_extracts,
             extract_encryption_state, is_deleted)
as
SELECT flows.id,
       flows.name,
       flows.luid,
       flows.owner_id,
       flows.project_id,
       flows.site_id,
       flows.data_id,
       flows.reduced_data_id,
       flows.created_at,
       flows.updated_at,
       flows.description,
       flows.lock_version,
       flows.size,
       flows.embedded,
       flows.asset_key_id,
       flows.thumbnail_id,
       flows.last_published_at,
       flows.content_version,
       flows.document_version,
       flows.file_type,
       flows.graph_image_id,
       flows.encryption_key_id,
       flows.data_engine_extracts,
       flows.extract_encryption_state,
       flows.is_deleted
FROM flows
WHERE flows.is_deleted = false;

comment on view flows_active is 'SUPPRESS_DOC_OUTPUT Postgres view representing the active (non-deleted) tableau flows';

alter table flows_active
    owner to rails;

