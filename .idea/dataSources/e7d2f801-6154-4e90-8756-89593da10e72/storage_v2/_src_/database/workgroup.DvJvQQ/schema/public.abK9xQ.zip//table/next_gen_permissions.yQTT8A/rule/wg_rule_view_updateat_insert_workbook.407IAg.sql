CREATE RULE wg_rule_view_updateat_insert_workbook AS
    ON INSERT TO next_gen_permissions
   WHERE new.authorizable_type::text = 'Workbook'::text DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
  WHERE views.workbook_id = new.authorizable_id;

