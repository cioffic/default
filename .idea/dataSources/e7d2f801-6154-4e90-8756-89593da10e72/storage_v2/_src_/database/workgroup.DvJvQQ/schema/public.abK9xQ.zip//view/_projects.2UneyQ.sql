create view _projects(id, name, created_at, owner_id, owner_name, system_user_id, site_id) as
SELECT projects.id,
       projects.name,
       projects.created_at,
       projects.owner_id,
       owner.name AS owner_name,
       users.system_user_id,
       projects.site_id
FROM projects,
     system_users owner,
     users
WHERE projects.owner_id = users.id
  AND users.system_user_id = owner.id
  AND projects.site_id = users.site_id;

comment on view _projects is 'Each row of the table corresponds to a project on Tableau Server.';

comment on column _projects.id is 'Primary key for the underlying record in the projects table.';

comment on column _projects.name is 'The name of the project.';

comment on column _projects.created_at is 'The time at which this record was created.';

comment on column _projects.owner_id is 'The id of the user who owns this project.';

comment on column _projects.owner_name is 'The name of the system_user who owns this project.';

comment on column _projects.system_user_id is 'The id of the system_user who owns this project.';

comment on column _projects.site_id is 'Refers to the site which contains this project.';

alter table _projects
    owner to rails;

