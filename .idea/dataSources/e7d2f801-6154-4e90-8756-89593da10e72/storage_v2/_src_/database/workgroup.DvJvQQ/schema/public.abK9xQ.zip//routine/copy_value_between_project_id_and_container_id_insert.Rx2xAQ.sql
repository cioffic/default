create function copy_value_between_project_id_and_container_id_insert() returns trigger
    language plpgsql
as
$$
BEGIN
  -- Old code inserting with project id but not container_id
  IF (NEW.container_id IS NULL AND NEW.project_id IS NOT NULL) THEN
    NEW.container_id = NEW.project_id;
  -- New code inserting with container_id but not project_id
  ELSIF (NEW.project_id IS NULL AND NEW.container_id IS NOT NULL AND NEW.container_type = 'Project') THEN
    NEW.project_id = NEW.container_id;
  END IF;
  RETURN NEW;
END
$$;

alter function copy_value_between_project_id_and_container_id_insert() owner to rails;

