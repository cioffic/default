create function update_iba_reporting_when_creator_role_changes() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (OLD.date_creator_role_unassigned IS DISTINCT FROM NEW.date_creator_role_unassigned) OR
     (OLD.date_creator_role_assigned IS DISTINCT FROM NEW.date_creator_role_assigned) 
  THEN
    UPDATE identity_based_activation_reporting
    SET date_last_updated = now()
    WHERE NEW.user_luid::text = identity_based_activation_reporting.iba_user_id
    AND NEW.site_id = identity_based_activation_reporting.site_id;
  END IF;
 RETURN NEW;
END;
$$;

alter function update_iba_reporting_when_creator_role_changes() owner to rails;

