create function update_for_cache_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
        IF NEW.updated_at > OLD.for_cache_updated_at THEN
          NEW.for_cache_updated_at = NEW.updated_at;
        END IF;
        RETURN NEW;
      END;
$$;

alter function update_for_cache_updated_at() owner to rails;

