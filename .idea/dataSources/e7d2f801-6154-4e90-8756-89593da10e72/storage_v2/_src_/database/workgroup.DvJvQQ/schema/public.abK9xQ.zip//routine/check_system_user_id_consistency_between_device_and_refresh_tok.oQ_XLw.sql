create function check_system_user_id_consistency_between_device_and_refresh_tok() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1 FROM refresh_tokens WHERE refresh_token_device_id = NEW.id AND system_user_id <> NEW.system_user_id LIMIT 1
        ) THEN
        RAISE EXCEPTION 'system_user_id is not consistent between the device and refresh token';
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_system_user_id_consistency_between_device_and_refresh_tok() owner to rails;

