create function get_garbage_repository_data(repository_expiration_minutes integer) returns SETOF bigint
    language plpgsql
as
$$
BEGIN
      CREATE TEMP TABLE temp_repo_data_ids (
        repo_id bigint CONSTRAINT pk_temp_repo_data_ids PRIMARY KEY
      )
      ON COMMIT DROP;

      -- To hold all foreign key references to repository_data
      CREATE TEMP TABLE temp_used_repo_data_ids (
        repo_id bigint CONSTRAINT pk_temp_used_repo_data_ids PRIMARY KEY
      )
      ON COMMIT DROP;

      -- To hold all unreferenced repository_data ids
      CREATE TEMP TABLE temp_garbage_repo_data_ids (
        repo_id bigint CONSTRAINT pk_temp_garbage_repo_data_ids PRIMARY KEY
      )
      ON COMMIT DROP;

      -- Fully populates temp_repo_data_ids, minus any item that has a type and is managed by SOS
      INSERT INTO temp_repo_data_ids
      SELECT id FROM repository_data
      WHERE type is NULL and created_at + repository_expiration_minutes * '1 minute'::interval < (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::timestamp without time zone;

      -- Note: no duplicate foreign key references to repository_data should exist---LEFT OUTER JOIN below is just a precaution.

      -- Insert repository_data_id values from workbooks table into temp_used_repo_data_ids
      INSERT INTO temp_used_repo_data_ids
      SELECT repository_data_id FROM workbooks
      WHERE repository_data_id IS NOT NULL;

      -- Insert repository_extract_data_id values from workbooks table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT w.repository_extract_data_id
      FROM workbooks AS w
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = w.repository_extract_data_id
      WHERE tur.repo_id IS NULL
      AND w.repository_extract_data_id IS NOT NULL;

      -- Insert repository_data_id values from views table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT v.repository_data_id
      FROM views AS v
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = v.repository_data_id
      WHERE tur.repo_id IS NULL
      AND v.repository_data_id IS NOT NULL;

      -- Insert repository_data_id values from datasources table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT ds.repository_data_id
      FROM datasources AS ds
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = ds.repository_data_id
      WHERE tur.repo_id IS NULL
      AND ds.repository_data_id IS NOT NULL;

      -- Insert repository_extract_data_id values from datasources table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT ds.repository_extract_data_id
      FROM datasources AS ds
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = ds.repository_extract_data_id
      WHERE tur.repo_id IS NULL
      AND ds.repository_extract_data_id IS NOT NULL;

      -- Insert repository_data_id values from customized_views table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT cv.repository_data_id
      FROM customized_views AS cv
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = cv.repository_data_id
      WHERE tur.repo_id IS NULL
      AND cv.repository_data_id IS NOT NULL;

      -- Insert repository_data_id values from metrics_data table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT md.repository_data_id
      FROM metrics_data AS md
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = md.repository_data_id
      WHERE tur.repo_id IS NULL
      AND md.repository_data_id IS NOT NULL;

      -- Insert repository_thumbnail_data_id values from customized_views table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT cv.repository_thumbnail_data_id
      FROM customized_views AS cv
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = cv.repository_thumbnail_data_id
      WHERE tur.repo_id IS NULL
      AND cv.repository_thumbnail_data_id IS NOT NULL;

      -- Insert data_storage_id values from sheet_images table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT si.data_storage_id
      FROM sheet_images AS si
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = si.data_storage_id
      WHERE tur.repo_id IS NULL
      AND si.data_storage_id IS NOT NULL;

      -- Insert data_storage_id values from workbook_exports table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT we.data_storage_id
      FROM workbook_exports AS we
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = we.data_storage_id
      WHERE tur.repo_id IS NULL
      AND we.data_storage_id IS NOT NULL;

      -- Insert data_storage_id values from user_images table into temp_used_repo_data_ids, avoiding duplicates (that shouldn't exist)
      INSERT INTO temp_used_repo_data_ids
      SELECT ui.repository_data_id
      FROM user_images AS ui
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = ui.repository_data_id
      WHERE tur.repo_id IS NULL
      AND ui.repository_data_id IS NOT NULL;

      -- Find all repository_data ids that have no foreign key reference
      INSERT INTO temp_garbage_repo_data_ids
      SELECT trd.repo_id
      FROM temp_repo_data_ids AS trd
      LEFT OUTER JOIN temp_used_repo_data_ids AS tur
        ON tur.repo_id = trd.repo_id
      WHERE tur.repo_id IS NULL;

      RETURN QUERY
      SELECT repo_id
      FROM temp_garbage_repo_data_ids;
      END;
$$;

alter function get_garbage_repository_data(integer) owner to rails;

