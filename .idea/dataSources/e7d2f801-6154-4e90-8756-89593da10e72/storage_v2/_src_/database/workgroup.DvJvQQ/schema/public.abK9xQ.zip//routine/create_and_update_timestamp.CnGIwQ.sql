create function create_and_update_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP AT TIME ZONE 'UTC';
        NEW.created_at = OLD.created_at;
        RETURN NEW;
      END;
$$;

alter function create_and_update_timestamp() owner to rails;

