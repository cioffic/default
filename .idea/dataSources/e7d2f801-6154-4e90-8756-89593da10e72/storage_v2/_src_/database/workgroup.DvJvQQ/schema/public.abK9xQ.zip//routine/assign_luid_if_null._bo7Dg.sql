create function assign_luid_if_null() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.luid IS NULL) THEN
      NEW.luid = generate_uuid_safer();
    END IF;
    RETURN NEW;
  END
$$;

comment on function assign_luid_if_null() is 'This function assumes that there is a column name luid. If the column has null value, then this method assigns a uuid to it';

alter function assign_luid_if_null() owner to rails;

