create function set_ss_vs_field_name_to_null() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.vs_field_name = NULL;
  RETURN NEW;
END;
$$;

alter function set_ss_vs_field_name_to_null() owner to rails;

