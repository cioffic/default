create view users_view(email, login_at, name, sys, id, system_user_id) as
SELECT system_users.email,
       users.login_at,
       system_users.name,
       system_users.sys,
       users.id,
       system_users.id AS system_user_id
FROM system_users,
     users
WHERE system_users.id = users.system_user_id;

comment on view users_view is 'Each record corresponds to a user on the system.  The data presented is a combination of user data and data from the linked system_user.';

comment on column users_view.email is 'The email of the system_user.';

comment on column users_view.login_at is 'The last time the system_user logged in.';

comment on column users_view.name is 'The name of the system_user.';

comment on column users_view.sys is 'SUPPRESS_DOC_OUTPUT: Is this ever anything but false?';

comment on column users_view.id is 'The id of the underlying users record.';

comment on column users_view.system_user_id is 'The id of the linked system_users record.';

alter table users_view
    owner to rails;

