create function system_users_sync_password_on_insert() returns trigger
    language plpgsql
as
$$
begin
	if (NEW.hashed_password is not null) then
		NEW.protected_password := '[t0]' || NEW.salt || '$' || NEW.hashed_password;
	elsif ((NEW.protected_password is not null) 
		and (substring(NEW.protected_password from 1 for 4) = '[t0]')
		and (char_length(NEW.protected_password) > 44)) then
		NEW.hashed_password := substring(NEW.protected_password from (char_length(NEW.protected_password) - 39));
		NEW.salt := substring(NEW.protected_password from 5 for (char_length(NEW.protected_password) - 45));
	end if;
	return new;
end
$$;

alter function system_users_sync_password_on_insert() owner to rails;

