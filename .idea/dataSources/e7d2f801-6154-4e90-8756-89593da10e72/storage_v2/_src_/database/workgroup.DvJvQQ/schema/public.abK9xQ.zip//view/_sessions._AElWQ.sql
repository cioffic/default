create view _sessions(session_id, updated_at, user_id, user_name, system_user_id, site_id) as
SELECT sessions.session_id,
       sessions.updated_at,
       sessions.user_id,
       system_users.name AS user_name,
       users.system_user_id,
       users.site_id
FROM sessions,
     system_users,
     users
WHERE sessions.user_id = users.id
  AND users.system_user_id = system_users.id;

comment on view _sessions is 'Settings associated with a user''s browser session.';

comment on column _sessions.session_id is 'Session identifier.';

comment on column _sessions.updated_at is 'Time when session was last updated, used to expire inactive sessions.';

comment on column _sessions.user_id is 'Foreign key to users table.  Tells the user whose session this is.';

comment on column _sessions.user_name is 'The name of the system_user linked to the user whose session this is.';

comment on column _sessions.system_user_id is 'The id of the system_user linked to the user whose session this is.';

comment on column _sessions.site_id is 'The site that this session belongs to.';

alter table _sessions
    owner to rails;

