create view _views
            (id, name, view_url, created_at, owner_id, owner_name, workbook_id, index, title, caption, site_id) as
SELECT views.id,
       views.name,
       regexp_replace(views.repository_url, '/sheets'::text, ''::text) AS view_url,
       views.created_at,
       views.owner_id,
       owner.name                                                      AS owner_name,
       views.workbook_id,
       views.index,
       views.title,
       views.caption,
       views.site_id
FROM views,
     users,
     system_users owner
WHERE views.owner_id = users.id
  AND users.system_user_id = owner.id
  AND views.site_id = users.site_id;

comment on view _views is 'Each records represents a view in a workbook.';

comment on column _views.id is 'Primary key for the underlying views record.';

comment on column _views.name is 'The name of the view.';

comment on column _views.view_url is 'Uniquely identifies a view.  More or less composed of workbook and sheet names, but not totally obviously, especially in the presence of non-ASCII characters.  Used in URLs meant to access this view.';

comment on column _views.created_at is 'The time at which the underlying views record was created.';

comment on column _views.owner_id is 'A foreign key reference to the user who owns this view.';

comment on column _views.owner_name is 'The name of the user who owns this view.';

comment on column _views.workbook_id is 'A foreign key reference to the workbook the view is part of.';

comment on column _views.index is 'Each view has an index that is unique among views belonging to that workbook.';

comment on column _views.title is 'A title for the worksheet extracted from the workbook''s twb file.';

comment on column _views.caption is 'A descriptive phrase constructed for the worksheet, based on the workbook definition.';

comment on column _views.site_id is 'A foreign key link to the site to which this view belongs.';

alter table _views
    owner to rails;

