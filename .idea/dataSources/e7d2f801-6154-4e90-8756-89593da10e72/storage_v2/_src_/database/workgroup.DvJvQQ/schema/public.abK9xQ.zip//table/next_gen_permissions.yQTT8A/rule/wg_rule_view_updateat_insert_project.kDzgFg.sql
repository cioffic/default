CREATE RULE wg_rule_view_updateat_insert_project AS
    ON INSERT TO next_gen_permissions
   WHERE new.authorizable_type::text = 'Project'::text DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
   FROM workbooks w
  WHERE w.id = views.workbook_id AND w.project_id = new.authorizable_id;

