create function update_system_user_subscription_license_role_after_change() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE system_users
  SET subscription_licensing_role_id = get_subscription_license_role_id_by_site_role_id(NEW.system_user_id)
  WHERE id = NEW.system_user_id;
  RETURN NEW;
END
$$;

alter function update_system_user_subscription_license_role_after_change() owner to rails;

