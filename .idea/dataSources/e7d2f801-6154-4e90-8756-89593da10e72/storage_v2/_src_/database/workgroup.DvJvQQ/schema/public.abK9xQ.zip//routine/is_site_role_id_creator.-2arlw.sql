create function is_site_role_id_creator(user_site_role_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
  RETURN user_site_role_id IN (SELECT id FROM site_roles WHERE name IN ('SiteAdministratorAuthor', 'Author'));
END
$$;

alter function is_site_role_id_creator(integer) owner to rails;

