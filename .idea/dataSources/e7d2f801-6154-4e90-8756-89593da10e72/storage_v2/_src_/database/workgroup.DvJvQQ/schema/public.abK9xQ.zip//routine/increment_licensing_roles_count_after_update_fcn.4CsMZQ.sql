create function increment_licensing_roles_count_after_update_fcn() returns trigger
    language plpgsql
as
$$
BEGIN
  IF OLD.system_user_id = NEW.system_user_id THEN
    PERFORM increment_licensing_roles_count_if_found(NEW.system_user_id);
  ELSE
    PERFORM increment_licensing_roles_count_if_found(OLD.system_user_id);
    PERFORM increment_licensing_roles_count_if_found(NEW.system_user_id);
  END IF;
  RETURN NEW;
END
$$;

alter function increment_licensing_roles_count_after_update_fcn() owner to rails;

