create function disallow_user_prefs_for_guest_user() returns trigger
    language plpgsql
as
$$
BEGIN
  IF exists (SELECT u.system_user_id FROM users u, site_roles AS s where s.name = 'Guest' and s.id = u.site_role_id and u.system_user_id = NEW.system_user_id) THEN
    RETURN NULL;
  ELSE
    RETURN NEW;
  END IF;
END
$$;

alter function disallow_user_prefs_for_guest_user() owner to rails;

