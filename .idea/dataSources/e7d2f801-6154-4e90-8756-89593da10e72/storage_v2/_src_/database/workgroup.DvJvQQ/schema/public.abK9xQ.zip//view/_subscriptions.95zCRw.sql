create view _subscriptions
            (id, subject, content_type, view_url, workbook_url, customized_view_id, last_sent, user_id, user_name,
             site_id, site_name, schedule_name, schedule_active, schedule_run_next_at, schedule_priority)
as
SELECT subscriptions.id,
       subscriptions.subject,
       CASE
           WHEN (subscriptions_customized_views.customized_view_id IS NULL AND false OR
                 NOT subscriptions_customized_views.customized_view_id IS NULL AND NOT false) AND
                (subscriptions_views.subscription_id IS NULL AND false OR
                 NOT subscriptions_views.subscription_id IS NULL AND NOT false) THEN 'Customized View - Single View'::text
           WHEN (subscriptions_customized_views.customized_view_id IS NULL AND false OR
                 NOT subscriptions_customized_views.customized_view_id IS NULL AND NOT false) AND
                (subscriptions_workbooks.subscription_id IS NULL AND false OR
                 NOT subscriptions_workbooks.subscription_id IS NULL AND NOT false) THEN 'Customized View - Workbook'::text
           WHEN subscriptions_views.subscription_id IS NULL AND false OR
                NOT subscriptions_views.subscription_id IS NULL AND NOT false THEN 'Single View'::text
           WHEN subscriptions_workbooks.subscription_id IS NULL AND false OR
                NOT subscriptions_workbooks.subscription_id IS NULL AND NOT false THEN 'Workbook'::text
           ELSE 'Unknown'::text
           END                                                                       AS content_type,
       regexp_replace(subscriptions_views.repository_url, '/sheets'::text, ''::text) AS view_url,
       subscriptions_workbooks.repository_url                                        AS workbook_url,
       subscriptions_customized_views.customized_view_id,
       subscriptions.last_sent,
       subscriptions.user_id,
       _users.name                                                                   AS user_name,
       _sites.id                                                                     AS site_id,
       _sites.name                                                                   AS site_name,
       schedules.name                                                                AS schedule_name,
       schedules.active                                                              AS schedule_active,
       schedules.run_next_at                                                         AS schedule_run_next_at,
       schedules.priority                                                            AS schedule_priority
FROM subscriptions subscriptions
         LEFT JOIN subscriptions_views subscriptions_views ON subscriptions.id = subscriptions_views.subscription_id
         LEFT JOIN subscriptions_workbooks subscriptions_workbooks
                   ON subscriptions.id = subscriptions_workbooks.subscription_id
         LEFT JOIN subscriptions_customized_views subscriptions_customized_views
                   ON subscriptions.id = subscriptions_customized_views.subscription_id
         JOIN schedules schedules ON subscriptions.schedule_id = schedules.id
         JOIN _users _users ON subscriptions.user_id = _users.id
         JOIN _sites _sites ON _users.site_id = _sites.id;

comment on view _subscriptions is 'Each record provides information about subscriptions that are scheduled.  Subscriptions are a mechanism for receiving specified content by email on some schedule.';

comment on column _subscriptions.id is 'Primary key for the underlying subscriptions record.';

comment on column _subscriptions.subject is 'A string that describes the nature of the subscription.';

comment on column _subscriptions.content_type is 'Describes what type of content is being delivered by this subscription. One of: "Customized View - Single View", "Workbook", "Single View", or "Customized View - Workbook".';

comment on column _subscriptions.view_url is 'A URL string that describes the view to be delivered, when the subscription is for a view.';

comment on column _subscriptions.workbook_url is 'A URL string that describes the workbook to be delivered, when the subscription is for a workbook.';

comment on column _subscriptions.customized_view_id is 'A foreign key reference to the customized view, if the subscription is for a customized view.';

comment on column _subscriptions.last_sent is 'The last time at which the the subscription was sent.';

comment on column _subscriptions.user_id is 'A foreign key reference to the user who will receive the subscription.';

comment on column _subscriptions.user_name is 'The name of the system_user who will receive the subscription.';

comment on column _subscriptions.site_id is 'The site that the subscription (and the user) belongs to.';

comment on column _subscriptions.site_name is 'The name of the site that the subscription (and the user) belongs to.';

comment on column _subscriptions.schedule_name is 'The name of the schedule that this subscription runs under.';

comment on column _subscriptions.schedule_active is 'If set to false, this means that the subscription is inactive.';

comment on column _subscriptions.schedule_run_next_at is 'The next time the subscription should be sent.';

comment on column _subscriptions.schedule_priority is 'Priority can range from 1 to 100, with lower values corresponding to higher priority.';

alter table _subscriptions
    owner to rails;

