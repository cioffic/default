create function set_hidden_name_in_datasources() returns trigger
    language plpgsql
as
$$
BEGIN
                -- This code should be noop if hidden_name is set.
                UPDATE datasources AS ds 
                SET hidden_name = NEW.name
                WHERE ds.id = NEW.datasource_id
                AND ds.hidden_name IS NULL;
                
                RETURN NEW;
            END;
$$;

alter function set_hidden_name_in_datasources() owner to rails;

