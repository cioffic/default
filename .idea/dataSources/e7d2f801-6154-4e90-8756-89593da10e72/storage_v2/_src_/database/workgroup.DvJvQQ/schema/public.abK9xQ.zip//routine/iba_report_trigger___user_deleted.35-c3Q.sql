create function iba_report_trigger___user_deleted() returns trigger
    language plpgsql
as
$$
DECLARE
    iba_user_row_change identity_based_activation_user_role_change%ROWTYPE;
BEGIN
   SELECT * INTO iba_user_row_change from identity_based_activation_user_role_change ibaurc
   WHERE ibaurc.user_luid = OLD.luid::text AND ibaurc.site_id = OLD.site_id;
-- If record == null Do Nothing
-- ElseIf record.role_assigned = null Do Nothing
-- ElseIf record.role_unassigned = null then role_unassigned = now();
-- ElseIf record.role_assigned > role_unassigned then role_unassigned = now();
  IF iba_user_row_change is null THEN
    -- Do Nothing
  ELSEIF iba_user_row_change.date_creator_role_assigned is null then
    -- Do Nothing
  ELSEIF iba_user_row_change.date_creator_role_unassigned is null then
    UPDATE identity_based_activation_user_role_change
    SET date_creator_role_unassigned = now()
    WHERE OLD.luid::text = identity_based_activation_user_role_change.user_luid;
  ELSEIF iba_user_row_change.date_creator_role_assigned > iba_user_row_change.date_creator_role_unassigned then
    UPDATE identity_based_activation_user_role_change
    SET date_creator_role_unassigned = now()
    WHERE OLD.luid::text = identity_based_activation_user_role_change.user_luid;
  END IF;
 RETURN NEW;
END;
$$;

alter function iba_report_trigger___user_deleted() owner to rails;

