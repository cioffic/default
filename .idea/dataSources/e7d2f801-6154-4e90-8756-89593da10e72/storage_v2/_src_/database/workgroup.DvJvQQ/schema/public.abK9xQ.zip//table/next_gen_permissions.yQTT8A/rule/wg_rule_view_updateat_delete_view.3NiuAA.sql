CREATE RULE wg_rule_view_updateat_delete_view AS
    ON DELETE TO next_gen_permissions
   WHERE old.authorizable_type::text = 'View'::text DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
  WHERE views.id = old.authorizable_id;

