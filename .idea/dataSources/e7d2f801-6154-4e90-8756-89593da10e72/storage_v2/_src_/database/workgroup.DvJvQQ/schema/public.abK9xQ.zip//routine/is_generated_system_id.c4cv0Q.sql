create function is_generated_system_id(system_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
  RETURN system_id IN (SELECT id FROM system_users WHERE name IN ('_system', 'guest'));
END
$$;

alter function is_generated_system_id(integer) owner to rails;

