create function replace_with_publish_site_roles() returns trigger
    language plpgsql
as
$$
DECLARE
  -- Site Role Constants
  VIEWER_WITH_PUBLISH_SITE_ROLE CONSTANT integer = 4;
  UNLICENSED_WITH_PUBLISH_SITE_ROLE CONSTANT integer = 6;
BEGIN
  -- Repurposing Unlicensed Can Publish and Viewer Can Publish site roles
  IF NEW.site_role_id = UNLICENSED_WITH_PUBLISH_SITE_ROLE THEN
    NEW.site_role_id := (SELECT sr.id FROM site_roles AS sr WHERE sr.name = 'Unlicensed');
  ELSIF NEW.site_role_id = VIEWER_WITH_PUBLISH_SITE_ROLE THEN
    NEW.site_role_id := (SELECT sr.id FROM site_roles AS sr WHERE sr.name = 'Viewer');
  END IF;
  RETURN NEW;
END
$$;

alter function replace_with_publish_site_roles() owner to rails;

