create function generate_uuid_safer() returns uuid
    language plpgsql
as
$$
DECLARE
unique_id uuid;
newer_unique_id uuid;
BEGIN
  unique_id:=uuid_generate_v4();
  LOOP
    newer_unique_id:=uuid_generate_v4();
    IF newer_unique_id!=unique_id THEN
      RETURN newer_unique_id;
    END IF;
  END LOOP;
END;
$$;

comment on function generate_uuid_safer() is 'This function is meant to be a safer version than the builtin postgres uuid generator with respect to avoiding collisions';

alter function generate_uuid_safer() owner to rails;

