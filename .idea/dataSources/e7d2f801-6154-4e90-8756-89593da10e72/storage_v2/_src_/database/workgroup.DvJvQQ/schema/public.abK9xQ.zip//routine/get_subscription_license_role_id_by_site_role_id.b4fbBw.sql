create function get_subscription_license_role_id_by_site_role_id(input_system_user_id integer) returns integer
    language plpgsql
as
$$
DECLARE
  MAX_SITE_ROLE_ID integer;
BEGIN
  MAX_SITE_ROLE_ID := (
    SELECT site_role_id
    FROM users AS u
      INNER JOIN site_roles AS sr ON u.site_role_id = sr.id
    WHERE u.system_user_id = input_system_user_id
    ORDER BY sr.licensing_rank DESC NULLS LAST LIMIT 1
  );
  
  RETURN (
      SELECT licensing_role_id
      FROM get_licensing_role_for_site_role()
      WHERE site_role_id = MAX_SITE_ROLE_ID
  );
END
$$;

alter function get_subscription_license_role_id_by_site_role_id(integer) owner to rails;

