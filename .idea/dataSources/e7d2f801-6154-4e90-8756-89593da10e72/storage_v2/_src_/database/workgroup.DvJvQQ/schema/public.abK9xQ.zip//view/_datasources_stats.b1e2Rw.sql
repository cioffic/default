create view _datasources_stats(nviews, last_access_time, datasource_id, site_id) as
SELECT count(1)                          AS nviews,
       max(historical_events.created_at) AS last_access_time,
       hist_datasources.datasource_id,
       hist_sites.site_id
FROM historical_events,
     hist_datasources,
     hist_sites,
     historical_event_types
WHERE historical_events.hist_datasource_id = hist_datasources.id
  AND historical_events.hist_target_site_id = hist_sites.id
  AND historical_events.historical_event_type_id = historical_event_types.type_id
  AND (historical_event_types.name = 'Access Data Source'::text OR
       historical_event_types.name = 'Download Data Source'::text)
GROUP BY hist_datasources.datasource_id, hist_sites.site_id;

comment on view _datasources_stats is 'Some historical useage information about datasources.  Based on the records that exist in the historical events tables.';

comment on column _datasources_stats.nviews is 'The number of times that the datasource has been accessed.';

comment on column _datasources_stats.last_access_time is 'The most recent access of the datasource';

comment on column _datasources_stats.datasource_id is 'Links to the datasource whose usage is being described.';

comment on column _datasources_stats.site_id is 'The site in which this datasource exists.';

alter table _datasources_stats
    owner to rails;

