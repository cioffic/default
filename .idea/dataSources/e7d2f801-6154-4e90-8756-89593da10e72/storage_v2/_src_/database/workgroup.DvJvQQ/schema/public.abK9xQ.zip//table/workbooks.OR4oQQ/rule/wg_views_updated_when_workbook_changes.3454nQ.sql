CREATE RULE wg_views_updated_when_workbook_changes AS
    ON UPDATE TO workbooks DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
  WHERE views.workbook_id = old.id;

