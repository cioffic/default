create view _sites(id, name, url_namespace, status) as
SELECT sites.id,
       sites.name,
       sites.url_namespace,
       sites.status
FROM sites;

comment on view _sites is 'Each record represents a site. Each site holds its own workbooks, datasources, users, etc.  Strict isolation between the contents of each site is maintained.';

comment on column _sites.id is 'Primary key for the underlying sites record.';

comment on column _sites.name is 'The name of the site.';

comment on column _sites.url_namespace is 'String used in the construction of URLs that target this site.';

comment on column _sites.status is 'One of "active" "suspended" or "locked".';

alter table _sites
    owner to rails;

