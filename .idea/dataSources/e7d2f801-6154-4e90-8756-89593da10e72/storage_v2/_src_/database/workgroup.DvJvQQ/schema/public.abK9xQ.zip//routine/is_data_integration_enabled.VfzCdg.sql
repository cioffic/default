create function is_data_integration_enabled() returns boolean
    language plpgsql
as
$$
DECLARE
            returnVal boolean;
        BEGIN
            BEGIN
                SELECT current_setting('vizportal.dataIntegration') INTO returnVal;
            EXCEPTION
                -- current_setting throws an exception if the setting is unknown.
                -- We should hit this exception when postgres is not restarted to load postgres.conf file.
                -- In online environment postgres is not restarted.
                when others then returnVal := FALSE;
            END;
            return returnVal;
        END;
$$;

alter function is_data_integration_enabled() owner to rails;

