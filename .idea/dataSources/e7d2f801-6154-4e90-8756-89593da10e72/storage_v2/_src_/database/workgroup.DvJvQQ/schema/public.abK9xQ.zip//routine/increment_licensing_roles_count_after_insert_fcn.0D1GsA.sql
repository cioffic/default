create function increment_licensing_roles_count_after_insert_fcn() returns trigger
    language plpgsql
as
$$
BEGIN
  PERFORM increment_licensing_roles_count_if_found(NEW.system_user_id);
  RETURN NEW;
END
$$;

alter function increment_licensing_roles_count_after_insert_fcn() owner to rails;

