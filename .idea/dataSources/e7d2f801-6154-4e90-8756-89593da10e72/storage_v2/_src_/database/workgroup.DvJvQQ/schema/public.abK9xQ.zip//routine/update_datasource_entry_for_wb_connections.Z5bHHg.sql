create function update_datasource_entry_for_wb_connections() returns trigger
    language plpgsql
as
$$
BEGIN
		-- This code should be noop if feature flag is enabled.
		IF (is_data_integration_enabled() IS FALSE AND TG_OP = 'UPDATE') THEN
			UPDATE datasources SET owner_id = NEW.owner_id, project_id = NEW.project_id,
					document_version = NEW.document_version, content_version = NEW.content_version,
                    updated_at = NEW.updated_at
					where parent_workbook_id = OLD.id;
		END IF;
		RETURN NEW;
	END;
$$;

alter function update_datasource_entry_for_wb_connections() owner to rails;

