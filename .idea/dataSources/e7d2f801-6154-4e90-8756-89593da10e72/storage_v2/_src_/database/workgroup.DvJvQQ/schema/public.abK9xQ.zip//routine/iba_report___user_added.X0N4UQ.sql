create function iba_report___user_added() returns trigger
    language plpgsql
as
$$
BEGIN
-- If NEW site_role_id IN creator role THEN insert/update with date_creator_role_assigned = current date_time
  IF NOT is_generated_system_id(new.system_user_id) Then
    IF is_site_role_id_creator(NEW.site_role_id) THEN
       INSERT INTO public.identity_based_activation_user_role_change
       (site_id, user_luid, site_role_id, system_user_id, system_user_name, date_creator_role_assigned, date_creator_role_unassigned)
       VALUES(NEW.site_id, NEW.luid, NEW.site_role_id, NEW.system_user_id, (SELECT name FROM system_users WHERE id = NEW.system_user_id), now(), null)
       ON CONFLICT (site_id, user_luid)
       DO 
         UPDATE
         SET date_creator_role_assigned = now(),
             site_role_id = NEW.site_role_id;
    ELSE
  -- Otherwise NEW value NOT IN creator role 
      INSERT INTO public.identity_based_activation_user_role_change
      (site_id, user_luid, site_role_id, system_user_id, system_user_name, date_creator_role_assigned, date_creator_role_unassigned)
      VALUES(NEW.site_id, NEW.luid, NEW.site_role_id, NEW.system_user_id, (SELECT name from system_users WHERE id = NEW.system_user_id), null, null)
      ON CONFLICT (site_id, user_luid)
      DO
        NOTHING;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

alter function iba_report___user_added() owner to rails;

