create function add_creator_id_for_subscriptions() returns trigger
    language plpgsql
as
$$
BEGIN
        NEW.creator_id = NEW.user_id;
        RETURN NEW;
      END
$$;

alter function add_creator_id_for_subscriptions() owner to rails;

