create function replace_read_only_site_roles() returns trigger
    language plpgsql
as
$$
DECLARE
  -- Site Role Constants
  READ_ONLY_SITE_ROLE CONSTANT integer = 5;
BEGIN
  IF NEW.site_role_id = READ_ONLY_SITE_ROLE THEN
    NEW.site_role_id := (SELECT sr.id FROM site_roles AS sr WHERE sr.name = 'BasicUser' AND sr.id = 9); -- new Viewer
  END IF;
  RETURN NEW;
END
$$;

alter function replace_read_only_site_roles() owner to rails;

