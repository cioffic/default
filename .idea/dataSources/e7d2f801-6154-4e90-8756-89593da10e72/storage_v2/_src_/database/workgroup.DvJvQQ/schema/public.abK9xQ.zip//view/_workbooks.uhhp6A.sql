create view _workbooks
            (id, name, workbook_url, created_at, updated_at, owner_id, project_id, size, view_count, owner_name,
             project_name, system_user_id, site_id, domain_id, domain_name)
as
SELECT workbooks.id,
       workbooks.name,
       workbooks.repository_url AS workbook_url,
       workbooks.created_at,
       workbooks.updated_at,
       workbooks.owner_id,
       workbooks.project_id,
       workbooks.size,
       workbooks.view_count,
       owner.name               AS owner_name,
       projects.name            AS project_name,
       users.system_user_id,
       workbooks.site_id,
       domains.id               AS domain_id,
       domains.name             AS domain_name
FROM workbooks,
     system_users owner,
     projects,
     users,
     domains
WHERE workbooks.owner_id = users.id
  AND workbooks.project_id = projects.id
  AND users.system_user_id = owner.id
  AND workbooks.site_id = users.site_id
  AND owner.domain_id = domains.id;

comment on view _workbooks is 'Each record represents a workbook that exists on the server.';

comment on column _workbooks.id is 'The primary key for the underlying workbook record.';

comment on column _workbooks.name is 'The name of the workbook.';

comment on column _workbooks.workbook_url is 'A unique name for the workbook, derived from the ASCII characters in the name, which can be used in URLs to refer to this workbook.';

comment on column _workbooks.created_at is 'The time at which the workbook record was created.';

comment on column _workbooks.updated_at is 'The last time any changes were made to this workbook record.';

comment on column _workbooks.owner_id is 'A foreign key reference to the user that owns this workbook.';

comment on column _workbooks.project_id is 'A foreign key reference to the project in which this workbook exists.';

comment on column _workbooks.size is 'The number of bytes used in storing the workbook information.';

comment on column _workbooks.view_count is 'Keeps count of the number of views that are associated with this workbook.';

comment on column _workbooks.owner_name is 'The name of the system_user who is the owner.';

comment on column _workbooks.project_name is 'The name of the project that this workbook is part of.';

comment on column _workbooks.system_user_id is 'The id of the system_user who is the owner.';

comment on column _workbooks.site_id is 'Links to the site that contains this workbook.';

comment on column _workbooks.domain_id is 'A foreign key reference to the domain of the owner.';

comment on column _workbooks.domain_name is 'The name is either "local" or the name of some Active Directory group.';

alter table _workbooks
    owner to rails;

