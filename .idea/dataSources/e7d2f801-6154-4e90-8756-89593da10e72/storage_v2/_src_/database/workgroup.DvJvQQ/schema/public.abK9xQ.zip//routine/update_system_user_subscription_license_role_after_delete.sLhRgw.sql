create function update_system_user_subscription_license_role_after_delete() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE system_users
  SET subscription_licensing_role_id = get_subscription_license_role_id_by_site_role_id(OLD.system_user_id)
  WHERE id = OLD.system_user_id;
  RETURN OLD;
END
$$;

alter function update_system_user_subscription_license_role_after_delete() owner to rails;

