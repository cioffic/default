create function get_default_guest_setting() returns boolean
    language sql
as
$$
SELECT CAST(value AS BOOLEAN) FROM global_settings WHERE name = 'enable_guest'
$$;

alter function get_default_guest_setting() owner to rails;

