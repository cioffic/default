create function is_site_role_id_admin(user_site_role_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
  RETURN user_site_role_id IN (SELECT id FROM site_roles WHERE name IN ('SiteAdministrator', 'SupportUser', 'SiteAdministratorAuthor'));
END
$$;

alter function is_site_role_id_admin(integer) owner to rails;

