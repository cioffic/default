create function get_content_ids_with_different_permissions_templates_from_proje(templatetype text, projectid integer, contenttype text, contentids integer[], capabilityids integer[]) returns SETOF integer
    stable
    language sql
as
$$
WITH cids AS (SELECT * FROM unnest($4) AS content_id),
     capability_ids AS (SELECT * FROM unnest($5) AS capability_id)
SELECT DISTINCT COALESCE(t_p.content_id, t_w.content_id)
FROM
(
  (
  SELECT grantee_id, grantee_type, capability_id, permission, cids.content_id
    FROM permissions_templates
    CROSS JOIN cids
    WHERE template_type = $1
    AND   project_id = $2
    AND   capability_id IN (SELECT capability_id FROM capability_ids)
  ) AS t_p
  FULL OUTER JOIN
  (
  SELECT grantee_id, grantee_type, capability_id, permission, authorizable_id AS content_id
    FROM next_gen_permissions
    WHERE authorizable_type = $3
    AND   authorizable_id IN (SELECT content_id FROM cids)
    AND   capability_id IN (SELECT capability_id FROM capability_ids)
  ) AS t_w
  ON  t_w.content_id = t_p.content_id
  AND t_w.grantee_id = t_p.grantee_id 
  AND t_w.grantee_type = t_p.grantee_type
  AND t_w.capability_id = t_p.capability_id
  AND t_w.permission = t_p.permission
)
WHERE t_p.content_id IS DISTINCT FROM t_w.content_id


$$;

alter function get_content_ids_with_different_permissions_templates_from_proje(text, integer, text, integer[], integer[]) owner to rails;

