create function process_datasource_event() returns trigger
    language plpgsql
as
$$
BEGIN
  --
  -- Create a row in datasource_events to reflect the operation performed on
  -- datasources, excluding embedded datasources (parentWorkbookId != null).
  -- Make use of special variable TG_OP to work out the operation.
  --
  -- Handle conflicts which come from multiple operations on the datasources table
  -- within a single transaction (same timestamp).
  --
  IF (TG_OP = 'DELETE') THEN
    IF (OLD.parent_workbook_id NOTNULL) THEN
      RETURN NULL;
    END IF;
    INSERT INTO datasource_events (datasource_id, site_id, event_time, event_type)
    VALUES (OLD.id, OLD.site_id, now(), 3)
    ON CONFLICT ON CONSTRAINT unique_event_time_datasource_id DO UPDATE
      SET event_type=3;
    RETURN OLD;
  ELSIF (TG_OP = 'UPDATE' AND NEW.id > 0) THEN
    IF (NEW.parent_workbook_id NOTNULL) THEN
      RETURN NULL;
    END IF;
    INSERT INTO datasource_events (datasource_id, site_id, event_time, event_type)
    VALUES (NEW.id, NEW.site_id, now(), 2)
    ON CONFLICT ON CONSTRAINT unique_event_time_datasource_id DO NOTHING;
    RETURN NEW;
  ELSIF (TG_OP = 'INSERT') THEN
    IF (NEW.parent_workbook_id NOTNULL) THEN
      RETURN NULL;
    END IF;
    INSERT INTO datasource_events (datasource_id, site_id, event_time, event_type)
    VALUES (NEW.id, NEW.site_id, now(), 1)
    ON CONFLICT ON CONSTRAINT unique_event_time_datasource_id DO UPDATE
      SET event_type=1;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

alter function process_datasource_event() owner to rails;

