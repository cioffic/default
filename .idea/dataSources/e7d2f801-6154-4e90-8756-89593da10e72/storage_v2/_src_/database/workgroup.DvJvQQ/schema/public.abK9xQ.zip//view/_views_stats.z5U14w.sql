create view _views_stats
            (users_id, system_users_name, users_login_at, system_users_friendly_name, views_id, system_users_id,
             views_name, views_url, views_workbook_id, views_created_at, views_owner_id, views_index, views_title,
             views_caption, device_type, nviews, last_view_time, site_id)
as
SELECT views_stats.user_id        AS users_id,
       system_users.name          AS system_users_name,
       users.login_at             AS users_login_at,
       system_users.friendly_name AS system_users_friendly_name,
       views_stats.view_id        AS views_id,
       system_users.id            AS system_users_id,
       views.name                 AS views_name,
       views.repository_url       AS views_url,
       views.workbook_id          AS views_workbook_id,
       views.created_at           AS views_created_at,
       views.owner_id             AS views_owner_id,
       views.index                AS views_index,
       views.title                AS views_title,
       views.caption              AS views_caption,
       views_stats.device_type,
       views_stats.nviews,
       views_stats."time"         AS last_view_time,
       users.site_id
FROM views_stats,
     system_users,
     users,
     views
WHERE views_stats.user_id = users.id
  AND views_stats.view_id = views.id
  AND system_users.id = users.system_user_id;

comment on view _views_stats is 'Used to track how many times each user has accessed different views.';

comment on column _views_stats.users_id is 'A foreign key reference to a particular user.';

comment on column _views_stats.system_users_name is 'The name of the system_user that corresponds to the user.';

comment on column _views_stats.users_login_at is 'The time of the most recent login for this user.';

comment on column _views_stats.system_users_friendly_name is 'The friendly_name of the system_user that corresponds to the user.';

comment on column _views_stats.views_id is 'A foreign key reference to the view that was accessed. This field must be populated.';

comment on column _views_stats.system_users_id is 'The id of the system_user that corresponds to the user.';

comment on column _views_stats.views_name is 'The name of the view that was accessed.';

comment on column _views_stats.views_url is 'Uniquely identifies a view.  More or less composed of workbook and sheet names, but not totally obviously, especially in the presence of non-ASCII characters.  Used in URLs meant to access this view.';

comment on column _views_stats.views_workbook_id is 'A foreign key reference to the workbook the view is part of.';

comment on column _views_stats.views_created_at is 'The time at which the view was created.';

comment on column _views_stats.views_owner_id is 'A foreign key reference to the user who owns the view.';

comment on column _views_stats.views_index is 'Each view has an index that is unique among views belonging to that workbook.';

comment on column _views_stats.views_title is 'A title for the worksheet extracted from the workbook''s twb file.';

comment on column _views_stats.views_caption is 'A descriptive phrase constructed for the worksheet, based on the workbook definition.';

comment on column _views_stats.device_type is 'DSD device type detected (non-null only if view is dashboard in non-authoring mode)';

comment on column _views_stats.nviews is 'Keeps a cumulative count of the number of times the view was accessed by this user.';

comment on column _views_stats.last_view_time is 'The time of the most recent access of the specified view by the specified user.';

comment on column _views_stats.site_id is 'Links to the site that contains the view.';

alter table _views_stats
    owner to rails;

