create function cleanup_old_deleted_objects() returns trigger
    language plpgsql
as
$$
BEGIN
        DELETE FROM deleted_objects
        WHERE updated_at + 30 * '1 day'::interval < (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::timestamp without time zone;
        RETURN NULL;
    END;
$$;

alter function cleanup_old_deleted_objects() owner to rails;

