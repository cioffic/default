create view _system_users
            (id, name, email, friendly_name, custom_display_name, state, admin_level, domain_name, domain_short_name,
             domain_family)
as
SELECT sysuser.id,
       sysuser.name,
       sysuser.email,
       sysuser.friendly_name,
       sysuser.custom_display_name,
       sysuser.state,
       sysuser.admin_level,
       domain.name       AS domain_name,
       domain.short_name AS domain_short_name,
       domain.family     AS domain_family
FROM system_users sysuser,
     domains domain
WHERE sysuser.domain_id = domain.id;

comment on view _system_users is 'Each record represents a user of the server. These records correspond to login identity. A single system_user may potentially be able to login to multiple sites. The linkage between a system_user and their allowed sites is defined through the "users" table.';

comment on column _system_users.id is 'Primary key for the underlying system_user record.';

comment on column _system_users.name is 'The username of the user.';

comment on column _system_users.email is 'The email of the user.';

comment on column _system_users.friendly_name is 'A friendly name that might be used in the GUI to refer to the user.';

comment on column _system_users.custom_display_name is 'If set to true, this prevents the friendly_name from potentially being overwritten by Active Airectory information when the user is read in from Active Directory.  Seldom done.';

comment on column _system_users.state is 'SUPPRESS_DOC_OUTPUT';

comment on column _system_users.admin_level is 'Indicates if the user is a system administrator. 10 : system admin, 0 : not a system admin';

comment on column _system_users.domain_name is 'The name of the domain that the user belongs to. The name is either "local" or the name of some Active Directory group.';

comment on column _system_users.domain_short_name is 'An alternate shorter form of the name';

comment on column _system_users.domain_family is 'Either local or ActiveDirectory.';

alter table _system_users
    owner to rails;

