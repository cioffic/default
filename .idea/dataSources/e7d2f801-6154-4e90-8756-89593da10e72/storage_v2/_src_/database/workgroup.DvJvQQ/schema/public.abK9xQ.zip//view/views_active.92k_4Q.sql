create view views_active
            (id, name, repository_url, description, created_at, locked, published, read_count, edit_count,
             datasource_id, workbook_id, index, updated_at, owner_id, fields, title, caption, sheet_id, state,
             sheettype, site_id, repository_data_id, first_published_at, revision, for_cache_updated_at, luid,
             thumbnail_id, is_deleted)
as
SELECT views.id,
       views.name,
       views.repository_url,
       views.description,
       views.created_at,
       views.locked,
       views.published,
       views.read_count,
       views.edit_count,
       views.datasource_id,
       views.workbook_id,
       views.index,
       views.updated_at,
       views.owner_id,
       views.fields,
       views.title,
       views.caption,
       views.sheet_id,
       views.state,
       views.sheettype,
       views.site_id,
       views.repository_data_id,
       views.first_published_at,
       views.revision,
       views.for_cache_updated_at,
       views.luid,
       views.thumbnail_id,
       views.is_deleted
FROM views
WHERE views.is_deleted = false;

comment on view views_active is 'SUPPRESS_DOC_OUTPUT Postgres view representing the active (non-deleted) tableau views';

alter table views_active
    owner to rails;

