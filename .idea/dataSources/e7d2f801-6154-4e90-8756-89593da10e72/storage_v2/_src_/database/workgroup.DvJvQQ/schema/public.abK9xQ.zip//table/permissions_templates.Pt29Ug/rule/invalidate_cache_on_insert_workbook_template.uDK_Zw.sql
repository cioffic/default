CREATE RULE invalidate_cache_on_insert_workbook_template AS
    ON INSERT TO permissions_templates
   WHERE new.template_type::text = 'Workbook'::text AND new.container_type = 'Project'::text DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
   FROM workbooks w
     JOIN projects p ON w.project_id = p.id
  WHERE w.id = views.workbook_id AND p.controlled_permissions_enabled = true AND p.id = new.container_id;

