create function fn_backup_mode_enable() returns void
    language sql
as
$$
UPDATE global_settings SET value = 'true' WHERE name = 'webops_backup_mode'; DELETE FROM sessions s USING users u WHERE (s.user_id = u.id AND u.name != 'guest') OR s.user_id IS NULL;
$$;

alter function fn_backup_mode_enable() owner to rails;

