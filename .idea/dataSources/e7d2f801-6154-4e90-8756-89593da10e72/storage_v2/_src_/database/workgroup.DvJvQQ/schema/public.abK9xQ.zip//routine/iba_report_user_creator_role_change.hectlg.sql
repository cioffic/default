create function iba_report_user_creator_role_change() returns trigger
    language plpgsql
as
$$
BEGIN
   -- If site_role_id changes then update_site_role_id otherwise do nothing.
   IF (OLD.site_role_id IS DISTINCT FROM NEW.site_role_id) then
    UPDATE identity_based_activation_user_role_change
    SET site_role_id = new.site_role_id
    WHERE OLD.luid::text = identity_based_activation_user_role_change.user_luid
    AND OLD.site_id = identity_based_activation_user_role_change.site_id;
	-- If OLD site_role_id NOT IN creator role and NEW site_role_id IN creator role 
	-- -- Then update creator_role_assigned date
	-- BECAUSE we assigned a user a creator role from a non-creator role.
	  IF NOT is_site_role_id_creator(OLD.site_role_id) AND is_site_role_id_creator(NEW.site_role_id) THEN
	    UPDATE identity_based_activation_user_role_change
	    SET date_creator_role_assigned = now()
	    WHERE OLD.luid::text = identity_based_activation_user_role_change.user_luid
	    AND OLD.site_id = identity_based_activation_user_role_change.site_id;
	  END IF;
	-- If OLD site_role_id IN creator role and NEW site_role_id NOT IN creator role 
	-- -- Then update creator_role_unassigned date
	-- BECAUSE we assigned a user a non-creator role from a creator role.
	  IF is_site_role_id_creator(OLD.site_role_id) AND NOT is_site_role_id_creator(NEW.site_role_id) THEN
	    UPDATE identity_based_activation_user_role_change
	    SET date_creator_role_unassigned = now()
	    WHERE OLD.luid::text = identity_based_activation_user_role_change.user_luid
	    AND OLD.site_id = identity_based_activation_user_role_change.site_id;
	  END IF;
  END IF;
  RETURN NEW;
END;
$$;

alter function iba_report_user_creator_role_change() owner to rails;

