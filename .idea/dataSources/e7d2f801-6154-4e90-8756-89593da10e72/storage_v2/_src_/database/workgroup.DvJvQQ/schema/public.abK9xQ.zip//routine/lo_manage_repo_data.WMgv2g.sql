create function lo_manage_repo_data() returns trigger
    language plpgsql
as
$$
BEGIN
            IF (TG_OP = 'DELETE') THEN
                PERFORM lo_unlink(OLD.content);
                RETURN OLD;
            ELSIF ((TG_OP = 'UPDATE') AND ((OLD.content != NEW.content) OR 
                    (OLD.content IS NOT NULL AND NEW.content IS NULL))) THEN
                PERFORM lo_unlink(OLD.content);
                RETURN NEW;
            END IF;
            RETURN NEW;
        END;
$$;

alter function lo_manage_repo_data() owner to rails;

