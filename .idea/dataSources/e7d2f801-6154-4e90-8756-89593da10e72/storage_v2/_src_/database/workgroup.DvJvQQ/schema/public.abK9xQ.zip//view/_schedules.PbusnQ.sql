create view _schedules
            (id, name, active, priority, schedule_type, day_of_week_mask, day_of_month_mask, start_at_minute,
             minute_interval, end_at_minute, end_schedule_at, run_next_at, created_at, updated_at, hidden,
             serial_collection_id, lock_version, scheduled_action, scheduled_action_type, defined_by)
as
SELECT schedules.id,
       schedules.name,
       schedules.active,
       schedules.priority,
       schedules.schedule_type,
       schedules.day_of_week_mask,
       schedules.day_of_month_mask,
       schedules.start_at_minute,
       schedules.minute_interval,
       schedules.end_at_minute,
       schedules.end_schedule_at,
       schedules.run_next_at,
       schedules.created_at,
       schedules.updated_at,
       schedules.hidden,
       schedules.serial_collection_id,
       schedules.lock_version,
       schedules.scheduled_action,
       CASE schedules.scheduled_action
           WHEN 0 THEN 'Refresh Extracts'::text
           WHEN 1 THEN 'Subscriptions'::text
           ELSE 'Others'::text
           END AS scheduled_action_type,
       schedules.defined_by
FROM schedules;

comment on view _schedules is 'Records define a schedule according to which certain regular tasks may be performed (see tasks table). They also indicate the next time at which the schedule will be triggered.';

comment on column _schedules.id is 'Primary key for the record in the underlying schedules table.';

comment on column _schedules.name is 'A schedule can be given a name, which is stored here.';

comment on column _schedules.active is 'If set to false, this means that the schedule is inactive, meaning that no tasks will be performed when the schedules triggers.';

comment on column _schedules.priority is 'Priority can range from 1 to 100, with lower values corresponding to higher priority.';

comment on column _schedules.schedule_type is 'One of 0 (Hourly), 1 (Daily), 2 (Weekly), 3 (Monthly).';

comment on column _schedules.day_of_week_mask is 'Indicates which day of the week this schedule will run.  The information is encoded in the given integer.  To interpret it, convert the integer to binary.  The days of the week correspond to Sunday : 1, Monday : 10, Tuesday : 100, Wednesday : 1000, Thursday : 10000, Friday : 100000, Saturday : 1000000.';

comment on column _schedules.day_of_month_mask is 'Indicates which day of the month this schedule will run.  The information is encoded in the given integer.  To interpret it, convert the integer to binary.  The days of the month correspond to 1st : 1, 2nd: 10, 3rd: 100, 4th: 1000, 5th: 10000, etc.';

comment on column _schedules.start_at_minute is 'The minute following the start of the designated time period implied by the schedule_type.  For example, for a daily schedule, this would be number of minutes past midnight at the start of the day.  For hourly, it would be the number of minutes past the beginning of the hour.';

comment on column _schedules.minute_interval is 'Once the schedule triggers, it will retrigger at this interval during the time period implied by the schedule_type or until end_at_minute, or end_schedule_at.';

comment on column _schedules.end_at_minute is 'The minute following the start of the designated time period implied schedule_type, at which the schedule should stop triggering.';

comment on column _schedules.end_schedule_at is 'Used to indicate a point in time, after which the schedule should never trigger.';

comment on column _schedules.run_next_at is 'When the schedule will next trigger.';

comment on column _schedules.created_at is 'The time at which this record was created.';

comment on column _schedules.updated_at is 'The last time any changes were made to this record.';

comment on column _schedules.hidden is 'If set to true, then this schedule will not be listed in the GUI, otherwise it will be.';

comment on column _schedules.serial_collection_id is 'A foreign key to the serial_collections table.  Two jobs with the same serial_collection_id cannot be processed simultaneously.  When the job record for a task linked to this schedule is created, it is assigned this serial_collection_id.';

comment on column _schedules.lock_version is 'Used to implement "optimistic locking" by JPA/Hibernate.  The counter increases each time the record is changed.  Not useful for customers.';

comment on column _schedules.scheduled_action is 'Used to classify schedules into one of two categories: 0 (Extract related) 1 (Subscription related)';

comment on column _schedules.scheduled_action_type is 'A friendly string representation of the type of scheduled action.';

comment on column _schedules.defined_by is 'The mechanism type of how the schedule is created, e.g. 0 for system_admin, 1 for self_service.';

alter table _schedules
    owner to rails;

