create function replace_with_publish_group_minimum_site_roles() returns trigger
    language plpgsql
as
$$
DECLARE
  -- Site Role Constants
  VIEWER_WITH_PUBLISH_SITE_ROLE CONSTANT varchar = 'VIEWER_WITH_PUBLISH';
  VIEWER_SITE_ROLE CONSTANT varchar = 'VIEWER';
  UNLICENSED_WITH_PUBLISH_SITE_ROLE CONSTANT varchar = 'UNLICENSED_WITH_PUBLISH';
  UNLICENSED_SITE_ROLE CONSTANT varchar = 'UNLICENSED';
BEGIN
  -- Repurposing Unlicensed Can Publish and Viewer Can Publish site roles
  IF NEW.minimum_site_role = UNLICENSED_WITH_PUBLISH_SITE_ROLE THEN
    NEW.minimum_site_role := UNLICENSED_SITE_ROLE;
  ELSIF NEW.minimum_site_role = VIEWER_WITH_PUBLISH_SITE_ROLE THEN
    NEW.minimum_site_role := VIEWER_SITE_ROLE;
  END IF;
  RETURN NEW;
END
$$;

alter function replace_with_publish_group_minimum_site_roles() owner to rails;

