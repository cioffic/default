create function system_users_sync_password_on_update() returns trigger
    language plpgsql
as
$$
begin
	if (NEW.hashed_password is distinct from OLD.hashed_password) then
		if (NEW.hashed_password is null) then
			NEW.protected_password := null;
		else
			NEW.protected_password := '[t0]' || NEW.salt || '$' || NEW.hashed_password;
		end if;
	elsif (NEW.protected_password is distinct from OLD.protected_password) then
		if (NEW.protected_password is null) then
			NEW.hashed_password := null;
			NEW.salt := null;
		elsif ((substring(NEW.protected_password from 1 for 4) = '[t0]') and (char_length(NEW.protected_password) > 44)) then
			NEW.hashed_password := substring(NEW.protected_password from (char_length(NEW.protected_password) - 39));
			NEW.salt := substring(NEW.protected_password from 5 for (char_length(NEW.protected_password) - 45));
		else
			NEW.hashed_password := null;
			NEW.salt := null;
		end if;
	end if;
	return new;
end
$$;

alter function system_users_sync_password_on_update() owner to rails;

