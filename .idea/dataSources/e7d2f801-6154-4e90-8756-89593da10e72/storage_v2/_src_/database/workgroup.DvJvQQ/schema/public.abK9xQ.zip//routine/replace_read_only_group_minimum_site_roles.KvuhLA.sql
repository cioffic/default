create function replace_read_only_group_minimum_site_roles() returns trigger
    language plpgsql
as
$$
DECLARE
  -- Site Role Constants
  READ_ONLY_SITE_ROLE CONSTANT varchar = 'VIEWER';
  BASIC_USER_SITE_ROLE CONSTANT varchar = 'BASIC_USER';
BEGIN
  IF NEW.minimum_site_role = READ_ONLY_SITE_ROLE THEN
    NEW.minimum_site_role := BASIC_USER_SITE_ROLE;
  END IF;
  RETURN NEW;
END
$$;

alter function replace_read_only_group_minimum_site_roles() owner to rails;

