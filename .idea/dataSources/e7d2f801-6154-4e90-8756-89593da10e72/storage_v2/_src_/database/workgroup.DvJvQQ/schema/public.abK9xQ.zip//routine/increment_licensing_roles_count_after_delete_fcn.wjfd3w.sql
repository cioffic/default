create function increment_licensing_roles_count_after_delete_fcn() returns trigger
    language plpgsql
as
$$
BEGIN
  PERFORM increment_licensing_roles_count_if_found(OLD.system_user_id);
  RETURN NULL;
END
$$;

alter function increment_licensing_roles_count_after_delete_fcn() owner to rails;

