CREATE RULE wg_rule_view_updateat_delete_project AS
    ON DELETE TO next_gen_permissions
   WHERE old.authorizable_type::text = 'Project'::text DO  UPDATE views SET for_cache_updated_at = timezone('UTC'::text, now())
   FROM workbooks w
  WHERE w.id = views.workbook_id AND w.project_id = old.authorizable_id;

