create function decrement_licensing_roles_count_if_found(input_system_user_id integer) returns void
    language plpgsql
as
$$
BEGIN
  LOCK TABLE licensing_roles IN SHARE ROW EXCLUSIVE MODE;
  UPDATE licensing_roles lr
  SET licensing_roles_count = licensing_roles_count - 1
  FROM system_users su
  WHERE lr.id = get_subscription_license_role_id_by_site_role_id(input_system_user_id)
    AND input_system_user_id = su.id AND su.name <> '_system'
    AND EXISTS (SELECT 1 FROM users u WHERE u.system_user_id = input_system_user_id);
END
$$;

alter function decrement_licensing_roles_count_if_found(integer) owner to rails;

