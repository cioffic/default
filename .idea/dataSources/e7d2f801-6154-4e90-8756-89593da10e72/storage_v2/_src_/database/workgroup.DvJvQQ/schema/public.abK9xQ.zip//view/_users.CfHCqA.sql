create view _users
            (id, name, login_at, friendly_name, licensing_role_id, licensing_role_name, domain_id, system_user_id,
             domain_name, domain_short_name, site_id)
as
SELECT user_info.id,
       user_info.name,
       user_info.login_at,
       user_info.friendly_name,
       tier_mapping.licensing_role_id,
       tier_mapping.licensing_role_name::character varying(255) AS licensing_role_name,
       user_info.domain_id,
       user_info.system_user_id,
       user_info.domain_name,
       user_info.domain_short_name,
       user_info.site_id
FROM (SELECT users.id,
             system_users.name,
             users.login_at,
             system_users.friendly_name,
             first_value(site_roles.id)
             OVER (PARTITION BY users.system_user_id ORDER BY site_roles.licensing_rank DESC) AS max_site_role_id,
             system_users.domain_id,
             users.system_user_id,
             domains.name                                                                     AS domain_name,
             domains.short_name                                                               AS domain_short_name,
             users.site_id
      FROM system_users
               JOIN users ON users.system_user_id = system_users.id
               JOIN domains ON system_users.domain_id = domains.id
               JOIN site_roles ON users.site_role_id = site_roles.id) user_info
         JOIN get_licensing_role_for_site_role() tier_mapping(site_role_id, licensing_role_id, licensing_role_name)
              ON tier_mapping.site_role_id = user_info.max_site_role_id;

comment on view _users is 'Information relating to users.';

comment on column _users.id is 'Primary key for the underlying user record.';

comment on column _users.name is 'The name of the system_user linked to the user record.';

comment on column _users.login_at is 'The time of the most recent login for this user.';

comment on column _users.friendly_name is 'The friendly name of the system_user linked to the user record.';

comment on column _users.licensing_role_id is 'Foreign key reference to the licensing_roles table. Indicates the licensing role that is assigned to this user.';

comment on column _users.licensing_role_name is 'The name of the licensing role that is assigned to this user.';

comment on column _users.domain_id is 'The domain_id of the system_user linked to the user record.';

comment on column _users.system_user_id is 'The id of the system_user linked to the user record.';

comment on column _users.domain_name is 'The domain_name of the system_user linked to the user record.';

comment on column _users.domain_short_name is 'The a shorter version of the domain_name of the system_user linked to the user record.';

comment on column _users.site_id is 'The id of the site that the user belongs to.';

alter table _users
    owner to rails;

