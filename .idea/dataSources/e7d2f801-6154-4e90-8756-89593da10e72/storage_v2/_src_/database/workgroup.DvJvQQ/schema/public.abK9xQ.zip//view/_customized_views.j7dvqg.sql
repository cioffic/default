create view _customized_views
            (name, repository_url, id, size, view_name, sheet_id, workbook_url, workbook_name, email, user_name,
             site_id) as
SELECT (((s.name::text || '/'::text) || c.name::text))::character varying(255)                                      AS name,
       ((((((((w.repository_url || '/'::text) || v.sheet_id::text) || '/'::text) || s.name::text) ||
           COALESCE('@'::text || d.name::text, ''::text)) || '/'::text) ||
         c.url_id::text))::character varying(255)                                                                   AS repository_url,
       c.id,
       c.size,
       v.name                                                                                                       AS view_name,
       v.sheet_id,
       w.repository_url                                                                                             AS workbook_url,
       w.name                                                                                                       AS workbook_name,
       s.email,
       s.name                                                                                                       AS user_name,
       c.site_id
FROM customized_views c,
     users u,
     views v,
     workbooks w,
     system_users s
         LEFT JOIN domains d ON d.id = s.domain_id AND d.family::text = 'ActiveDirectory'::text
WHERE c.creator_id = u.id
  AND c.view_id = v.id
  AND v.workbook_id = w.id
  AND s.id = u.system_user_id;

comment on view _customized_views is 'When a user creates a customized view, the data that supports that goes in the customized_views table, and is reflected in this view.';

comment on column _customized_views.name is 'A combination of the site name and the customized_view name.';

comment on column _customized_views.repository_url is 'URL text created from workbook, sheet domain, and url_id.';

comment on column _customized_views.id is 'Primary key for the underlying customized_views record.';

comment on column _customized_views.size is 'The number of bytes it took to describe the changes from the base view to the customized view.';

comment on column _customized_views.view_name is 'The name of the view that this customized view is based on.';

comment on column _customized_views.sheet_id is 'An identifier for the sheet.  Based on the name of the sheet.';

comment on column _customized_views.workbook_url is 'A unique name for the workbook, that contains the base view, derived from the ASCII characters in the name, which can be used in URLs to refer to this workbook.';

comment on column _customized_views.workbook_name is 'The actual name of the workbook, that contains the base view, derived from the ASCII characters in the name, which can be used in URLs to refer to this workbook.';

comment on column _customized_views.email is 'The email of the system_user associated with this customized view.';

comment on column _customized_views.user_name is 'The name of the system_user associated with this customized view.';

comment on column _customized_views.site_id is 'A foreign key to the site that this customized view is associated with (the site of the user who created it).';

alter table _customized_views
    owner to rails;

