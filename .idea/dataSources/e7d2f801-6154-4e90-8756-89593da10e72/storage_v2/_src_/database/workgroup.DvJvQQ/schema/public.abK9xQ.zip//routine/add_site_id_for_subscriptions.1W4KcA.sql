create function add_site_id_for_subscriptions() returns trigger
    language plpgsql
as
$$
BEGIN
        SELECT site_id INTO NEW.site_id FROM users WHERE NEW.user_id = users.id;
        RETURN NEW;
      END
$$;

alter function add_site_id_for_subscriptions() owner to rails;

