create view _comments (id, title, comment, commentable_type, created_at, drawing, commentable_id, user_id, site_id) as
SELECT comments.id,
       comments.title,
       comments.comment,
       comments.commentable_type,
       comments.created_at,
       comments.drawing,
       comments.commentable_id,
       comments.user_id,
       users.site_id
FROM comments,
     users
WHERE comments.user_id = users.id;

comment on view _comments is 'Comments users made on views.';

comment on column _comments.id is 'Primary key for the underlying comments record.';

comment on column _comments.title is 'Not used.';

comment on column _comments.comment is 'Comment text.';

comment on column _comments.commentable_type is 'View.';

comment on column _comments.created_at is 'Date when comment was created.';

comment on column _comments.drawing is 'Not used.';

comment on column _comments.commentable_id is 'Corresponding view id.';

comment on column _comments.user_id is 'Id of the user who made the comment.';

comment on column _comments.site_id is 'Links to the site that the user and this comment belong to.';

alter table _comments
    owner to rails;

