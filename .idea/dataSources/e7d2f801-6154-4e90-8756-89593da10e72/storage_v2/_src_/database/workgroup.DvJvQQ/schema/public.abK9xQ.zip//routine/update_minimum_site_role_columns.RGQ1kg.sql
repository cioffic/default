create function update_minimum_site_role_columns() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (OLD.minimum_site_role_id != NEW.minimum_site_role_id) THEN
    NEW.minimum_site_role = CASE NEW.minimum_site_role_id
      WHEN 0 THEN 'SITE_ADMIN'
      WHEN 1 THEN 'SUPPORT_USER'
      WHEN 2 THEN 'PUBLISHER'
      WHEN 3 THEN 'INTERACTOR'
      WHEN 7 THEN 'GUEST'
      WHEN 8 THEN 'UNLICENSED'
      WHEN 9 THEN 'BASIC_USER'
      WHEN 10 THEN 'AUTHOR'
      WHEN 11 THEN 'SITE_ADMIN_AUTHOR'
      END;
  ELSIF (OLD.minimum_site_role != NEW.minimum_site_role) THEN
    NEW.minimum_site_role_id = CASE NEW.minimum_site_role
      WHEN 'SITE_ADMIN' THEN 0
      WHEN 'SUPPORT_USER' THEN 1
      WHEN 'PUBLISHER' THEN 2
      WHEN 'INTERACTOR' THEN 3
      WHEN 'GUEST' THEN 7
      WHEN 'UNLICENSED' THEN 8
      WHEN 'BASIC_USER' THEN 9
      WHEN 'AUTHOR' THEN 10
      WHEN 'SITE_ADMIN_AUTHOR' THEN 11
      END;
  END IF;
RETURN NEW;
END
$$;

alter function update_minimum_site_role_columns() owner to rails;

