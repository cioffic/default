create view _tags
            (tag_id, tag_name, object_type, taggable_id, object_id, object_name, user_id, user_name, system_user_id,
             site_id) as
SELECT taggings.tag_id,
       tags.name              AS tag_name,
       taggings.taggable_type AS object_type,
       taggings.taggable_id,
       workbooks.id           AS object_id,
       workbooks.name         AS object_name,
       taggings.user_id,
       system_users.name      AS user_name,
       users.system_user_id,
       tags.site_id
FROM taggings,
     tags,
     workbooks,
     system_users,
     users
WHERE taggings.tag_id = tags.id
  AND taggings.taggable_type::text = 'Workbook'::text
  AND taggings.taggable_id = workbooks.id
  AND taggings.user_id = users.id
  AND users.system_user_id = system_users.id
UNION
SELECT taggings.tag_id,
       tags.name              AS tag_name,
       taggings.taggable_type AS object_type,
       taggings.taggable_id,
       views.id               AS object_id,
       views.name             AS object_name,
       taggings.user_id,
       system_users.name      AS user_name,
       users.system_user_id,
       tags.site_id
FROM taggings,
     tags,
     views,
     system_users,
     users
WHERE taggings.tag_id = tags.id
  AND taggings.taggable_type::text = 'View'::text
  AND taggings.taggable_id = views.id
  AND taggings.user_id = users.id
  AND users.system_user_id = system_users.id
UNION
SELECT taggings.tag_id,
       tags.name              AS tag_name,
       taggings.taggable_type AS object_type,
       taggings.taggable_id,
       datasources.id         AS object_id,
       datasources.name       AS object_name,
       taggings.user_id,
       system_users.name      AS user_name,
       users.system_user_id,
       tags.site_id
FROM taggings,
     tags,
     datasources,
     system_users,
     users
WHERE taggings.tag_id = tags.id
  AND taggings.taggable_type::text = 'Datasource'::text
  AND taggings.taggable_id = datasources.id
  AND taggings.user_id = users.id
  AND users.system_user_id = system_users.id;

comment on view _tags is 'Each tag is a string value. A given tag can be associated with many taggable items in a site.';

comment on column _tags.tag_id is 'The primary key for the underlying tags table.';

comment on column _tags.tag_name is 'The value of the tag.';

comment on column _tags.object_type is 'The type of the taggable item - this is used to identify which table to join to.';

comment on column _tags.taggable_id is 'The ID of the taggable item.';

comment on column _tags.object_id is 'The same as taggable_id.';

comment on column _tags.object_name is 'The name of the view, workbook, or datasource that is being tagged.';

comment on column _tags.user_id is 'The ID of the user that owns the tagging.';

comment on column _tags.user_name is 'The name of the system_user that owns the tagging.';

comment on column _tags.system_user_id is 'The id of the system_user that owns the tagging.';

comment on column _tags.site_id is 'The site in which the tagged object exists (likewise the user, etc.).';

alter table _tags
    owner to rails;

