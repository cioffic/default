create function get_permission_sets(permission_set_class_id integer, user_id integer, p_group_ids integer[], p_capability_id integer, p_site_id integer) returns SETOF integer
    language sql
as
$$
WITH group_ids AS (SELECT * FROM unnest($3) AS group_id),
    applicable_items AS
        (SELECT grantee_id, grantee_type, capability_id, permission, permission_set_id
        FROM permission_set_items
        WHERE
            (p_site_id = site_id) AND
            (p_capability_id = capability_id) AND
            (
                (grantee_type = 'User' AND grantee_id = user_id)
                OR
                (grantee_type = 'Group' AND grantee_id IN (SELECT group_id FROM group_ids))
            )
        ),
    permission_set_id_and_highest_precedence_reason AS
        (SELECT DISTINCT ON (permission_set_id) permission_set_id, permission -- grab the highest precedence rule
        FROM applicable_items
        ORDER BY permission_set_id, permission desc),
    final_permission_set_ids AS
        (SELECT permission_set_id
        FROM permission_set_id_and_highest_precedence_reason
        WHERE permission IN (1,3)) -- permission_sets can only effectively lead to allows.  filter down to only permission_sets that resolve to allow.

    SELECT permission_set_id
    FROM final_permission_set_ids
    INNER JOIN permission_sets
        ON final_permission_set_ids.permission_set_id = permission_sets.id
    WHERE permission_sets.permission_set_class_id = permission_set_class_id -- filter to the applicable permission_set_class_id

$$;

alter function get_permission_sets(integer, integer, integer[], integer, integer) owner to rails;

