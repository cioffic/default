create function fn_backup_mode_disable() returns void
    language sql
as
$$
UPDATE global_settings SET value = 'false' WHERE name = 'webops_backup_mode';
$$;

alter function fn_backup_mode_disable() owner to rails;

