create function sync_nlp_setting_new_on_update() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (NEW.nlp_setting_new = OLD.nlp_setting_new) THEN
    NEW.nlp_setting_new = NEW.nlp_setting;
  END IF;
  RETURN NEW;
END
$$;

alter function sync_nlp_setting_new_on_update() owner to rails;

