create view _groups(id, name, site_name, domain_name, domain_short_name, domain_family) as
SELECT g.id,
       g.name,
       s.name       AS site_name,
       d.name       AS domain_name,
       d.short_name AS domain_short_name,
       d.family     AS domain_family
FROM groups g,
     domains d,
     sites s
WHERE g.domain_id = d.id
  AND s.id = g.site_id;

comment on view _groups is 'A grouping of users. Can be locally created or imported from Active Directory.  Reflects the contents of the groups table and associated tables.';

comment on column _groups.id is 'The primary key of the underlying groups record.';

comment on column _groups.name is 'The name that was given to the group.';

comment on column _groups.site_name is 'The name of the site that this group belongs in.';

comment on column _groups.domain_name is 'The name of the domain that this group is linked to.';

comment on column _groups.domain_short_name is 'A short version of the domain that this group is linked to.';

comment on column _groups.domain_family is 'Either local or ActiveDirectory.';

alter table _groups
    owner to rails;

