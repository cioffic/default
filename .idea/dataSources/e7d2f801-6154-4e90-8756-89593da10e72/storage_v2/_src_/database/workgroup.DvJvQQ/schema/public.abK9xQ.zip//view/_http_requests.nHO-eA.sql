create view _http_requests
            (controller, action, http_referer, http_user_agent, http_request_uri, remote_ip, created_at, session_id,
             completed_at, port, user_id, worker, vizql_session, user_ip, currentsheet, site_id)
as
SELECT http_requests.controller,
       http_requests.action,
       http_requests.http_referer,
       http_requests.http_user_agent,
       http_requests.http_request_uri,
       http_requests.remote_ip,
       http_requests.created_at,
       http_requests.session_id,
       http_requests.completed_at,
       http_requests.port,
       http_requests.user_id,
       http_requests.worker,
       http_requests.vizql_session,
       http_requests.user_ip,
       http_requests.currentsheet,
       http_requests.site_id
FROM http_requests;

comment on view _http_requests is 'Each record represents a request received by Tableau Server.  Reflects data in the http_requests table.';

comment on column _http_requests.controller is 'The part of the application that received the request.';

comment on column _http_requests.action is 'The action requested.';

comment on column _http_requests.http_referer is 'The referrer.';

comment on column _http_requests.http_user_agent is 'The agent string supplied by the client.';

comment on column _http_requests.http_request_uri is 'The requested URI.';

comment on column _http_requests.remote_ip is 'The client''s IP address (from the perspective of the server).';

comment on column _http_requests.created_at is 'When this record was created.';

comment on column _http_requests.session_id is 'The session with which the request is associated.';

comment on column _http_requests.completed_at is 'When the request was completed.';

comment on column _http_requests.port is 'The port on which the request was received.';

comment on column _http_requests.user_id is 'The user associated with the request.';

comment on column _http_requests.worker is 'Which worker machine received the request.';

comment on column _http_requests.vizql_session is 'The vizql session associated with this request.';

comment on column _http_requests.user_ip is 'The IP address of the originator of the request.';

comment on column _http_requests.currentsheet is 'Which sheet was being viewed.';

comment on column _http_requests.site_id is 'The site associated with the request.';

alter table _http_requests
    owner to rails;

