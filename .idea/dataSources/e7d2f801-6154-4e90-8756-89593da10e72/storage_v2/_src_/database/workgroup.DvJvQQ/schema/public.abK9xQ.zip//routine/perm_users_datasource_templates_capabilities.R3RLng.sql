create function perm_users_datasource_templates_capabilities(p_user_ids integer[], p_project_ids integer[], p_capability_ids integer[])
    returns TABLE(user_id integer, project_id integer, capability_id integer, permission character varying)
    stable
    language sql
as
$$
WITH user_ids AS (SELECT * FROM unnest($1) AS user_id),
     project_ids AS (SELECT * FROM unnest($2) AS project_id),
     capability_ids AS (SELECT * FROM unnest($3) AS capability_id),
    project_leader_info AS
    ( -- Information about which users have project leadership of which projects and why
        SELECT DISTINCT ON (t.user_id, t.authorizable_id) t.user_id, t.grantee_id, t.grantee_type, t.authorizable_id, t.capability_id, t.permission
        FROM
        (
            ( -- Project leadership granted to user
                SELECT user_ids.user_id, ngp.grantee_id, ngp.grantee_type, ngp.authorizable_id, ngp.capability_id, ngp.permission
                FROM next_gen_permissions AS ngp
                INNER JOIN user_ids ON user_ids.user_id = ngp.grantee_id
                WHERE ngp.grantee_type = 'User' AND (ngp.capability_id = 19 OR ngp.capability_id = 34)
            )
            UNION ALL
            ( -- Project leadership granted to group containing user
                SELECT user_ids.user_id, ngp.grantee_id, ngp.grantee_type, ngp.authorizable_id, ngp.capability_id, ngp.permission
                FROM next_gen_permissions AS ngp
                INNER JOIN group_users as gu on gu.group_id = ngp.grantee_id
                INNER JOIN user_ids ON user_ids.user_id = gu.user_id
                WHERE ngp.grantee_type = 'Group' AND (ngp.capability_id = 19 OR ngp.capability_id = 34)
            )
        ) AS t
        -- Sort by capability_id descending as inherited project leader capability takes precedence over project leader capability
        ORDER BY t.user_id, t.authorizable_id, t.capability_id DESC, t.permission DESC
    )

SELECT raw.user_id, raw.authorizable_id, raw.capability_id, permission_reasons.reason
FROM
(
    -- Pick the top row from each group, where groups are defined by identical r.user_id, r.authorizable_id, r.capability_id and sorted by r.permission.
    -- That top one is what controls the user's permission for that project and capability.
    SELECT DISTINCT ON (r.user_id, r.authorizable_id, r.capability_id) r.user_id, r.authorizable_id, r.capability_id, r.permission
    FROM
    (
        SELECT operms.user_id, operms.authorizable_id, capability_ids.capability_id AS capability_id, operms.permission FROM
        ( -- Records from when user is a project owner, or has leadership rights on a project.
            (
                (  -- Admin permissions
                    SELECT user_ids.user_id AS user_id,
                        project_ids.project_id as authorizable_id,
                        10::integer AS permission
                    FROM users AS u
                    CROSS JOIN project_ids
                    INNER JOIN user_ids ON user_ids.user_id = u.id
                    INNER JOIN system_users AS su ON u.system_user_id = su.id
                    INNER JOIN projects AS p ON project_ids.project_id = p.id
                    WHERE ((SELECT is_site_role_id_admin(u.site_role_id)) AND u.site_id = p.site_id) OR su.admin_level = 10 -- site admin or system admin
                )
                UNION ALL
                ( -- Records for when user is the owner of a project
                    SELECT user_ids.user_id AS user_id, p.id AS authorizable_id, 8::integer AS permission
                    FROM projects AS p
                    INNER JOIN project_ids ON project_ids.project_id = p.id
                    INNER JOIN user_ids ON user_ids.user_id = p.owner_id
                )
                UNION ALL
                ( -- Records for when user has leadership rights on a project
                    SELECT user_ids.user_id AS user_id, p.id AS authorizable_id, (CASE pli.grantee_type WHEN 'Group' THEN  6 ELSE 7 END)::integer AS permission
                    FROM projects AS p
                    INNER JOIN project_ids ON project_ids.project_id = p.id
                    INNER JOIN project_leader_info AS pli ON pli.authorizable_id = p.id AND pli.permission IN (1, 3)
                    INNER JOIN user_ids ON user_ids.user_id = pli.user_id
                )
            ) AS operms
            CROSS JOIN capability_ids
        )
        UNION ALL
        (  -- Licensing restrictions
            SELECT user_ids.user_id AS user_id,
                project_ids.project_id as authorizable_id,
                capability_id,
                9::integer AS permission
            FROM users AS u
            CROSS JOIN project_ids
            INNER JOIN user_ids ON user_ids.user_id = u.id
            CROSS JOIN capability_ids
            INNER JOIN capabilities as caps on capability_ids.capability_id = caps.id
            WHERE -- grab only the denials!
            (
                (u.site_role_id = 0 OR u.site_role_id = 2) -- 'SiteAdministrator' (new name SiteAdministratorExplorer) and 'Publisher' (new name ExplorerCanPublish) can do everything except add_new_datasource
                AND
                caps.name IN ('add_new_datasource')
            )
            OR
            (
                u.site_role_id = 3 -- 'Interactor' (new name 'Explorer') can read, export_image, export_data, view_comments, add_comment, filter, vud, share_view, web_authoring, connect, export_xml, change_hierarchy, create_data_alert
                AND
                caps.name IN ('write','delete','change_permissions','project_leader','inherited_project_leader','add_new_datasource')
            )
            OR
            (
                u.site_role_id = 5 -- 'Viewer' (new name 'ReadOnly') can read, add_tag, add_comment, view_comments, export_data, export_image, add_favorite, tooltip
                AND
                caps.name IN ('write','filter','vud','exclude','keep_only','administrator','create_groups','delete','change_permissions','rename','transfer_ownership','export_xml',
                              'change_hierarchy','project_leader','publish','share_view','draw','select','highlight','url_link','content_admin','stateful_url','connect','web_authoring','inherited_project_leader','add_new_datasource','create_data_alert')
            )
            OR
            (
                u.site_role_id = 8  -- 'Unlicensed' can read, export_xml
                AND
                caps.name IN ('write','filter','vud','exclude','keep_only','export_image','export_data','add_comment','view_comments','administrator','create_groups','delete',
                              'change_permissions','rename','transfer_ownership','change_hierarchy','project_leader','publish','share_view','draw','add_tag','add_favorite','select',
                              'tooltip','highlight','url_link','content_admin','stateful_url','connect','web_authoring','inherited_project_leader','add_new_datasource','create_data_alert')
            )
            OR
            (
                u.site_role_id = 7 -- 'Guest'  can export_xml, read, view_comments, filter, vud, exclude, keep_only, export_data, export_image, tooltip, select, highlight, url_link, stateful_url, web_authoring
                AND
                caps.name IN ('write','add_comment','administrator','create_groups','delete','change_permissions','rename','transfer_ownership','change_hierarchy','project_leader',
                              'publish','share_view','draw','add_tag','add_favorite','content_admin','connect','inherited_project_leader','add_new_datasource','create_data_alert')
            )
            OR
            (
                u.site_role_id = 9 -- 'BasicUser' (new name 'Viewer') can read, export_image, filter, highlight, exclude, keep_only, select, stateful_url, tooltip, url_link, view_comments, export_data, add_comment, add_favorite, connect
                AND
                caps.name IN (
                    'write', -- Various publish/move/update resource scenarios are prohibited
                    'delete', -- Delete view/datasource/workbook are prohibited
                    'change_permissions', -- Cannot change resource permissions
                    'change_hierarchy', -- Cannot change hierarchy or move resources
                    'project_leader', -- Cannot act a project leader
                    'web_authoring', -- Cannot use web authoring to modify workbooks
                    'administrator', -- Defunct
                    'create_groups', -- Defunct
                    'rename', -- Defunct
                    'transfer_ownership', -- Defunct
                    'publish', -- Defunct
                    'draw', -- Defunct
                    'content_admin', -- Defunct
                    'inherited_project_leader', -- Cannot act as inherited project leader
                    'add_new_datasource',
                    'vud',
                    'export_xml',
                    'add_tag',
                    'create_data_alert',
                    'share_view'
                )
            )
        )
        UNION ALL
        ( -- Explicit permissions for the project capability stated directly about the user in the permissions_templates table
            SELECT user_ids.user_id, project_ids.project_id, capability_ids.capability_id, pt.permission
            FROM permissions_templates AS pt
            INNER JOIN user_ids ON user_ids.user_id = pt.grantee_id AND pt.grantee_type = 'User'
            INNER JOIN project_ids ON project_ids.project_id = pt.project_id AND pt.template_type = 'Datasource'
            INNER JOIN capability_ids ON capability_ids.capability_id = pt.capability_id
        )
        UNION ALL
        ( -- Explicit permissions for the project capability stated about a group the user belongs to in the permissions_templates table
            SELECT user_ids.user_id, project_ids.project_id, capability_ids.capability_id, pt.permission
            FROM permissions_templates AS pt
            INNER JOIN group_users as gu on gu.group_id = pt.grantee_id AND pt.grantee_type = 'Group'
            INNER JOIN user_ids ON user_ids.user_id = gu.user_id
            INNER JOIN project_ids ON project_ids.project_id = pt.project_id AND pt.template_type = 'Datasource'
            INNER JOIN capability_ids ON capability_ids.capability_id = pt.capability_id
        )
    ) AS r
    ORDER BY r.user_id, r.authorizable_id, r.capability_id, r.permission DESC
) AS raw
INNER JOIN permission_reasons ON raw.permission = permission_reasons.precedence

$$;

alter function perm_users_datasource_templates_capabilities(integer[], integer[], integer[]) owner to rails;

