create function temp_sync_notification_prefs_fn() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF NEW.refresh_failure_notification_enabled != OLD.refresh_failure_notification_enabled THEN
            NEW.notification_enabled = NEW.refresh_failure_notification_enabled;
        ELSIF NEW.notification_enabled != OLD.notification_enabled THEN
            NEW.refresh_failure_notification_enabled = NEW.notification_enabled;
        END IF;
    ELSE
        IF NEW.refresh_failure_notification_enabled IS NOT NULL THEN
            NEW.notification_enabled = NEW.refresh_failure_notification_enabled;
        ELSIF NEW.notification_enabled IS NOT NULL THEN
            NEW.refresh_failure_notification_enabled = NEW.notification_enabled;
        END IF;
    END IF;
    RETURN NEW;
END
$$;

alter function temp_sync_notification_prefs_fn() owner to rails;

