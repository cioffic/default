create view wlm_query_state_vw(query, queue, slot_count, start_time, state, queue_time, exec_time) as
SELECT stv_wlm_query_state.query,
       stv_wlm_query_state.service_class - 5                              AS queue,
       stv_wlm_query_state.slot_count,
       btrim(stv_wlm_query_state.wlm_start_time::character varying::text) AS start_time,
       btrim(stv_wlm_query_state.state::character varying::text)          AS state,
       btrim(stv_wlm_query_state.queue_time::character varying::text)     AS queue_time,
       btrim(stv_wlm_query_state.exec_time::character varying::text)      AS exec_time
FROM stv_wlm_query_state;

alter table wlm_query_state_vw
    owner to msgadmin;

