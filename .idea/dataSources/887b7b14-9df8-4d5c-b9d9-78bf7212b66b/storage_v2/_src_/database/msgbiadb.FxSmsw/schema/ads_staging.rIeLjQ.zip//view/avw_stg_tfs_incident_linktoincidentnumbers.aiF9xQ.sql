create or replace view ads_staging.avw_stg_tfs_incident_linktoincidentnumbers as
select a.incident_no
from ext_staging.stg_tfs_incidents as s
         inner join s.linktoincidentnumbers a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incident_linktoincidentnumbers
    owner to ads_staging;

