create or replace view ads_staging.avw_stg_formio_forms
as
select firstname,
       lastname,
       email,
       phonenumber,
       zipcode,
--(created_date :: datetime - interval '4 hour') as created_date, 
       created_date :: datetime                                                                                   as created_date,
       source,
       md5(nvl(firstname, '') || nvl(lastname, '') || nvl(email, '') || nvl(phonenumber, '') ||
           nvl(zipcode, ''))                                                                                      as acct_id,
       ads_staging.f_s3_parse_athena_filename("$path")                                                            as ads_source_file,
       'FORMIO'                                                                                                   as ads_source
from forms_io.formio_forms_fix
with no schema binding;

alter table avw_stg_formio_forms
    owner to ads_staging;

