create view vw_liberty_stm_customer
            (acct_type, customer_master_index, name_first, name_last, name_full, email_address, street_addr_1,
             street_addr_2, city, state, zip, country, liberty_plan_flag)
as
SELECT x.acct_type,
       x.customer_master_index,
       x.name_first,
       x.name_last,
       x.name_full,
       x.email_address,
       x.street_addr_1,
       x.street_addr_2,
       x.city,
       x.state,
       x.zip,
       x.country,
       "max"(x.liberty_plan_flag::text) AS liberty_plan_flag
FROM (SELECT COALESCE(b.acct_type_desc, a.acct_type)                    AS acct_type,
             COALESCE(b.customer_master_index, c.customer_master_index) AS customer_master_index,
             COALESCE(b.name_first, a.name_first)                       AS name_first,
             COALESCE(b.name_last, a.name_last)                         AS name_last,
             COALESCE((b.name_first::text || ' '::character varying::text) || b.name_last::text,
                      a.name_full::text)::character varying             AS name_full,
             COALESCE(b.email_address, a.email)                         AS email_address,
             COALESCE(b.street_addr_1, a.full_addr_line_1)              AS street_addr_1,
             COALESCE(b.street_addr_2, a.full_addr_line_2)              AS street_addr_2,
             COALESCE(b.city, a.city)                                   AS city,
             COALESCE(b.state, a.state_region)                          AS state,
             COALESCE(b.zip, a.postal_cd)                               AS zip,
             COALESCE(b.country, a.country_name)                        AS country,
             "substring"("max"("substring"(x.event_cd::text, 1, 2)::integer + 2000)::character varying::text, 1,
                         4)::character varying                          AS liberty_plan_flag
      FROM ads_staging.mdm_acct_event_txn x
               JOIN ads_staging.mdm_acct_nameaddr a ON x.perm_id = a.perm_id
               LEFT JOIN ads_main.d_customer_account b ON x.acct_nbr::text = b.tm_acct_id::character varying::text AND
                                                          b.ads_active_flag::text = 'Y'::character varying::text AND
                                                          "substring"(x.acct_source::text, 1,
                                                                      charindex('_'::character varying::text, x.acct_source::text) - 1) =
                                                          b.ads_source::text
               LEFT JOIN ads_main.d_customer_master_keys c ON x.acct_nbr::text = c.account_id::text AND
                                                              c.ads_source::text = 'ACXIOM'::character varying::text AND
                                                              c.ads_active_flag::text = 'Y'::character varying::text
      WHERE x.acct_source::text = 'LIBERTY_ARCHTICS'::character varying::text
        AND x.total_event::text > 1::character varying::text
        AND x.event_cd::text ~~ '%LFS%'::character varying::text
        AND x.event_cd::text !~~ 'TST%'::character varying::text
        AND "substring"("replace"(x.event_cd::text, 'TST'::character varying::text, ''::character varying::text), 1,
                        2) <= 15::character varying::text
      GROUP BY COALESCE(b.acct_type_desc, a.acct_type), COALESCE(b.customer_master_index, c.customer_master_index),
               COALESCE(b.name_first, a.name_first), COALESCE(b.name_last, a.name_last),
               COALESCE((b.name_first::text || ' '::character varying::text) || b.name_last::text, a.name_full::text),
               COALESCE(b.email_address, a.email), COALESCE(b.street_addr_1, a.full_addr_line_1),
               COALESCE(b.street_addr_2, a.full_addr_line_2), COALESCE(b.city, a.city),
               COALESCE(b.state, a.state_region), COALESCE(b.zip, a.postal_cd), COALESCE(b.country, a.country_name)
      UNION
      SELECT b.acct_type_desc                                                                               AS acct_type,
             b.customer_master_index,
             b.name_first,
             b.name_last,
             ((b.name_first::text || ' '::character varying::text) ||
              b.name_last::text)::character varying                                                         AS name_full,
             b.email_address,
             b.street_addr_1,
             b.street_addr_2,
             b.city,
             b.state,
             b.zip,
             b.country,
             "substring"("max"(c.tm_season_name::text)::character varying::text, 1,
                         4)::character varying                                                              AS liberty_plan_flag
      FROM ads_main.f_ticket_sales_event_seat a
               JOIN ads_main.d_event_plan c ON a.event_plan_id = c.event_plan_id
               LEFT JOIN ads_main.d_customer_account b
                         ON a.tm_acct_id = b.tm_acct_id AND b.ads_active_flag::text = 'Y'::character varying::text AND
                            a.ads_source::text = b.ads_source::text
      WHERE c.tm_season_name::text ~~ '2%Liberty'::character varying::text
        AND c.tm_plan_event_id <> -1
      GROUP BY b.acct_type_desc, b.customer_master_index, b.name_first, b.name_last,
               (b.name_first::text || ' '::character varying::text) || b.name_last::text, b.email_address,
               b.street_addr_1, b.street_addr_2, b.city, b.state, b.zip, b.country) x
GROUP BY x.acct_type, x.customer_master_index, x.name_first, x.name_last, x.name_full, x.email_address, x.street_addr_1,
         x.street_addr_2, x.city, x.state, x.zip, x.country;

alter table vw_liberty_stm_customer
    owner to ads_main;

