create or replace view ads_main.dq_fmb_location_hierarchy_unknowns as
select loaddate,
       venue_id,
       id,
       venue,
       segment,
       fmb_services,
       floor,
       section,
       stand_name,
       location_name,
       neighborhood_owner
from ads_staging.avw_mpd_fmb_location_hierarchy
where location_name
    in (select location_name
        from ads_main.t_fmb_sales_product_dtls
        where venue = 'Unknown'
           or fmb_services = 'Unknown'
           or segment = 'Unknown'
           or stand_name = 'Unknown'
           or neighborhood_owner = 'Unknown')

  and loaddate = (select max(loaddate)
                  from ads_staging.avw_mpd_fmb_location_hierarchy)
with no schema binding;

alter table dq_fmb_location_hierarchy_unknowns
    owner to ads_main;

