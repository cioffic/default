CREATE OR REPLACE view ads_staging.avw_mpd_geo_state_cleanup
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       state_name :: VARCHAR(255)                                               state_name,
       state_code :: VARCHAR(255)                                               state_code,
       country_code :: VARCHAR(255)
FROM ext_staging.mpd_geo_state_cleanup
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_state_cleanup
    owner to ads_staging;

