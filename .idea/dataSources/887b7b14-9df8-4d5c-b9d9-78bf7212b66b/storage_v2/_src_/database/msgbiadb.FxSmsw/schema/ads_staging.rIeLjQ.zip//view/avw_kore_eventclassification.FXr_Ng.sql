create view ads_staging.avw_kore_eventclassification as
select *
from ext_staging.stg_kore_eventclassification
with no schema binding;

alter table avw_kore_eventclassification
    owner to ads_staging;

