create or replace view ads_staging.avw_stg_tfs_incident_locations as
select a.locationId,
       a.locationName,
       a.sectionId,
       a.sectionName,
       a.rows,
       a.seat,
       a.facility
from ext_staging.stg_tfs_incidents as s
         inner join s.locations a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incident_locations
    owner to ads_staging;

