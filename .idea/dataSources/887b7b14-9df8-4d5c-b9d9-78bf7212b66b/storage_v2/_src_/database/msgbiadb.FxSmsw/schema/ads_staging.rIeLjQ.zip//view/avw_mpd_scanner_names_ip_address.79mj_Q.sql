CREATE OR REPLACE VIEW ads_staging.avw_mpd_scanner_names_ip_address
AS

SELECT *
     , ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
FROM ext_staging.mpd_scanner_names_ip_address
WITH NO SCHEMA BINDING;

alter table avw_mpd_scanner_names_ip_address
    owner to ads_staging;

