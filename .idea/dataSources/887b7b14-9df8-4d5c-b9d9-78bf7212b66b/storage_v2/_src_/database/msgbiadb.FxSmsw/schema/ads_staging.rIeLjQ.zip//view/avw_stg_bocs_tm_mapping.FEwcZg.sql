create OR REPLACE view ads_staging.avw_stg_bocs_tm_mapping as
select venue                                                                        tm_arena_name,
       to_date(eventdate, 'mm/dd/yyyy')                                             tm_event_date,
       eventtime                                                                    tm_event_time,
       eventcode                                                                    gl_event_code,
       eventname                                                                    primary_act,
       shows                                                                        number_of_shows,
       tmeventid                                                                    inet_event_id,
       tmeventcode                                                                  tm_event_name,
       tmeventname                                                                  tm_event_name_long,
       pt_year || pt_month || pt_day                                                ads_source_file,
       'MSG' as                                                                     ads_source,
       row_number() OVER (PARTITION BY tmeventid ORDER BY eventcode,eventtime DESC) rnk
from bocs.bocs_tm_tm
where pt_year || pt_month || pt_day = (SELECT MAX(pt_year || pt_month || pt_day) FROM bocs.bocs_tm_tm)
with no schema binding;

alter table avw_stg_bocs_tm_mapping
    owner to ads_staging;

