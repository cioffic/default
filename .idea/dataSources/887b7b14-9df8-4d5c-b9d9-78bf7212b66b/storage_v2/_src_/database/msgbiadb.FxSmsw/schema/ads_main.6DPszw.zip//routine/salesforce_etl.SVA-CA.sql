create procedure salesforce_etl(inout object character varying, out out_var character varying)
    language plpgsql
as
$$
DECLARE
  last_partition int;
BEGIN

  last_partition := 2020070212;

  CREATE TEMP TABLE salesforce_delta as
  select a.*
  from
  (
  SELECT
   "rank"() OVER (PARTITION BY "id" ORDER BY "lastmodifieddate" DESC) "rnk"
  , "$path" "s3path"
  , id
  from salesforce.stg_sfdc_task
  where cast((partition_0 || lpad(partition_1, 2, '0') || lpad(partition_2, 2, '0') ||
              lpad(partition_3, 2, '0')) as integer) > 2020070212
  ) as a
  where a.rnk=1;

  SELECT INTO out_var count(*) from salesforce_delta;
END;
$$;

