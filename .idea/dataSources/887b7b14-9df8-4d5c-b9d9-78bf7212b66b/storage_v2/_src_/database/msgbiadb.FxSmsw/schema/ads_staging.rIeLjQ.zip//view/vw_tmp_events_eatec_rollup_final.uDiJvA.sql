create view vw_tmp_events_eatec_rollup_final
            (arena_date, event_id, event_name, parent_eatec_event_start_datetime, parent_eatec_event_end_datetime,
             locations, tm_arena_name)
as
SELECT a.arena_date,
       a.event_id,
       a.event_name,
       a.parent_eatec_event_start_datetime,
       a.parent_eatec_event_end_datetime,
       b.locations,
       a.tm_arena_name
FROM ads_staging.tmp_events_eatec_group_loc_rank a
         JOIN (SELECT derived_table1.arena_date,
                      pg_catalog.listagg(derived_table1.location_id, ','::character varying::text) WITHIN GROUP (
                          ORDER BY derived_table1.location_id) AS locations
               FROM (SELECT DISTINCT a.arena_date,
                                     split_part(a.locations::text, ','::character varying::text,
                                                b.counter) AS location_id
                     FROM ads_staging.tmp_events_eatec_group_loc_rank a
                              CROSS JOIN ads_staging.dummy_counter b
                     WHERE 1 = 1
                       AND b.counter >= 1
                       AND b.counter <= 300
                       AND split_part(a.locations::text, ','::character varying::text, b.counter) IS NOT NULL
                       AND split_part(a.locations::text, ','::character varying::text, b.counter) <>
                           ''::character varying::text) derived_table1
               GROUP BY derived_table1.arena_date) b ON a.arena_date::text = b.arena_date::text
WHERE a.rnk = 1;

alter table vw_tmp_events_eatec_rollup_final
    owner to ads_staging;

