create view vw_ticket_flash_adj
            (retail_ticket_type, tm_season_name, year, ticket_type, flash_adjustment, ads_dtm_created,
             ads_dtm_last_updated, retail_qualifiers, discount_partner_percentage, negative_match_string)
as
SELECT mpd_mse_flash_adj.retail_ticket_type,
       mpd_mse_flash_adj.tm_season_name,
       mpd_mse_flash_adj."year",
       mpd_mse_flash_adj.ticket_type,
       mpd_mse_flash_adj.flash_adjustment,
       mpd_mse_flash_adj.ads_dtm_created,
       mpd_mse_flash_adj.ads_dtm_last_updated,
       mpd_mse_flash_adj.retail_qualifiers,
       mpd_mse_flash_adj.discount_partner_percentage,
       mpd_mse_flash_adj.negative_match_string
FROM ads_staging.mpd_mse_flash_adj;

alter table vw_ticket_flash_adj
    owner to ads_main;

