create view ads_staging.avw_kore_event as
select *
from ext_staging.stg_kore_event
with no schema binding;

alter table avw_kore_event
    owner to ads_staging;

