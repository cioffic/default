create or replace view ads_staging.avw_eatec_recipes as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'EATEC' as ads_source
from ext_staging.stg_eatec_recipes
with no schema binding;

alter table avw_eatec_recipes
    owner to ads_main;

