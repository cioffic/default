create or replace view ads_staging.avw_stg_formstack_forms_fields
as
select id,
       label,
       description,
       name,
       type,
       required,
       "sort",
       form,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'FORMSTACK'                                     as ads_source
from ext_staging.stg_formstack_forms_fields
with no schema binding;

alter table avw_stg_formstack_forms_fields
    owner to ads_main;

