CREATE OR REPLACE VIEW ads_main.avw_mpd_yearly_teams_event_finance_budget_show
AS
select *
from ext_staging.mpd_yearly_teams_event_finance_budget_show
with no schema binding;

alter table avw_mpd_yearly_teams_event_finance_budget_show
    owner to etluser;

