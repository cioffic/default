CREATE OR REPLACE view ads_staging.avw_tm_host_audit as
select *,
       "$path" :: VARCHAR(255)                                               AS ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file
from ticketmaster.host_audit
with no schema binding;

alter table avw_tm_host_audit
    owner to ads_main;

