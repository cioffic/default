create or replace view ads_staging.avw_stg_sfdc_contract
as
SELECT *
FROM ext_staging.stg_sfdc_contract
with no schema binding;

alter table avw_stg_sfdc_contract
    owner to ads_staging;

