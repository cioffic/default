create or replace view ads_main.avw_tm_resale
as
select reporttitle
     , ordernumber
     , platforminventorysource
     , case when transactiondttm_pt = '' then null else transactiondttm_pt::timestamp end                           as transactiondttm_pt
     , case when transactiondate = '' then null else transactiondate::date end                                      as transactiondate
     , case
           when daysbetweenpurchaseandevent = '' then 0
           else daysbetweenpurchaseandevent::int end                                                                AS daysbetweenpurchaseandevent
     , primaryact
     , secondaryact
     , case when eventdate = '' then null else eventdate::date end                                                  as eventdate
     , event_time
     , tickettype
     , section
     , seatrow
     , seatfrom::int
     , seatto::int
     , tickets::int
     , listingpriceperticket::decimal(12, 2)
     , listingpriceperorder::decimal(12, 2)
     , markup::decimal(12, 2)
     , sellerfee::decimal(12, 2)
     , buyerfee::decimal(12, 2)
     , deliveryfee::decimal(12, 2)
     , gtv::decimal(12, 2)
     , grossrevenue::decimal(12, 2)
     , lastname
     , firstname
     , address_line1
     , address_line2
     , city
     , state
     , country
     , postalcode
     , phone1
     , phone2
     , email_address
     , case when dayslisted = '' then 0 else dayslisted::int end                                                    as dayslisted
     , case
           when inventoryticketid = '' then 0::int
           else regexp_replace(inventoryticketid, '[^0-9]+', '0')::int end                                          as inventoryticketid
     , buyermarketingoptin
     , currency
     , tm_eventid
     , case when tnow_productionid = '' then 0 else tnow_productionid::bigint end                                   as tnow_productionid
     , venuename
     , ordersource
     , case
           when extracttimestamp = '' then null
           else extracttimestamp::timestamp end                                                                     as extracttimestamp
     , "$path"                                                                                                      as file_name
from ext_staging.stg_tm_resale
with no schema binding;

alter table avw_tm_resale
    owner to ads_main;

