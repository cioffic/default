create view ads_staging.avw_kore_premiumdealcontractyear as
select *
from ext_staging.stg_kore_premiumdealcontractyear
with no schema binding;

alter table avw_kore_premiumdealcontractyear
    owner to ads_staging;

