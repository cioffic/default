create or replace view ads_staging.avw_exctgt_opens
as
select clientid,
       sendid,
       subscriberkey,
       emailaddress,
       subscriberid,
       listid,
       eventdate :: datetime,
       eventtype,
       batchid :: INTEGER,
       triggeredsendexternalkey,
       isunique,
       ipaddress,
       country,
       region,
       city,
       latitude,
       longitude,
       metrocode,
       areacode,
       browser,
       emailclient,
       operatingsystem,
       device,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_opens
with no schema binding;

alter table avw_exctgt_opens
    owner to ads_staging;

