create view v_generate_view_ddl(schemaname, viewname, ddl) as
SELECT n.nspname AS schemaname,
       c.relname AS viewname,
       '--DROP VIEW '::text + quote_ident(n.nspname::text) + '.'::text + quote_ident(c.relname::text) + ';\012'::text +
       CASE
           WHEN c.relnatts > 0 THEN 'CREATE OR REPLACE VIEW '::text + quote_ident(n.nspname::text) + '.'::text +
                                    quote_ident(c.relname::text) + ' AS\012'::text +
                                    COALESCE(pg_get_viewdef(c.oid, true), ''::text)
           ELSE COALESCE(pg_get_viewdef(c.oid, true), ''::text)
           END   AS ddl
FROM pg_class c
         JOIN pg_namespace n ON c.relnamespace = n.oid
WHERE c.relkind = 'v'::"char";

alter table v_generate_view_ddl
    owner to chant;

