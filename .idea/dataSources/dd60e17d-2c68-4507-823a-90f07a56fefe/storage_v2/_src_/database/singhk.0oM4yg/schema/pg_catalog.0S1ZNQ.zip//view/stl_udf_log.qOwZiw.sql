create view stl_udf_log
            (query, message, created, filename, funcname, level_name, level_number, lineno, module, msecs, name,
             path_name, process, process_name, relative_created, thread, thread_name, traceback, node, slice, seq)
as
SELECT stll_udf_log.query,
       stll_udf_log.message,
       stll_udf_log.created,
       stll_udf_log.filename,
       stll_udf_log.funcname,
       stll_udf_log.level_name,
       stll_udf_log.level_number,
       stll_udf_log.lineno,
       stll_udf_log.module,
       stll_udf_log.msecs,
       stll_udf_log.name,
       stll_udf_log.path_name,
       stll_udf_log.process,
       stll_udf_log.process_name,
       stll_udf_log.relative_created,
       stll_udf_log.thread,
       stll_udf_log.thread_name,
       stll_udf_log.traceback,
       stll_udf_log.node,
       stll_udf_log.slice,
       stll_udf_log.seq
FROM stll_udf_log;

alter table stl_udf_log
    owner to rdsdb;

