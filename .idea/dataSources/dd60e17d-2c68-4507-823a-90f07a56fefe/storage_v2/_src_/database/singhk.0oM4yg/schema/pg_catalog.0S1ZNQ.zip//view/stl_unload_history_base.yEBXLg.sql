create view stl_unload_history_base
            (userid, db, xid, pid, user_query_id, child_query_sequence, rewritten_qid, status, event_time, slice,
             files_count_produced, files_size_produced, rows_produced, file_format, compression_type, unloaded_location,
             error_message)
as
SELECT stll_unload_history_base.userid,
       stll_unload_history_base.db,
       stll_unload_history_base.xid,
       stll_unload_history_base.pid,
       stll_unload_history_base.user_query_id,
       stll_unload_history_base.child_query_sequence,
       stll_unload_history_base.rewritten_qid,
       stll_unload_history_base.status,
       stll_unload_history_base.event_time,
       stll_unload_history_base.slice,
       stll_unload_history_base.files_count_produced,
       stll_unload_history_base.files_size_produced,
       stll_unload_history_base.rows_produced,
       stll_unload_history_base.file_format,
       stll_unload_history_base.compression_type,
       stll_unload_history_base.unloaded_location,
       stll_unload_history_base.error_message
FROM stll_unload_history_base;

alter table stl_unload_history_base
    owner to rdsdb;

