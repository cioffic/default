create view svv_alter_table_recommendations(type, database, table_id, group_id, ddl, auto_eligible) as
SELECT tbl_recos_str."type",
       tbl_recos_str."database",
       tbl_recos_str.table_id,
       tbl_recos_str.group_id,
       ((((((('ALTER TABLE "'::text || tbl_recos_str."schema") || '"."'::text) || tbl_recos_str.table_name) ||
           '"'::text) || tbl_recos_str.dkr) || tbl_recos_str.comma_dkr_skr) || tbl_recos_str.skr) ||
       tbl_recos_str.enc AS ddl,
       tbl_recos_str.auto_eligible
FROM (SELECT rj."type",
             rj."database",
             rj."schema",
             rj.table_name,
             rj.table_id,
             rj.group_id,
             CASE
                 WHEN len(rj."distkey") = 0 THEN ''::text
                 ELSE (' ALTER DISTSTYLE KEY DISTKEY "'::text || rj."distkey") || '"'::text
                 END AS dkr,
             CASE
                 WHEN len(rj."sortkey") = 0 THEN ''::text
                 ELSE (' ALTER COMPOUND SORTKEY ('::text || rj."sortkey") || ')'::text
                 END AS skr,
             CASE
                 WHEN len(rj.encode_col) = 0 THEN ''::text
                 ELSE ((' ALTER COLUMN '::text || split_part(rj.encode_col, ':'::text, 1)) || ' ENCODE '::text) ||
                      split_part(rj.encode_col, ':'::text, 2)
                 END AS enc,
             CASE
                 WHEN len(rj."distkey") <> 0 AND len(rj."sortkey") <> 0 THEN ','::text
                 ELSE ''::text
                 END AS comma_dkr_skr,
             CASE
                 WHEN rj."type" = 'diststyle'::text AND pce0.value::integer >= 10 OR
                      rj."type" = 'sortkey'::text AND pce12.value::integer = 1 OR
                      rj."type" = 'encode'::text AND pce14.value::integer = 1 THEN 't'::text
                 ELSE 'f'::text
                 END AS auto_eligible
      FROM (SELECT btrim(stv_alter_table_recommendations."database"::text)                                  AS "database",
                   btrim(stv_alter_table_recommendations."schema"::text)                                    AS "schema",
                   btrim(stv_alter_table_recommendations.table_name::text)                                  AS table_name,
                   stv_alter_table_recommendations.table_id,
                   stv_alter_table_recommendations.group_id,
                   stv_alter_table_recommendations.benefit,
                   CASE
                       WHEN stv_alter_table_recommendations."type" = 23 OR stv_alter_table_recommendations."type" = 25
                           THEN 'diststyle'::text
                       WHEN stv_alter_table_recommendations."type" = 24 THEN 'sortkey'::text
                       WHEN stv_alter_table_recommendations."type" = 26 THEN 'encode'::text
                       ELSE NULL::text
                       END                                                                                  AS "type",
                   json_extract_path_text(stv_alter_table_recommendations.col_names::text,
                                          'distkey'::text)                                                  AS "distkey",
                   translate(json_extract_path_text(stv_alter_table_recommendations.col_names::text, 'sortkey'::text),
                             '[]'::text,
                             ''::text)                                                                      AS "sortkey",
                   translate(json_extract_path_text(stv_alter_table_recommendations.col_names::text, 'encode'::text),
                             '[]'::text,
                             ''::text)                                                                      AS encode_col
            FROM stv_alter_table_recommendations
            ORDER BY stv_alter_table_recommendations.benefit DESC) rj
               LEFT JOIN pg_class_extended pce0 ON rj.table_id::oid = pce0.reloid AND pce0.colnum = 0
               LEFT JOIN pg_class_extended pce12 ON rj.table_id::oid = pce12.reloid AND pce12.colnum = 12
               LEFT JOIN pg_class_extended pce14 ON rj.table_id::oid = pce14.reloid AND pce14.colnum = 14
      WHERE rj."type" IS NOT NULL) tbl_recos_str;

alter table svv_alter_table_recommendations
    owner to rdsdb;

