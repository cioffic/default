create view stl_vacuum
            (userid, xid, table_id, status, rows, sortedrows, blocks, max_merge_partitions, eventtime, reclaimable_rows,
             reclaimable_space_mb, cutoff_xid, is_recluster)
as
SELECT stll_vacuum.userid,
       stll_vacuum.xid,
       stll_vacuum.table_id,
       stll_vacuum.status,
       stll_vacuum."rows",
       stll_vacuum.sortedrows,
       stll_vacuum."blocks",
       stll_vacuum.max_merge_partitions,
       stll_vacuum.eventtime,
       stll_vacuum.reclaimable_rows,
       stll_vacuum.reclaimable_space_mb,
       stll_vacuum.cutoff_xid,
       stll_vacuum.is_recluster
FROM stll_vacuum;

alter table stl_vacuum
    owner to rdsdb;

