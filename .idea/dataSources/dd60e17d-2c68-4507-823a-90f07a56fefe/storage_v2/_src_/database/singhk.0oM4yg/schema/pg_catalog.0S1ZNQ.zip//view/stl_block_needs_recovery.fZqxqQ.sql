create view stl_block_needs_recovery
            (logtime, xid, node, tbl, col, global_slice, blknum, sb_pos, blkid, reason, num_values, flags, reps,
             s3_state, rep_strings)
as
SELECT stll_block_needs_recovery.logtime,
       stll_block_needs_recovery.xid,
       stll_block_needs_recovery.node,
       stll_block_needs_recovery.tbl,
       stll_block_needs_recovery.col,
       stll_block_needs_recovery.global_slice,
       stll_block_needs_recovery.blknum,
       stll_block_needs_recovery.sb_pos,
       stll_block_needs_recovery.blkid,
       stll_block_needs_recovery.reason,
       stll_block_needs_recovery.num_values,
       stll_block_needs_recovery.flags,
       stll_block_needs_recovery.reps,
       stll_block_needs_recovery.s3_state,
       stll_block_needs_recovery.rep_strings
FROM stll_block_needs_recovery;

alter table stl_block_needs_recovery
    owner to rdsdb;

