create view stl_sem_usage (currenttime, query, last, node, count, waittime, longest, mutex_requests, name) as
SELECT stll_sem_usage.currenttime,
       stll_sem_usage.query,
       stll_sem_usage."last",
       stll_sem_usage.node,
       stll_sem_usage.count,
       stll_sem_usage.waittime,
       stll_sem_usage.longest,
       stll_sem_usage.mutex_requests,
       stll_sem_usage.name
FROM stll_sem_usage;

alter table stl_sem_usage
    owner to rdsdb;

