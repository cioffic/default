create view stl_insert (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl) as
SELECT stll_insert.userid,
       stll_insert.query,
       stll_insert.slice,
       stll_insert.segment,
       stll_insert.step,
       stll_insert.starttime,
       stll_insert.endtime,
       stll_insert.tasknum,
       stll_insert."rows",
       stll_insert.tbl
FROM stll_insert;

alter table stl_insert
    owner to rdsdb;

