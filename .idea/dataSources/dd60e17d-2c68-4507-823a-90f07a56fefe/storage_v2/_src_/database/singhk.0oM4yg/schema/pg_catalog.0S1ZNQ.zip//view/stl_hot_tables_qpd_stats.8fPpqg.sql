create view stl_hot_tables_qpd_stats
            (eventtime, num_hot_tables, table_id, highest_qpd, min_qpd, max_qpd, avg_qpd, median_qpd) as
SELECT stll_hot_tables_qpd_stats.eventtime,
       stll_hot_tables_qpd_stats.num_hot_tables,
       stll_hot_tables_qpd_stats.table_id,
       stll_hot_tables_qpd_stats.highest_qpd,
       stll_hot_tables_qpd_stats.min_qpd,
       stll_hot_tables_qpd_stats.max_qpd,
       stll_hot_tables_qpd_stats.avg_qpd,
       stll_hot_tables_qpd_stats.median_qpd
FROM stll_hot_tables_qpd_stats;

alter table stl_hot_tables_qpd_stats
    owner to rdsdb;

