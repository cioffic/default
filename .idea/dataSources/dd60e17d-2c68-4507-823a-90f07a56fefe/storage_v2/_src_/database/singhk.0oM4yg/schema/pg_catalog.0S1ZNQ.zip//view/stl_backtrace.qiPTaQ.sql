create view stl_backtrace(now, since, name, count, hex_addresses) as
SELECT stll_backtrace.now,
       stll_backtrace.since,
       stll_backtrace.name,
       stll_backtrace.count,
       stll_backtrace.hex_addresses
FROM stll_backtrace;

alter table stl_backtrace
    owner to rdsdb;

