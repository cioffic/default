create view stl_clear_reps(call_time, line_num, sb_pos) as
SELECT stll_clear_reps.call_time, stll_clear_reps.line_num, stll_clear_reps.sb_pos
FROM stll_clear_reps;

alter table stl_clear_reps
    owner to rdsdb;

