create view stl_plan_explain_tree(query, nodeid, parentid) as
SELECT stll_plan_explain_tree.query, stll_plan_explain_tree.nodeid, stll_plan_explain_tree.parentid
FROM stll_plan_explain_tree;

alter table stl_plan_explain_tree
    owner to rdsdb;

