create view stl_superblock_integrity_error(recordtime, node, diskno, raw_disk_addr) as
SELECT stll_superblock_integrity_error.recordtime,
       stll_superblock_integrity_error.node,
       stll_superblock_integrity_error.diskno,
       stll_superblock_integrity_error.raw_disk_addr
FROM stll_superblock_integrity_error;

alter table stl_superblock_integrity_error
    owner to rdsdb;

