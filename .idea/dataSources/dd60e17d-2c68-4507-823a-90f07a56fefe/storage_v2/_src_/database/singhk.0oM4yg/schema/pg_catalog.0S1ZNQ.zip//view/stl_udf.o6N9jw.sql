create view stl_udf (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, udfid) as
SELECT stll_udf.userid,
       stll_udf.query,
       stll_udf.slice,
       stll_udf.segment,
       stll_udf.step,
       stll_udf.starttime,
       stll_udf.endtime,
       stll_udf.tasknum,
       stll_udf."rows",
       stll_udf.bytes,
       stll_udf.udfid
FROM stll_udf;

alter table stl_udf
    owner to rdsdb;

