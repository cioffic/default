create view stl_s3log
            (userid, is_internal, pid, query, uuid, segment, step, node, slice, eventtime, message, scan_type,
             request_id, error_type, spectrum_error_code)
as
SELECT stll_s3log.userid,
       stll_s3log.is_internal,
       stll_s3log.pid,
       stll_s3log.query,
       stll_s3log.uuid,
       stll_s3log.segment,
       stll_s3log.step,
       stll_s3log.node,
       stll_s3log.slice,
       stll_s3log.eventtime,
       stll_s3log.message,
       stll_s3log.scan_type,
       stll_s3log.request_id,
       stll_s3log.error_type,
       stll_s3log.spectrum_error_code
FROM stll_s3log;

alter table stl_s3log
    owner to rdsdb;

