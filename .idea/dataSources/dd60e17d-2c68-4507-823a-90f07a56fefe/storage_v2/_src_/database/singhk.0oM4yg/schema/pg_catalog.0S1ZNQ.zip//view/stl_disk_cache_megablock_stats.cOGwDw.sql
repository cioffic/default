create view stl_disk_cache_megablock_stats
            (logtime, node, adds, new_blocks, dbr_blocks, faults, pins, thrashed_blocks, evictions) as
SELECT stll_disk_cache_megablock_stats.logtime,
       stll_disk_cache_megablock_stats.node,
       stll_disk_cache_megablock_stats.adds,
       stll_disk_cache_megablock_stats.new_blocks,
       stll_disk_cache_megablock_stats.dbr_blocks,
       stll_disk_cache_megablock_stats."faults",
       stll_disk_cache_megablock_stats.pins,
       stll_disk_cache_megablock_stats.thrashed_blocks,
       stll_disk_cache_megablock_stats.evictions
FROM stll_disk_cache_megablock_stats;

alter table stl_disk_cache_megablock_stats
    owner to rdsdb;

