create view stl_process_state
            (pid, node, process_type, process_type_str, record_time, mem_current_virtual_kb, mem_peak_virtual_kb,
             mem_current_rss_kb, mem_peak_rss_kb, mem_current_rss_anon_kb, mem_current_rss_file_kb,
             mem_current_rss_shared_kb, mem_current_swap_kb)
as
SELECT stll_process_state.pid,
       stll_process_state.node,
       stll_process_state."process_type",
       stll_process_state.process_type_str,
       stll_process_state.record_time,
       stll_process_state.mem_current_virtual_kb,
       stll_process_state.mem_peak_virtual_kb,
       stll_process_state.mem_current_rss_kb,
       stll_process_state.mem_peak_rss_kb,
       stll_process_state.mem_current_rss_anon_kb,
       stll_process_state.mem_current_rss_file_kb,
       stll_process_state.mem_current_rss_shared_kb,
       stll_process_state.mem_current_swap_kb
FROM stll_process_state;

alter table stl_process_state
    owner to rdsdb;

