create view table_constraints
            (constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name,
             constraint_type, is_deferrable, initially_deferred)
as
SELECT current_database()::information_schema.sql_identifier AS constraint_catalog,
       nc.nspname::information_schema.sql_identifier         AS constraint_schema,
       c.conname::information_schema.sql_identifier          AS constraint_name,
       current_database()::information_schema.sql_identifier AS table_catalog,
       nr.nspname::information_schema.sql_identifier         AS table_schema,
       r.relname::information_schema.sql_identifier          AS table_name,
       CASE
           WHEN c.contype = 'c'::"char" THEN 'CHECK'::text
           WHEN c.contype = 'f'::"char" THEN 'FOREIGN KEY'::text
           WHEN c.contype = 'p'::"char" THEN 'PRIMARY KEY'::text
           WHEN c.contype = 'u'::"char" THEN 'UNIQUE'::text
           ELSE NULL::text
           END::information_schema.character_data            AS constraint_type,
       CASE
           WHEN c.condeferrable THEN 'YES'::text
           ELSE 'NO'::text
           END::information_schema.character_data            AS is_deferrable,
       CASE
           WHEN c.condeferred THEN 'YES'::text
           ELSE 'NO'::text
           END::information_schema.character_data            AS initially_deferred
FROM pg_namespace nc,
     pg_namespace nr,
     pg_constraint c,
     pg_class r,
     pg_user u
WHERE nc.oid = c.connamespace
  AND nr.oid = r.relnamespace
  AND c.conrelid = r.oid
  AND r.relowner = u.usesysid
  AND r.relkind = 'r'::"char"
  AND u.usename = "current_user"()::name;

alter table table_constraints
    owner to rdsdb;

