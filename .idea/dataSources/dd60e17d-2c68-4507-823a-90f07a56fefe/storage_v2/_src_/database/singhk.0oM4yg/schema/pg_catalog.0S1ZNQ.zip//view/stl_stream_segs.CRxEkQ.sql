create view stl_stream_segs(userid, query, stream, segment) as
SELECT stll_stream_segs.userid, stll_stream_segs.query, stll_stream_segs.stream, stll_stream_segs.segment
FROM stll_stream_segs;

alter table stl_stream_segs
    owner to rdsdb;

