create view stl_burst_manager_personalization
            (userid, pid, xid, starttime, endtime, cluster_arn, backup_id, backup_prefix, backup_midfix,
             creds_access_key, creds_secret_key, creds_session_token, creds_expiration, cluster_id, cluster_name, error,
             account_id, query, auto_wlm_total_memory_mb, auto_wlm_per_query_max_memory_mb, instance_type, num_nodes)
as
SELECT stll_burst_manager_personalization.userid,
       stll_burst_manager_personalization.pid,
       stll_burst_manager_personalization.xid,
       stll_burst_manager_personalization.starttime,
       stll_burst_manager_personalization.endtime,
       stll_burst_manager_personalization.cluster_arn,
       stll_burst_manager_personalization.backup_id,
       stll_burst_manager_personalization.backup_prefix,
       stll_burst_manager_personalization.backup_midfix,
       stll_burst_manager_personalization.creds_access_key,
       stll_burst_manager_personalization.creds_secret_key,
       stll_burst_manager_personalization.creds_session_token,
       stll_burst_manager_personalization.creds_expiration,
       stll_burst_manager_personalization.cluster_id,
       stll_burst_manager_personalization.cluster_name,
       stll_burst_manager_personalization.error,
       stll_burst_manager_personalization.account_id,
       stll_burst_manager_personalization.query,
       stll_burst_manager_personalization.auto_wlm_total_memory_mb,
       stll_burst_manager_personalization.auto_wlm_per_query_max_memory_mb,
       stll_burst_manager_personalization.instance_type,
       stll_burst_manager_personalization.num_nodes
FROM stll_burst_manager_personalization;

alter table stl_burst_manager_personalization
    owner to rdsdb;

