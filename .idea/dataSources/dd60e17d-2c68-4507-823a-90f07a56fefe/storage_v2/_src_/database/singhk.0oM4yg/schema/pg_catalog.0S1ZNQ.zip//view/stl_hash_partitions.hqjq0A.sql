create view stl_hash_partitions(query, slice, segment, step, part_num, num_blocks, mem_resident, card) as
SELECT stll_hash_partitions.query,
       stll_hash_partitions.slice,
       stll_hash_partitions.segment,
       stll_hash_partitions.step,
       stll_hash_partitions.part_num,
       stll_hash_partitions.num_blocks,
       stll_hash_partitions.mem_resident,
       stll_hash_partitions.card
FROM stll_hash_partitions;

alter table stl_hash_partitions
    owner to rdsdb;

