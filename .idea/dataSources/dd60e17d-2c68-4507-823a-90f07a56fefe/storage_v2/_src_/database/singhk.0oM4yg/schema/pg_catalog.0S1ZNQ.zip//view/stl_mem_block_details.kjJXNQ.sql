create view stl_mem_block_details
            (recordtime, node, slice, type, uid, pid, process, qid, requested, roundedsize, page, buddy_page) as
SELECT stll_mem_block_details.recordtime,
       stll_mem_block_details.node,
       stll_mem_block_details.slice,
       stll_mem_block_details."type",
       stll_mem_block_details.uid,
       stll_mem_block_details.pid,
       stll_mem_block_details.process,
       stll_mem_block_details.qid,
       stll_mem_block_details.requested,
       stll_mem_block_details.roundedsize,
       stll_mem_block_details.page,
       stll_mem_block_details.buddy_page
FROM stll_mem_block_details;

alter table stl_mem_block_details
    owner to rdsdb;

