create view stl_auto_alter_worker_event
            (xid, pid, tbl, recommend, status, eventtime, retry_count, sequence, previous_state) as
SELECT stll_auto_alter_worker_event.xid,
       stll_auto_alter_worker_event.pid,
       stll_auto_alter_worker_event.tbl,
       stll_auto_alter_worker_event.recommend,
       stll_auto_alter_worker_event.status,
       stll_auto_alter_worker_event.eventtime,
       stll_auto_alter_worker_event.retry_count,
       stll_auto_alter_worker_event."sequence",
       stll_auto_alter_worker_event.previous_state
FROM stll_auto_alter_worker_event;

alter table stl_auto_alter_worker_event
    owner to rdsdb;

