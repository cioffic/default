create view stl_node_failovers(recordtime, failed_node, standby_node, stopped_veritas) as
SELECT stll_node_failovers.recordtime,
       stll_node_failovers.failed_node,
       stll_node_failovers.standby_node,
       stll_node_failovers.stopped_veritas
FROM stll_node_failovers;

alter table stl_node_failovers
    owner to rdsdb;

