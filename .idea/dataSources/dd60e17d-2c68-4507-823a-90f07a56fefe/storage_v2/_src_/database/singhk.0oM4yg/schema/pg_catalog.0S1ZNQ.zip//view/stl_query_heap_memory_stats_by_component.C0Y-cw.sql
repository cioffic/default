create view stl_query_heap_memory_stats_by_component
            (recordtime, pid, xid, query, userid, checkpoint, heap_mem_consumption, time_consumption, malloc, calloc,
             valloc, realloc, memalign, free)
as
SELECT stll_query_heap_memory_stats_by_component.recordtime,
       stll_query_heap_memory_stats_by_component.pid,
       stll_query_heap_memory_stats_by_component.xid,
       stll_query_heap_memory_stats_by_component.query,
       stll_query_heap_memory_stats_by_component.userid,
       stll_query_heap_memory_stats_by_component.checkpoint,
       stll_query_heap_memory_stats_by_component.heap_mem_consumption,
       stll_query_heap_memory_stats_by_component.time_consumption,
       stll_query_heap_memory_stats_by_component.malloc,
       stll_query_heap_memory_stats_by_component.calloc,
       stll_query_heap_memory_stats_by_component.valloc,
       stll_query_heap_memory_stats_by_component.realloc,
       stll_query_heap_memory_stats_by_component.memalign,
       stll_query_heap_memory_stats_by_component.free
FROM stll_query_heap_memory_stats_by_component;

alter table stl_query_heap_memory_stats_by_component
    owner to rdsdb;

