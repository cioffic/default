create view stl_dead_tuples_stats
            (eventtime, xid, table_id, num_visible_rows, dead_tuples_accurate, dead_tuples_stats) as
SELECT stll_dead_tuples_stats.eventtime,
       stll_dead_tuples_stats.xid,
       stll_dead_tuples_stats.table_id,
       stll_dead_tuples_stats.num_visible_rows,
       stll_dead_tuples_stats.dead_tuples_accurate,
       stll_dead_tuples_stats.dead_tuples_stats
FROM stll_dead_tuples_stats;

alter table stl_dead_tuples_stats
    owner to rdsdb;

