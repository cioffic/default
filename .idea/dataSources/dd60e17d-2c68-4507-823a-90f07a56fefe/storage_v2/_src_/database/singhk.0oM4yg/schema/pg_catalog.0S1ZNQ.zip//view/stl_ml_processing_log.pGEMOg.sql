create view stl_ml_processing_log (recordtime, pid, model_id, model_name, operation, processing_s3_path, message) as
SELECT stll_ml_processing_log.recordtime,
       stll_ml_processing_log.pid,
       stll_ml_processing_log.model_id,
       stll_ml_processing_log.model_name,
       stll_ml_processing_log.operation,
       stll_ml_processing_log.processing_s3_path,
       stll_ml_processing_log.message
FROM stll_ml_processing_log;

alter table stl_ml_processing_log
    owner to rdsdb;

