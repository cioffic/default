create view stl_xregion_metering(eventtime, query, region, internal_request_uuid, metered_mbs) as
SELECT stll_xregion_metering.eventtime,
       stll_xregion_metering.query,
       stll_xregion_metering."region",
       stll_xregion_metering.internal_request_uuid,
       stll_xregion_metering.metered_mbs
FROM stll_xregion_metering;

alter table stl_xregion_metering
    owner to rdsdb;

