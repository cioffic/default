create view stl_arcadia_main_usage
            (userid, recordtime, xid, cluster, instance_type, num_nodes, starttime, endtime, request_id,
             incurred_usage_ms) as
SELECT stll_arcadia_main_usage.userid,
       stll_arcadia_main_usage.recordtime,
       stll_arcadia_main_usage.xid,
       stll_arcadia_main_usage."cluster",
       stll_arcadia_main_usage.instance_type,
       stll_arcadia_main_usage.num_nodes,
       stll_arcadia_main_usage.starttime,
       stll_arcadia_main_usage.endtime,
       stll_arcadia_main_usage.request_id,
       stll_arcadia_main_usage.incurred_usage_ms
FROM stll_arcadia_main_usage;

alter table stl_arcadia_main_usage
    owner to rdsdb;

