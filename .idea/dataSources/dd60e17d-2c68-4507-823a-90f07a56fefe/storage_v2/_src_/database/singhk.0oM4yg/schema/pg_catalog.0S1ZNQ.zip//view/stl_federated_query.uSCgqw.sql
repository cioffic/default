create view stl_federated_query
            (userid, xid, pid, query, sourcetype, database, segment, node, slice, recordtime, querytext, num_rows,
             num_bytes, duration)
as
SELECT stll_federated_query.userid,
       stll_federated_query.xid,
       stll_federated_query.pid,
       stll_federated_query.query,
       stll_federated_query.sourcetype,
       stll_federated_query."database",
       stll_federated_query.segment,
       stll_federated_query.node,
       stll_federated_query.slice,
       stll_federated_query.recordtime,
       stll_federated_query.querytext,
       stll_federated_query.num_rows,
       stll_federated_query.num_bytes,
       stll_federated_query.duration
FROM stll_federated_query;

alter table stl_federated_query
    owner to rdsdb;

