create view stl_pinned_blocks(error_time, pid, slice, tbl, col, sb_pos) as
SELECT stll_pinned_blocks.error_time,
       stll_pinned_blocks.pid,
       stll_pinned_blocks.slice,
       stll_pinned_blocks.tbl,
       stll_pinned_blocks.col,
       stll_pinned_blocks.sb_pos
FROM stll_pinned_blocks;

alter table stl_pinned_blocks
    owner to rdsdb;

