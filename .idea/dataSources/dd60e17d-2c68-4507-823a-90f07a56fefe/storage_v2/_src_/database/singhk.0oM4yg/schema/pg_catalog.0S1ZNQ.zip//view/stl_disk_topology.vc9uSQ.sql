create view stl_disk_topology(t, node, host, diskno, mirror) as
SELECT stll_disk_topology.t,
       stll_disk_topology.node,
       stll_disk_topology."host",
       stll_disk_topology.diskno,
       stll_disk_topology.mirror
FROM stll_disk_topology;

alter table stl_disk_topology
    owner to rdsdb;

