create view stl_load_errors
            (userid, slice, tbl, starttime, session, query, filename, line_number, colname, type, col_length, position,
             raw_line, raw_field_value, err_code, err_reason, is_partial, start_offset)
as
SELECT stll_load_errors.userid,
       stll_load_errors.slice,
       stll_load_errors.tbl,
       stll_load_errors.starttime,
       stll_load_errors."session",
       stll_load_errors.query,
       stll_load_errors.filename,
       stll_load_errors.line_number,
       stll_load_errors.colname,
       stll_load_errors."type",
       stll_load_errors.col_length,
       stll_load_errors."position",
       stll_load_errors.raw_line,
       stll_load_errors.raw_field_value,
       stll_load_errors.err_code,
       stll_load_errors.err_reason,
       stll_load_errors.is_partial,
       stll_load_errors.start_offset
FROM stll_load_errors;

alter table stl_load_errors
    owner to rdsdb;

