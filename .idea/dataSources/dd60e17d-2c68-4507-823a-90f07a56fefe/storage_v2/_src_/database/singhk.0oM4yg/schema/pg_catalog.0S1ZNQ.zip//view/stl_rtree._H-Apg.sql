create view stl_rtree
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, tbl, is_diskbased, workmem,
             mem_allowance_for_index, cheating_mem, index_predicted_size, index_size)
as
SELECT stll_rtree.userid,
       stll_rtree.query,
       stll_rtree.slice,
       stll_rtree.segment,
       stll_rtree.step,
       stll_rtree.starttime,
       stll_rtree.endtime,
       stll_rtree.tasknum,
       stll_rtree."rows",
       stll_rtree.bytes,
       stll_rtree.tbl,
       stll_rtree.is_diskbased,
       stll_rtree.workmem,
       stll_rtree.mem_allowance_for_index,
       stll_rtree.cheating_mem,
       stll_rtree.index_predicted_size,
       stll_rtree.index_size
FROM stll_rtree;

alter table stl_rtree
    owner to rdsdb;

