create view stl_limit (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, hit_limit, checksum) as
SELECT stll_limit.userid,
       stll_limit.query,
       stll_limit.slice,
       stll_limit.segment,
       stll_limit.step,
       stll_limit.starttime,
       stll_limit.endtime,
       stll_limit.tasknum,
       stll_limit."rows",
       stll_limit.hit_limit,
       stll_limit.checksum
FROM stll_limit;

alter table stl_limit
    owner to rdsdb;

