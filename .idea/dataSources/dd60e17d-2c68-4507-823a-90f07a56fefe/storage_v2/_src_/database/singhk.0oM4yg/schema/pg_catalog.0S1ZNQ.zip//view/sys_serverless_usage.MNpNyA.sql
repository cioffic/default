create view sys_serverless_usage(start_time, end_time, compute_seconds, compute_capacity, data_storage) as
    Error: describing system view <sys_serverless_usage> is disabled;

alter table sys_serverless_usage
    owner to rdsdb;

