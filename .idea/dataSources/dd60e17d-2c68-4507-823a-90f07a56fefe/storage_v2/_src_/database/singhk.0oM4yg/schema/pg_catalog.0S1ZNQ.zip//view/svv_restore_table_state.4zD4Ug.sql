create view svv_restore_table_state (request_id, total_blocks, blocks_restored, status, allow_snapshot_delete) as
SELECT btrim(p."key"::text)                        AS request_id,
       COALESCE(sum(s.total_blocks), 0::bigint)    AS total_blocks,
       COALESCE(sum(s.blocks_restored), 0::bigint) AS blocks_restored,
       CASE
           WHEN "max"(s.in_progress) = 1 THEN 'IN_PROGRESS'::text
           WHEN "max"(s.in_progress) = 0 THEN 'SUCCESS'::text
           WHEN "max"(s.in_progress) = -1 THEN 'DROPPED'::text
           WHEN "max"(s.in_progress) IS NULL THEN 'DROPPED'::text
           ELSE 'INVALID_STATUS'::text
           END                                     AS status,
       CASE
           WHEN min(s.allow_snapshot_delete) IS NULL THEN 1
           ELSE min(s.allow_snapshot_delete)
           END                                     AS allow_snapshot_delete
FROM pg_conf p
         LEFT JOIN stv_restore_table_state s ON p.value = s.table_id::text
WHERE p."key" ~~ 'TLR_%'::text
GROUP BY p."key", p.value
ORDER BY p."key", p.value;

alter table svv_restore_table_state
    owner to rdsdb;

