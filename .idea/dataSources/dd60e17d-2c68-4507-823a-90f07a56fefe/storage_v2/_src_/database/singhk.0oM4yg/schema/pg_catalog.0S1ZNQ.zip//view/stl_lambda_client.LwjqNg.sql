create view stl_lambda_client (query, node, slice, segment, request_id, function_name, recordtime, num_records, size) as
SELECT stll_lambda_client.query,
       stll_lambda_client.node,
       stll_lambda_client.slice,
       stll_lambda_client.segment,
       stll_lambda_client.request_id,
       stll_lambda_client.function_name,
       stll_lambda_client.recordtime,
       stll_lambda_client.num_records,
       stll_lambda_client.size
FROM stll_lambda_client;

alter table stl_lambda_client
    owner to rdsdb;

