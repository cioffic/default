create view pg_table_def (schemaname, tablename, "column", type, encoding, distkey, sortkey, "notnull") as
SELECT n.nspname                                   AS schemaname,
       c.relname                                   AS tablename,
       a.attname                                   AS "column",
       format_type(a.atttypid, a.atttypmod)        AS "type",
       format_encoding(a.attencodingtype::integer) AS "encoding",
       a.attisdistkey                              AS "distkey",
       a.attsortkeyord                             AS "sortkey",
       a.attnotnull                                AS "notnull"
FROM pg_namespace n,
     pg_class c,
     pg_attribute a
WHERE n.oid = c.relnamespace
  AND c.oid = a.attrelid
  AND a.attnum > 0
  AND NOT a.attisdropped
  AND pg_table_is_visible(c.oid)
ORDER BY n.nspname, c.relname, a.attnum;

alter table pg_table_def
    owner to rdsdb;

