create view stl_skr_scan_metrics
            (query, segment, tbl, slice, col, observed_rrscan_rows_filtered, observed_post_rrscan_rows_filtered,
             estimated_rows_filtered, observation_type, recordtime)
as
SELECT stll_skr_scan_metrics.query,
       stll_skr_scan_metrics.segment,
       stll_skr_scan_metrics.tbl,
       stll_skr_scan_metrics.slice,
       stll_skr_scan_metrics.col,
       stll_skr_scan_metrics.observed_rrscan_rows_filtered,
       stll_skr_scan_metrics.observed_post_rrscan_rows_filtered,
       stll_skr_scan_metrics.estimated_rows_filtered,
       stll_skr_scan_metrics.observation_type,
       stll_skr_scan_metrics.recordtime
FROM stll_skr_scan_metrics;

alter table stl_skr_scan_metrics
    owner to rdsdb;

