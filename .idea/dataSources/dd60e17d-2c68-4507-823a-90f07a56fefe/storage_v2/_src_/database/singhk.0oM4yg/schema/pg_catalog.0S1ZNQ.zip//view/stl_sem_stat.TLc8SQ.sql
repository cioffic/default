create view stl_sem_stat (currenttime, sampletime, node, count, waittime, longest, mutex_requests, name) as
SELECT stll_sem_stat.currenttime,
       stll_sem_stat.sampletime,
       stll_sem_stat.node,
       stll_sem_stat.count,
       stll_sem_stat.waittime,
       stll_sem_stat.longest,
       stll_sem_stat.mutex_requests,
       stll_sem_stat.name
FROM stll_sem_stat;

alter table stl_sem_stat
    owner to rdsdb;

