create view svcs_s3requests
            (query, uuid, pid, segment, node, eventtime, duration_msec, retry_count, returned_rows, returned_bytes,
             s3_scanned_rows, s3_scanned_bytes, row_groups, skipped_row_groups, skipped_rows, fetched, file_size,
             start_offset, length, location, file, num_splits, last_timeout_msec, failed, etag, fingerprint,
             cache_status)
as
SELECT "map".primary_query                AS query,
       stcs.uuid,
       stcs.pid,
       stcs.segment,
       stcs.node,
       stcs.eventtime,
       stcs.duration_msec,
       stcs.retry_count,
       stcs.returned_rows,
       stcs.returned_bytes,
       stcs.s3_scanned_rows,
       stcs.s3_scanned_bytes,
       stcs.row_groups,
       stcs.skipped_row_groups,
       stcs.skipped_rows,
       stcs.fetched,
       stcs.file_size,
       stcs.start_offset,
       stcs.length,
       stcs."location"::character varying AS "location",
       stcs."file"::character varying     AS "file",
       stcs.num_splits,
       stcs.last_timeout_msec,
       stcs.failed,
       stcs.etag::character varying       AS etag,
       stcs.fingerprint,
       stcs.cache_status
FROM (SELECT r.query,
             r.uuid,
             r.pid,
             r.segment,
             r.node,
             '1970-01-01 00:00:00'::timestamp without time zone +
             (r.eventtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
             '00:00:01'::interval                                                         AS eventtime,
             round(r.duration::double precision / 1000::double precision, 1::numeric)     AS duration_msec,
             r.retry_count,
             r.returned_rows,
             r.returned_bytes,
             r.s3_scanned_rows,
             r.s3_scanned_bytes,
             r.row_groups,
             r.skipped_row_groups,
             r.skipped_rows,
             r.fetched,
             r.file_size,
             r.start_offset,
             r.length,
             btrim(r."location"::text)                                                    AS "location",
             btrim(r.file_name::text)                                                     AS "file",
             r.num_splits,
             round(r.last_timeout::double precision / 1000::double precision, 1::numeric) AS last_timeout_msec,
             r.failed,
             btrim(r.etag::text)                                                          AS etag,
             q.request_fingerprint                                                        AS fingerprint,
             CASE
                 WHEN r.cache_status > 1 THEN -1
                 ELSE r.cache_status
                 END                                                                      AS cache_status,
             r.__path,
             r.scan_type
      FROM stcs_s3requests r,
           stcs_s3query q
      WHERE r.__cluster_type = 'cs'::bpchar
        AND to_date(r.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
        AND q.__cluster_type = 'cs'::bpchar
        AND to_date(q.__log_generated_date::text, 'YYYYMMDD'::text) > (getdate() - '7 days'::interval)
        AND r.query = q.query
        AND r.segment = q.segment
        AND r.node = q.node
        AND r.slice = q.slice) stcs
         JOIN stcs_concurrency_scaling_query_mapping "map" ON "map".concurrency_scaling_query = stcs.query
WHERE "map".concurrency_scaling_cluster::text = split_part(stcs.__path::text, '/'::text, 10)
  AND stcs.scan_type = 2
UNION ALL
SELECT svl_s3requests.query,
       svl_s3requests.uuid,
       svl_s3requests.pid,
       svl_s3requests.segment,
       svl_s3requests.node,
       svl_s3requests.eventtime,
       svl_s3requests.duration_msec,
       svl_s3requests.retry_count,
       svl_s3requests.returned_rows,
       svl_s3requests.returned_bytes,
       svl_s3requests.s3_scanned_rows,
       svl_s3requests.s3_scanned_bytes,
       svl_s3requests.row_groups,
       svl_s3requests.skipped_row_groups,
       svl_s3requests.skipped_rows,
       svl_s3requests.fetched,
       svl_s3requests.file_size,
       svl_s3requests.start_offset,
       svl_s3requests.length,
       svl_s3requests."location"::character varying AS "location",
       svl_s3requests."file"::character varying     AS "file",
       svl_s3requests.num_splits,
       svl_s3requests.last_timeout_msec,
       svl_s3requests.failed,
       svl_s3requests.etag::character varying       AS etag,
       svl_s3requests.fingerprint,
       svl_s3requests.cache_status
FROM svl_s3requests;

alter table svcs_s3requests
    owner to rdsdb;

