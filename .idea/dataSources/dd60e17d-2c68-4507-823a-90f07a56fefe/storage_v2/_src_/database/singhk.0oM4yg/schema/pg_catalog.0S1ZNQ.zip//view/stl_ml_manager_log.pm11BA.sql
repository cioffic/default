create view stl_ml_manager_log(pid, recordtime, message) as
SELECT stll_ml_manager_log.pid, stll_ml_manager_log.recordtime, stll_ml_manager_log.message
FROM stll_ml_manager_log;

alter table stl_ml_manager_log
    owner to rdsdb;

