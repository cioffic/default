create view stl_plan_explain_props(query, nodeid, propid, lineno, detail) as
SELECT stll_plan_explain_props.query,
       stll_plan_explain_props.nodeid,
       stll_plan_explain_props.propid,
       stll_plan_explain_props.lineno,
       stll_plan_explain_props.detail
FROM stll_plan_explain_props;

alter table stl_plan_explain_props
    owner to rdsdb;

