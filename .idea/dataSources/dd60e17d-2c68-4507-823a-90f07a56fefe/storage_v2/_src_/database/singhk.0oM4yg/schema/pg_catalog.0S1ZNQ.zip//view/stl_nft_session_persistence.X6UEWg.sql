create view stl_nft_session_persistence(recordtime, pid, event) as
SELECT stll_nft_session_persistence.recordtime, stll_nft_session_persistence.pid, stll_nft_session_persistence.event
FROM stll_nft_session_persistence;

alter table stl_nft_session_persistence
    owner to rdsdb;

