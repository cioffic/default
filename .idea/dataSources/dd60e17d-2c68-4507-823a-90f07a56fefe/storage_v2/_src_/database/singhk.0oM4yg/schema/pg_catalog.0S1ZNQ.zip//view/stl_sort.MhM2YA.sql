create view stl_sort
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, bytes, tbl, is_diskbased, workmem,
             checksum) as
SELECT stll_sort.userid,
       stll_sort.query,
       stll_sort.slice,
       stll_sort.segment,
       stll_sort.step,
       stll_sort.starttime,
       stll_sort.endtime,
       stll_sort.tasknum,
       stll_sort."rows",
       stll_sort.bytes,
       stll_sort.tbl,
       stll_sort.is_diskbased,
       stll_sort.workmem,
       stll_sort.checksum
FROM stll_sort;

alter table stl_sort
    owner to rdsdb;

