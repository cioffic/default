create view stl_smfaults_mval(seq, run, thresh, value) as
SELECT stll_smfaults_mval.seq, stll_smfaults_mval.run, stll_smfaults_mval.thresh, stll_smfaults_mval.value
FROM stll_smfaults_mval;

alter table stl_smfaults_mval
    owner to rdsdb;

