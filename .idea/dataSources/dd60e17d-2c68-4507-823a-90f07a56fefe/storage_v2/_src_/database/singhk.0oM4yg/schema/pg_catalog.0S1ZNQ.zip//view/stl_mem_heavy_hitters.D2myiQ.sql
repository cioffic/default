create view stl_mem_heavy_hitters
            (since, now, node, memory_type, mem_operation, shared_mem_type, process_type, hex_addresses) as
SELECT stll_mem_heavy_hitters.since,
       stll_mem_heavy_hitters.now,
       stll_mem_heavy_hitters.node,
       stll_mem_heavy_hitters.memory_type,
       stll_mem_heavy_hitters.mem_operation,
       stll_mem_heavy_hitters.shared_mem_type,
       stll_mem_heavy_hitters."process_type",
       stll_mem_heavy_hitters.hex_addresses
FROM stll_mem_heavy_hitters;

alter table stl_mem_heavy_hitters
    owner to rdsdb;

