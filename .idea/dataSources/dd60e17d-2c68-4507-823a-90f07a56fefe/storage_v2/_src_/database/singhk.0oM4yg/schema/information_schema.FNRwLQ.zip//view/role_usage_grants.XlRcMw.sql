create view role_usage_grants
            (grantor, grantee, object_catalog, object_schema, object_name, object_type, privilege_type, is_grantable) as
SELECT NULL::information_schema.sql_identifier::information_schema.sql_identifier    AS grantor,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier    AS grantee,
       current_database()::information_schema.sql_identifier                         AS object_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier    AS object_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier    AS object_name,
       NULL::information_schema.character_data::information_schema.character_data    AS object_type,
       'USAGE'::information_schema.character_data::information_schema.character_data AS privilege_type,
       NULL::information_schema.character_data::information_schema.character_data    AS is_grantable
WHERE false;

alter table role_usage_grants
    owner to rdsdb;

