create view stl_steps(query, nodeid, segment, step) as
SELECT stll_steps.query, stll_steps.nodeid, stll_steps.segment, stll_steps.step
FROM stll_steps;

alter table stl_steps
    owner to rdsdb;

