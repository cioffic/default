create view stl_comm_excess
            (process, recordtime, cmd_code, seqnum, channel, src_slice, dst_slice, len, is_bcast, ack_reply, ack_xon,
             sync_msg, fragment, comment)
as
SELECT stll_comm_excess.process,
       stll_comm_excess.recordtime,
       stll_comm_excess.cmd_code,
       stll_comm_excess.seqnum,
       stll_comm_excess.channel,
       stll_comm_excess.src_slice,
       stll_comm_excess.dst_slice,
       stll_comm_excess.len,
       stll_comm_excess.is_bcast,
       stll_comm_excess.ack_reply,
       stll_comm_excess.ack_xon,
       stll_comm_excess.sync_msg,
       stll_comm_excess.fragment,
       stll_comm_excess."comment"
FROM stll_comm_excess;

alter table stl_comm_excess
    owner to rdsdb;

