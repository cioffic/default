create view stl_omnisql_error (userid, recordtime, query, errcode, file, linenum, context, error, module) as
SELECT stll_omnisql_error.userid,
       stll_omnisql_error.recordtime,
       stll_omnisql_error.query,
       stll_omnisql_error.errcode,
       stll_omnisql_error."file",
       stll_omnisql_error.linenum,
       stll_omnisql_error.context,
       stll_omnisql_error.error,
       stll_omnisql_error.module
FROM stll_omnisql_error;

alter table stl_omnisql_error
    owner to rdsdb;

