create view stl_plan_rule_stats
            (query, sequence, optimizer, rule, match_count, applicable_count, apply_count, trasnformed_count,
             applicable_total_time, applicable_max_time, applicable_min_time, applicable_avg_time, apply_total_time,
             apply_max_time, apply_min_time, apply_avg_time)
as
SELECT stll_plan_rule_stats.query,
       stll_plan_rule_stats."sequence",
       stll_plan_rule_stats.optimizer,
       stll_plan_rule_stats."rule",
       stll_plan_rule_stats.match_count,
       stll_plan_rule_stats.applicable_count,
       stll_plan_rule_stats.apply_count,
       stll_plan_rule_stats.trasnformed_count,
       stll_plan_rule_stats.applicable_total_time,
       stll_plan_rule_stats.applicable_max_time,
       stll_plan_rule_stats.applicable_min_time,
       stll_plan_rule_stats.applicable_avg_time,
       stll_plan_rule_stats.apply_total_time,
       stll_plan_rule_stats.apply_max_time,
       stll_plan_rule_stats.apply_min_time,
       stll_plan_rule_stats.apply_avg_time
FROM stll_plan_rule_stats;

alter table stl_plan_rule_stats
    owner to rdsdb;

