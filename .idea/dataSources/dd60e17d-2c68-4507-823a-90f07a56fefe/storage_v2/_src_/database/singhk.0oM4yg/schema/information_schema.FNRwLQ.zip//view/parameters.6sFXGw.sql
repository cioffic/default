create view parameters
            (specific_catalog, specific_schema, specific_name, ordinal_position, parameter_mode, is_result, as_locator,
             parameter_name, data_type, character_maximum_length, character_octet_length, character_set_catalog,
             character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
             numeric_precision, numeric_precision_radix, numeric_scale, datetime_precision, interval_type,
             interval_precision, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema, scope_name,
             maximum_cardinality, dtd_identifier)
as
SELECT current_database()::information_schema.sql_identifier                                                 AS specific_catalog,
       n.nspname::information_schema.sql_identifier                                                          AS specific_schema,
       ((p.proname::text || '_'::text) || p.oid::character varying::text)::information_schema.sql_identifier AS specific_name,
       pos.n::information_schema.cardinal_number                                                             AS ordinal_position,
       'IN'::information_schema.character_data::information_schema.character_data                            AS parameter_mode,
       'NO'::information_schema.character_data::information_schema.character_data                            AS is_result,
       'NO'::information_schema.character_data::information_schema.character_data                            AS as_locator,
       CASE
           WHEN p.proargnames[pos.n] = ''::text THEN NULL::text
           ELSE p.proargnames[pos.n]
           END::information_schema.sql_identifier                                                            AS parameter_name,
       CASE
           WHEN t.typelem <> 0::oid AND t.typlen = -1 THEN 'ARRAY'::text
           WHEN nt.nspname = 'pg_catalog'::name THEN format_type(t.oid, NULL::integer)
           ELSE 'USER-DEFINED'::text
           END::information_schema.character_data                                                            AS data_type,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS character_maximum_length,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS character_octet_length,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS character_set_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS character_set_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS character_set_name,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS collation_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS collation_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS collation_name,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS numeric_precision,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS numeric_precision_radix,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS numeric_scale,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS datetime_precision,
       NULL::information_schema.character_data::information_schema.character_data                            AS interval_type,
       NULL::information_schema.character_data::information_schema.character_data                            AS interval_precision,
       current_database()::information_schema.sql_identifier                                                 AS udt_catalog,
       nt.nspname::information_schema.sql_identifier                                                         AS udt_schema,
       t.typname::information_schema.sql_identifier                                                          AS udt_name,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS scope_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS scope_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier                            AS scope_name,
       NULL::information_schema.cardinal_number::information_schema.cardinal_number                          AS maximum_cardinality,
       pos.n::information_schema.sql_identifier                                                              AS dtd_identifier
FROM pg_namespace n,
     pg_proc p,
     pg_type t,
     pg_namespace nt,
     pg_user u,
     information_schema._pg_keypositions() pos(n)
WHERE n.oid = p.pronamespace
  AND p.pronargs >= pos.n
  AND p.proargtypes[pos.n - 1] = t.oid
  AND t.typnamespace = nt.oid
  AND p.proowner = u.usesysid
  AND (u.usename = "current_user"()::name OR has_function_privilege(p.oid, 'EXECUTE'::text));

alter table parameters
    owner to rdsdb;

