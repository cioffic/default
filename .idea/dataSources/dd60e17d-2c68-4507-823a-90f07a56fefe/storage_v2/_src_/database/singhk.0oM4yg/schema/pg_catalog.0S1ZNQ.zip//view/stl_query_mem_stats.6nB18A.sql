create view stl_query_mem_stats
            (node, query, max_mem_count, max_mem_size, num_pin_count, num_unpin_count, max_pinned_count, now) as
SELECT stll_query_mem_stats.node,
       stll_query_mem_stats.query,
       stll_query_mem_stats.max_mem_count,
       stll_query_mem_stats.max_mem_size,
       stll_query_mem_stats.num_pin_count,
       stll_query_mem_stats.num_unpin_count,
       stll_query_mem_stats.max_pinned_count,
       stll_query_mem_stats.now
FROM stll_query_mem_stats;

alter table stl_query_mem_stats
    owner to rdsdb;

