create view stl_leader_control(recordtime, pid, msg) as
SELECT stll_leader_control.recordtime, stll_leader_control.pid, stll_leader_control.msg
FROM stll_leader_control;

alter table stl_leader_control
    owner to rdsdb;

