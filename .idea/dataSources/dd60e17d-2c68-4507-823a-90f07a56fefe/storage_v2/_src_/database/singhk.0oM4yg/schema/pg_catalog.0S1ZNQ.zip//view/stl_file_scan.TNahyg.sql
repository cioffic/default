create view stl_file_scan (userid, query, slice, name, lines, bytes, loadtime, curtime, is_partial, start_offset) as
SELECT stll_file_scan.userid,
       stll_file_scan.query,
       stll_file_scan.slice,
       stll_file_scan.name,
       stll_file_scan."lines",
       stll_file_scan.bytes,
       stll_file_scan.loadtime,
       stll_file_scan.curtime,
       stll_file_scan.is_partial,
       stll_file_scan.start_offset
FROM stll_file_scan;

alter table stl_file_scan
    owner to rdsdb;

