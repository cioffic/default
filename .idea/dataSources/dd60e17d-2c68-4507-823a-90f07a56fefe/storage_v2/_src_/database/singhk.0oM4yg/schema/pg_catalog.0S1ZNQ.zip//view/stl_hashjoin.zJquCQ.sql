create view stl_hashjoin
            (userid, query, slice, segment, step, starttime, endtime, tasknum, rows, tbl, num_parts, join_type,
             hash_looped, switched_parts, used_prefetching, hash_segment, hash_step, checksum, distribution,
             is_externalized)
as
SELECT stll_hashjoin.userid,
       stll_hashjoin.query,
       stll_hashjoin.slice,
       stll_hashjoin.segment,
       stll_hashjoin.step,
       stll_hashjoin.starttime,
       stll_hashjoin.endtime,
       stll_hashjoin.tasknum,
       stll_hashjoin."rows",
       stll_hashjoin.tbl,
       stll_hashjoin.num_parts,
       stll_hashjoin.join_type,
       stll_hashjoin.hash_looped,
       stll_hashjoin.switched_parts,
       stll_hashjoin.used_prefetching,
       stll_hashjoin.hash_segment,
       stll_hashjoin.hash_step,
       stll_hashjoin.checksum,
       stll_hashjoin.distribution,
       stll_hashjoin.is_externalized
FROM stll_hashjoin;

alter table stl_hashjoin
    owner to rdsdb;

