create view stl_catalog_rebuild_info
            (xid, database, table_name, table_oid, num_live_tups, num_dead_tups, total_live_tup_sz, total_dead_tup_sz,
             starttime, tuple_storage_duration_in_msec, commit_lock_acq_duration_in_msec, rebuild_duration_in_msec,
             total_duration_in_msec, message, rebuild_mode, startup, versioned_rebuild, versioned_rebuild_pivot_xid,
             heap_xlog_duration_in_msec, index_xlog_duration_in_msec, xlog_write_duration_in_msec,
             xlog_fsync_duration_in_msec, repwal_duration_in_msec, xlog_write_lock_acq_time_in_msec,
             xlog_insert_lock_acq_time_in_msec, num_xlog_writes, num_xlog_fsyncs)
as
SELECT stll_catalog_rebuild_info.xid,
       stll_catalog_rebuild_info."database",
       stll_catalog_rebuild_info.table_name,
       stll_catalog_rebuild_info.table_oid,
       stll_catalog_rebuild_info.num_live_tups,
       stll_catalog_rebuild_info.num_dead_tups,
       stll_catalog_rebuild_info.total_live_tup_sz,
       stll_catalog_rebuild_info.total_dead_tup_sz,
       stll_catalog_rebuild_info.starttime,
       stll_catalog_rebuild_info.tuple_storage_duration_in_msec,
       stll_catalog_rebuild_info.commit_lock_acq_duration_in_msec,
       stll_catalog_rebuild_info.rebuild_duration_in_msec,
       stll_catalog_rebuild_info.total_duration_in_msec,
       stll_catalog_rebuild_info.message,
       stll_catalog_rebuild_info.rebuild_mode,
       stll_catalog_rebuild_info.startup,
       stll_catalog_rebuild_info.versioned_rebuild,
       stll_catalog_rebuild_info.versioned_rebuild_pivot_xid,
       stll_catalog_rebuild_info.heap_xlog_duration_in_msec,
       stll_catalog_rebuild_info.index_xlog_duration_in_msec,
       stll_catalog_rebuild_info.xlog_write_duration_in_msec,
       stll_catalog_rebuild_info.xlog_fsync_duration_in_msec,
       stll_catalog_rebuild_info.repwal_duration_in_msec,
       stll_catalog_rebuild_info.xlog_write_lock_acq_time_in_msec,
       stll_catalog_rebuild_info.xlog_insert_lock_acq_time_in_msec,
       stll_catalog_rebuild_info.num_xlog_writes,
       stll_catalog_rebuild_info.num_xlog_fsyncs
FROM stll_catalog_rebuild_info;

alter table stl_catalog_rebuild_info
    owner to rdsdb;

