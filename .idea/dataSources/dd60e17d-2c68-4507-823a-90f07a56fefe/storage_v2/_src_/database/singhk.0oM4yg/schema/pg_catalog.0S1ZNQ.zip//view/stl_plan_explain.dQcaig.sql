create view stl_plan_explain
            (query, nid, level, blockid, block_nid, opname, estimate_rows, estimate_width, total_cost, startup_cost) as
SELECT stll_plan_explain.query,
       stll_plan_explain.nid,
       stll_plan_explain."level",
       stll_plan_explain.blockid,
       stll_plan_explain.block_nid,
       stll_plan_explain.opname,
       stll_plan_explain.estimate_rows,
       stll_plan_explain.estimate_width,
       stll_plan_explain.total_cost,
       stll_plan_explain.startup_cost
FROM stll_plan_explain;

alter table stl_plan_explain
    owner to rdsdb;

