create or replace view ads_staging.avw_map_qualifier_codes as
(
select qualifier_code_mapping_id,
       channel,
       partner,
       qualifier_code,
       business_unit,
       season_year,
       venue_name,
       season_name,
       cast(msg_off_amount as float)                                        as msg_off_amount,
       cast(tm_fee_amount as float)                                         as tm_fee_amount,
       included_ff_flg,
       cast(credit_card as float)                                           as credit_card,
       cast(msg_revshare as float)                                          as msg_revshare,
       cast(partner_revshare as float)                                      as partner_revshare,
       metadata,
       created_at,
       updated_at,
       username,
       '%' || qualifier_code || '%'                                         as retail_qualifier_code,
       '%,' || qualifier_code || ',%'                                       as ticket_retail_qualifiers,
       rank() over (partition by partner order by len(qualifier_code) desc) as rnk_len
from mapping_tables.map_qualifier_codes a
    )
with no schema binding;

alter table avw_map_qualifier_codes
    owner to singhk;

