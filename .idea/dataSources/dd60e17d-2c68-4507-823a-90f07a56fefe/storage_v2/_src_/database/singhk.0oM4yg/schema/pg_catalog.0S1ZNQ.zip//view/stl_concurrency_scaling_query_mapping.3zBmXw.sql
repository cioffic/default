create view stl_concurrency_scaling_query_mapping
            (userid, primary_query, concurrency_scaling_query, concurrency_scaling_cluster) as
SELECT stll_concurrency_scaling_query_mapping.userid,
       stll_concurrency_scaling_query_mapping.primary_query,
       stll_concurrency_scaling_query_mapping.concurrency_scaling_query,
       stll_concurrency_scaling_query_mapping.concurrency_scaling_cluster
FROM stll_concurrency_scaling_query_mapping;

alter table stl_concurrency_scaling_query_mapping
    owner to rdsdb;

