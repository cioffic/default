create view stl_arcadia_concurrency_scaling_usage
            (userid, recordtime, rewritten_qid, user_query_id, child_query_seq, cluster, instance_type, num_nodes,
             starttime, endtime, request_id, incurred_usage_ms)
as
SELECT stll_arcadia_concurrency_scaling_usage.userid,
       stll_arcadia_concurrency_scaling_usage.recordtime,
       stll_arcadia_concurrency_scaling_usage.rewritten_qid,
       stll_arcadia_concurrency_scaling_usage.user_query_id,
       stll_arcadia_concurrency_scaling_usage.child_query_seq,
       stll_arcadia_concurrency_scaling_usage."cluster",
       stll_arcadia_concurrency_scaling_usage.instance_type,
       stll_arcadia_concurrency_scaling_usage.num_nodes,
       stll_arcadia_concurrency_scaling_usage.starttime,
       stll_arcadia_concurrency_scaling_usage.endtime,
       stll_arcadia_concurrency_scaling_usage.request_id,
       stll_arcadia_concurrency_scaling_usage.incurred_usage_ms
FROM stll_arcadia_concurrency_scaling_usage;

alter table stl_arcadia_concurrency_scaling_usage
    owner to rdsdb;

