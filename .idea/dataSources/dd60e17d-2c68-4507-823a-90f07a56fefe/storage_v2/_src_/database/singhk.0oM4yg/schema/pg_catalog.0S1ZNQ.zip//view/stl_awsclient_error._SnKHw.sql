create view stl_awsclient_error
            (userid, query, slice, recordtime, pid, http_method, endpoint, error, amzn_request_id) as
SELECT stll_awsclient_error.userid,
       stll_awsclient_error.query,
       stll_awsclient_error.slice,
       stll_awsclient_error.recordtime,
       stll_awsclient_error.pid,
       stll_awsclient_error.http_method,
       stll_awsclient_error.endpoint,
       stll_awsclient_error.error,
       stll_awsclient_error.amzn_request_id
FROM stll_awsclient_error;

alter table stl_awsclient_error
    owner to rdsdb;

