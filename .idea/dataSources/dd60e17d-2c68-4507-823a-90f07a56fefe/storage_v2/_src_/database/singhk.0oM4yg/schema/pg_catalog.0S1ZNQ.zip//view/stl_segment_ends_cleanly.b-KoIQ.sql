create view stl_segment_ends_cleanly
            (userid, node, tasknum, pid, dispatched, starttime, endtime, query, slice, seg, global_slice) as
SELECT stll_segment_ends_cleanly.userid,
       stll_segment_ends_cleanly.node,
       stll_segment_ends_cleanly.tasknum,
       stll_segment_ends_cleanly.pid,
       stll_segment_ends_cleanly.dispatched,
       stll_segment_ends_cleanly.starttime,
       stll_segment_ends_cleanly.endtime,
       stll_segment_ends_cleanly.query,
       stll_segment_ends_cleanly.slice,
       stll_segment_ends_cleanly.seg,
       stll_segment_ends_cleanly.global_slice
FROM stll_segment_ends_cleanly;

alter table stl_segment_ends_cleanly
    owner to rdsdb;

