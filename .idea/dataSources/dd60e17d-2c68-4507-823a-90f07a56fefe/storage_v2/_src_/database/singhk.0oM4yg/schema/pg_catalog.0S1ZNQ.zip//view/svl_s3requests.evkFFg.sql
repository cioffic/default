create view svl_s3requests
            (query, uuid, pid, segment, node, slice, eventtime, duration_msec, retry_count, returned_rows,
             returned_bytes, s3_scanned_rows, s3_scanned_bytes, row_groups, skipped_row_groups, skipped_rows, fetched,
             file_size, start_offset, length, location, file, num_splits, last_timeout_msec, failed, etag, fingerprint,
             cache_status, s3_physical_scanned_bytes, starttime, client_fetch_wait_time, cache_compression_ratio,
             cache_compression_latency)
as
SELECT r.query,
       r.uuid,
       r.pid,
       r.segment,
       r.node,
       r.slice,
       r.eventtime,
       round(r.duration::double precision / 1000::double precision, 1::numeric)     AS duration_msec,
       r.retry_count,
       r.returned_rows,
       r.returned_bytes,
       r.s3_scanned_rows,
       r.s3_scanned_bytes,
       r.row_groups,
       r.skipped_row_groups,
       r.skipped_rows,
       r.fetched,
       r.file_size,
       r.start_offset,
       r.length,
       btrim(r."location"::text)                                                    AS "location",
       btrim(r.file_name::text)                                                     AS "file",
       r.num_splits,
       round(r.last_timeout::double precision / 1000::double precision, 1::numeric) AS last_timeout_msec,
       r.failed,
       btrim(r.etag::text)                                                          AS etag,
       q.request_fingerprint                                                        AS fingerprint,
       CASE
           WHEN r.cache_status > 1 THEN -1
           ELSE r.cache_status
           END                                                                      AS cache_status,
       r.s3_physical_scanned_bytes,
       r.starttime,
       r.client_fetch_wait_time,
       CASE
           WHEN r.cache_compressed_size > 1 THEN round(
                       r.cache_uncompressed_size::double precision / r.cache_compressed_size::double precision,
                       1::numeric)
           ELSE 0::double precision
           END                                                                      AS cache_compression_ratio,
       r.cache_compression_latency
FROM stl_s3requests r
         LEFT JOIN stl_s3query q
                   ON r.query = q.query AND r.segment = q.segment AND r.node = q.node AND r.slice = q.slice;

alter table svl_s3requests
    owner to rdsdb;

