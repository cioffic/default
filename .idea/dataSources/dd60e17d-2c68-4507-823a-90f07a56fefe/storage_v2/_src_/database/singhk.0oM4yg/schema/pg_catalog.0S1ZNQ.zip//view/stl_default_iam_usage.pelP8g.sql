create view stl_default_iam_usage (record_time, node, slice, xid, pid, command_type, request_type, is_succeeded) as
SELECT stll_default_iam_usage.record_time,
       stll_default_iam_usage.node,
       stll_default_iam_usage.slice,
       stll_default_iam_usage.xid,
       stll_default_iam_usage.pid,
       stll_default_iam_usage.command_type,
       stll_default_iam_usage.request_type,
       stll_default_iam_usage.is_succeeded
FROM stll_default_iam_usage;

alter table stl_default_iam_usage
    owner to rdsdb;

