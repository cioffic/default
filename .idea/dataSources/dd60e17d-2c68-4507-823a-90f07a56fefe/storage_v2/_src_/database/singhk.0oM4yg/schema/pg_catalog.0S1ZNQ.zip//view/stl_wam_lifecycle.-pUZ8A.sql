create view stl_wam_lifecycle
            (record_time, wam_file_name, wam_action, wam_type_id, record_type_id, node, caller_description,
             number_of_records, precommit_id, restart_incarnation)
as
SELECT stll_wam_lifecycle.record_time,
       stll_wam_lifecycle.wam_file_name,
       stll_wam_lifecycle.wam_action,
       stll_wam_lifecycle.wam_type_id,
       stll_wam_lifecycle.record_type_id,
       stll_wam_lifecycle.node,
       stll_wam_lifecycle.caller_description,
       stll_wam_lifecycle.number_of_records,
       stll_wam_lifecycle.precommit_id,
       stll_wam_lifecycle.restart_incarnation
FROM stll_wam_lifecycle;

alter table stl_wam_lifecycle
    owner to rdsdb;

