create view stl_s3query_billing_trace(eventtime, requestid, errtype, errmsg) as
SELECT stll_s3query_billing_trace.eventtime,
       stll_s3query_billing_trace.requestid,
       stll_s3query_billing_trace.errtype,
       stll_s3query_billing_trace.errmsg
FROM stll_s3query_billing_trace;

alter table stl_s3query_billing_trace
    owner to rdsdb;

