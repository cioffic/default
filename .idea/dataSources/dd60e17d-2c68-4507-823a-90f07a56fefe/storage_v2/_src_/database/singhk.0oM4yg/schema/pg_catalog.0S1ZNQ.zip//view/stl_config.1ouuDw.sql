create view stl_config (name, value, category, advanced, helpfile, updater, chooser, restart, summary) as
SELECT stll_config.name,
       stll_config.value,
       stll_config.category,
       stll_config.advanced,
       stll_config.helpfile,
       stll_config."updater",
       stll_config.chooser,
       stll_config."restart",
       stll_config.summary
FROM stll_config;

alter table stl_config
    owner to rdsdb;

