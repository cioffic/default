create view stl_hdr_integrity_error(recordtime, node_num, sb_ver, xid, sb_pos, hdr_dump) as
SELECT stll_hdr_integrity_error.recordtime,
       stll_hdr_integrity_error.node_num,
       stll_hdr_integrity_error.sb_ver,
       stll_hdr_integrity_error.xid,
       stll_hdr_integrity_error.sb_pos,
       stll_hdr_integrity_error.hdr_dump
FROM stll_hdr_integrity_error;

alter table stl_hdr_integrity_error
    owner to rdsdb;

