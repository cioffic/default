create view stl_s3retries
            (userid, query, uuid, segment, node, slice, eventtime, retries, successful_fetches, file_size, start_offset,
             length, location, message, retry_backoff_ms, scan_type, timeout, connect_retries, connect_time,
             exectask_time, fast_forward_fetch_time, fetch_time, request_id, state)
as
SELECT stll_s3retries.userid,
       stll_s3retries.query,
       stll_s3retries.uuid,
       stll_s3retries.segment,
       stll_s3retries.node,
       stll_s3retries.slice,
       stll_s3retries.eventtime,
       stll_s3retries.retries,
       stll_s3retries.successful_fetches,
       stll_s3retries.file_size,
       stll_s3retries.start_offset,
       stll_s3retries.length,
       stll_s3retries."location",
       stll_s3retries.message,
       stll_s3retries.retry_backoff_ms,
       stll_s3retries.scan_type,
       stll_s3retries."timeout",
       stll_s3retries.connect_retries,
       stll_s3retries.connect_time,
       stll_s3retries.exectask_time,
       stll_s3retries.fast_forward_fetch_time,
       stll_s3retries.fetch_time,
       stll_s3retries.request_id,
       stll_s3retries.state
FROM stll_s3retries;

alter table stl_s3retries
    owner to rdsdb;

