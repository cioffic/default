create view stl_mv_state
            (userid, starttime, xid, event_desc, db_name, base_table_schema, base_table_name, mv_schema, mv_name,
             state) as
SELECT stll_mv_state.userid,
       stll_mv_state.starttime,
       stll_mv_state.xid,
       stll_mv_state.event_desc,
       stll_mv_state.db_name,
       stll_mv_state.base_table_schema,
       stll_mv_state.base_table_name,
       stll_mv_state.mv_schema,
       stll_mv_state.mv_name,
       stll_mv_state.state
FROM stll_mv_state;

alter table stl_mv_state
    owner to rdsdb;

