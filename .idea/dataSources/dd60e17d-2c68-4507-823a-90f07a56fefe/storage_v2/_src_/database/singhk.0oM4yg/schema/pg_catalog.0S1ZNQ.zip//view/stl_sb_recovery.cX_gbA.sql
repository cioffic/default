create view stl_sb_recovery(start_time, end_time, sb_img, sb_version, recovery_type) as
SELECT stll_sb_recovery.start_time,
       stll_sb_recovery.end_time,
       stll_sb_recovery.sb_img,
       stll_sb_recovery.sb_version,
       stll_sb_recovery.recovery_type
FROM stll_sb_recovery;

alter table stl_sb_recovery
    owner to rdsdb;

