create view svl_table_mutex (query, segment, step, slice, pid, eventtime, table_id, data_slice, mode, type) as
SELECT a.query,
       a.segment,
       a.step,
       a.slice,
       a.pid,
       a.eventtime,
       a.table_id,
       a.data_slice,
       CASE
           WHEN a."mode" = 1 THEN 'SHARED'::text
           WHEN a."mode" = 2 THEN 'EXCLUSIVE'::text
           ELSE NULL::text
           END AS "mode",
       CASE
           WHEN a."type" = 0 THEN 'ATTEMPT'::text
           WHEN a."type" = 1 THEN 'ACQUIRED'::text
           WHEN a."type" = 2 THEN 'RELEASED'::text
           WHEN a."type" = 3 THEN 'TRY-LOCK-FAILED'::text
           WHEN a."type" = 4 THEN 'RELINQUISHED'::text
           ELSE NULL::text
           END AS "type"
FROM stl_table_mutex a;

alter table svl_table_mutex
    owner to rdsdb;

