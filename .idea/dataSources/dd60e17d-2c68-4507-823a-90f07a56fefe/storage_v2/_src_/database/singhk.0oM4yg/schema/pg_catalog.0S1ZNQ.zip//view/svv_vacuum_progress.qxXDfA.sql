create view svv_vacuum_progress(table_name, status, time_remaining_estimate) as
SELECT rtrim(t.name::text)::character varying(255) AS table_name,
       CASE
           WHEN v.status = 'Finished'::bpchar THEN 'Complete'::text
           WHEN v.status ~~ 'Skipped%'::text THEN rtrim(v.status::text)
           WHEN x.xid IS NULL AND v.status <> 'Finished'::bpchar AND v.status !~~ 'Skipped%'::text THEN 'Failed'::text
           ELSE rtrim(q.querytxt::text)
           END::character varying(4000)            AS status,
       CASE
           WHEN v.status = 'Finished'::bpchar OR v.status ~~ 'Skipped%'::text OR x.xid IS NULL OR
                e.est_remaining IS NULL THEN NULL::text
           WHEN e.est_remaining::text < 0::text AND
                NOT (v.status = 'Finished'::bpchar OR v.status ~~ 'Skipped%'::text OR x.xid IS NULL OR
                     e.est_remaining IS NULL) THEN '0m 0s'::text
           ELSE "date_part"('minute'::text, e.est_remaining)::character varying::text + 'm '::text +
                ("date_part"('second'::text, e.est_remaining) -
                 "date_part"('minute'::text, e.est_remaining) * 60::double precision)::character varying::text + 's'::text
           END::character varying(32)              AS time_remaining_estimate
FROM stl_vacuum v
         LEFT JOIN stv_xact x ON v.xid = x.xid,
     stl_query q,
     stv_tbl_perm t,
     (SELECT "max"(derived_table2.time_remaining) AS est_remaining
      FROM (SELECT d.slice,
                   sum(d.num_blocks_replaced)   AS blocks_replaced,
                   sum(q.endtime - q.starttime) AS etime,
                   CASE
                       WHEN sum(d.num_blocks_replaced) = 0 OR "max"(d.total_block_io_estimate) = 0 THEN NULL::interval
                       ELSE sum(q.endtime - q.starttime) / (sum(d.num_blocks_replaced)::real /
                                                            "max"(d.total_block_io_estimate)::real)::double precision -
                            sum(q.endtime - q.starttime)
                       END                      AS time_remaining
            FROM stl_query q,
                 stl_vacuum v,
                 stl_vacuum_detail d
            WHERE q.xid = v.xid
              AND v.xid = ((SELECT "max"(stl_vacuum.xid) AS "max"
                            FROM stl_vacuum))
              AND v.status <> 'Finished'::bpchar
              AND q.query = d.query
            GROUP BY d.slice) derived_table2) e
WHERE q.xid = v.xid
  AND v.xid = ((SELECT "max"(stl_vacuum.xid) AS "max"
                FROM stl_vacuum))
  AND v.table_id = t.id
  AND t.slice = 0
ORDER BY q.query DESC, v.eventtime DESC
LIMIT 1;

alter table svv_vacuum_progress
    owner to rdsdb;

