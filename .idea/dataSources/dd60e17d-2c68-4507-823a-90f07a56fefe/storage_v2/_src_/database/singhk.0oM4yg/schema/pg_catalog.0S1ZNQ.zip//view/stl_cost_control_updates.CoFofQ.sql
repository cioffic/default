create view stl_cost_control_updates
            (recordtime, type, quota_id, usage, available, threshold, updated_at, period_start, period_end, feature) as
SELECT stll_cost_control_updates.recordtime,
       stll_cost_control_updates."type",
       stll_cost_control_updates.quota_id,
       stll_cost_control_updates."usage",
       stll_cost_control_updates.available,
       stll_cost_control_updates.threshold,
       stll_cost_control_updates.updated_at,
       stll_cost_control_updates.period_start,
       stll_cost_control_updates.period_end,
       stll_cost_control_updates.feature
FROM stll_cost_control_updates;

alter table stl_cost_control_updates
    owner to rdsdb;

