create view stl_command_result(commandtime, command, args, resultcode, errormsg) as
SELECT stll_command_result.commandtime,
       stll_command_result.command,
       stll_command_result.args,
       stll_command_result.resultcode,
       stll_command_result.errormsg
FROM stll_command_result;

alter table stl_command_result
    owner to rdsdb;

