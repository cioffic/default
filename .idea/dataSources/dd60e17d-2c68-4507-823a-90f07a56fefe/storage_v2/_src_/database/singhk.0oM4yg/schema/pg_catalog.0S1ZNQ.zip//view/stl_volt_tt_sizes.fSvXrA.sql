create view stl_volt_tt_sizes(table_id, node, num_blocks) as
SELECT stll_volt_tt_sizes.table_id, stll_volt_tt_sizes.node, stll_volt_tt_sizes.num_blocks
FROM stll_volt_tt_sizes;

alter table stl_volt_tt_sizes
    owner to rdsdb;

