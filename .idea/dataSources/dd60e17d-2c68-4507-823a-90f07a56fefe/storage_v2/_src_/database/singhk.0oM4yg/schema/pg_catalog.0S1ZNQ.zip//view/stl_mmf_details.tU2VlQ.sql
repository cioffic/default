create view stl_mmf_details(query, slice, segment, step, action, source_slice, col_index) as
SELECT stll_mmf_details.query,
       stll_mmf_details.slice,
       stll_mmf_details.segment,
       stll_mmf_details.step,
       stll_mmf_details."action",
       stll_mmf_details.source_slice,
       stll_mmf_details.col_index
FROM stll_mmf_details;

alter table stl_mmf_details
    owner to rdsdb;

