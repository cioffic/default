create view stl_s3_commit_leak(logtime, node, key) as
SELECT stll_s3_commit_leak.logtime, stll_s3_commit_leak.node, stll_s3_commit_leak."key"
FROM stll_s3_commit_leak;

alter table stl_s3_commit_leak
    owner to rdsdb;

