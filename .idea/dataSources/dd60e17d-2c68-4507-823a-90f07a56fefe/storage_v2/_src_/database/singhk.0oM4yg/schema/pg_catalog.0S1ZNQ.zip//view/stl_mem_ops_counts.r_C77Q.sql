create view stl_mem_ops_counts(since, now, node, memory_type, process_type, mem_operation, count) as
SELECT stll_mem_ops_counts.since,
       stll_mem_ops_counts.now,
       stll_mem_ops_counts.node,
       stll_mem_ops_counts.memory_type,
       stll_mem_ops_counts."process_type",
       stll_mem_ops_counts.mem_operation,
       stll_mem_ops_counts.count
FROM stll_mem_ops_counts;

alter table stl_mem_ops_counts
    owner to rdsdb;

