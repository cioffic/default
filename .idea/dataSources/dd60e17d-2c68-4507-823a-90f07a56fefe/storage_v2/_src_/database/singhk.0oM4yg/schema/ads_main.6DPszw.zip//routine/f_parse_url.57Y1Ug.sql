create function f_parse_url(url character varying, part character varying) returns character varying
    immutable
    language plpythonu
as
$$
    if url is None:
        return None
    else:
        import urlparse
        parsed = urlparse.urlparse(url)
        return getattr(parsed, part)

$$;

