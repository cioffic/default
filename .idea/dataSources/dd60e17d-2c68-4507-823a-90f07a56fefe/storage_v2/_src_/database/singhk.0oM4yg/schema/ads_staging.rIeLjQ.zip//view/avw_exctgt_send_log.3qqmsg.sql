create or replace view ads_staging.avw_exctgt_send_log as
select
    --"$path" as    ads_source_file_path, 
    RIGHT("$path", Position('/' IN Reverse("$path")) - 1)                        as ads_source_file,
    case when jobid <> '' then jobid::decimal(20, 0)::int else null::int end     as jobid,
    listid :: integer,
    case when batchid <> '' then batchid::decimal(20, 0)::int else null::int end as batchid,
    --batchid :: integer,
    case when subid <> '' then subid::decimal(20, 0)::int else null::int end     as subid,
    --subid :: integer,
    triggeredsendid,
    errorcode,
    subscriberkey,
    customerkey,
    audienceid,
    trackingcode,
    segmentcode,
    segmentname,
    priority,
    segmentid,
    splitid,
    splitname,
    splitcode,
    sendgroupid,
    name_first,
    name_last,
    street_addr_1,
    street_addr_2,
    city,
    state,
    zip,
    customer_master_index,
    name_full,
    country,
    event_id,
    send_date,
    audiencecode,
    email_address,
    tm_section_name,
    cast(created_date as date)                                                      created_date
from ext_staging.stg_exctgt_send_log
     --where 1=2
where nvl(jobid, '') <> ''
  and nvl(batchid, '') <> ''
  and nvl(subid, '') <> ''
with no schema binding;

alter table avw_exctgt_send_log
    owner to singhk;

