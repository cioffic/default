create view stl_block_integrity_error
            (recordtime, sb_pos, id, node, diskno, disk_addr, raw_disk_addr, tbl, col, slice, remaining_reps,
             computed_crc, computed_crc_with_pincount, expected_crc, data_block_sb_pos, data_block_guid)
as
SELECT stll_block_integrity_error.recordtime,
       stll_block_integrity_error.sb_pos,
       stll_block_integrity_error.id,
       stll_block_integrity_error.node,
       stll_block_integrity_error.diskno,
       stll_block_integrity_error.disk_addr,
       stll_block_integrity_error.raw_disk_addr,
       stll_block_integrity_error.tbl,
       stll_block_integrity_error.col,
       stll_block_integrity_error.slice,
       stll_block_integrity_error.remaining_reps,
       stll_block_integrity_error.computed_crc,
       stll_block_integrity_error.computed_crc_with_pincount,
       stll_block_integrity_error.expected_crc,
       stll_block_integrity_error.data_block_sb_pos,
       stll_block_integrity_error.data_block_guid
FROM stll_block_integrity_error;

alter table stl_block_integrity_error
    owner to rdsdb;

