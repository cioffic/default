create view stl_xid_consumption_rate(time, node, num_xids_consumed, starting_xid, ending_xid, interval) as
SELECT stll_xid_consumption_rate."time",
       stll_xid_consumption_rate.node,
       stll_xid_consumption_rate.num_xids_consumed,
       stll_xid_consumption_rate.starting_xid,
       stll_xid_consumption_rate.ending_xid,
       stll_xid_consumption_rate."interval"
FROM stll_xid_consumption_rate;

alter table stl_xid_consumption_rate
    owner to rdsdb;

