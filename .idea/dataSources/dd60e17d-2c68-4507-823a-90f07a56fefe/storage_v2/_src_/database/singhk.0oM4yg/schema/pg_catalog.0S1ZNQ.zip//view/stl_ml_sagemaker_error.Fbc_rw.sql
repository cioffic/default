create view stl_ml_sagemaker_error(xid, pid, recordtime, request_type, job_arn, exception_name, message) as
SELECT stll_ml_sagemaker_error.xid,
       stll_ml_sagemaker_error.pid,
       stll_ml_sagemaker_error.recordtime,
       stll_ml_sagemaker_error.request_type,
       stll_ml_sagemaker_error.job_arn,
       stll_ml_sagemaker_error.exception_name,
       stll_ml_sagemaker_error.message
FROM stll_ml_sagemaker_error;

alter table stl_ml_sagemaker_error
    owner to rdsdb;

