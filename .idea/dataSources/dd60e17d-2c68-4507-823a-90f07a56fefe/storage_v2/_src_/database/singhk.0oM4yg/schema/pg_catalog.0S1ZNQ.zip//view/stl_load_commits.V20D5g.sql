create view stl_load_commits
            (userid, query, slice, name, filename, byte_offset, lines_scanned, errors, status, curtime, file_format,
             is_partial, start_offset)
as
SELECT stll_load_commits.userid,
       stll_load_commits.query,
       stll_load_commits.slice,
       stll_load_commits.name,
       stll_load_commits.filename,
       stll_load_commits.byte_offset,
       stll_load_commits.lines_scanned,
       stll_load_commits.errors,
       stll_load_commits.status,
       stll_load_commits.curtime,
       stll_load_commits.file_format,
       stll_load_commits.is_partial,
       stll_load_commits.start_offset
FROM stll_load_commits;

alter table stl_load_commits
    owner to rdsdb;

