create view stl_arcadia_billing_log
            (interval_starttime, interval_endtime, rpu, duration, duration_start, duration_end) as
SELECT stll_arcadia_billing_log.interval_starttime,
       stll_arcadia_billing_log.interval_endtime,
       stll_arcadia_billing_log.rpu,
       stll_arcadia_billing_log.duration,
       stll_arcadia_billing_log.duration_start,
       stll_arcadia_billing_log.duration_end
FROM stll_arcadia_billing_log;

alter table stl_arcadia_billing_log
    owner to rdsdb;

