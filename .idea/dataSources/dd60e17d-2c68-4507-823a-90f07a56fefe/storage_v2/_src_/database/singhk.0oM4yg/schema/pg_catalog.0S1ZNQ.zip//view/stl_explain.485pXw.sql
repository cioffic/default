create view stl_explain(userid, query, nodeid, parentid, plannode, info) as
SELECT stll_explain.userid,
       stll_explain.query,
       stll_explain.nodeid,
       stll_explain.parentid,
       stll_explain.plannode,
       stll_explain.info
FROM stll_explain;

alter table stl_explain
    owner to rdsdb;

