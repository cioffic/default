create view stl_burst_prepare(userid, pid, xid, starttime, endtime, error, query, code) as
SELECT stll_burst_prepare.userid,
       stll_burst_prepare.pid,
       stll_burst_prepare.xid,
       stll_burst_prepare.starttime,
       stll_burst_prepare.endtime,
       stll_burst_prepare.error,
       stll_burst_prepare.query,
       stll_burst_prepare.code
FROM stll_burst_prepare;

alter table stl_burst_prepare
    owner to rdsdb;

