create view stl_rtf_stats
            (query, slice, segment, step, hash_segment, hash_step, rw_id, was_disabled, eval_checked, eval_rejected,
             checked, rejected, distributed, prefetched, validity_check)
as
SELECT stll_rtf_stats.query,
       stll_rtf_stats.slice,
       stll_rtf_stats.segment,
       stll_rtf_stats.step,
       stll_rtf_stats.hash_segment,
       stll_rtf_stats.hash_step,
       stll_rtf_stats.rw_id,
       stll_rtf_stats.was_disabled,
       stll_rtf_stats.eval_checked,
       stll_rtf_stats.eval_rejected,
       stll_rtf_stats.checked,
       stll_rtf_stats.rejected,
       stll_rtf_stats.distributed,
       stll_rtf_stats.prefetched,
       stll_rtf_stats.validity_check
FROM stll_rtf_stats;

alter table stl_rtf_stats
    owner to rdsdb;

