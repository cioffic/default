create view stl_concurrency_scaling_usage_error(recordtime, message) as
SELECT stll_concurrency_scaling_usage_error.recordtime, stll_concurrency_scaling_usage_error.message
FROM stll_concurrency_scaling_usage_error;

alter table stl_concurrency_scaling_usage_error
    owner to rdsdb;

