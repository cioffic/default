create view stl_small_table_convert_event(xid, query, tbl, rows, start_time, end_time, command) as
SELECT stll_small_table_convert_event.xid,
       stll_small_table_convert_event.query,
       stll_small_table_convert_event.tbl,
       stll_small_table_convert_event."rows",
       stll_small_table_convert_event.start_time,
       stll_small_table_convert_event.end_time,
       stll_small_table_convert_event.command
FROM stll_small_table_convert_event;

alter table stl_small_table_convert_event
    owner to rdsdb;

