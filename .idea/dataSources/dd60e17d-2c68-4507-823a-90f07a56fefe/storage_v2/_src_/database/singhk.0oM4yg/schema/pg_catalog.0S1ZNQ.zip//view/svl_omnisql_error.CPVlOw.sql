create view svl_omnisql_error(userid, recordtime, errcode, file, linenum, error, sql) as
SELECT e.userid,
       e.recordtime,
       e.errcode,
       btrim(e."file"::text)   AS "file",
       e.linenum,
       btrim(e.error::text)    AS error,
       btrim(q.querytxt::text) AS sql
FROM stl_omnisql_error e
         JOIN stl_plan_qid_map m ON e.query = m.plan_qid
         JOIN stl_query q ON q.query = m.query;

alter table svl_omnisql_error
    owner to rdsdb;

