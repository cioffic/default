create view stl_lambda_invocation_error(query, recordtime, message) as
SELECT stll_lambda_invocation_error.query,
       stll_lambda_invocation_error.recordtime,
       stll_lambda_invocation_error.message
FROM stll_lambda_invocation_error;

alter table stl_lambda_invocation_error
    owner to rdsdb;

