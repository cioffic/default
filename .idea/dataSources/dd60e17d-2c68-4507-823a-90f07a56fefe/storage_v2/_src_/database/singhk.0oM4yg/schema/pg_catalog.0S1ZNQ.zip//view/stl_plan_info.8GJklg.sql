create view stl_plan_info
            (userid, query, nodeid, segment, step, locus, plannode, startupcost, totalcost, rows, bytes) as
SELECT stll_plan_info.userid,
       stll_plan_info.query,
       stll_plan_info.nodeid,
       stll_plan_info.segment,
       stll_plan_info.step,
       stll_plan_info.locus,
       stll_plan_info.plannode,
       stll_plan_info.startupcost,
       stll_plan_info.totalcost,
       stll_plan_info."rows",
       stll_plan_info.bytes
FROM stll_plan_info;

alter table stl_plan_info
    owner to rdsdb;

