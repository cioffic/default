create view stl_spectrum_scan_error
            (userid, query, location, rowid, colname, original_value, modified_value, trigger, action, action_value,
             error_code) as
SELECT stll_spectrum_scan_error.userid,
       stll_spectrum_scan_error.query,
       stll_spectrum_scan_error."location",
       stll_spectrum_scan_error."rowid",
       stll_spectrum_scan_error.colname,
       stll_spectrum_scan_error.original_value,
       stll_spectrum_scan_error.modified_value,
       stll_spectrum_scan_error."trigger",
       stll_spectrum_scan_error."action",
       stll_spectrum_scan_error.action_value,
       stll_spectrum_scan_error.error_code
FROM stll_spectrum_scan_error;

alter table stl_spectrum_scan_error
    owner to rdsdb;

