create view stl_persisted_sessions_on_disk(recordtime, pid, sessionid, expirationtime, eventname) as
SELECT stll_persisted_sessions_on_disk.recordtime,
       stll_persisted_sessions_on_disk.pid,
       stll_persisted_sessions_on_disk.sessionid,
       stll_persisted_sessions_on_disk.expirationtime,
       stll_persisted_sessions_on_disk.eventname
FROM stll_persisted_sessions_on_disk;

alter table stl_persisted_sessions_on_disk
    owner to rdsdb;

