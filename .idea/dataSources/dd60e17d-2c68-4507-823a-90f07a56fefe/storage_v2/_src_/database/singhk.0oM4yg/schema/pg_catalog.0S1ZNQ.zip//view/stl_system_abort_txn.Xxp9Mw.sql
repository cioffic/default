create view stl_system_abort_txn
            (xid, txn_start_time, txn_idle_start_time, txn_log_abort_time, txn_check_type, aborted) as
SELECT stll_system_abort_txn.xid,
       stll_system_abort_txn.txn_start_time,
       stll_system_abort_txn.txn_idle_start_time,
       stll_system_abort_txn.txn_log_abort_time,
       stll_system_abort_txn.txn_check_type,
       stll_system_abort_txn.aborted
FROM stll_system_abort_txn;

alter table stl_system_abort_txn
    owner to rdsdb;

