create view stl_burst_async_mark(pid, xid, query, event, eventtime) as
SELECT stll_burst_async_mark.pid,
       stll_burst_async_mark.xid,
       stll_burst_async_mark.query,
       stll_burst_async_mark.event,
       stll_burst_async_mark.eventtime
FROM stll_burst_async_mark;

alter table stl_burst_async_mark
    owner to rdsdb;

