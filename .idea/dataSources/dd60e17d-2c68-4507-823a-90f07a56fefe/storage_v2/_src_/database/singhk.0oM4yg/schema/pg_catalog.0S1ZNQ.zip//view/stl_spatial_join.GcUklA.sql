create view stl_spatial_join
            (userid, query, slice, segment, step, rtree_segment, rtree_step, starttime, endtime, tasknum, predicate,
             rows, pruned_tuples, tbl, checksum, distribution)
as
SELECT stll_spatial_join.userid,
       stll_spatial_join.query,
       stll_spatial_join.slice,
       stll_spatial_join.segment,
       stll_spatial_join.step,
       stll_spatial_join.rtree_segment,
       stll_spatial_join.rtree_step,
       stll_spatial_join.starttime,
       stll_spatial_join.endtime,
       stll_spatial_join.tasknum,
       stll_spatial_join."predicate",
       stll_spatial_join."rows",
       stll_spatial_join.pruned_tuples,
       stll_spatial_join.tbl,
       stll_spatial_join.checksum,
       stll_spatial_join.distribution
FROM stll_spatial_join;

alter table stl_spatial_join
    owner to rdsdb;

