create view stl_tiered_storage_controller
            (node_num, event_time, eviction_type, node_sb_version, leader_sb_version, request_accepted,
             used_capacity_perc, blks_evictable, blks_to_backup)
as
SELECT stll_tiered_storage_controller.node_num,
       stll_tiered_storage_controller.event_time,
       stll_tiered_storage_controller.eviction_type,
       stll_tiered_storage_controller.node_sb_version,
       stll_tiered_storage_controller.leader_sb_version,
       stll_tiered_storage_controller.request_accepted,
       stll_tiered_storage_controller.used_capacity_perc,
       stll_tiered_storage_controller.blks_evictable,
       stll_tiered_storage_controller.blks_to_backup
FROM stll_tiered_storage_controller;

alter table stl_tiered_storage_controller
    owner to rdsdb;

