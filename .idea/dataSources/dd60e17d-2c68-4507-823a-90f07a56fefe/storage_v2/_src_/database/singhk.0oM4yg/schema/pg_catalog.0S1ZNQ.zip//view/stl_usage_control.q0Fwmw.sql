create view stl_usage_control(eventtime, query, xid, pid, usage_limit_id, feature_type) as
SELECT stll_usage_control.eventtime,
       stll_usage_control.query,
       stll_usage_control.xid,
       stll_usage_control.pid,
       stll_usage_control.usage_limit_id,
       stll_usage_control.feature_type
FROM stll_usage_control;

alter table stl_usage_control
    owner to rdsdb;

