create view stl_xrestore_alter_distkey(pid, xid, tbl, column_name, event_time, message) as
SELECT stll_xrestore_alter_distkey.pid,
       stll_xrestore_alter_distkey.xid,
       stll_xrestore_alter_distkey.tbl,
       stll_xrestore_alter_distkey.column_name,
       stll_xrestore_alter_distkey.event_time,
       stll_xrestore_alter_distkey.message
FROM stll_xrestore_alter_distkey;

alter table stl_xrestore_alter_distkey
    owner to rdsdb;

