create view stl_diskman_query_block_read_stats
            (recordtime, node_num, query_read_memory, query_read_disk, diskman_read_memory, diskman_read_disk,
             read_io_redirected, read_completion_outside_diskman, read_completion_in_diskman,
             read_completion_redirected, query_read_append_pending_io, diskman_read_append_pending_io)
as
SELECT stll_diskman_query_block_read_stats.recordtime,
       stll_diskman_query_block_read_stats.node_num,
       stll_diskman_query_block_read_stats.query_read_memory,
       stll_diskman_query_block_read_stats.query_read_disk,
       stll_diskman_query_block_read_stats.diskman_read_memory,
       stll_diskman_query_block_read_stats.diskman_read_disk,
       stll_diskman_query_block_read_stats.read_io_redirected,
       stll_diskman_query_block_read_stats.read_completion_outside_diskman,
       stll_diskman_query_block_read_stats.read_completion_in_diskman,
       stll_diskman_query_block_read_stats.read_completion_redirected,
       stll_diskman_query_block_read_stats.query_read_append_pending_io,
       stll_diskman_query_block_read_stats.diskman_read_append_pending_io
FROM stll_diskman_query_block_read_stats;

alter table stl_diskman_query_block_read_stats
    owner to rdsdb;

