create view stl_rms_calls
            (transaction, api_call, starttime, duration_us, segment, node, slice, query, num_returned_objects,
             status) as
SELECT stll_rms_calls."transaction",
       stll_rms_calls.api_call,
       stll_rms_calls.starttime,
       stll_rms_calls.duration_us,
       stll_rms_calls.segment,
       stll_rms_calls.node,
       stll_rms_calls.slice,
       stll_rms_calls.query,
       stll_rms_calls.num_returned_objects,
       stll_rms_calls.status
FROM stll_rms_calls;

alter table stl_rms_calls
    owner to rdsdb;

