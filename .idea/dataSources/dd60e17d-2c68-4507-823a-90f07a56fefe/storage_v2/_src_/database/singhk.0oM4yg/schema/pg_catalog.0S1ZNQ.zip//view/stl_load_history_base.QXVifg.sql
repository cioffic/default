create view stl_load_history_base
            (userid, db, xid, pid, user_query_id, child_query_sequence, rewritten_qid, status, table_name, event_time,
             slice, filename, file_count, file_bytes, bytes_copied, rows_copied, file_format, error_count, data_source)
as
SELECT stll_load_history_base.userid,
       stll_load_history_base.db,
       stll_load_history_base.xid,
       stll_load_history_base.pid,
       stll_load_history_base.user_query_id,
       stll_load_history_base.child_query_sequence,
       stll_load_history_base.rewritten_qid,
       stll_load_history_base.status,
       stll_load_history_base.table_name,
       stll_load_history_base.event_time,
       stll_load_history_base.slice,
       stll_load_history_base.filename,
       stll_load_history_base.file_count,
       stll_load_history_base.file_bytes,
       stll_load_history_base.bytes_copied,
       stll_load_history_base.rows_copied,
       stll_load_history_base.file_format,
       stll_load_history_base.error_count,
       stll_load_history_base.data_source
FROM stll_load_history_base;

alter table stl_load_history_base
    owner to rdsdb;

