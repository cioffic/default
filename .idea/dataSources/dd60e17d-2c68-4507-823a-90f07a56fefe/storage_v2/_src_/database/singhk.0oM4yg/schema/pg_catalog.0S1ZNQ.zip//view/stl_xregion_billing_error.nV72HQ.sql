create view stl_xregion_billing_error(eventtime, query, uuid, errtype, errmsg) as
SELECT stll_xregion_billing_error.eventtime,
       stll_xregion_billing_error.query,
       stll_xregion_billing_error.uuid,
       stll_xregion_billing_error.errtype,
       stll_xregion_billing_error.errmsg
FROM stll_xregion_billing_error;

alter table stl_xregion_billing_error
    owner to rdsdb;

