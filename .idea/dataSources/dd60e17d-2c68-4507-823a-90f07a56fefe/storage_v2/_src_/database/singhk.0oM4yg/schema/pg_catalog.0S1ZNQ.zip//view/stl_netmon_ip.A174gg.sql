create view stl_netmon_ip (tn, sn, ts, ip, din, ihe, iar, unk, idsc, idlv, outr, odsc, onor, rf, ff, smpl_t) as
SELECT stll_netmon_ip.tn,
       stll_netmon_ip.sn,
       stll_netmon_ip."ts",
       stll_netmon_ip.ip,
       stll_netmon_ip.din,
       stll_netmon_ip.ihe,
       stll_netmon_ip.iar,
       stll_netmon_ip.unk,
       stll_netmon_ip.idsc,
       stll_netmon_ip.idlv,
       stll_netmon_ip.outr,
       stll_netmon_ip.odsc,
       stll_netmon_ip.onor,
       stll_netmon_ip.rf,
       stll_netmon_ip.ff,
       stll_netmon_ip.smpl_t
FROM stll_netmon_ip;

alter table stl_netmon_ip
    owner to rdsdb;

