create view stl_res_leaks(node, mark, restype, leakinfo) as
SELECT stll_res_leaks.node, stll_res_leaks.mark, stll_res_leaks.restype, stll_res_leaks.leakinfo
FROM stll_res_leaks;

alter table stl_res_leaks
    owner to rdsdb;

