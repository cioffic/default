create view stl_proc_stat
            (pid, query, slice, segment, starttime, endtime, tasknum, utime, stime, processor, minflt, maxmemory,
             daemonmemory, block_reads, block_faults, total_block_fetchtime, max_block_fetchtime, transblock_reads,
             transblock_faults, total_transblock_fetchtime, max_transblock_fetchtime, blocks_used, comm_us, lock_us,
             ipc_us)
as
SELECT stll_proc_stat.pid,
       stll_proc_stat.query,
       stll_proc_stat.slice,
       stll_proc_stat.segment,
       stll_proc_stat.starttime,
       stll_proc_stat.endtime,
       stll_proc_stat.tasknum,
       stll_proc_stat.utime,
       stll_proc_stat.stime,
       stll_proc_stat.processor,
       stll_proc_stat.minflt,
       stll_proc_stat.maxmemory,
       stll_proc_stat.daemonmemory,
       stll_proc_stat.block_reads,
       stll_proc_stat.block_faults,
       stll_proc_stat.total_block_fetchtime,
       stll_proc_stat.max_block_fetchtime,
       stll_proc_stat.transblock_reads,
       stll_proc_stat.transblock_faults,
       stll_proc_stat.total_transblock_fetchtime,
       stll_proc_stat.max_transblock_fetchtime,
       stll_proc_stat.blocks_used,
       stll_proc_stat.comm_us,
       stll_proc_stat.lock_us,
       stll_proc_stat.ipc_us
FROM stll_proc_stat;

alter table stl_proc_stat
    owner to rdsdb;

