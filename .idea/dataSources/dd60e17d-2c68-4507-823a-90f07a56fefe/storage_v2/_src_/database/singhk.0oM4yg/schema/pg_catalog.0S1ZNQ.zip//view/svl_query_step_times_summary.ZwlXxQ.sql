create view svl_query_step_times_summary
            (query, step_name, step_type, starttime, duration_ms, on_cpu_perc, off_cpu_perc) as
SELECT st.query,
       st.step_name,
       st.step_type,
       min(q.starttime)                                                             AS starttime,
       date_diff('ms'::text, min(q.starttime), "max"(q.endtime))                    AS duration_ms,
       trunc(sum(st.agg_on) / sum(qt.agg_all) * 100::double precision, 2::numeric)  AS on_cpu_perc,
       trunc(sum(st.agg_off) / sum(qt.agg_all) * 100::double precision, 2::numeric) AS off_cpu_perc
FROM (SELECT stl_query_step_times.query,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision  AS agg_on,
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_off,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision +
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_all
      FROM stl_query_step_times
      WHERE stl_query_step_times.step_type !~~ '%ScanFabric%'::text
      GROUP BY stl_query_step_times.query) qt,
     (SELECT stl_query_step_times.query,
             stl_query_step_times.step_name,
             stl_query_step_times.step_type,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision  AS agg_on,
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_off,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision +
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_all
      FROM stl_query_step_times
      WHERE stl_query_step_times.step_type !~~ '%ScanFabric%'::text
      GROUP BY stl_query_step_times.query, stl_query_step_times.step_name, stl_query_step_times.step_type) st,
     stl_query q
WHERE st.query = qt.query
  AND q.query = qt.query
  AND qt.agg_all > 0::double precision
GROUP BY st.query, st.step_name, st.step_type;

alter table svl_query_step_times_summary
    owner to rdsdb;

