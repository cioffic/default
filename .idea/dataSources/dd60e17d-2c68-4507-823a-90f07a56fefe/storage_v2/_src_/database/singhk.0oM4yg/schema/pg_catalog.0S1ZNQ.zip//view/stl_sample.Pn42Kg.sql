create view stl_sample (userid, query, slice, segment, step, starttime, endtime, tasknum, rows) as
SELECT stll_sample.userid,
       stll_sample.query,
       stll_sample.slice,
       stll_sample.segment,
       stll_sample.step,
       stll_sample.starttime,
       stll_sample.endtime,
       stll_sample.tasknum,
       stll_sample."rows"
FROM stll_sample;

alter table stl_sample
    owner to rdsdb;

