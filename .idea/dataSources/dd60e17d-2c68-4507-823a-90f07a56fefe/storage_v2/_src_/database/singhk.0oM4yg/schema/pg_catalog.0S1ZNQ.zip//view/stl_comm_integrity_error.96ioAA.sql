create view stl_comm_integrity_error(process, pid, recordtime, sender_ip) as
SELECT stll_comm_integrity_error.process,
       stll_comm_integrity_error.pid,
       stll_comm_integrity_error.recordtime,
       stll_comm_integrity_error.sender_ip
FROM stll_comm_integrity_error;

alter table stl_comm_integrity_error
    owner to rdsdb;

