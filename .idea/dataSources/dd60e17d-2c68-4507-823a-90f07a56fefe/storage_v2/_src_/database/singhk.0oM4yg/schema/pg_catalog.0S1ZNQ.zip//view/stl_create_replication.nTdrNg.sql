create view stl_create_replication
            (recordtime, slice, sb_pos, id, flags, new_node, new_diskno, new_address, crc, reason) as
SELECT stll_create_replication.recordtime,
       stll_create_replication.slice,
       stll_create_replication.sb_pos,
       stll_create_replication.id,
       stll_create_replication.flags,
       stll_create_replication.new_node,
       stll_create_replication.new_diskno,
       stll_create_replication.new_address,
       stll_create_replication.crc,
       stll_create_replication.reason
FROM stll_create_replication;

alter table stl_create_replication
    owner to rdsdb;

