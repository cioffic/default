create view stl_function_column_linker
            (userid, query, functionid, sqloperation, category, nesting_depth, param_no, param_tbl, param_attnum) as
SELECT stll_function_column_linker.userid,
       stll_function_column_linker.query,
       stll_function_column_linker.functionid,
       stll_function_column_linker.sqloperation,
       stll_function_column_linker.category,
       stll_function_column_linker.nesting_depth,
       stll_function_column_linker.param_no,
       stll_function_column_linker.param_tbl,
       stll_function_column_linker.param_attnum
FROM stll_function_column_linker;

alter table stl_function_column_linker
    owner to rdsdb;

