create view pg_class_info
            (reloid, relname, relnamespace, reltype, relowner, relam, relfilenode, reltablespace, relpages, reltuples,
             reltoastrelid, reltoastidxid, relhasindex, relisshared, relkind, relnatts, relexternid, relisreplicated,
             relispinned, reldiststyle, relprojbaseid, relchecks, reltriggers, relukeys, relfkeys, relrefs, relhasoids,
             relhaspkey, relhasrules, relhassubclass, relacl, releffectivediststyle, relcreationtime)
as
SELECT pgc.oid                                                                                                AS reloid,
       pgc.relname,
       pgc.relnamespace,
       pgc.reltype,
       pgc.relowner,
       pgc.relam,
       pgc.relfilenode,
       pgc.reltablespace,
       pgc.relpages,
       pgc.reltuples,
       pgc.reltoastrelid,
       pgc.reltoastidxid,
       pgc.relhasindex,
       pgc.relisshared,
       pgc.relkind,
       pgc.relnatts,
       pgc.relexternid,
       pgc.relisreplicated,
       pgc.relispinned,
       pgc.reldiststyle,
       pgc.relprojbaseid,
       pgc.relchecks,
       pgc.reltriggers,
       pgc.relukeys,
       pgc.relfkeys,
       pgc.relrefs,
       pgc.relhasoids,
       pgc.relhaspkey,
       pgc.relhasrules,
       pgc.relhassubclass,
       pgc.relacl,
       COALESCE(pgce0.value::smallint, pgc.reldiststyle)                                                      AS releffectivediststyle,
       date_add('microsecond'::text, pgce1.value::bigint,
                '2000-01-01 00:00:00'::timestamp without time zone)                                           AS relcreationtime
FROM pg_class pgc
         LEFT JOIN pg_class_extended pgce0 ON pgc.oid = pgce0.reloid AND pgce0.colnum = 0
         LEFT JOIN pg_class_extended pgce1 ON pgc.oid = pgce1.reloid AND pgce1.colnum = 1;

alter table pg_class_info
    owner to rdsdb;

