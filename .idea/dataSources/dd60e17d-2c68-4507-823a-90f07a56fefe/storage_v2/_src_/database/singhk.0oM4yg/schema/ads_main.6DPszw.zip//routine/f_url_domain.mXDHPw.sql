create function f_url_domain(url character varying) returns character varying
    stable
    language plpythonu
as
$$
          from urlparse import urlparse
          if not url:
            return None
          try:
            u = urlparse(url)
            return u.netloc
          except ValueError:
            return None
        
$$;

