create view stl_query_history_base
            (userid, user_query_id, rewritten_qid, child_query_sequence, label, xid, pid, db, query_type, query_text,
             eventtime, status, result_cache_source_query, concurrency_scaling_status, error_message, task,
             service_class, compile_time, planning_time, lock_wait_time, other_wait_time, returned_rows, returned_bytes,
             total_queue_time, total_exec_time, redshift_version, location_tag)
as
SELECT stll_query_history_base.userid,
       stll_query_history_base.user_query_id,
       stll_query_history_base.rewritten_qid,
       stll_query_history_base.child_query_sequence,
       stll_query_history_base."label",
       stll_query_history_base.xid,
       stll_query_history_base.pid,
       stll_query_history_base.db,
       stll_query_history_base.query_type,
       stll_query_history_base.query_text,
       stll_query_history_base.eventtime,
       stll_query_history_base.status,
       stll_query_history_base.result_cache_source_query,
       stll_query_history_base.concurrency_scaling_status,
       stll_query_history_base.error_message,
       stll_query_history_base.task,
       stll_query_history_base.service_class,
       stll_query_history_base.compile_time,
       stll_query_history_base.planning_time,
       stll_query_history_base.lock_wait_time,
       stll_query_history_base.other_wait_time,
       stll_query_history_base.returned_rows,
       stll_query_history_base.returned_bytes,
       stll_query_history_base.total_queue_time,
       stll_query_history_base.total_exec_time,
       stll_query_history_base.redshift_version,
       stll_query_history_base.location_tag
FROM stll_query_history_base;

alter table stl_query_history_base
    owner to rdsdb;

