create view pg_proc_info
            (prooid, proname, pronamespace, proowner, prolang, prokind, proisagg, prosecdef, proisstrict, proretset,
             provolatile, pronargs, prorettype, proargtypes, proargmodes, proallargtypes, proargnames, prosrc, probin,
             proacl)
as
SELECT pgp.oid               AS prooid,
       pgp.proname,
       pgp.pronamespace,
       pgp.proowner,
       pgp.prolang,
       CASE
           WHEN pgp.prorettype = 0::oid THEN 'p'::text
           WHEN pgp.proisagg IS TRUE THEN 'a'::text
           ELSE 'f'::text
           END::"char"       AS prokind,
       pgp.proisagg,
       pgp.prosecdef,
       pgp.proisstrict,
       pgp.proretset,
       pgp.provolatile,
       pgp.pronargs,
       pgp.prorettype,
       pgp.proargtypes,
       pgpe0.value::"char"[] AS proargmodes,
       pgpe1.value::oid[]    AS proallargtypes,
       CASE
           WHEN pgpe0.value IS NOT NULL THEN pgpe2.value
           ELSE pgp.proargnames
           END               AS proargnames,
       pgp.prosrc,
       pgp.probin,
       pgp.proacl
FROM pg_proc pgp
         LEFT JOIN pg_proc_extended pgpe0 ON pgp.oid = pgpe0.procoid AND pgpe0.colnum = 0
         LEFT JOIN pg_proc_extended pgpe1 ON pgp.oid = pgpe1.procoid AND pgpe1.colnum = 1
         LEFT JOIN pg_proc_extended pgpe2 ON pgp.oid = pgpe2.procoid AND pgpe2.colnum = 2;

alter table pg_proc_info
    owner to rdsdb;

