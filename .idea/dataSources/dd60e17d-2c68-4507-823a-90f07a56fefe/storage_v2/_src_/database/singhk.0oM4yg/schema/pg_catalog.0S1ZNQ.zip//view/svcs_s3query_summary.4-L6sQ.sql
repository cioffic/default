create view svcs_s3query_summary
            (userid, query, xid, pid, segment, step, starttime, endtime, elapsed, aborted, external_table_name,
             file_format, is_partitioned, is_rrscan, is_nested, s3_scanned_rows, s3_scanned_bytes,
             s3query_returned_rows, s3query_returned_bytes, files, files_max, files_avg, splits, splits_max, splits_avg,
             total_split_size, max_split_size, avg_split_size, total_retries, max_retries, max_request_duration,
             avg_request_duration, max_request_parallelism, avg_request_parallelism, total_slowdown_count,
             max_slowdown_count)
as
SELECT e.userid,
       e.query,
       q.xid,
       q.pid,
       e.segment,
       e.step,
       min(e.starttime)                                          AS starttime,
       "max"(e.endtime)                                          AS endtime,
       date_diff('us'::text, min(e.starttime), "max"(e.endtime)) AS elapsed,
       q.aborted,
       e.external_table_name::character varying                  AS external_table_name,
       e.file_format,
       "max"(e.is_partitioned::text)::character varying          AS is_partitioned,
       "max"(e.is_rrscan::text)::character varying               AS is_rrscan,
       "max"(e.is_nested::text)::character varying               AS is_nested,
       sum(e.s3_scanned_rows)                                    AS s3_scanned_rows,
       sum(e.s3_scanned_bytes)                                   AS s3_scanned_bytes,
       sum(e.s3query_returned_rows)                              AS s3query_returned_rows,
       sum(e.s3query_returned_bytes)                             AS s3query_returned_bytes,
       sum(e.files)                                              AS files,
       "max"(e.files)                                            AS files_max,
       avg(e.files)                                              AS files_avg,
       sum(e.splits)                                             AS splits,
       "max"(e.splits)                                           AS splits_max,
       avg(e.splits)                                             AS splits_avg,
       sum(e.total_split_size)                                   AS total_split_size,
       "max"(e.max_split_size)                                   AS max_split_size,
       CASE
           WHEN sum(e.splits) > 0 THEN sum(e.total_split_size) / sum(e.splits)
           ELSE NULL::bigint
           END                                                   AS avg_split_size,
       sum(e.total_retries)                                      AS total_retries,
       "max"(e.max_retries)                                      AS max_retries,
       "max"(e.max_request_duration)                             AS max_request_duration,
       avg(e.avg_request_duration)                               AS avg_request_duration,
       "max"(e.max_request_parallelism)                          AS max_request_parallelism,
       round(avg(e.avg_request_parallelism), 1::numeric)         AS avg_request_parallelism,
       sum(e.slowdown_count)                                     AS total_slowdown_count,
       "max"(e.slowdown_count)                                   AS max_slowdown_count
FROM svcs_s3query e,
     stl_query q
WHERE e.query = q.query
  AND e.scan_type = 2
  AND ((EXISTS(SELECT 1
               FROM pg_user
               WHERE pg_user.usename = "current_user"()::name
                 AND pg_user.usesuper = true)) OR (EXISTS(SELECT 1
                                                          FROM pg_shadow_extended
                                                          WHERE pg_shadow_extended."sysid" = "current_user_id"()
                                                            AND pg_shadow_extended.colnum = 2
                                                            AND pg_shadow_extended.value = -1::text)) OR
       e.userid = "current_user_id"())
GROUP BY e.userid, e.query, q.xid, q.pid, e.segment, e.step, q.aborted, e.external_table_name, e.file_format
UNION ALL
SELECT svl_s3query_summary.userid,
       svl_s3query_summary.query,
       svl_s3query_summary.xid,
       svl_s3query_summary.pid,
       svl_s3query_summary.segment,
       svl_s3query_summary.step,
       svl_s3query_summary.starttime,
       svl_s3query_summary.endtime,
       svl_s3query_summary.elapsed,
       svl_s3query_summary.aborted,
       svl_s3query_summary.external_table_name,
       svl_s3query_summary.file_format,
       svl_s3query_summary.is_partitioned,
       svl_s3query_summary.is_rrscan,
       svl_s3query_summary.is_nested,
       svl_s3query_summary.s3_scanned_rows,
       svl_s3query_summary.s3_scanned_bytes,
       svl_s3query_summary.s3query_returned_rows,
       svl_s3query_summary.s3query_returned_bytes,
       svl_s3query_summary.files,
       svl_s3query_summary.files_max,
       svl_s3query_summary.files_avg,
       svl_s3query_summary.splits,
       svl_s3query_summary.splits_max,
       svl_s3query_summary.splits_avg,
       svl_s3query_summary.total_split_size,
       svl_s3query_summary.max_split_size,
       svl_s3query_summary.avg_split_size,
       svl_s3query_summary.total_retries,
       svl_s3query_summary.max_retries,
       svl_s3query_summary.max_request_duration,
       svl_s3query_summary.avg_request_duration,
       svl_s3query_summary.max_request_parallelism,
       svl_s3query_summary.avg_request_parallelism,
       svl_s3query_summary.total_slowdown_count,
       svl_s3query_summary.max_slowdown_count
FROM svl_s3query_summary;

alter table svcs_s3query_summary
    owner to rdsdb;

