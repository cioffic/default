create view stl_udf_trace (component, pid, query, udfid, step, node, slice, recordtime, sequence, message) as
SELECT stll_udf_trace.component,
       stll_udf_trace.pid,
       stll_udf_trace.query,
       stll_udf_trace.udfid,
       stll_udf_trace.step,
       stll_udf_trace.node,
       stll_udf_trace.slice,
       stll_udf_trace.recordtime,
       stll_udf_trace."sequence",
       stll_udf_trace.message
FROM stll_udf_trace;

alter table stl_udf_trace
    owner to rdsdb;

