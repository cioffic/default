create view stl_stack_traces (pid, exceptionid, frame, address, instruction, filename, unique_exception_identifier) as
SELECT stll_stack_traces.pid,
       stll_stack_traces.exceptionid,
       stll_stack_traces.frame,
       stll_stack_traces.address,
       stll_stack_traces.instruction,
       stll_stack_traces.filename,
       stll_stack_traces.unique_exception_identifier
FROM stll_stack_traces;

alter table stl_stack_traces
    owner to rdsdb;

