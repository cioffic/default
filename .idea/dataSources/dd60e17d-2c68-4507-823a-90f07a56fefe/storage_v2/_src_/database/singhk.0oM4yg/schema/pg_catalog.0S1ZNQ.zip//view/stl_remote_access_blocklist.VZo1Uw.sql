create view stl_remote_access_blocklist
            (logtime, local_table_id, remote_table_id, col_num, slice_num, local_block_id, remote_block_id) as
SELECT stll_remote_access_blocklist.logtime,
       stll_remote_access_blocklist.local_table_id,
       stll_remote_access_blocklist.remote_table_id,
       stll_remote_access_blocklist.col_num,
       stll_remote_access_blocklist.slice_num,
       stll_remote_access_blocklist.local_block_id,
       stll_remote_access_blocklist.remote_block_id
FROM stll_remote_access_blocklist;

alter table stl_remote_access_blocklist
    owner to rdsdb;

