create view stl_super_query
            (userid, query, starttime, endtime, query_cmd_type, num_of_array_nav, num_of_object_nav,
             has_unnest_subquery, aborted) as
SELECT stll_super_query.userid,
       stll_super_query.query,
       stll_super_query.starttime,
       stll_super_query.endtime,
       stll_super_query.query_cmd_type,
       stll_super_query.num_of_array_nav,
       stll_super_query.num_of_object_nav,
       stll_super_query.has_unnest_subquery,
       stll_super_query.aborted
FROM stll_super_query;

alter table stl_super_query
    owner to rdsdb;

