create view stl_core_stat
            (currenttime, sampletime, query, segment, node, core, elapsed, utime, stime, ntime, idle, iowait, irq,
             softirq) as
SELECT stll_core_stat.currenttime,
       stll_core_stat.sampletime,
       stll_core_stat.query,
       stll_core_stat.segment,
       stll_core_stat.node,
       stll_core_stat.core,
       stll_core_stat.elapsed,
       stll_core_stat.utime,
       stll_core_stat.stime,
       stll_core_stat.ntime,
       stll_core_stat.idle,
       stll_core_stat.iowait,
       stll_core_stat.irq,
       stll_core_stat.softirq
FROM stll_core_stat;

alter table stl_core_stat
    owner to rdsdb;

