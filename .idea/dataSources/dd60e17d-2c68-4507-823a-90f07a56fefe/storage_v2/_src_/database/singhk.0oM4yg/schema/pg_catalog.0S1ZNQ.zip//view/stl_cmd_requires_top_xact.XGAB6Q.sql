create view stl_cmd_requires_top_xact(process, eventtime, name, xid, padb_version) as
SELECT stll_cmd_requires_top_xact.process,
       stll_cmd_requires_top_xact.eventtime,
       stll_cmd_requires_top_xact.name,
       stll_cmd_requires_top_xact.xid,
       stll_cmd_requires_top_xact.padb_version
FROM stll_cmd_requires_top_xact;

alter table stl_cmd_requires_top_xact
    owner to rdsdb;

