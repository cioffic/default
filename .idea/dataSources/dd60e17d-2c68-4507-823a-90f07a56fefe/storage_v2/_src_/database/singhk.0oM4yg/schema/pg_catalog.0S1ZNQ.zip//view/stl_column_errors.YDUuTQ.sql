create view stl_column_errors
            (recordtime, node, slice, sb_pos, expected_table_id, expected_column_id, actual_table_id,
             actual_column_id) as
SELECT stll_column_errors.recordtime,
       stll_column_errors.node,
       stll_column_errors.slice,
       stll_column_errors.sb_pos,
       stll_column_errors.expected_table_id,
       stll_column_errors.expected_column_id,
       stll_column_errors.actual_table_id,
       stll_column_errors.actual_column_id
FROM stll_column_errors;

alter table stl_column_errors
    owner to rdsdb;

