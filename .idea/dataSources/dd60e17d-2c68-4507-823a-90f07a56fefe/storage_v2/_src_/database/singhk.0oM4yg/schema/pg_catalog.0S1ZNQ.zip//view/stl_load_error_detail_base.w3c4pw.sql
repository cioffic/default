create view stl_load_error_detail_base
            (userid, user_query_id, rewritten_query_id, pid, db, xid, slice, table_id, starttime, filename, line_number,
             col_name, type, col_length, position, raw_line, raw_field_value, err_code, err_reason)
as
SELECT stll_load_error_detail_base.userid,
       stll_load_error_detail_base.user_query_id,
       stll_load_error_detail_base.rewritten_query_id,
       stll_load_error_detail_base.pid,
       stll_load_error_detail_base.db,
       stll_load_error_detail_base.xid,
       stll_load_error_detail_base.slice,
       stll_load_error_detail_base.table_id,
       stll_load_error_detail_base.starttime,
       stll_load_error_detail_base.filename,
       stll_load_error_detail_base.line_number,
       stll_load_error_detail_base.col_name,
       stll_load_error_detail_base."type",
       stll_load_error_detail_base.col_length,
       stll_load_error_detail_base."position",
       stll_load_error_detail_base.raw_line,
       stll_load_error_detail_base.raw_field_value,
       stll_load_error_detail_base.err_code,
       stll_load_error_detail_base.err_reason
FROM stll_load_error_detail_base;

alter table stl_load_error_detail_base
    owner to rdsdb;

