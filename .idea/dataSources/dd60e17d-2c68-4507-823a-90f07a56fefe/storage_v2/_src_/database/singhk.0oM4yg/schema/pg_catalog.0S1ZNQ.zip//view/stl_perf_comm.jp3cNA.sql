create view stl_perf_comm (query_id, segment_number, slice_number, packet_count, bytes_transferred, event_time) as
SELECT stll_perf_comm.query_id,
       stll_perf_comm.segment_number,
       stll_perf_comm.slice_number,
       stll_perf_comm.packet_count,
       stll_perf_comm.bytes_transferred,
       stll_perf_comm.event_time
FROM stll_perf_comm;

alter table stl_perf_comm
    owner to rdsdb;

