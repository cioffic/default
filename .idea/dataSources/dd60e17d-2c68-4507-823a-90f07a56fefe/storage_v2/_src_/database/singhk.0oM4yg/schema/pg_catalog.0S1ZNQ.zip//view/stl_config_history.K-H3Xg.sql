create view stl_config_history(changed, filename, reason) as
SELECT stll_config_history.changed, stll_config_history.filename, stll_config_history.reason
FROM stll_config_history;

alter table stl_config_history
    owner to rdsdb;

