create view stl_misc_sys_stat
            (currenttime, node, bs_queue_cap, free_bs_workers, reg_queue_cap, free_reg_workers, free_shared_mem_mb) as
SELECT stll_misc_sys_stat.currenttime,
       stll_misc_sys_stat.node,
       stll_misc_sys_stat.bs_queue_cap,
       stll_misc_sys_stat.free_bs_workers,
       stll_misc_sys_stat.reg_queue_cap,
       stll_misc_sys_stat.free_reg_workers,
       stll_misc_sys_stat.free_shared_mem_mb
FROM stll_misc_sys_stat;

alter table stl_misc_sys_stat
    owner to rdsdb;

