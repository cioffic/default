create view stl_dynamodb_restore(starttime, endtime, in_progress, errored) as
SELECT stll_dynamodb_restore.starttime,
       stll_dynamodb_restore.endtime,
       stll_dynamodb_restore.in_progress,
       stll_dynamodb_restore.errored
FROM stll_dynamodb_restore;

alter table stl_dynamodb_restore
    owner to rdsdb;

