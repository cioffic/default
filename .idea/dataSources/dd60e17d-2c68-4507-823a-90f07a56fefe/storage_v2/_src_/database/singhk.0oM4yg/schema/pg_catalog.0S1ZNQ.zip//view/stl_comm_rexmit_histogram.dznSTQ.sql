create view stl_comm_rexmit_histogram
            (now, since, src_node, dest_node, mean, stdev, min, max, sum, sample_count, less_than_5, less_than_10,
             less_than_20, less_than_100, less_than_200, less_than_1000, less_than_10000, inf)
as
SELECT stll_comm_rexmit_histogram.now,
       stll_comm_rexmit_histogram.since,
       stll_comm_rexmit_histogram.src_node,
       stll_comm_rexmit_histogram.dest_node,
       stll_comm_rexmit_histogram.mean,
       stll_comm_rexmit_histogram.stdev,
       stll_comm_rexmit_histogram.min,
       stll_comm_rexmit_histogram."max",
       stll_comm_rexmit_histogram.sum,
       stll_comm_rexmit_histogram.sample_count,
       stll_comm_rexmit_histogram.less_than_5,
       stll_comm_rexmit_histogram.less_than_10,
       stll_comm_rexmit_histogram.less_than_20,
       stll_comm_rexmit_histogram.less_than_100,
       stll_comm_rexmit_histogram.less_than_200,
       stll_comm_rexmit_histogram.less_than_1000,
       stll_comm_rexmit_histogram.less_than_10000,
       stll_comm_rexmit_histogram.inf
FROM stll_comm_rexmit_histogram;

alter table stl_comm_rexmit_histogram
    owner to rdsdb;

