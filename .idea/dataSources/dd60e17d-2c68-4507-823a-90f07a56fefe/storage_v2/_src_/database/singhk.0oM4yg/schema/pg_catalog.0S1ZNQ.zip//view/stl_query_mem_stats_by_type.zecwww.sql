create view stl_query_mem_stats_by_type
            (node, query, type, allocated_count, freed_count, max_mem_count, allocated_size, freed_size,
             max_mem_size) as
SELECT stll_query_mem_stats_by_type.node,
       stll_query_mem_stats_by_type.query,
       stll_query_mem_stats_by_type."type",
       stll_query_mem_stats_by_type.allocated_count,
       stll_query_mem_stats_by_type.freed_count,
       stll_query_mem_stats_by_type.max_mem_count,
       stll_query_mem_stats_by_type.allocated_size,
       stll_query_mem_stats_by_type.freed_size,
       stll_query_mem_stats_by_type.max_mem_size
FROM stll_query_mem_stats_by_type;

alter table stl_query_mem_stats_by_type
    owner to rdsdb;

