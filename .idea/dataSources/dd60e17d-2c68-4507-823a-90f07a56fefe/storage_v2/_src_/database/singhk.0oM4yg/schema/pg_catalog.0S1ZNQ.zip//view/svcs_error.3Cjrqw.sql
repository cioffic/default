create view svcs_error (userid, process, recordtime, pid, errcode, file, linenum, context, error) as
SELECT stcs_error.userid,
       stcs_error.process,
       '1970-01-01 00:00:00'::timestamp without time zone +
       (stcs_error.recordtime::numeric / (1000.0 * 1000.0) + 946684800.0)::double precision *
       '00:00:01'::interval AS recordtime,
       stcs_error.pid,
       stcs_error.errcode,
       stcs_error."file",
       stcs_error.linenum,
       stcs_error.context,
       stcs_error.error
FROM stcs_error;

alter table svcs_error
    owner to rdsdb;

