create view stl_print(process, pid, node, slice, recordtime, message) as
SELECT stll_print.process,
       stll_print.pid,
       stll_print.node,
       stll_print.slice,
       stll_print.recordtime,
       stll_print.message
FROM stll_print;

alter table stl_print
    owner to rdsdb;

