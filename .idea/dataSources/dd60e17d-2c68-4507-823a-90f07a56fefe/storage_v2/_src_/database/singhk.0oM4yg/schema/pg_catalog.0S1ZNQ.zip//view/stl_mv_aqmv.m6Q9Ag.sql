create view stl_mv_aqmv
            (query, starttime, endtime, candidates, matches, aqmv_cost, original_cost, costing_time, aqmv_status,
             original_exec_time_est, original_exec_time_est_error, aqmv_exec_time_est, aqmv_exec_time_est_error,
             candidates_fetching_time, algebra_translation_time, total_cpu_time)
as
SELECT stll_mv_aqmv.query,
       stll_mv_aqmv.starttime,
       stll_mv_aqmv.endtime,
       stll_mv_aqmv.candidates,
       stll_mv_aqmv.matches,
       stll_mv_aqmv.aqmv_cost,
       stll_mv_aqmv.original_cost,
       stll_mv_aqmv.costing_time,
       stll_mv_aqmv.aqmv_status,
       stll_mv_aqmv.original_exec_time_est,
       stll_mv_aqmv.original_exec_time_est_error,
       stll_mv_aqmv.aqmv_exec_time_est,
       stll_mv_aqmv.aqmv_exec_time_est_error,
       stll_mv_aqmv.candidates_fetching_time,
       stll_mv_aqmv.algebra_translation_time,
       stll_mv_aqmv.total_cpu_time
FROM stll_mv_aqmv;

alter table stl_mv_aqmv
    owner to rdsdb;

