create view stl_codegen (xid, query, codegenquery, starttime, endtime, tokwaittime, token_acquired) as
SELECT stll_codegen.xid,
       stll_codegen.query,
       stll_codegen.codegenquery,
       stll_codegen.starttime,
       stll_codegen.endtime,
       stll_codegen.tokwaittime,
       stll_codegen.token_acquired
FROM stll_codegen;

alter table stl_codegen
    owner to rdsdb;

