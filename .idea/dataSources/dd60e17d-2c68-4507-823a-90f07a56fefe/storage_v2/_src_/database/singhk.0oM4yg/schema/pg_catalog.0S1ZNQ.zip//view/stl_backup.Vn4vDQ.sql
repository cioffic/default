create view stl_backup (db_name, xid, repository_name, backup_name, backup_type, starttime, endtime, succeeded) as
SELECT stll_backup.db_name,
       stll_backup.xid,
       stll_backup.repository_name,
       stll_backup.backup_name,
       stll_backup.backup_type,
       stll_backup.starttime,
       stll_backup.endtime,
       stll_backup.succeeded
FROM stll_backup;

alter table stl_backup
    owner to rdsdb;

