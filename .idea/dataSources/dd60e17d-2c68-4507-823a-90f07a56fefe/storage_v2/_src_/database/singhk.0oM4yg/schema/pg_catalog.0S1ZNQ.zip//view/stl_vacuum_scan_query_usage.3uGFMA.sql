create view stl_vacuum_scan_query_usage
            (eventtime, node, bucket0_10, bucket10_20, bucket20_30, bucket30_40, bucket40_50, bucket50_60, bucket60_70,
             bucket70_80, bucket80_90, bucket90_100, no_loss_query_count)
as
SELECT stll_vacuum_scan_query_usage.eventtime,
       stll_vacuum_scan_query_usage.node,
       stll_vacuum_scan_query_usage.bucket0_10,
       stll_vacuum_scan_query_usage.bucket10_20,
       stll_vacuum_scan_query_usage.bucket20_30,
       stll_vacuum_scan_query_usage.bucket30_40,
       stll_vacuum_scan_query_usage.bucket40_50,
       stll_vacuum_scan_query_usage.bucket50_60,
       stll_vacuum_scan_query_usage.bucket60_70,
       stll_vacuum_scan_query_usage.bucket70_80,
       stll_vacuum_scan_query_usage.bucket80_90,
       stll_vacuum_scan_query_usage.bucket90_100,
       stll_vacuum_scan_query_usage.no_loss_query_count
FROM stll_vacuum_scan_query_usage;

alter table stl_vacuum_scan_query_usage
    owner to rdsdb;

