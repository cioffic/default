create view svl_query_step_times
            (query, segment, step, step_name, step_type, min_duration, avg_duration, max_duration, min_on_cpu,
             avg_on_cpu, max_on_cpu, active_slices, min_off_cpu, avg_off_cpu, max_off_cpu, waiting_slices)
as
SELECT st.query,
       st.segment,
       st.step,
       st.step_name,
       st.step_type,
       min(sl.duration)                                                             AS min_duration,
       avg(sl.duration)                                                             AS avg_duration,
       "max"(sl.duration)                                                           AS max_duration,
       trunc(min(st.agg_on / sl.agg_all) * 100::double precision, 2::numeric)       AS min_on_cpu,
       trunc(sum(st.agg_on) / sum(sl.agg_all) * 100::double precision, 2::numeric)  AS avg_on_cpu,
       trunc("max"(st.agg_on / sl.agg_all) * 100::double precision, 2::numeric)     AS max_on_cpu,
       count(sl.agg_on > 0::double precision)                                       AS active_slices,
       trunc(min(st.agg_off / sl.agg_all) * 100::double precision, 2::numeric)      AS min_off_cpu,
       trunc(sum(st.agg_off) / sum(sl.agg_all) * 100::double precision, 2::numeric) AS avg_off_cpu,
       trunc("max"(st.agg_off / sl.agg_all) * 100::double precision, 2::numeric)    AS max_off_cpu,
       count(sl.agg_off > 0::double precision)                                      AS waiting_slices
FROM (SELECT stl_query_step_times.query,
             stl_query_step_times.segment,
             stl_query_step_times.slice,
             "max"(stl_query_step_times.duration)                                         AS duration,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision  AS agg_on,
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_off,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision +
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_all
      FROM stl_query_step_times
      GROUP BY stl_query_step_times.query, stl_query_step_times.segment, stl_query_step_times.slice) sl,
     (SELECT stl_query_step_times.query,
             stl_query_step_times.segment,
             stl_query_step_times.step,
             stl_query_step_times.slice,
             stl_query_step_times.step_name,
             stl_query_step_times.step_type,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision  AS agg_on,
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_off,
             sum(stl_query_step_times.on_cpu)::double precision / 1000::double precision +
             sum(stl_query_step_times.off_cpu)::double precision / 1000::double precision AS agg_all
      FROM stl_query_step_times
      GROUP BY stl_query_step_times.query, stl_query_step_times.segment, stl_query_step_times.step,
               stl_query_step_times.slice, stl_query_step_times.step_name, stl_query_step_times.step_type) st
WHERE st.query = sl.query
  AND st.segment = sl.segment
  AND st.slice = sl.slice
  AND sl.agg_all > 0::double precision
GROUP BY st.query, st.segment, st.step, st.step_name, st.step_type;

alter table svl_query_step_times
    owner to rdsdb;

