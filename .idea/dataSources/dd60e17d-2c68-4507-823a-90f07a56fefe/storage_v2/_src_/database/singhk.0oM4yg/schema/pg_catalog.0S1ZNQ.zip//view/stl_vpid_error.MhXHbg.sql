create view stl_vpid_error(recordtime, pid, vpid, is_virtualized, error) as
SELECT stll_vpid_error.recordtime,
       stll_vpid_error.pid,
       stll_vpid_error.vpid,
       stll_vpid_error.is_virtualized,
       stll_vpid_error.error
FROM stll_vpid_error;

alter table stl_vpid_error
    owner to rdsdb;

