create view stl_unnest (userid, query, slice, segment, step, starttime, endtime, tasknum, rows) as
SELECT stll_unnest.userid,
       stll_unnest.query,
       stll_unnest.slice,
       stll_unnest.segment,
       stll_unnest.step,
       stll_unnest.starttime,
       stll_unnest.endtime,
       stll_unnest.tasknum,
       stll_unnest."rows"
FROM stll_unnest;

alter table stl_unnest
    owner to rdsdb;

