create view stl_query_metrics
            (userid, service_class, query, segment, step_type, starttime, slices, max_rows, rows, max_cpu_time,
             cpu_time, max_blocks_read, blocks_read, max_run_time, run_time, max_blocks_to_disk, blocks_to_disk, step,
             max_query_scan_size, query_scan_size, query_priority, query_queue_time, service_class_name)
as
SELECT stll_query_metrics.userid,
       stll_query_metrics.service_class,
       stll_query_metrics.query,
       stll_query_metrics.segment,
       stll_query_metrics.step_type,
       stll_query_metrics.starttime,
       stll_query_metrics.slices,
       stll_query_metrics.max_rows,
       stll_query_metrics."rows",
       stll_query_metrics.max_cpu_time,
       stll_query_metrics.cpu_time,
       stll_query_metrics.max_blocks_read,
       stll_query_metrics.blocks_read,
       stll_query_metrics.max_run_time,
       stll_query_metrics.run_time,
       stll_query_metrics.max_blocks_to_disk,
       stll_query_metrics.blocks_to_disk,
       stll_query_metrics.step,
       stll_query_metrics.max_query_scan_size,
       stll_query_metrics.query_scan_size,
       stll_query_metrics.query_priority,
       stll_query_metrics.query_queue_time,
       stll_query_metrics.service_class_name
FROM stll_query_metrics;

alter table stl_query_metrics
    owner to rdsdb;

