create view stl_varbyte_query(userid, query, starttime, endtime, query_cmd_type, aborted) as
SELECT stll_varbyte_query.userid,
       stll_varbyte_query.query,
       stll_varbyte_query.starttime,
       stll_varbyte_query.endtime,
       stll_varbyte_query.query_cmd_type,
       stll_varbyte_query.aborted
FROM stll_varbyte_query;

alter table stl_varbyte_query
    owner to rdsdb;

