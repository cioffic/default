create view stl_comm_diag_errors
            (recordtime, component, node_index, switch_index, ip_addr, diagnostic_state, enabled_switch_vec) as
SELECT stll_comm_diag_errors.recordtime,
       stll_comm_diag_errors.component,
       stll_comm_diag_errors.node_index,
       stll_comm_diag_errors.switch_index,
       stll_comm_diag_errors.ip_addr,
       stll_comm_diag_errors.diagnostic_state,
       stll_comm_diag_errors.enabled_switch_vec
FROM stll_comm_diag_errors;

alter table stl_comm_diag_errors
    owner to rdsdb;

