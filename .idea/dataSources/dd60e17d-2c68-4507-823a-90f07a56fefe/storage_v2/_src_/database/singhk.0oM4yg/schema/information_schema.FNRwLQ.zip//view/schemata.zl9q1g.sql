create view schemata
            (catalog_name, schema_name, schema_owner, default_character_set_catalog, default_character_set_schema,
             default_character_set_name, sql_path)
as
SELECT current_database()::information_schema.sql_identifier                      AS catalog_name,
       n.nspname::information_schema.sql_identifier                               AS schema_name,
       u.usename::information_schema.sql_identifier                               AS schema_owner,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS default_character_set_catalog,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS default_character_set_schema,
       NULL::information_schema.sql_identifier::information_schema.sql_identifier AS default_character_set_name,
       NULL::information_schema.character_data::information_schema.character_data AS sql_path
FROM pg_namespace n,
     pg_user u
WHERE n.nspowner = u.usesysid
  AND u.usename = "current_user"()::name;

alter table schemata
    owner to rdsdb;

