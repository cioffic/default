create view stl_sorted_checker
            (recordtime, xid, qid, relid, slice, total_rows, expected_sorted, checked_rows, ooo_rows, type, status) as
SELECT stll_sorted_checker.recordtime,
       stll_sorted_checker.xid,
       stll_sorted_checker.qid,
       stll_sorted_checker.relid,
       stll_sorted_checker.slice,
       stll_sorted_checker.total_rows,
       stll_sorted_checker.expected_sorted,
       stll_sorted_checker.checked_rows,
       stll_sorted_checker.ooo_rows,
       stll_sorted_checker."type",
       stll_sorted_checker.status
FROM stll_sorted_checker;

alter table stl_sorted_checker
    owner to rdsdb;

