create view stl_superblock_vacuum
            (leaderstarttime, node, nodestarttime, nodeendtime, commitstarttime, commitendtime, success, permbefore,
             tempbefore, leadersnapshotbefore, pgwalbefore, metadatabefore, freebefore, allocatedbefore, permafter,
             tempafter, leadersnapshotafter, pgwalafter, metadataafter, freeafter, allocatedafter, freelistbefore,
             freelistafter, logbefore, logafter)
as
SELECT stll_superblock_vacuum.leaderstarttime,
       stll_superblock_vacuum.node,
       stll_superblock_vacuum.nodestarttime,
       stll_superblock_vacuum.nodeendtime,
       stll_superblock_vacuum.commitstarttime,
       stll_superblock_vacuum.commitendtime,
       stll_superblock_vacuum.success,
       stll_superblock_vacuum.permbefore,
       stll_superblock_vacuum.tempbefore,
       stll_superblock_vacuum.leadersnapshotbefore,
       stll_superblock_vacuum.pgwalbefore,
       stll_superblock_vacuum.metadatabefore,
       stll_superblock_vacuum.freebefore,
       stll_superblock_vacuum.allocatedbefore,
       stll_superblock_vacuum.permafter,
       stll_superblock_vacuum.tempafter,
       stll_superblock_vacuum.leadersnapshotafter,
       stll_superblock_vacuum.pgwalafter,
       stll_superblock_vacuum.metadataafter,
       stll_superblock_vacuum.freeafter,
       stll_superblock_vacuum.allocatedafter,
       stll_superblock_vacuum.freelistbefore,
       stll_superblock_vacuum.freelistafter,
       stll_superblock_vacuum.logbefore,
       stll_superblock_vacuum.logafter
FROM stll_superblock_vacuum;

alter table stl_superblock_vacuum
    owner to rdsdb;

