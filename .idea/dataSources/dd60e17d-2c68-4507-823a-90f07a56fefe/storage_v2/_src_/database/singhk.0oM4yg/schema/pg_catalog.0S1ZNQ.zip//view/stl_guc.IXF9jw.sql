create view stl_guc(guc, value, recordtime) as
SELECT stll_guc.guc, stll_guc.value, stll_guc.recordtime
FROM stll_guc;

alter table stl_guc
    owner to rdsdb;

