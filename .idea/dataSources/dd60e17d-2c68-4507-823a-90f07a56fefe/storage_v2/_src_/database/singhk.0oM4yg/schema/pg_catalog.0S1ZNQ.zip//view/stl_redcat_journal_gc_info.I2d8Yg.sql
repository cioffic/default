create view stl_redcat_journal_gc_info
            (delete_xid, pid, database, table_name, pivot_xid, pivot_timestamp, starttime, duration_msec,
             num_tuples_deleted) as
SELECT stll_redcat_journal_gc_info.delete_xid,
       stll_redcat_journal_gc_info.pid,
       stll_redcat_journal_gc_info."database",
       stll_redcat_journal_gc_info.table_name,
       stll_redcat_journal_gc_info.pivot_xid,
       stll_redcat_journal_gc_info.pivot_timestamp,
       stll_redcat_journal_gc_info.starttime,
       stll_redcat_journal_gc_info.duration_msec,
       stll_redcat_journal_gc_info.num_tuples_deleted
FROM stll_redcat_journal_gc_info;

alter table stl_redcat_journal_gc_info
    owner to rdsdb;

