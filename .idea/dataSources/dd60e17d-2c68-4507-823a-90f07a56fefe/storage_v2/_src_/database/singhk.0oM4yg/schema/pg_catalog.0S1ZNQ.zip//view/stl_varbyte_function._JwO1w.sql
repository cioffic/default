create view stl_varbyte_function(userid, query, functionid, sqloperation) as
SELECT stll_varbyte_function.userid,
       stll_varbyte_function.query,
       stll_varbyte_function.functionid,
       stll_varbyte_function.sqloperation
FROM stll_varbyte_function;

alter table stl_varbyte_function
    owner to rdsdb;

