create view stl_arcadia_main_usage_error(recordtime, message) as
SELECT stll_arcadia_main_usage_error.recordtime, stll_arcadia_main_usage_error.message
FROM stll_arcadia_main_usage_error;

alter table stl_arcadia_main_usage_error
    owner to rdsdb;

