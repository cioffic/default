create view stl_analyze_compression (userid, start_time, xid, tbl, tablename, col, old_encoding, new_encoding, mode) as
SELECT stll_analyze_compression.userid,
       stll_analyze_compression.start_time,
       stll_analyze_compression.xid,
       stll_analyze_compression.tbl,
       stll_analyze_compression.tablename,
       stll_analyze_compression.col,
       stll_analyze_compression.old_encoding,
       stll_analyze_compression.new_encoding,
       stll_analyze_compression."mode"
FROM stll_analyze_compression;

alter table stl_analyze_compression
    owner to rdsdb;

