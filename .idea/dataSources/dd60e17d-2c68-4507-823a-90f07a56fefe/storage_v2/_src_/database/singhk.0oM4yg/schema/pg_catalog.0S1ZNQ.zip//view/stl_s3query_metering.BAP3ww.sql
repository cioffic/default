create view stl_s3query_metering(eventtime, query, internal_request_uuid, metered_mbs) as
SELECT stll_s3query_metering.eventtime,
       stll_s3query_metering.query,
       stll_s3query_metering.internal_request_uuid,
       stll_s3query_metering.metered_mbs
FROM stll_s3query_metering;

alter table stl_s3query_metering
    owner to rdsdb;

