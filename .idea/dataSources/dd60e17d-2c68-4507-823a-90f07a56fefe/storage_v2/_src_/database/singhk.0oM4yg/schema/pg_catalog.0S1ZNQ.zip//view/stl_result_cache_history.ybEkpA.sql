create view stl_result_cache_history(userid, cache_hit_query, source_query) as
SELECT stll_result_cache_history.userid,
       stll_result_cache_history.cache_hit_query,
       stll_result_cache_history.source_query
FROM stll_result_cache_history;

alter table stl_result_cache_history
    owner to rdsdb;

