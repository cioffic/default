create function f_s3_parse_athena_filename(s3path character varying) returns character varying
    volatile
    language sql
as
$$
    select substring( $1, len($1) - ( position( '/' in reverse($1) ) - 2 ), len($1) );

$$;

