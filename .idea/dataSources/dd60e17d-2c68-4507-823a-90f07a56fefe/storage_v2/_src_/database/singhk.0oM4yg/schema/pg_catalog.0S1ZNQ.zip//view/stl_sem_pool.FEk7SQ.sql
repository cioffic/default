create view stl_sem_pool(node, semid, semnum, type) as
SELECT stll_sem_pool.node, stll_sem_pool.semid, stll_sem_pool.semnum, stll_sem_pool."type"
FROM stll_sem_pool;

alter table stl_sem_pool
    owner to rdsdb;

