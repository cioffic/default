create view stl_smlog (seq, ip, process, level, recordtime, file, linenum, sys_errno, errno_str, msg, stack) as
SELECT stll_smlog.seq,
       stll_smlog.ip,
       stll_smlog.process,
       stll_smlog."level",
       stll_smlog.recordtime,
       stll_smlog."file",
       stll_smlog.linenum,
       stll_smlog.sys_errno,
       stll_smlog.errno_str,
       stll_smlog.msg,
       stll_smlog.stack
FROM stll_smlog;

alter table stl_smlog
    owner to rdsdb;

