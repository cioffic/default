create view stl_tiered_storage_s3_blocks
            (node_num, event_time, num_blocks_evicted, on_demand_eviction, superblock_version, transaction_id,
             local_capacity, ts_cache_elems, blks_evictable, blks_to_backup, evicted_without_reads)
as
SELECT stll_tiered_storage_s3_blocks.node_num,
       stll_tiered_storage_s3_blocks.event_time,
       stll_tiered_storage_s3_blocks.num_blocks_evicted,
       stll_tiered_storage_s3_blocks.on_demand_eviction,
       stll_tiered_storage_s3_blocks.superblock_version,
       stll_tiered_storage_s3_blocks.transaction_id,
       stll_tiered_storage_s3_blocks.local_capacity,
       stll_tiered_storage_s3_blocks.ts_cache_elems,
       stll_tiered_storage_s3_blocks.blks_evictable,
       stll_tiered_storage_s3_blocks.blks_to_backup,
       stll_tiered_storage_s3_blocks.evicted_without_reads
FROM stll_tiered_storage_s3_blocks;

alter table stl_tiered_storage_s3_blocks
    owner to rdsdb;

