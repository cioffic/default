create view stl_alert_event_log (userid, query, slice, segment, step, pid, xid, event, solution, event_time) as
SELECT stll_alert_event_log.userid,
       stll_alert_event_log.query,
       stll_alert_event_log.slice,
       stll_alert_event_log.segment,
       stll_alert_event_log.step,
       stll_alert_event_log.pid,
       stll_alert_event_log.xid,
       stll_alert_event_log.event,
       stll_alert_event_log.solution,
       stll_alert_event_log.event_time
FROM stll_alert_event_log;

alter table stl_alert_event_log
    owner to rdsdb;

