create view stl_bootstrap(starttime, process, pid, recordtime, file, linenum, msg) as
SELECT stll_bootstrap.starttime,
       stll_bootstrap.process,
       stll_bootstrap.pid,
       stll_bootstrap.recordtime,
       stll_bootstrap."file",
       stll_bootstrap.linenum,
       stll_bootstrap.msg
FROM stll_bootstrap;

alter table stl_bootstrap
    owner to rdsdb;

