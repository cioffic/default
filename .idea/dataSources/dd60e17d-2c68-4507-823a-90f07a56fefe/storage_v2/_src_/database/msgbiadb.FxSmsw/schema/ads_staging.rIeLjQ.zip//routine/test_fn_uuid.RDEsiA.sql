create function test_fn_uuid() returns character varying
    volatile
    language plpythonu
as
$$
 import uuid
 return uuid.uuid4().__str__()
$$;

