create or replace view ads_main.avw_mpd_weekly_event_finance_budget_show as
select *,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file
from ext_staging.mpd_weekly_event_finance_budget_show
with no schema binding;

alter table avw_mpd_weekly_event_finance_budget_show
    owner to etluser;

