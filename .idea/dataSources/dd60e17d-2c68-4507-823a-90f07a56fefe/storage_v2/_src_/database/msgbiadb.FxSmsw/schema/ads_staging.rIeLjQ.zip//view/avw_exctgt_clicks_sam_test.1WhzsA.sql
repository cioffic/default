create or replace view ads_staging.avw_exctgt_clicks_sam_test
as
select clientid,
       sendid,
       subscriberkey,
       emailaddress,
       subscriberid,
       listid,
       eventdate :: datetime,
       eventtype,
       sendurlid :: integer,
       urlid :: integer,
       url,
       alias,
       batchid :: integer,
       triggeredsendexternalkey,
       isunique,
       isuniqueforurl,
       ipaddress,
       country,
       region,
       city,
       latitude,
       longitude,
       metrocode,
       areacode,
       browser,
       emailclient,
       operatingsystem,
       device,
       ads_main.f_url_domain(url) :: varchar            as domain,
       ads_main.f_url_param(url, 'cmp') :: varchar      as cmp,
       ads_main.f_url_param(url, 'camefrom') :: varchar as cfc,
       ads_main.f_url_param(url, 'brand') :: varchar    as urlbrand,
       ads_main.f_parse_url(url, 'path') :: varchar     as urlpath,
       ads_staging.f_s3_parse_athena_filename("$path")  AS ads_source_file,
       'EXACT TARGET'                                   AS ads_source
from ext_staging.stg_et_bia_clicks
with no schema binding;

alter table avw_exctgt_clicks_sam_test
    owner to ads_staging;

