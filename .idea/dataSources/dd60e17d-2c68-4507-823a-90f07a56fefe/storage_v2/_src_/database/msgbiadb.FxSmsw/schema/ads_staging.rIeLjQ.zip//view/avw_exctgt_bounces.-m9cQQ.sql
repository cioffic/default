create or replace view ads_staging.avw_exctgt_bounces
as
select clientid,
       sendid,
       subscriberkey,
       emailaddress,
       subscriberid,
       listid,
       eventdate :: datetime,
       eventtype,
       bouncecategory,
       smtpcode :: integer,
       bouncereason,
       batchid :: integer,
       triggeredsendexternalkey,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_bounces
with no schema binding;

alter table avw_exctgt_bounces
    owner to ads_staging;

