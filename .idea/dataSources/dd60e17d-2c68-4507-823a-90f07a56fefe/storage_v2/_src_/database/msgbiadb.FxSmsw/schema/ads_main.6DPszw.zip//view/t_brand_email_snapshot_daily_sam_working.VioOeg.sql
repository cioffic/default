create or replace view ads_main.t_brand_email_snapshot_daily_sam_working AS
WITH date_brand as (
    select a.*, b.brand, b.brand_id
    FROM ads_main.d_date a
             join (select distinct brand, brand_id from ads_main.vw_brand_customer) b on 1 = 1
    where full_date between '2018-12-31' and convert_timezone('America/New_York', current_date)::date
),

     main AS
         (
             SELECT to_char(full_date, 'YYYYMMDD')::int AS inception_day_id,
                    full_date                              inception_date,
                    fiscal_year                            inception_date_fiscal_year,
                    month_name                             inception_date_month_name,
                    fiscal_month                           inception_date_fiscal_month,
                    a.brand_id,
                    a.brand,
                    SUM(nvl(total_customer_count, 0))   as total_customer_count_daily,
                    SUM(nvl(engaged_customer_count, 0)) as engaged_customer_count_daily,
                    SUM(nvl(engaged_customer_count, 0)) as unengaged_customer_count_daily


             FROM date_brand a
                      LEFT JOIN ads_main.vw_brand_customer b
                                on a.day_id = to_char(b.msg_inception_date, 'YYYYMMDD')::int
                                    and a.brand = b.brand
--where full_date between  '2018-12-31' and current_date
             GROUP BY full_date,
                      fiscal_year,
                      month_name,
                      fiscal_month,
                      a.brand_id,
                      a.brand
         )
SELECT inception_day_id,
       inception_date,
       inception_date_fiscal_year,
       inception_date_month_name,
       inception_date_fiscal_month,
       case when inception_date = last_day(inception_date) then 'Y' else 'N' END                                       AS inception_date_month_end_flag,
       brand_id,
       brand,

       SUM(total_customer_count_daily)
       OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS UNBOUNDED PRECEDING ) -
       total_customer_count_daily                                                                                      AS total_opening_email_count_daily,
       SUM(total_customer_count_daily)
       OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )   AS total_closing_email_count_daily,
       total_customer_count_daily                                                                                      as total_change_email_count_daily,

       SUM(engaged_customer_count_daily)
       OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS UNBOUNDED PRECEDING ) -
       engaged_customer_count_daily                                                                                    AS engaged_opening_email_count_daily,
       SUM(engaged_customer_count_daily)
       OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )   AS engaged_closing_email_count_daily,
       engaged_customer_count_daily                                                                                    as engaged_change_email_count_daily,


       (SUM(total_customer_count_daily)
        OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS UNBOUNDED PRECEDING ) -
        total_customer_count_daily) -
       (SUM(engaged_customer_count_daily)
        OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS UNBOUNDED PRECEDING ) -
        engaged_customer_count_daily)                                                                                  AS unengaged_opening_email_count_daily,
       (SUM(total_customer_count_daily)
        OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )) -
       (SUM(engaged_customer_count_daily)
        OVER (PARTITION BY brand_id, brand ORDER BY inception_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )) AS unengaged_closing_email_count_daily,
       (total_customer_count_daily - engaged_customer_count_daily)                                                     AS unengaged_change_email_count_daily

FROM main
WITH NO SCHEMA BINDING;

alter table t_brand_email_snapshot_daily_sam_working
    owner to ads_main;

