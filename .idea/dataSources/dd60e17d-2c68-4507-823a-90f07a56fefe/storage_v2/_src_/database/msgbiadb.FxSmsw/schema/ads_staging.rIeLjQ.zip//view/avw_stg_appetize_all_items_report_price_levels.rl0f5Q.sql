CREATE OR replace VIEW ads_staging.avw_stg_appetize_all_items_report_price_levels AS
SELECT a.id,
       price_levels.price_level_id,
       price_levels.price_level_name,
       price_levels.price,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day

FROM appetize.api_all_items_report a
         LEFT JOIN a.price_levels price_levels
                   ON TRUE
WITH no SCHEMA binding;

alter table avw_stg_appetize_all_items_report_price_levels
    owner to ads_staging;

