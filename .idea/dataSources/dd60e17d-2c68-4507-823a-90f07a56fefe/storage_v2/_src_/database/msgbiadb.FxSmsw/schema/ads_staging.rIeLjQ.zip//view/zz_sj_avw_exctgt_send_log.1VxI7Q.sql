create or replace view ads_staging.zz_sj_avw_exctgt_send_log as
select
    --"$path" as    ads_source_file_path, 
    RIGHT("$path", Position('/' IN Reverse("$path")) - 1) as ads_source_file,
    cast(jobid as int)                                       jobid,
    cast(listid as int)                                      listid,
    cast(batchid as int)                                     batchid,
    subid,
    triggeredsendid,
    errorcode,
    subscriberkey,
    customerkey,
    audienceid,
    trackingcode,
    segmentcode,
    segmentname,
    priority,
    segmentid,
    splitid,
    splitname,
    splitcode,
    sendgroupid,
    name_first,
    name_last,
    street_addr_1,
    street_addr_2,
    city,
    state,
    zip,
    customer_master_index,
    name_full,
    country,
    event_id,
    send_date,
    audiencecode,
    email_address,
    tm_section_name,
    cast(created_date as date)                               created_date
from ext_staging.stg_exctgt_send_log
with no schema binding;

alter table zz_sj_avw_exctgt_send_log
    owner to ads_main;

