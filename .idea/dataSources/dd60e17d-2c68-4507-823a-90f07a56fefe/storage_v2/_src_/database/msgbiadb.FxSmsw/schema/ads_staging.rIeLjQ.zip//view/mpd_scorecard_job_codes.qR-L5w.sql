create or replace view ads_staging.mpd_scorecard_job_codes
as
select null                                as job_title,
       scorecard,
       null                                as department,
       null                                as work_location_name,
       job_code,
       f_s3_parse_athena_filename("$path") as file_name
from athena_schema.mpd_scorecard_job_codes
group by 1, 2, 3, 4, 5, 6
with no schema binding;

alter table mpd_scorecard_job_codes
    owner to ads_staging;

