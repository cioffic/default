CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_items_discounts_applied AS
SELECT a.order_id,
       items.id                       item_id,
       items_discounts_applied.id     discounts_applied_id,
       items_discounts_applied.name   discounts_applied_name,
       items_discounts_applied.amount discounts_applied_amount
FROM appetize.api_orders_report a
         LEFT JOIN a.items items
                   ON TRUE
         LEFT JOIN items.discounts_applied items_discounts_applied
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_items_discounts_applied
    owner to ads_staging;

