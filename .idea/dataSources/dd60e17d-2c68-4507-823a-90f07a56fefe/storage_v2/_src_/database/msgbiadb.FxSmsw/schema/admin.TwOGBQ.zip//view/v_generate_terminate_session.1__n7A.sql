create view v_generate_terminate_session(process, starttime, "user", terminate_stmt) as
SELECT stv_sessions.process,
       stv_sessions.starttime,
       btrim(stv_sessions.user_name::character varying::text) AS "user",
       ('SELECT pg_terminate_backend('::character varying::text || stv_sessions.process::character varying::text) ||
       ');'::character varying::text                          AS terminate_stmt
FROM stv_sessions
WHERE stv_sessions.user_name <> 'rdsdb'::bpchar
  AND stv_sessions.process <> pg_backend_pid()
ORDER BY stv_sessions.starttime;

alter table v_generate_terminate_session
    owner to msgadmin;

