CREATE OR REPLACE view ads_staging.avw_mpd_geo_country_state
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       country_code :: VARCHAR(255),
       state_code :: VARCHAR(255),
       state_name :: VARCHAR(255),
       state_latitude:: VARCHAR(255),
       state_longitude:: VARCHAR(255)

FROM ext_staging.mpd_geo_country_state
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_country_state
    owner to ads_staging;

