CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_refunds AS
SELECT a.order_id,
       refunds.product_id,
       refunds.name,
       refunds.order_items_id,
       payments.payment_index,
       payments.payment_type,
       payments.payment_type_name,
       payments.subpayment_type,
       payments.payment_status,
       payments.amount,
       payments.subtotal,
       payments.tip,
       payments.tax,
       --taxes={inclusive_tax_amount=0.00, exclusive_tax_amount=0.00}, 
       payments.last_four_credit,
       payments.status,
       payments.type,
       payments.date_created,
       payments.date_completed,
       payments.transaction_id

FROM appetize.api_orders_report a
         LEFT JOIN a.refunds refunds
                   ON TRUE
         LEFT JOIN refunds.payments payments
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_refunds
    owner to ads_staging;

