CREATE OR REPLACE VIEW ads_main.vw_d_msg_employee_active AS
SELECT e.employee_id,
       Nvl(pe.employee_id, -1) AS active_employee_id,
       e.source_id
FROM ads_main.d_msg_employee e
         LEFT JOIN ads_main.d_msg_employee pe
                   ON e.source_id = pe.source_id
                       AND pe.primary_job_flag = 'Y'
WITH NO SCHEMA BINDING;

alter table vw_d_msg_employee_active
    owner to ads_main;

