create or replace view ads_staging.avw_stg_formstack_forms_latest
    --create table ads_staging.avw_stg_formstack_forms_latest
as
select *
from (
         select *,
                ads_staging.f_s3_parse_athena_filename("$path")                   as ads_source_file,
                'FORMSTACK'                                                       as ads_source,
                row_number() over (partition by id order by ads_source_file desc) as rank
         from ext_staging.stg_formstack_forms)
where rank = 1
with no schema binding;

alter table avw_stg_formstack_forms_latest
    owner to ads_staging;

