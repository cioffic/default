create or replace view ads_staging.avw_cssr_historic
as
select *
from ext_staging.stg_cssr_media_perf_20200106
with no schema binding;

alter table avw_cssr_historic
    owner to ads_staging;

