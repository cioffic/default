create view ads_staging.avw_stg_wfm_exceptions
as
select employee_name
     , employee_id
     , assignment
     , case when length(exception_date) = 10 then exception_date::DATE else null end as exception_date
     , severity
     , message
     , substring(replace("$path", 's3://msg-dashboard-data/workforcemanagement/exceptions/', ''), 1,
                 position('/' in replace("$path", 's3://msg-dashboard-data/workforcemanagement/exceptions/', '')) -
                 1)                                                                  as venue
     , ads_staging.f_s3_parse_athena_filename("$path")                               as filename
from athena_schema.stg_wfm_exceptions
with no schema binding;

alter table avw_stg_wfm_exceptions
    owner to ads_staging;

