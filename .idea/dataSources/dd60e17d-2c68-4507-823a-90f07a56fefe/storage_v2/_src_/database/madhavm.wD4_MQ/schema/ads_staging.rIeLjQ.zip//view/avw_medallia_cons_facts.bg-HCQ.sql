CREATE or replace VIEW ads_staging.avw_medallia_cons_facts AS
SELECT "response date",
       "event id"                                            event_id,
       "likelihood to recommend"                             likeliehood_to_recommend,
       "entering the arena/theater"                          entering_the_arena_theatre,
       "helpfulness of suite attendant"                      helpfulness_of_suite_attendant,
       "helpfulness of ushers"                               helpfulness_of_ushers,
       "quality of the suite attendant"                      quality_of_the_suite_attendant,
       "cleanliness of arena/theater"                        cleanliness_of_arena_theater,
       "cleanliness of restrooms"                            cleanliness_of_restrooms,
       "Quality of experience at concession stands or clubs" quality_of_experience_at_concession_stands,
       "quality of merchandise shopping experience"          quality_of_merchandise_shopping_experience,
       "quality of wifi experience"                          quality_of_wifi_experience,
       pt_year,
       pt_month,
       pt_day
FROM medallia.medallia_daily_survey_response
WHERE pt_year = '2021'
WITH NO SCHEMA BINDING;

alter table avw_medallia_cons_facts
    owner to madhavm;

