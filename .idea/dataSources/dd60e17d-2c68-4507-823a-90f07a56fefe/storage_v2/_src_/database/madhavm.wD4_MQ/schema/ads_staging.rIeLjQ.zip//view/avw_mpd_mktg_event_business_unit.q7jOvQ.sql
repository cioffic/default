create or replace view ads_staging.avw_mpd_mktg_event_business_unit as
select distinct legacy_marketing_business_unit, b.event_business_unit, b.arena_name tm_arena_name
from ext_staging.mpd_mktg_legacy_current_business_unit a
         inner join ext_staging.mpd_mktg_event_business_unit b
                    on lower(a.current_marketing_business_unit) = lower(b.marketing_business_unit)
                        and a.arena_name = b.arena_name
where b.event_business_unit != 'ALL'
UNION
select distinct legacy_marketing_business_unit, c.event_business_unit, c.tm_arena_name tm_arena_name
from ext_staging.mpd_mktg_legacy_current_business_unit a
         inner join ext_staging.mpd_mktg_event_business_unit b
                    on lower(a.current_marketing_business_unit) = lower(b.marketing_business_unit)
                        and a.arena_name = b.arena_name
         inner join (
    select distinct event_business_unit, tm_arena_name from ads_main.d_event_plan) c
                    on 1 = 1
where b.event_business_unit = 'ALL'
WITH NO SCHEMA BINDING;

alter table avw_mpd_mktg_event_business_unit
    owner to madhavm;

