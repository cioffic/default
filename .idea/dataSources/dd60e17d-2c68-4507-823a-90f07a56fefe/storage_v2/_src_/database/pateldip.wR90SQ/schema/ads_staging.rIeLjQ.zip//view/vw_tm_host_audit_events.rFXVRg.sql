create view ads_staging.vw_tm_host_audit_events
            (cstm_src_filename, system_name, inet_event_id, tm_event_name, tm_event_name_long, tm_major_category,
             tm_minor_category, tm_primary_act_name, tm_secondary_act_name, tm_arena_name, tm_event_date, tm_event_time,
             rnk)
as
SELECT derived_table1.audit_date,
       derived_table1.system_name,
       derived_table1.inet_event_id,
       derived_table1.tm_event_name,
       derived_table1.tm_event_name_long,
       derived_table1.tm_major_category,
       derived_table1.tm_minor_category,
       derived_table1.tm_primary_act_name,
       derived_table1.tm_secondary_act_name,
       derived_table1.tm_arena_name,
       derived_table1.tm_event_date,
       derived_table1.tm_event_time,
       derived_table1.rnk
FROM (SELECT host_audit.pt_year || '-' || host_audit.pt_month || '-' || host_audit.pt_day                       audit_date,
             host_audit.system_name,
             host_audit.hexvaxevid                                                                           AS inet_event_id,
             host_audit.evcode                                                                               AS tm_event_name,
             host_audit.eventname                                                                            AS tm_event_name_long,
             host_audit.majorcategory                                                                        AS tm_major_category,
             host_audit.minorcategory                                                                        AS tm_minor_category,
             host_audit.actname                                                                              AS tm_primary_act_name,
             host_audit.secondactname                                                                        AS tm_secondary_act_name,
             host_audit.venuename                                                                            AS tm_arena_name,
             host_audit.epdate                                                                               AS tm_event_date,
             host_audit.eptime                                                                               AS tm_event_time,
             pg_catalog.row_number()
             OVER (
                 PARTITION BY host_audit.hexvaxevid
                 ORDER BY host_audit.pt_year || '-' || host_audit.pt_month || '-' || host_audit.pt_day DESC) AS rnk
      FROM ticketmaster.host_audit) derived_table1
WHERE derived_table1.rnk = 1

WITH NO SCHEMA BINDING;

alter table vw_tm_host_audit_events
    owner to pateldip;

