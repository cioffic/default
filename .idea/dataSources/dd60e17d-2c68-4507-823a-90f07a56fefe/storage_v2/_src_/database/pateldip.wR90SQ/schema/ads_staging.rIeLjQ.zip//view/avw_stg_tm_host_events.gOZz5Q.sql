CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_host_events AS
SELECT -- rank() over (partition by events.id order by e._embedded.pulldatetime desc) as rnk,
       events.id                         discovery_event_id,
       events.info                       event_info,
       events.type,
       events.locale,
       events.pleaseNote                 event_please_note_desc,
       events.url                        event_url,
       events.name                       event_name_long,
       events.seatmap.staticurl          event_seatmap_url,
       events.dates.status.code          event_status,
       events.dates.timezone             event_date_timezone,
       events.dates.spanMultipleDays     event_span_multiple_days,
       events.dates.start.localDate      event_date,
       events.dates.start.dateTime       event_date_time,
       events.dates.start.dateTBD        event_date_tbd,
       events.dates.start.dateTBA        event_date_tba,
       events.dates.start.timeTBA        event_date_time_tba,
       events.dates.start.noSpecificTime event_date_no_specific_time,
       events.dates.start.localtime      event_time,
       events.sales.public.startDateTime event_public_onsale_start_datetime,
       events.sales.public.endDateTime   event_public_onsale_end_datetime,
       events.sales.public.startTBD      event_public_onsale_date_tbd,
       events.ticketLimit.info           event_ticketlimit_desc,
       events.promoter.description       event_promoter_desc,
       events.promoter.id                event_promoter_id,
       events.promoter.name              event_promoter_name,
       venues.name                       event_arena_name,
       venues.state.name                 event_arena_state_name,
       venues.city.name                  event_arena_city_name,
       venues.country.name               event_arena_country_name,
       venues.address.line1              event_arena_address,
       venues.location.longitude         event_arena_longitude,
       venues.location.latitude          event_arena_latitude,
       classifications.primary           event_classification_primary_flag,
       classifications.segment.id        event_classification_segment_id,
       classifications.segment.name      event_classification_segment_name,
       classifications.genre.id          event_classification_genre_id,
       classifications.genre.name        event_classification_genre_name,
       classifications.subGenre.id       event_classification_subgenre_id,
       classifications.subGenre.name     event_classification_subgenre_name,
       classifications.type.id           event_classification_type_id,
       classifications.type.name         event_classification_type_name,
       classifications.type.id           event_classification_subtype_id,
       classifications.type.name         event_classification_subtype_name,
       classifications.family            event_classification_family_flag,
       e.pt_year                         pt_year,
       e.pt_month                        pt_month,
       e.pt_day                          pt_day
FROM ticketmaster.discoveryapi_events_search e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events._embedded.venues venues
                   ON TRUE
         LEFT JOIN events.classifications classifications
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events
    owner to pateldip;

