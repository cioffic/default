create view d_credited_account_rep
            (credited_account_rep_id, tm_acct_rep_id, tm_rep_name_first, tm_rep_name_middle, tm_rep_name_last,
             tm_rep_name_title, tm_rep_company_name, tm_rep_nick_name, tm_rep_name_last_first_mi, tm_rep_full_name,
             msg_departmentname, ads_source, rnk)
as
SELECT derived_table1.credited_account_rep_id,
       derived_table1.tm_acct_rep_id,
       derived_table1.tm_rep_name_first,
       derived_table1.tm_rep_name_middle,
       derived_table1.tm_rep_name_last,
       derived_table1.tm_rep_name_title,
       derived_table1.tm_rep_company_name,
       derived_table1.tm_rep_nick_name,
       derived_table1.tm_rep_name_last_first_mi,
       derived_table1.tm_rep_full_name,
       derived_table1.msg_departmentname,
       derived_table1.ads_source,
       derived_table1.rnk
FROM (SELECT min(d_account_rep.account_rep_id)                                                            AS credited_account_rep_id,
             d_account_rep.tm_acct_rep_id,
             d_account_rep.tm_rep_name_first,
             d_account_rep.tm_rep_name_middle,
             d_account_rep.tm_rep_name_last,
             d_account_rep.tm_rep_name_title,
             d_account_rep.tm_rep_company_name,
             d_account_rep.tm_rep_nick_name,
             d_account_rep.tm_rep_name_last_first_mi,
             d_account_rep.tm_rep_full_name,
             d_account_rep.msg_departmentname,
             d_account_rep.ads_source,
             pg_catalog.row_number()
             OVER (
                 PARTITION BY d_account_rep.tm_acct_rep_id, d_account_rep.ads_source, d_account_rep.tm_rep_name_last
                 ORDER BY d_account_rep.tm_rep_full_name, length(d_account_rep.msg_departmentname::text)) AS rnk
      FROM ads_main.d_account_rep
      GROUP BY d_account_rep.tm_acct_rep_id, d_account_rep.tm_rep_name_first, d_account_rep.tm_rep_name_middle,
               d_account_rep.tm_rep_name_last, d_account_rep.tm_rep_name_title, d_account_rep.tm_rep_company_name,
               d_account_rep.tm_rep_nick_name, d_account_rep.tm_rep_name_last_first_mi, d_account_rep.tm_rep_full_name,
               d_account_rep.msg_departmentname, d_account_rep.ads_source) derived_table1
WHERE derived_table1.rnk = 1;

alter table d_credited_account_rep
    owner to pateldip;

