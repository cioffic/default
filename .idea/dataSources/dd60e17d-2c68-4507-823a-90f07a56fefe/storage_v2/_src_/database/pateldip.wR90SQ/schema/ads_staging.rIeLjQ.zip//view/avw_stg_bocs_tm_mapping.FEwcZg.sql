create OR REPLACE view ads_staging.avw_stg_bocs_tm_mapping as
select *,
       'MSG' as                                                                                 ads_source,
       row_number() OVER (PARTITION BY inet_event_id ORDER BY gl_event_code,tm_event_time DESC) rnk
from bocs.bocs_tm_mapping
where pt_year || pt_month || pt_day = (SELECT MAX(pt_year || pt_month || pt_day) FROM bocs.bocs_tm_mapping)
with no schema binding;

alter table avw_stg_bocs_tm_mapping
    owner to pateldip;

