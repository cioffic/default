create function fn_uuid() returns character varying
    volatile
    language plpythonu
as
$$
 import uuid
 return uuid.uuid1().__str__()
$$;

