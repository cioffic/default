CREATE VIEW ads_staging.avw_stg_tm_host_events_presales AS
SELECT events.id              discovery_event_id,
       presales.name          presale_name,
       presales.startDateTime presale_startdatetime,
       presales.endDateTime   presale_enddatetime
FROM ticketmaster.tm_host_eventsstagedevents_search e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events.sales.presales presales
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_presales
    owner to pateldip;

