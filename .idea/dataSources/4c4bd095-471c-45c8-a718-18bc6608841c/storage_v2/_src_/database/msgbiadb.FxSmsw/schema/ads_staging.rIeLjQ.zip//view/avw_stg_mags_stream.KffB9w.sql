create view ads_staging.avw_stg_mags_stream
as
select *, ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
from ext_staging.stg_mags_stream
with no schema binding;

alter table avw_stg_mags_stream
    owner to ads_staging;

