create or replace view ads_staging.avw_stg_tfs_incidents_locationdetails as
select a.locationId,
       a.locationName,
       a.sectionId,
       a.sectionName,
       a.rows,
       a.seat,
       a.facility,
       a.conditions,
       a.obstacles_present,
       a.normal_lighting
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.locationdetails a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_locationdetails
    owner to ads_staging;

