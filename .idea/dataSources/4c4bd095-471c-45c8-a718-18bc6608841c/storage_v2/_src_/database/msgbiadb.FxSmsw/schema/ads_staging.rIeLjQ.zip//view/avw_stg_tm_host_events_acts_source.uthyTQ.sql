-- ads_staging.avw_stg_tm_host_events_acts_source source

CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_host_events_acts_source AS
SELECT --e._embedded.pulldatetime,
       events.id                                 discovery_event_id,
       attractions.name,
       attractions.url,
       attractions.locale,
       attractions._links.self.href,
       attractions.test,
       --attractions.upcomingevents._total,
       --attractions.upcomingevents.tmr,
       --attractions.upcomingevents.ticketmaster,
       attractions.type,
       attractions.id,
       attractions_classifications.family,
       attractions_classifications.segment.id    attractions_segment_id,
       attractions_classifications.segment.name  attractions_segment_name,
       attractions_classifications.primary,
       attractions_classifications.subType.id    attractions_subtype_id,
       attractions_classifications.subType.name  attractions_subtype_name,
       attractions_classifications.genre.id      attractions_genre_id,
       attractions_classifications.genre.name    attractions_genre_name,
       attractions_classifications.subGenre.id   attractions_subgenre_id,
       attractions_classifications.subGenre.name attractions_subgenre_name,
       attractions_classifications.type.id       attractions_type_id,
       attractions_classifications.type.name     attractions_type_name,
       e.pt_year                                 pt_year,
       e.pt_month                                pt_month,
       e.pt_day                                  pt_day
FROM ticketmaster.discoveryapi_events_search e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events._embedded.attractions attractions
                   ON TRUE
         LEFT JOIN attractions.classifications attractions_classifications
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_acts_source
    owner to ads_staging;

