create view v_get_users_in_group
            (groname, grosysid, usename, usesysid, usecreatedb, usesuper, usecatupd, passwd, valuntil, useconfig) as
SELECT pg_group.groname,
       pg_group.grosysid,
       pg_user.usename,
       pg_user.usesysid,
       pg_user.usecreatedb,
       pg_user.usesuper,
       pg_user.usecatupd,
       pg_user.passwd,
       pg_user.valuntil,
       pg_user.useconfig
FROM pg_group,
     pg_user
WHERE pg_user.usesysid = ANY (pg_group.grolist)
ORDER BY pg_group.groname, pg_group.grosysid;

alter table v_get_users_in_group
    owner to msgadmin;

