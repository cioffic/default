create or replace view ads_staging.avw_stg_tfs_incidents_linktoincidents as
select a.linked_incident_id,
       a.linked_incident_number
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.linktoincidents a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_linktoincidents
    owner to ads_staging;

