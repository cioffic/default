create view ads_staging.avw_kore_category as
select *
from ext_staging.stg_kore_category
with no schema binding;

alter table avw_kore_category
    owner to ads_staging;

