CREATE VIEW ads_staging.mpd_ticket_class_group_name AS
SELECT *
FROM ext_staging.mpd_ticket_class_group_name
WITH NO SCHEMA BINDING;

alter table mpd_ticket_class_group_name
    owner to ads_staging;

