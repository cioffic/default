CREATE OR REPLACE view ads_staging.avw_mpd_geo_address_cleanup
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       id::varchar(255),
       match_1::varchar(255),
       match_2::varchar(255),
       match_score::varchar(255),
       city::varchar(255),
       county::varchar(255),
       zip::varchar(255),
       state_code::varchar(255),
       country_code::varchar(255)

FROM ext_staging.mpd_geo_address_cleanup
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_address_cleanup
    owner to ads_staging;

