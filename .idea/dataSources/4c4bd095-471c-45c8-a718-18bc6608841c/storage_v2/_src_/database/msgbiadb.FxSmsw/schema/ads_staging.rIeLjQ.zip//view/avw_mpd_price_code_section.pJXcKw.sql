create or replace view ads_staging.avw_mpd_price_code_section
as
select season_name,
       price_level,
       price_code_section
from ext_staging.mpd_price_code_section
with no schema binding;

alter table avw_mpd_price_code_section
    owner to ads_staging;

