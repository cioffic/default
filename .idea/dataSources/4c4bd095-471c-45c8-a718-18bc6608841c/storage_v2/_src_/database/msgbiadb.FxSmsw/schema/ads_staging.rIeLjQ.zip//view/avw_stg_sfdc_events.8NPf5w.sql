create or replace view ads_staging.avw_stg_sfdc_events as
select *
from ext_staging.stg_sfdc_event
with no schema binding;

alter table avw_stg_sfdc_events
    owner to ads_staging;

