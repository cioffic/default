create or replace view ads_staging.avw_stg_tradedesk_sales as
(
select status,
       invoice_date,
       invoice_time,
       home,
       event_datetime1                                               as event_date_time_1,
       event_datetime2                                               as event_date_time_2,
       section,
       row,
       beg_seat                                                         begin_seat,
       end_seat,
       qty,
       msg_rev_per_ticket                                            as msg_revenue_per_ticket,
       msg_total_revenue,
       msg_reporting_rev_per_ticket,
       msg_reporting_revenue,
       customer,
       daysout,
       pricecode,
       pricelevel,
       event_code                                                    AS "event code",
       grade,
       (TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2, 1, 5) + '-' + substring(event_date_time_1, 5, 3) + '-' +
                                  lpad(substring(event_date_time_1, 9, 2), 2, '0') + ' ' +
                                  trim(lpad(substring(event_date_time_2, 7, 5), 5, '0')) + ':00' + ' ' +
                                  substring(event_date_time_2, 12), 'YYYY-MON-DD HH12:MI:SS PM'),
                     'YYYY-MM-DD HH24:MI:SS'))                       as event_date,
       trim(substring(TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2, 1, 5) + '-' +
                                                substring(event_date_time_1, 5, 3) + '-' +
                                                lpad(substring(event_date_time_1, 9, 2), 2, '0') + ' ' +
                                                trim(lpad(substring(event_date_time_2, 7, 5), 5, '0')) + ':00' + ' ' +
                                                substring(event_date_time_2, 12), 'YYYY-MON-DD HH12:MI:SS PM'),
                                   'YYYY-MM-DD HH24:MI:SS'), 12, 8)) AS event_time,
       'TRADEDESK'                                                   as cstm_source,
       split_part("$path", '/', 6)                                   as cstm_src_filename
from ext_staging.stg_tradedesk_sales a
where status <> '------'
/*union all
select
status::varchar(255) ,
invoice_date::varchar(255) ,
invoice_time::varchar(255) ,
home::varchar(255) ,
event_date_time_1::varchar(100) ,
event_date_time_2::varchar(100) ,
section::varchar(30),
"row"::varchar(30) ,
begin_seat::int ,
end_seat::int ,
qty::varchar ,
msg_revenue_per_ticket::varchar ,
msg_total_revenue::varchar ,
0::varchar msg_reporting_rev_per_ticket ,
0::varchar msg_reporting_revenue ,
customer::varchar ,
daysout::varchar ,
pricecode::varchar ,
pricelevel::varchar ,
CASE WHEN a."event code" LIKE 'ERX%' THEN SUBSTRING(a."event code",2,8) ELSE a."event code" END::varchar "event code" ,
grade::varchar ,
(TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2,1,5)+'-'+substring(event_date_time_1,5,3)+'-'+lpad(substring(event_date_time_1,9,2),2,'0')+' '+trim(lpad(substring(event_date_time_2,7,5),5,'0'))+':00'+' '+substring(event_date_time_2,12),'YYYY-MON-DD HH12:MI:SS PM'),'YYYY-MM-DD HH24:MI:SS')) as event_date,
trim(substring(TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2,1,5)+'-'+substring(event_date_time_1,5,3)+'-'+lpad(substring(event_date_time_1,9,2),2,'0')+' '+trim(lpad(substring(event_date_time_2,7,5),5,'0'))+':00'+' '+substring(event_date_time_2,12),'YYYY-MON-DD HH12:MI:SS PM'),'YYYY-MM-DD HH24:MI:SS'),12,8)) AS event_time,
cstm_source::varchar(100),
 cstm_src_filename::varchar(100)
FROM ads_staging.stg_autoproc_rccs a
JOIN ads_Main.d_event_plan b
	ON CASE WHEN a."event code" LIKE 'ERX%' THEN SUBSTRING(a."event code",2,8) ELSE a."event code" END = b.tm_event_name
WHERE 1=1
	AND tm_season_name IN ('FAM 2018 The Grinch','KNK 2018-19 New York Knicks','RCS 2018 RCCS 1st Half','RCS 2018 RCCS 2nd Half','RNG 2018-19 New York Rangers')
	AND a.cstm_src_filename IN ('DailySalesRCCS_20190425.csv','DailySalesElf_20190425.csv','DailySalesRangers_20190425.csv','DailySalesGrinch_20190425.csv','DailySalesKnicks_20190425.csv')
	AND a.status = 'Sold'
	AND b.tm_season_year=2018
	AND b.tm_plan_event_id=-1
*/
    )
with no schema binding;

alter table avw_stg_tradedesk_sales
    owner to ads_staging;

