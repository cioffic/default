CREATE OR REPLACE VIEW ads_mon.vw_medallia_event_mapping AS
select *
from ads_staging.vw_medallia_event_mapping
with no schema binding;

alter table vw_medallia_event_mapping
    owner to ads_main;

