create or replace view ads_staging.avw_mpd_qualifiers
as
select channel,
       partner,
       detail,
       pricing,
       public_offer,
       percent_disc,
       qualifier_code,
       vanity_needed,
       valid_perfs,
       offer_active::date  as offer_active,
       offer_expires::date as offer_expires,
       season
from ext_staging.mpd_qualifiers
with no schema binding;

alter table avw_mpd_qualifiers
    owner to ads_staging;

