create view ads_staging.avw_stg_wfm_payroll_earning_codes
as
select *, ads_staging.f_s3_parse_athena_filename("$path") as filename
from ext_staging.stg_wfm_payroll_earning_codes
with no schema binding;

alter table avw_stg_wfm_payroll_earning_codes
    owner to ads_staging;

