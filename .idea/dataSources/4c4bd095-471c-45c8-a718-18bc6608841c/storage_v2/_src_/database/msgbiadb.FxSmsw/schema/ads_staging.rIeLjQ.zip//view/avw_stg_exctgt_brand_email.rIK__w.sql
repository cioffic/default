create or replace view ads_staging.avw_stg_exctgt_brand_email as
select ads_staging.f_s3_parse_athena_filename("$path"):: VARCHAR(255) as                        ads_source_file,
       substring("$path" :: VARCHAR(255), position('.' IN "$path" :: VARCHAR(255)) - 8, 8)::int load_date,
       mid::int                                                                                 exctgt_brand_id,
       brand::varchar(100)                                                                      exctgt_brand,
       email_address::varchar(100)                                                              exctgt_email_address,
       engagement_flag::varchar(1)
from ext_staging.stg_email_by_brand
WHERE email_address IS NOT NULL

with no schema binding;

alter table avw_stg_exctgt_brand_email
    owner to ads_staging;

