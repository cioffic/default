create view vw_fmb_merchandise_inventory
            (venue, segment, fmb_services, floor, section, stand_name, location_name, product_segment,
             fmb_product_class, fmb_product_subclass, fmb_business, fmb_category, fmb_subcategory, fmb_size, fmb_player,
             fmb_vendor, product_name, product_description, current_retail, post_date_full_date, post_date_day_name,
             post_date_day_name_abbrev, post_date_weekday_indicator, post_date_week_id, post_date_week_end_date,
             post_date_fiscal_year, purchase_quantity, production_quantity, transfer_out_quantity,
             transfer_into_quantity, total_usage_quantity, variance_quantity, physical_inventory_quantity,
             current_units_on_hand, cost_dollar_on_hand, purchase_amount, production_amount, transfer_out_amount,
             transfer_into_amount, total_usage_amount, variance_amount, physical_inventory_amount, pos_quantity,
             spoilage_quantity, used_in_production_quantity, pos_amount, spoilage_amount, used_in_production_amount,
             unit_cost, net_retail_dollar_on_hand, eatec_location_id, eatec_product_id, post_day_id,
             eatec_product_number)
as
SELECT CASE
           WHEN COALESCE(d_location.venue, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_location.venue
           END                                                                               AS venue,
       CASE
           WHEN COALESCE(d_location.segment, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_location.segment
           END                                                                               AS segment,
       CASE
           WHEN COALESCE(d_location.fmb_services, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_location.fmb_services
           END                                                                               AS fmb_services,
       CASE
           WHEN COALESCE(d_location.floor, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_location.floor
           END                                                                               AS floor,
       CASE
           WHEN COALESCE(d_location.section, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_location.section
           END                                                                               AS section,
       CASE
           WHEN COALESCE(d_location.stand_name, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_location.stand_name
           END                                                                               AS stand_name,
       CASE
           WHEN COALESCE(d_location.location_name, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_location.location_name
           END                                                                               AS location_name,
       CASE
           WHEN COALESCE(d_product.segment, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_product.segment
           END                                                                               AS product_segment,
       CASE
           WHEN COALESCE(d_product.fmb_product_class, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.fmb_product_class
           END                                                                               AS fmb_product_class,
       CASE
           WHEN COALESCE(d_product.fmb_product_subclass, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.fmb_product_subclass
           END                                                                               AS fmb_product_subclass,
       CASE
           WHEN COALESCE(d_product.fmb_business, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.fmb_business
           END                                                                               AS fmb_business,
       CASE
           WHEN COALESCE(d_product.fmb_category, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.fmb_category
           END                                                                               AS fmb_category,
       CASE
           WHEN COALESCE(d_product.fmb_subcategory, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.fmb_subcategory
           END                                                                               AS fmb_subcategory,
       CASE
           WHEN COALESCE(d_product.fmb_size, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_product.fmb_size
           END                                                                               AS fmb_size,
       CASE
           WHEN COALESCE(d_product.fmb_player, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_product.fmb_player
           END                                                                               AS fmb_player,
       CASE
           WHEN COALESCE(d_product.fmb_vendor, ''::character varying)::text = ''::text THEN 'Unknown'::character varying
           ELSE d_product.fmb_vendor
           END                                                                               AS fmb_vendor,
       CASE
           WHEN COALESCE(d_product.product_name, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.product_name
           END                                                                               AS product_name,
       CASE
           WHEN COALESCE(d_product.product_description, ''::character varying)::text = ''::text
               THEN 'Unknown'::character varying
           ELSE d_product.product_description
           END                                                                               AS product_description,
       d_product.cost_amount                                                                 AS current_retail,
       d_date.full_date                                                                      AS post_date_full_date,
       d_date.day_name                                                                       AS post_date_day_name,
       d_date.day_name_abbrev                                                                AS post_date_day_name_abbrev,
       d_date.weekday_indicator                                                              AS post_date_weekday_indicator,
       d_date.week_id                                                                        AS post_date_week_id,
       d_date.week_end_date                                                                  AS post_date_week_end_date,
       d_date.fiscal_year                                                                    AS post_date_fiscal_year,
       f.purchase_quantity,
       f.production_quantity,
       f.transfer_out_quantity,
       f.transfer_into_quantity,
       f.total_usage_quantity,
       f.variance_quantity,
       f.physical_inventory_quantity,
       f.total_quantity                                                                      AS current_units_on_hand,
       f.total_amount                                                                        AS cost_dollar_on_hand,
       f.purchase_amount,
       f.production_amount,
       f.transfer_out_amount,
       f.transfer_into_amount,
       f.total_usage_amount,
       f.variance_amount,
       f.physical_inventory_amount,
       f.pos_quantity,
       f.spoilage_quantity,
       f.used_in_production_quantity,
       f.pos_amount,
       f.spoilage_amount,
       f.used_in_production_amount,
       f.current_cost                                                                        AS unit_cost,
       f.total_quantity *
       (f.total_amount - f.total_amount * 8.875 * 0.01)::double precision                    AS net_retail_dollar_on_hand,
       f.eatec_location_id,
       d_product.eatec_product_id::character varying(50)                                     AS eatec_product_id,
       f.post_day_id::character varying(50)                                                  AS post_day_id,
       f.eatec_ingredients_id                                                                AS eatec_product_number
FROM ads_main.f_fmb_merchandise_inventory f
         LEFT JOIN ads_main.d_date d_date ON f.post_day_id = d_date.day_id
         LEFT JOIN ads_main.d_location d_location ON f.location_dim_id = d_location.location_dim_id
         LEFT JOIN ads_main.d_product d_product ON f.product_dim_id = d_product.product_dim_id;

alter table vw_fmb_merchandise_inventory
    owner to ads_main;

