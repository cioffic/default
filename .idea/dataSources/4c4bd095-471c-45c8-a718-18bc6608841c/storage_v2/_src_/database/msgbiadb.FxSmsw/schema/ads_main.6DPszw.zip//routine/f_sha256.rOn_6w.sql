create function f_sha256(mes character varying) returns character varying
    stable
    language plpythonu
as
$$
  import hashlib
  return hashlib.sha256(mes).hexdigest()
$$;

