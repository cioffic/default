create or replace view ads_staging.avw_stg_tfs_incidents_incidentassignedto as
select a.assigned_to_user_id,
       a.assigned_to_user_name
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.incidentassignedto a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_incidentassignedto
    owner to ads_staging;

