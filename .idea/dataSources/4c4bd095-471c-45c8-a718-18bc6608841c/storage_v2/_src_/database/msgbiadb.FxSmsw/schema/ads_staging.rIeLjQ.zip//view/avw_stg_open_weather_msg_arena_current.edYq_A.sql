CREATE OR REPLACE VIEW ads_staging.avw_stg_open_weather_msg_arena_current
AS
Select timestamp 'epoch' + dt * interval '1 second'      AS dtime,
       timestamp 'epoch' + sunrise * interval '1 second' AS sunrise_dtime,
       timestamp 'epoch' + sunset * interval '1 second'  AS sunset_dttime,
       ((temp - 273.15) * 1.8) + 32                      AS temp,
       ((feels_like - 273.15) * 1.8) + 32                AS feels_like,
       pressure,
       humidity,
       dew_point,
       uvi,
       clouds,
       visibility,
       wind_speed,
       wind_deg,
       id,
       main,
       description,
       icon,
       1                                                    h,
       wind_gust,
       ads_staging.f_s3_parse_athena_filename("$path")   as ads_source_file,
       'MSG'                                             as ads_source
from open_weather.open_weather_current_reports_6fcb92d04eeb85b72fced7965c5a7378
with no schema binding;

alter table avw_stg_open_weather_msg_arena_current
    owner to ads_staging;

