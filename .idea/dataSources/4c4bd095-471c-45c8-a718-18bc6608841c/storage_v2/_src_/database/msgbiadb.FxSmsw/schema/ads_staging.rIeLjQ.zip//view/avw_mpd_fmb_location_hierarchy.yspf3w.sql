CREATE OR REPLACE view ads_staging.avw_mpd_fmb_location_hierarchy AS

select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       nullif(venue_id, '')::int,
       id::int,
       venue::varchar(255),
       segment::varchar(255),
       fmb_services::varchar(255),
       floor::varchar(255),
       section::varchar(255),
       stand_name::varchar(255),
       location_name::varchar(255),
       neighborhood_owner::varchar(255)
from ext_staging.mpd_fmb_location_hierarchy
with no schema binding;

alter table avw_mpd_fmb_location_hierarchy
    owner to ads_staging;

