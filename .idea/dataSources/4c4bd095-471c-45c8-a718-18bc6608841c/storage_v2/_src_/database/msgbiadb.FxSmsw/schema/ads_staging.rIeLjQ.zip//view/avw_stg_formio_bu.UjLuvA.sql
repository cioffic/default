CREATE or replace view ads_staging.avw_stg_formio_bu
as
select *
from forms_io.formio_bu
with no schema binding;

alter table avw_stg_formio_bu
    owner to ads_staging;

