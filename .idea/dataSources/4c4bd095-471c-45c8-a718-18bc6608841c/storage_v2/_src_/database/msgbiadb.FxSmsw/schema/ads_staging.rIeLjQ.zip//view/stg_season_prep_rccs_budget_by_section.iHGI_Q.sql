create or replace view ads_staging.stg_season_prep_rccs_budget_by_section
as
select season,
       tm_event_code,
       date_of_show::DATE                                                            as date_of_show,
       week_ending::DATE                                                             as week_ending,
       show_grade,
       finance_ticket_type,
       reporting_ticket_type,
       section,
       case
           when tickets_sold = '-' then 0 :: FLOAT
           else
               nvl(replace(tickets_sold, ',', ''), '0') :: FLOAT end                 as tickets_sold,
       case
           when tickets_revenue = '-' then 0 :: FLOAT
           else
               nvl(replace(tickets_revenue, ',', ''), '0') :: FLOAT end              as tickets_revenue,
       case
           when event_sort = '-' then 0 ::FLOAT
           else nvl(replace(replace(event_sort, ',', ''), '-', '0'), '0')::FLOAT end as event_sort,
       case
           when capacity = '-' then 0 :: FLOAT
           else
               nvl(replace(replace(capacity, ',', ''), '-', '0'), '0') :: FLOAT end  as capacity,
       "time",
       season_old,
       case
           when capacity2 = '-' then 0 :: FLOAT
           else
               nvl(replace(capacity2, ',', ''), '0') :: FLOAT end                    as capacity2,
       db,
       season_type
from ext_staging.stg_season_prep_rccs_budget_by_section
with no schema binding;

alter table stg_season_prep_rccs_budget_by_section
    owner to ads_staging;

