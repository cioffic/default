create or replace view ads_staging.avw_stg_tfs_incidents_attachments as
select a.medianame,
       a.type,
       a.DocumentType,
       a.URL
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.attachments a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_attachments
    owner to ads_staging;

