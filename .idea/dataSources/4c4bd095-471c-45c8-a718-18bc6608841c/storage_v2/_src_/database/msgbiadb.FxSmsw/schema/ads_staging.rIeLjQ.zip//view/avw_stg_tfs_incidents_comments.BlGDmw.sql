create or replace view ads_staging.avw_stg_tfs_incidents_comments as
select a.id,
       a.comment_id,
       a.comment,
       a.created_on,
       a.created_by,
       a.updated_by
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.comments a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_comments
    owner to ads_staging;

