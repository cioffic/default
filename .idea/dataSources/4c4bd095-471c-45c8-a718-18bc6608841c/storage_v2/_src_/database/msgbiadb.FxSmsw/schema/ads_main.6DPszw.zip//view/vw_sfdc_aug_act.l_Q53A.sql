create view vw_sfdc_aug_act
            (activity_id, activity_dynamics_id, record_type_id, record_type_name, activity_status, activity_type,
             activity_scheduled_date, activity_actual_end, activity_what_id, activity_who_id, call_disposition,
             call_duration_in_seconds, is_outbound_call, appointment_type, owner_id, owner_name, department, opp_id,
             acct_id)
as
SELECT DISTINCT t.id                             AS activity_id,
                t.legacy_dynamics_id__c          AS activity_dynamics_id,
                t.recordtypeid                   AS record_type_id,
                rt.name                          AS record_type_name,
                t.status                         AS activity_status,
                CASE
                    WHEN "left"(t.subject::text, 6) = 'Email:'::character varying::text THEN 'Email'::character varying
                    ELSE t.activity_type__c
                    END                          AS activity_type,
                t.activitydate                   AS activity_scheduled_date,
                CASE
                    WHEN t.actual_end__c IS NULL AND t.status::text = 'Completed'::text THEN t.activitydate
                    ELSE t.actual_end__c
                    END                          AS activity_actual_end,
                t.whatid                         AS activity_what_id,
                t.whoid                          AS activity_who_id,
                t.calldisposition                AS call_disposition,
                t.calldurationinseconds::integer AS call_duration_in_seconds,
                t.koreps__is_outbound_call__c    AS is_outbound_call,
                t.appointment_type__c            AS appointment_type,
                t.ownerid                        AS owner_id,
                tou.name                         AS owner_name,
                tou.msg_department__c            AS department,
                CASE
                    WHEN "left"(t.whatid::text, 5) = '0063i'::character varying::text THEN t.whatid
                    ELSE NULL::character varying
                    END                          AS opp_id,
                t.accountid                      AS acct_id
FROM ads_main.sfdc_task t
         LEFT JOIN ads_main.sfdc_user tou ON t.ownerid::text = tou.id::text
         LEFT JOIN ads_main.sfdc_recordtype rt ON t.recordtypeid::text = rt.id::text
WHERE t.status IS NOT NULL
  AND t.status::text !~~ 'Cancel%'::text
UNION ALL
SELECT DISTINCT e.id                          AS activity_id,
                e.legacy_dynamics_id__c       AS activity_dynamics_id,
                NULL::character varying       AS record_type_id,
                NULL::character varying       AS record_type_name,
                e.appointment_status__c       AS activity_status,
                e.activity_type__c            AS activity_type,
                e.activitydate                AS activity_scheduled_date,
                CASE
                    WHEN e.actual_end__c IS NULL AND e.appointment_status__c::text = 'Completed'::text
                        THEN e.activitydate
                    ELSE e.actual_end__c
                    END                       AS activity_actual_end,
                e.whatid                      AS activity_what_id,
                e.whoid                       AS activity_who_id,
                NULL::bpchar::character(1)    AS call_disposition,
                NULL::integer                 AS call_duration_in_seconds,
                e.koreps__is_outbound_call__c AS is_outbound_call,
                e.appointment_type__c         AS appointment_type,
                e.ownerid                     AS owner_id,
                tou.name                      AS owner_name,
                tou.msg_department__c         AS department,
                CASE
                    WHEN "left"(e.whatid::text, 5) = '0063i'::character varying::text THEN e.whatid
                    ELSE NULL::character varying
                    END                       AS opp_id,
                e.accountid                   AS acct_id
FROM ads_main.sfdc_event e
         LEFT JOIN ads_main.sfdc_user tou ON e.ownerid::text = tou.id::text
WHERE e.appointment_status__c IS NOT NULL
  AND e.appointment_status__c::text !~~ 'Cancel%'::text;

alter table vw_sfdc_aug_act
    owner to ads_main;

