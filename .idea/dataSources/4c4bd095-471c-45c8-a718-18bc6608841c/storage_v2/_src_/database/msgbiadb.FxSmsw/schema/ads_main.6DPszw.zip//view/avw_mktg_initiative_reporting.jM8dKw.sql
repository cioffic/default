CREATE OR REPLACE VIEW ads_main.avw_mktg_initiative_reporting AS


SELECT *,
       right("$path", position('/' in reverse("$path")) - 1)::varchar(255) as file_name
FROM ext_staging.stg_mktg_initiative_reporting
    --where file_name>='MSG INI Weekly Reporting - 2018.05.13.csv'
--and file_name<>'MSG INI Weekly Reporting - Totals 2018 (002).csv'
with no schema binding;

alter table avw_mktg_initiative_reporting
    owner to ads_main;

