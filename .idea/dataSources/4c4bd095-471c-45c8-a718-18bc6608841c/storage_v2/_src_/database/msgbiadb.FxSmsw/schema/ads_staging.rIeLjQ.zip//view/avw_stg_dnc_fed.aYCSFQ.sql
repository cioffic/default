create or replace view ads_staging.avw_stg_dnc_fed
as
select area_code, suffix, area_code || suffix as phone_number
from ext_staging.stg_dnc_fed
with no schema binding;

alter table avw_stg_dnc_fed
    owner to ads_staging;

