create view vw_t_exctgt_matchback
            (sent_day_name, sent_month, sent_quarter, sent_fiscal_year, sent_fiscal_year_month,
             sent_fiscal_year_quarter, sent_full_date, sent_week_end_date, sent_week_id, sent_year_month,
             event_business_unit, inet_event_id, report_event_flag, tm_arena_name, tm_event_date, tm_event_name,
             tm_event_name_long, tm_event_time, tm_season_name, tm_season_year, brand, email_category,
             exctgt_email_name, exctgt_additional, exctgt_from_name, exctgt_job_status, exctgt_sched_time,
             exctgt_send_id, exctgt_subject, exctgt_from_email, test_job_flag, all_matched_ticket_count,
             all_matched_ticket_revenue, brand_matched_ticket_count, brand_matched_ticket_revenue,
             cfc_matched_ticket_count, cfc_matched_ticket_revenue, brand_matched_purchasers, all_matched_purchasers,
             cfc_matched_purchasers, exctgt_email_sent_day_id, exctgt_sendjob_id, exctgt_segment_name)
as
SELECT dt.day_name                                  AS sent_day_name,
       dt.fiscal_month                              AS sent_month,
       dt.fiscal_quarter                            AS sent_quarter,
       dt.fiscal_year                               AS sent_fiscal_year,
       dt.fiscal_year_month                         AS sent_fiscal_year_month,
       dt.fiscal_year_quarter                       AS sent_fiscal_year_quarter,
       dt.full_date                                 AS sent_full_date,
       dt.week_end_date                             AS sent_week_end_date,
       dt.week_id                                   AS sent_week_id,
       dt.year_month                                AS sent_year_month,
       ep.event_business_unit,
       ep.inet_event_id,
       ep.report_event_flag,
       ep.tm_arena_name,
       ep.tm_event_date,
       ep.tm_event_name,
       ep.tm_event_name_long,
       ep.tm_event_time,
       ep.tm_season_name,
       ep.tm_season_year,
       sj.brand,
       sj.email_category,
       sj.exctgt_email_name,
       sj.exctgt_additional,
       sj.exctgt_from_name,
       sj.exctgt_job_status,
       sj.exctgt_sched_time,
       sj.exctgt_send_id,
       sj.exctgt_subject,
       sj.exctgt_from_email,
       sj.test_job_flag,
       sum(match_back.all_matched_ticket_count)     AS all_matched_ticket_count,
       sum(match_back.all_matched_ticket_revenue)   AS all_matched_ticket_revenue,
       sum(match_back.brand_matched_ticket_count)   AS brand_matched_ticket_count,
       sum(match_back.brand_matched_ticket_revenue) AS brand_matched_ticket_revenue,
       sum(match_back.cfc_matched_ticket_count)     AS cfc_matched_ticket_count,
       sum(match_back.cfc_matched_ticket_revenue)   AS cfc_matched_ticket_revenue,
       COALESCE(count(DISTINCT
                      CASE
                          WHEN match_back.brand_matched_ticket_count > 0 THEN match_back.exctgt_ads_subscriber_id
                          ELSE NULL::integer
                          END), 0::bigint)          AS brand_matched_purchasers,
       COALESCE(count(DISTINCT
                      CASE
                          WHEN match_back.all_matched_ticket_count > 0 THEN match_back.exctgt_ads_subscriber_id
                          ELSE NULL::integer
                          END), 0::bigint)          AS all_matched_purchasers,
       COALESCE(count(DISTINCT
                      CASE
                          WHEN match_back.cfc_matched_ticket_count > 0 THEN match_back.exctgt_ads_subscriber_id
                          ELSE NULL::integer
                          END), 0::bigint)          AS cfc_matched_purchasers,
       match_back.exctgt_email_sent_day_id,
       match_back.exctgt_sendjob_id,
       seg.exctgt_segment_name
FROM ads_main.f_exctgt_matchback match_back
         JOIN ads_main.d_exctgt_sendjobs sj ON match_back.exctgt_sendjob_id = sj.exctgt_sendjob_id
         LEFT JOIN ads_main.d_date dt ON match_back.exctgt_email_sent_day_id = dt.day_id
         LEFT JOIN ads_main.d_event_plan ep ON match_back.event_plan_id = ep.event_plan_id
         LEFT JOIN ads_main.d_ticket_type_desc tt ON match_back.ticket_type_desc_id = tt.ticket_type_desc_id
         LEFT JOIN ads_main.d_exctgt_segment seg ON match_back.exctgt_seg_id = seg.exctgt_seg_id
GROUP BY dt.day_name, dt.fiscal_month, dt.fiscal_quarter, dt.fiscal_year, dt.fiscal_year_month, dt.fiscal_year_quarter,
         dt.full_date, dt.week_end_date, dt.week_id, dt.year_month, ep.event_business_unit, ep.inet_event_id,
         ep.report_event_flag, ep.tm_arena_name, ep.tm_event_date, ep.tm_event_name, ep.tm_event_name_long,
         ep.tm_event_time, ep.tm_season_name, ep.tm_season_year, sj.brand, sj.email_category, sj.exctgt_email_name,
         sj.exctgt_additional, sj.exctgt_from_name, sj.exctgt_job_status, sj.exctgt_sched_time, sj.exctgt_send_id,
         sj.exctgt_subject, sj.exctgt_from_email, sj.test_job_flag, match_back.exctgt_email_sent_day_id,
         match_back.exctgt_sendjob_id, seg.exctgt_segment_name;

alter table vw_t_exctgt_matchback
    owner to ads_main;

