create or replace view ads_staging.mpd_scorecard_job_codes
as
select *
from ext_staging.mpd_scorecard_job_codes
with no schema binding;

alter table mpd_scorecard_job_codes
    owner to ads_staging;

