create view t_et_job_kpis_summary
            (exctgt_email_send_day_id, exctgt_segment_name, exctgt_seg_id, tm_event_name, tm_event_name_long,
             tm_event_date, tm_event_time, exctgt_email_event_name, brand, email_category, exctgt_email_name,
             exctgt_from_email, exctgt_from_name, exctgt_is_multipart, exctgt_job_status, exctgt_preview_url,
             exctgt_sched_time, exctgt_send_definition_external_key, exctgt_send_id, exctgt_sendjob_id, exctgt_subject,
             exctgt_triggered_send_external_key, full_date, full_date_desc, calendar_quarter, calendar_year_quarter,
             week_end_date, week_id, istest, et_email_sent_count, et_email_delivered_count, et_email_bounce_count,
             et_email_unsub_count, et_email_click_count, et_email_distinct_click_count, et_email_distinct_url_count,
             et_email_open_count, et_email_distinct_open_count, et_email_tablet_device_opens,
             et_email_mobile_device_opens, et_email_pc_mac_device_opens, et_email_other_device_opens,
             et_brand_matched_ticket_purchasers, et_brand_matched_ticket_count, et_brand_matched_ticket_revenue,
             et_all_matched_ticket_purchasers, et_cfc_matched_ticket_purchasers)
as
SELECT a.exctgt_email_send_day_id,
       COALESCE(e.exctgt_segment_name, ''::character varying)                 AS exctgt_segment_name,
       COALESCE(e.exctgt_seg_id, -1)                                          AS exctgt_seg_id,
       COALESCE(f.tm_event_name, 'N/A'::character varying)                    AS tm_event_name,
       COALESCE(f.tm_event_name_long, 'N/A'::character varying)               AS tm_event_name_long,
       COALESCE(f.tm_event_date::character varying, 'N/A'::character varying) AS tm_event_date,
       COALESCE(f.tm_event_time, 'N/A'::character varying)                    AS tm_event_time,
       CASE
           WHEN b.email_category::text = 'Preshow'::character varying::text THEN (
                   (b.exctgt_email_name::text || ' - '::character varying::text) ||
                   f.tm_event_name_long::text)::character varying
           ELSE b.exctgt_email_name
           END                                                                AS exctgt_email_event_name,
       b.brand,
       b.email_category,
       b.exctgt_email_name,
       b.exctgt_from_email,
       b.exctgt_from_name,
       b.exctgt_is_multipart,
       b.exctgt_job_status,
       b.exctgt_preview_url,
       b.exctgt_sched_time,
       b.exctgt_send_definition_external_key,
       b.exctgt_send_id,
       b.exctgt_sendjob_id,
       b.exctgt_subject,
       b.exctgt_triggered_send_external_key,
       c.full_date,
       c.full_date_desc,
       c.calendar_quarter,
       c.calendar_year_quarter,
       c.week_end_date,
       c.week_id,
       CASE
           WHEN upper(b.exctgt_email_name::text) ~~ '%TESTING%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '% TEST%'::character varying::text OR
                upper(b.exctgt_subject::text) ~~ '% TEST%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%TESTING%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%ZTEST%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%\\_TEST%'::character varying::text OR
                upper(b.exctgt_subject::text) ~~ '%\\_TEST%'::character varying::text OR
                upper(b.exctgt_subject::text) ~~ '%TESTING%'::character varying::text OR
                upper(b.exctgt_subject::text) ~~ '%TBD%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%TBD%'::character varying::text OR
                upper(b.exctgt_subject::text) ~~ '%\\_DW\\_%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%\\_DW\\_%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%\\_REPORTING%'::character varying::text OR
                upper(b.exctgt_email_name::text) ~~ '%DW\\_VERIFY%'::character varying::text OR
                "substring"(upper(b.exctgt_email_name::text), 1, 4) = 'TEST'::character varying::text OR
                "substring"(upper(b.exctgt_subject::text), 1, 4) = 'TEST'::character varying::text
               THEN 'True'::character varying
           ELSE 'False'::character varying
           END                                                                AS istest,
       sum(a.et_email_sent_count)                                             AS et_email_sent_count,
       sum(a.et_email_delivered_count)                                        AS et_email_delivered_count,
       sum(a.et_email_bounce_count)                                           AS et_email_bounce_count,
       sum(a.et_email_unsub_count)                                            AS et_email_unsub_count,
       sum(a.et_email_click_count)                                            AS et_email_click_count,
       sum(a.et_email_distinct_click_count)                                   AS et_email_distinct_click_count,
       sum(a.et_email_distinct_url_count)                                     AS et_email_distinct_url_count,
       sum(a.et_email_open_count)                                             AS et_email_open_count,
       sum(a.et_email_distinct_open_count)                                    AS et_email_distinct_open_count,
       sum(a.et_email_tablet_device_opens)                                    AS et_email_tablet_device_opens,
       sum(a.et_email_mobile_device_opens)                                    AS et_email_mobile_device_opens,
       sum(a.et_email_pc_mac_device_opens)                                    AS et_email_pc_mac_device_opens,
       sum(a.et_email_other_device_opens)                                     AS et_email_other_device_opens,
       sum(a.et_brand_matched_ticket_purchasers)                              AS et_brand_matched_ticket_purchasers,
       sum(a.et_brand_matched_ticket_count)                                   AS et_brand_matched_ticket_count,
       sum(a.et_brand_matched_ticket_revenue)                                 AS et_brand_matched_ticket_revenue,
       sum(a.et_all_matched_ticket_purchasers)                                AS et_all_matched_ticket_purchasers,
       sum(a.et_cfc_matched_ticket_purchasers)                                AS et_cfc_matched_ticket_purchasers
FROM ads_main.f_exctgt_job_kpis_summary a
         JOIN ads_main.d_exctgt_sendjobs b ON a.exctgt_sendjob_id = b.exctgt_sendjob_id
         JOIN ads_main.d_date c ON a.et_as_of_day_id = c.day_id
         LEFT JOIN ads_main.d_exctgt_segment e ON a.exctgt_seg_id = e.exctgt_seg_id
         LEFT JOIN ads_main.d_event_plan f ON a.exctgt_event_plan_id = f.event_plan_id
         LEFT JOIN ads_staging.dummy_counter d ON d.counter = regexp_count(
        "replace"(b.exctgt_email_name::text, '_'::character varying::text, ' '::character varying::text),
        ' '::character varying::text)
GROUP BY a.exctgt_email_send_day_id, e.exctgt_segment_name, e.exctgt_seg_id, f.tm_event_name, f.tm_event_name_long,
         f.tm_event_date, f.tm_event_time,
         CASE
             WHEN b.email_category::text = 'Preshow'::character varying::text THEN (
                     (b.exctgt_email_name::text || ' - '::character varying::text) ||
                     f.tm_event_name_long::text)::character varying
             ELSE b.exctgt_email_name
             END, b.brand, b.email_category, b.exctgt_additional, b.exctgt_email_name, b.exctgt_from_email,
         b.exctgt_from_name, b.exctgt_is_multipart, b.exctgt_job_status, b.exctgt_preview_url, b.exctgt_sched_time,
         b.exctgt_send_definition_external_key, b.exctgt_send_id, b.exctgt_sendjob_id, b.exctgt_subject,
         b.exctgt_triggered_send_external_key, c.full_date, c.full_date_desc, c.calendar_quarter,
         c.calendar_year_quarter, c.week_end_date, c.week_id,
         CASE
             WHEN upper(b.exctgt_email_name::text) ~~ '%TESTING%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '% TEST%'::character varying::text OR
                  upper(b.exctgt_subject::text) ~~ '% TEST%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%TESTING%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%ZTEST%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%\\_TEST%'::character varying::text OR
                  upper(b.exctgt_subject::text) ~~ '%\\_TEST%'::character varying::text OR
                  upper(b.exctgt_subject::text) ~~ '%TESTING%'::character varying::text OR
                  upper(b.exctgt_subject::text) ~~ '%TBD%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%TBD%'::character varying::text OR
                  upper(b.exctgt_subject::text) ~~ '%\\_DW\\_%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%\\_DW\\_%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%\\_REPORTING%'::character varying::text OR
                  upper(b.exctgt_email_name::text) ~~ '%DW\\_VERIFY%'::character varying::text OR
                  "substring"(upper(b.exctgt_email_name::text), 1, 4) = 'TEST'::character varying::text OR
                  "substring"(upper(b.exctgt_subject::text), 1, 4) = 'TEST'::character varying::text
                 THEN 'True'::character varying
             ELSE 'False'::character varying
             END;

alter table t_et_job_kpis_summary
    owner to ads_main;

