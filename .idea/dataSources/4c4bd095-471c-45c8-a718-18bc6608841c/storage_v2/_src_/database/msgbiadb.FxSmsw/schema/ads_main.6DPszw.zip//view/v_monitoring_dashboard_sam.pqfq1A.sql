CREATE OR REPLACE VIEW ads_main.v_monitoring_dashboard_sam AS


SELECT a.table_name,
       a.check_type,
       a.ads_source,
       a.venue_id,
       a.severity,
       a.hide_display_flag,
       a.reason_for_hiding,
       count AS count
FROM (
         /********************************************************************************************************************************************************/
         /********************************************************************************************************************************************************/
         --d_product

         SELECT 'd_product' :: character varying           AS table_name,
                'Null Product Dim Id' :: character varying AS check_type,
                'N/A' :: character varying                 AS venue_id,
                d_product.ads_source,
                count(1)
                                                           AS count,
                'Critical' :: character varying            AS severity,
                'No' :: character varying                  AS hide_display_flag,
                '' :: character varying                    AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.product_dim_id IS NULL
         GROUP BY d_product.venue_id, d_product.ads_source
         UNION ALL
         SELECT 'd_product' :: character varying                          AS table_name,
                'Null Appetize Venue and Product Id' :: character varying AS check_type,
                'N/A' :: character varying                                AS venue_id,
                d_product.ads_source,
                count(1)
                                                                          AS count,
                'Critical' :: character varying                           AS severity,
                'No' :: character varying                                 AS hide_display_flag,
                '' :: character varying                                   AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source = 'APPETIZE' :: character varying
           AND (d_product.venue_id IS NULL OR d_product.appetize_product_id IS NULL)
         GROUP BY d_product.venue_id, d_product.ads_source
         UNION ALL
         SELECT 'd_product' :: character varying             AS table_name,
                'Null Eatec Product Id' :: character varying AS check_type,
                d_product.venue_id :: character varying      AS venue_id,
                d_product.ads_source,
                count(1)
                                                             AS count,
                'Minor' :: character varying                 AS severity,
                'No' :: character varying                    AS hide_display_flag,
                '' :: character varying                      AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           AND d_product.eatec_product_id IS NULL
         GROUP BY d_product.ads_source, d_product.venue_id
         HAVING count(1) > 0
         UNION ALL
         SELECT 'd_product' :: character varying                 AS table_name,
                'Null Eatec Product Number' :: character varying AS check_type,
                d_product.venue_id :: character varying          AS venue_id,
                d_product.ads_source,
                count(1)
                                                                 AS count,
                'Major' :: character varying                     AS severity,
                'No' :: character varying                        AS hide_display_flag,
                '' :: character varying                          AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           AND d_product.product_number IS NULL
         GROUP BY d_product.ads_source, d_product.venue_id
         HAVING count(1) > 0
         UNION ALL
         SELECT 'd_product' :: character varying                AS table_name,
                'Duplicate Product Dim Id' :: character varying AS check_type,
                'N/A' :: character varying                      AS venue_id,
                'N/A' :: character varying                      AS ads_source,
                count(1)
                                                                AS count,
                'Critical' :: character varying                 AS severity,
                'No' :: character varying                       AS hide_display_flag,
                '' :: character varying                         AS reason_for_hiding
         FROM ads_main.d_product
         GROUP BY d_product.product_dim_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_product' :: character varying                               AS table_name,
                'Duplicate Appetize Venue and Product Id' :: character varying AS check_type,
                d_product.venue_id :: character varying                        AS venue_id,
                d_product.ads_source,
                count(1)
                                                                               AS count,
                'Critical' :: character varying                                AS severity,
                'No' :: character varying                                      AS hide_display_flag,
                '' :: character varying                                        AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source = 'APPETIZE' :: character varying
           AND d_product.ads_active_flag = 'Y' :: character varying
         GROUP BY d_product.ads_source, d_product.venue_id, d_product.appetize_product_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_product' :: character varying                AS table_name,
                'Duplicate Product Number' :: character varying AS check_type,
                d_product.venue_id :: character varying         AS venue_id,
                d_product.ads_source,
                count(1)
                                                                AS count,
                'Critical' :: character varying                 AS severity,
                'No' :: character varying                       AS hide_display_flag,
                '' :: character varying                         AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source <> 'APPETIZE' :: character varying
           AND d_product.ads_active_flag = 'Y' :: character varying
         GROUP BY d_product.ads_source, d_product.venue_id, d_product.product_number
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown Product Segment':: character varying       AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Critical' :: character varying                     AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(segment, 'Unknown') = 'Unknown'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Product Class':: character varying     AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Normal' :: character varying                       AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_product_class, 'Unknown') = 'Unknown'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Product Subclass':: character varying  AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Normal' :: character varying                       AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_product_subclass, 'Unknown') = 'Unknown'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Business':: character varying          AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Critical' :: character varying                     AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_business, 'Unknown') = 'Unknown'
           and segment = 'Merchandise'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')

         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Product Category':: character varying  AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Normal' :: character varying                       AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_category, 'Unknown') = 'Unknown'

         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                      AS table_name,
                'Unknown FMB Product Subcategory':: character varying AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A')   AS venue_id,
                d_product.ads_source,
                count(1)
                                                                      AS count,
                'Normal' :: character varying                         AS severity,
                'No' :: character varying                             AS hide_display_flag,
                '' :: character varying                               AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_subcategory, 'Unknown') = 'Unknown'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Size':: character varying              AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Minor' :: character varying                        AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_size, 'Unknown') = 'Unknown'
           and segment = 'Merchandise'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Player':: character varying            AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Minor' :: character varying                        AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_player, 'Unknown') = 'Unknown'
           and segment = 'Merchandise'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')
         UNION ALL
         SELECT 'd_product' :: character varying                    AS table_name,
                'Unknown FMB Vendor':: character varying            AS check_type,
                nvl(d_product.venue_id :: character varying, 'N/A') AS venue_id,
                d_product.ads_source,
                count(1)
                                                                    AS count,
                'Minor' :: character varying                        AS severity,
                'No' :: character varying                           AS hide_display_flag,
                '' :: character varying                             AS reason_for_hiding
         FROM ads_main.d_product
         WHERE d_product.ads_source IS NOT NULL
           and nvl(fmb_vendor, 'Unknown') = 'Unknown'
           and segment = 'Merchandise'
         group by ads_source, nvl(d_product.venue_id :: character varying, 'N/A')

             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                  --d_location


         UNION ALL
         SELECT 'd_location' :: character varying           AS table_name,
                'Null Location Dim Id' :: character varying AS check_type,
                'N/A' :: character varying                  AS venue_id,
                d_location.ads_source,
                count(1)
                                                            AS count,
                'Critical' :: character varying             AS severity,
                'No' :: character varying                   AS hide_display_flag,
                '' :: character varying                     AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.location_dim_id IS NULL
         GROUP BY d_location.venue_id, d_location.ads_source
         UNION ALL
         SELECT 'd_location' :: character varying                        AS table_name,
                'Null Appetize Venue and Vendor Id' :: character varying AS check_type,
                d_location.venue_id :: character varying                 AS venue_id,
                d_location.ads_source,
                count(1)
                                                                         AS count,
                'Critical' :: character varying                          AS severity,
                'No' :: character varying                                AS hide_display_flag,
                '' :: character varying                                  AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source = 'APPETIZE' :: character varying
           AND (d_location.venue_id IS NULL OR d_location.vendor_id IS NULL)
         GROUP BY d_location.venue_id, d_location.ads_source
         UNION ALL
         SELECT 'd_location' :: character varying        AS table_name,
                'Null Location Id' :: character varying  AS check_type,
                d_location.venue_id :: character varying AS venue_id,
                d_location.ads_source,
                count(1)
                                                         AS count,
                'Critical' :: character varying          AS severity,
                case
                    when d_location.ads_source = 'DELPHI'
                        then 'Yes'
                    when venue_id in (799, 800)
                        then 'Yes'
                    when venue_id = 801 and vendor_id = 15369
                        then 'Yes'
                    when venue_id = 798 and vendor_id in (17586,
                                                          18110,
                                                          20268,
                                                          20274,
                                                          20277,
                                                          20340,
                                                          20342)
                        then 'Yes'
                    else 'No' end :: character varying   AS hide_display_flag,
                case
                    when d_location.ads_source = 'DELPHI'
                        then 'DELPHI doesn''t use location ids'
                    when venue_id in (799, 800)
                        then 'Venue doesn''t use location id'
                    when venue_id = 801 and vendor_id = 15369
                        then 'Default vendor'
                    when venue_id = 798 and vendor_id in (17586,
                                                          18110,
                                                          20268,
                                                          20274,
                                                          20277,
                                                          20340,
                                                          20342)
                        then 'Locations don''t sell'
                    else '' end :: character varying     AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source IS NOT NULL
           AND d_location.location_id IS NULL
         GROUP BY d_location.ads_source, d_location.venue_id,
                  case
                      when d_location.ads_source = 'DELPHI'
                          then 'Yes'
                      when venue_id in (799, 800)
                          then 'Yes'
                      when venue_id = 801 and vendor_id = 15369
                          then 'Yes'
                      when venue_id = 798 and vendor_id in (17586,
                                                            18110,
                                                            20268,
                                                            20274,
                                                            20277,
                                                            20340,
                                                            20342)
                          then 'Yes'
                      else 'No' end :: character varying,
                  case
                      when d_location.ads_source = 'DELPHI'
                          then 'DELPHI doesn''t use location ids'
                      when venue_id in (799, 800)
                          then 'Venue doesn''t use location id'
                      when venue_id = 801 and vendor_id = 15369
                          then 'Default vendor'
                      when venue_id = 798 and vendor_id in (17586,
                                                            18110,
                                                            20268,
                                                            20274,
                                                            20277,
                                                            20340,
                                                            20342)
                          then 'Locations don''t sell'
                      else '' end :: character varying
         HAVING count(1) > 0
         UNION ALL
         SELECT 'd_location' :: character varying        AS table_name,
                'Null Acprefix' :: character varying     AS check_type,
                d_location.venue_id :: character varying AS venue_id,
                d_location.ads_source,
                count(1)
                                                         AS count,
                CASE
                    WHEN d_location.venue_id = 798
                        THEN 'Critical' :: character varying
                    ELSE 'Minor' :: character varying
                    END                                  AS severity,
                CASE
                    WHEN d_location.location_id IS NULL
                        THEN 'Yes' :: character varying
                    ELSE 'No' :: character varying
                    END                                  AS hide_display_flag,
                '' :: character varying                  AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source IS NOT NULL
           AND d_location.acprefix IS NULL
         GROUP BY d_location.ads_source, d_location.venue_id,
                  CASE
                      WHEN d_location.location_id IS NULL
                          THEN 'Yes' :: character varying
                      ELSE 'No' :: character varying
                      END
         HAVING count(1) > 0
         UNION ALL
         SELECT 'd_location' :: character varying          AS table_name,
                'Blank or null Venue' :: character varying AS check_type,
                d_location.venue_id :: character varying   AS venue_id,
                d_location.ads_source,
                count(
                        DISTINCT d_location.location_name)
                                                           AS count,
                'Critical' :: character varying            AS severity,
                CASE
                    WHEN d_location.location_id IS NULL
                        THEN 'Yes' :: character varying
                    ELSE 'No' :: character varying
                    END                                    AS hide_display_flag,
                '' :: character varying                    AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source IS NOT NULL
           AND COALESCE(d_location.venue, '' :: character varying) = '' :: character varying
         GROUP BY d_location.ads_source, d_location.venue_id,
                  CASE
                      WHEN d_location.location_id IS NULL
                          THEN 'Yes' :: character varying
                      ELSE 'No' :: character varying
                      END
         HAVING count(1) > 0
         UNION ALL
         SELECT 'd_location' :: character varying                AS table_name,
                'Duplicate Location Dim Id' :: character varying AS check_type,
                'N/A' :: character varying                       AS venue_id,
                'N/A' :: character varying                       AS ads_source,
                count(1)
                                                                 AS count,
                'Critical' :: character varying                  AS severity,
                'No' :: character varying                        AS hide_display_flag,
                '' :: character varying                          AS reason_for_hiding
         FROM ads_main.d_location
         GROUP BY d_location.location_dim_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_location' :: character varying                             AS table_name,
                'Duplicate Appetize Venue and Vendor Id' :: character varying AS check_type,
                d_location.venue_id :: character varying                      AS venue_id,
                d_location.ads_source,
                count(1)
                                                                              AS count,
                'Critical' :: character varying                               AS severity,
                'No' :: character varying                                     AS hide_display_flag,
                '' :: character varying                                       AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source = 'APPETIZE' :: character varying
         GROUP BY d_location.ads_source, d_location.venue_id, d_location.vendor_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_location' :: character varying            AS table_name,
                'Duplicate Location Id' :: character varying AS check_type,
                d_location.venue_id :: character varying     AS venue_id,
                d_location.ads_source,
                count(1)
                                                             AS count,
                'Critical' :: character varying              AS severity,
                'No' :: character varying                    AS hide_display_flag,
                '' :: character varying                      AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source <> 'APPETIZE' :: character varying
         GROUP BY d_location.ads_source, d_location.venue_id, d_location.location_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'd_location' :: character varying        AS table_name,
                'Unknown Venue':: character varying      AS check_type,
                d_location.venue_id :: character varying AS venue_id,
                d_location.ads_source,
                count(1)
                                                         AS count,
                'Critical' :: character varying          AS severity,
                'No' :: character varying                AS hide_display_flag,
                '' :: character varying                  AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source IS NOT NULL
           and nvl(venue, 'Unknown') = 'Unknown'
         group by ads_source, venue_id
         UNION ALL
         SELECT 'd_location' :: character varying        AS table_name,
                'Unknown Segment':: character varying    AS check_type,
                d_location.venue_id :: character varying AS venue_id,
                d_location.ads_source,
                count(1)
                                                         AS count,
                'Critical' :: character varying          AS severity,
                'No' :: character varying                AS hide_display_flag,
                '' :: character varying                  AS reason_for_hiding
         FROM ads_main.d_location
         WHERE d_location.ads_source IS NOT NULL
           and nvl(segment, 'Unknown') = 'Unknown'
         group by ads_source, venue_id
             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                  --d_event_plan

         UNION ALL
         SELECT 'd_event_plan' :: character varying       AS table_name,
                'Null Event Plan Id' :: character varying AS check_type,
                'N/A' :: character varying                AS venue_id,
                d_event_plan.ads_source,
                count(1)
                                                          AS count,
                'Critical' :: character varying           AS severity,
                'No' :: character varying                 AS hide_display_flag,
                '' :: character varying                   AS reason_for_hiding
         FROM ads_main.d_event_plan
         WHERE d_event_plan.event_plan_id IS NULL
         GROUP BY 3, d_event_plan.ads_source
         UNION ALL
         SELECT 'd_event_plan' :: character varying    AS table_name,
                'Null Event Name' :: character varying AS check_type,
                'N/A' :: character varying             AS venue_id,
                d_event_plan.ads_source,
                count(1)
                                                       AS count,
                'Minor' :: character varying           AS severity,
                'No' :: character varying              AS hide_display_flag,
                '' :: character varying                AS reason_for_hiding
         FROM ads_main.d_event_plan
         WHERE d_event_plan.ads_source IS NOT NULL
           AND d_event_plan.tm_event_name IS NULL
         GROUP BY d_event_plan.ads_source, 3
         HAVING count(1) > 0

         UNION ALL
         SELECT 'd_event_plan' :: character varying                                         AS table_name,
                'Deleted Event with reference in f_fmb_sales_hdr_dtls' :: character varying AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying)       AS venue_id,
                f.ads_source,
                count(distinct transaction_data_id)                                         AS count,
                'Critical' :: character varying                                             AS severity,
                'No' :: character varying                                                   AS hide_display_flag,
                '' :: character varying                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls f
         WHERE COALESCE(f.event_plan_id, -1) <> -1
           --AND f.tendered_date_id >= 20141231
           AND NOT EXISTS(select 1 from ads_main.d_event_plan e where f.event_plan_id = e.event_plan_id)
         GROUP BY f.ads_source, f.venue_id


         UNION ALL
         SELECT 'd_event_plan' :: character varying                                             AS table_name,
                'Deleted Event with reference in f_fmb_sales_product_dtls' :: character varying AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying)           AS venue_id,
                f.ads_source,
                count(distinct transaction_data_id)                                             AS count,
                'Critical' :: character varying                                                 AS severity,
                'No' :: character varying                                                       AS hide_display_flag,
                '' :: character varying                                                         AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls f
         WHERE COALESCE(f.event_plan_id, -1) <> -1
           --AND f.tendered_date_id >= 20141231
           AND NOT EXISTS(select 1 from ads_main.d_event_plan e where f.event_plan_id = e.event_plan_id)
         GROUP BY f.ads_source, f.venue_id

         UNION ALL
         SELECT 'd_event_plan' :: character varying                                            AS table_name,
                'Deleted Event with reference in f_fmb_sales_tender_dtls' :: character varying AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying)          AS venue_id,
                f.ads_source,
                count(distinct transaction_data_id)                                            AS count,
                'Critical' :: character varying                                                AS severity,
                'No' :: character varying                                                      AS hide_display_flag,
                '' :: character varying                                                        AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls f
         WHERE COALESCE(f.event_plan_id, -1) <> -1
           --AND f.tendered_date_id >= 20141231
           AND NOT EXISTS(select 1 from ads_main.d_event_plan e where f.event_plan_id = e.event_plan_id)
         GROUP BY f.ads_source, f.venue_id

             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                  --f_fmb_sales_hdr_dtls

         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                           AS table_name,
                'Unavailable Event' :: character varying                              AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f.ads_source,
                count(1)
                                                                                      AS count,
                'Critical' :: character varying                                       AS severity,
                'No' :: character varying                                             AS hide_display_flag,
                case
                    when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                    when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                    else '' :: character varying end                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls f
         WHERE COALESCE(f.event_plan_id, -1) = -1
           AND f.tendered_date_id >= 20141231
           AND NOT (f.location_dim_id
             IN (
                        SELECT l.location_dim_id
                        FROM ads_main.d_location l
                        WHERE l.location_id = 619
                           OR l.location_id = 1010
                           OR l.location_id = 1011))
         GROUP BY f.ads_source, f.venue_id,
                  case
                      when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                      when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                      else '' :: character varying end
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Location' :: character varying                                              AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.location_dim_id, -1) = -1
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Tendered Date' :: character varying                                         AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.tendered_date_id, -1) = -1
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Appetize Server Completion Date' :: character varying                       AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.appetize_server_completion_date_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Open Terminal Date' :: character varying                                    AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.opened_terminal_date_id, -1) = -1
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Customer' :: character varying                                              AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'Yes' :: character varying                                                               AS hide_display_flag,
                case f_fmb_sales_hdr_dtls.ads_source
                    WHEN 'EATEC' :: character varying then 'Not Applicable' :: character varying
                    WHEN 'IG' :: character varying
                        then 'Names are available only credit cared customers' :: character varying
                    WHEN 'APPETIZE' :: character varying
                        then 'Names are available only credit cared customers' :: character varying
                    else '' :: character varying
                    end                                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.customer_account_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
           AND f_fmb_sales_hdr_dtls.ads_source <> 'EATEC' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Void Reason' :: character varying                                           AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.void_reason_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
           AND f_fmb_sales_hdr_dtls.ads_source <> 'EATEC' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable FMB Misc dimension' :: character varying                                    AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.fmb_misc_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Server Employee' :: character varying                                       AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.server_emp_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Cashier Employee' :: character varying                                      AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.cashier_emp_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Authorizing Emploee' :: character varying                                   AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.authorizing_emp_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
           AND f_fmb_sales_hdr_dtls.ads_source <> 'EATEC' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Open Terminal' :: character varying                                         AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.opened_terminal_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
           AND f_fmb_sales_hdr_dtls.ads_source <> 'EATEC' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying                                              AS table_name,
                'Unavailable Tendered Terminal' :: character varying                                     AS check_type,
                COALESCE(f_fmb_sales_hdr_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_hdr_dtls.ads_source,
                count(1)
                                                                                                         AS count,
                'Minor' :: character varying                                                             AS severity,
                'No' :: character varying                                                                AS hide_display_flag,
                '' :: character varying                                                                  AS reason_for_hiding
         FROM ads_main.f_fmb_sales_hdr_dtls
         WHERE COALESCE(f_fmb_sales_hdr_dtls.tendered_terminal_dim_id, -1) = -1
           AND f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
           AND f_fmb_sales_hdr_dtls.ads_source <> 'EATEC' :: character varying
         GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id
             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                  --f_fmb_sales_product_dtls
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Product' :: character varying                                                   AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.product_dim_id, -1) = -1
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Appetize Product' :: character varying                                          AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE (COALESCE(f_fmb_sales_product_dtls.appetize_product_id, -1) = -1
             OR COALESCE(f_fmb_sales_product_dtls.venue_id, -1) = -1)
           AND f_fmb_sales_product_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Transaction Type' :: character varying                                          AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE (COALESCE(f_fmb_sales_product_dtls.transaction_type_fmb_misc_dim_id, -1) = -1
             OR COALESCE(f_fmb_sales_product_dtls.venue_id, -1) = -1)
           AND f_fmb_sales_product_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                       AS table_name,
                'Unavailable Event' :: character varying                              AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f.ads_source,
                count(1)
                                                                                      AS count,
                'Critical' :: character varying                                       AS severity,
                'No' :: character varying                                             AS hide_display_flag,
                case
                    when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                    when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                    else '' :: character varying end :: character varying             AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls f
         WHERE COALESCE(f.event_plan_id, -1) = -1
           AND f.tendered_date_id >= 20141231
           AND NOT (f.location_dim_id
             IN (
                        SELECT l.location_dim_id
                        FROM ads_main.d_location l
                        WHERE l.location_id = 619
                           OR l.location_id = 1010
                           OR l.location_id = 1011))
         GROUP BY f.ads_source, f.venue_id,
                  case
                      when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                      when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                      else '' :: character varying end
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Location' :: character varying                                                  AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.location_dim_id, -1) = -1
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Tendered Date' :: character varying                                             AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.tendered_date_id, -1) = -1
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Void Reason' :: character varying                                               AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.void_reason_dim_id, -1) = -1
           AND f_fmb_sales_product_dtls.ads_source <> 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable FMB Order Level Misc dimension' :: character varying                            AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.order_fmb_misc_dim_id, -1) = -1
           AND f_fmb_sales_product_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable FMB Misc dimension' :: character varying                                        AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.fmb_misc_dim_id, -1) = -1
           AND f_fmb_sales_product_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                                              AS table_name,
                'Unavailable Employee' :: character varying                                                  AS check_type,
                COALESCE(f_fmb_sales_product_dtls.venue_id :: character varying,
                         'N/A' :: character varying)                                                         AS venue_id,
                f_fmb_sales_product_dtls.ads_source,
                count(1)
                                                                                                             AS count,
                'Minor' :: character varying                                                                 AS severity,
                'No' :: character varying                                                                    AS hide_display_flag,
                '' :: character varying                                                                      AS reason_for_hiding
         FROM ads_main.f_fmb_sales_product_dtls
         WHERE COALESCE(f_fmb_sales_product_dtls.emp_dim_id, -1) = -1
           AND f_fmb_sales_product_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable Product' :: character varying                                                  AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE COALESCE(f_fmb_sales_tender_dtls.product_dim_id, -1) = -1
           AND f_fmb_sales_tender_dtls.ads_source = 'APPETIZE' :: character varying
           AND (f_fmb_sales_tender_dtls.transaction_type_fmb_misc_dim_id
             IN (
                    SELECT DISTINCT d_fmb_misc.fmb_misc_dim_id
                    FROM ads_main.d_fmb_misc
                    WHERE d_fmb_misc.fact_type = 'Appetize Order Transaction' :: character varying
                      AND d_fmb_misc.transaction_type = 'Refund' :: character varying))
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable Appetize Product' :: character varying                                         AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE (COALESCE(f_fmb_sales_tender_dtls.appetize_product_id, -1) = -1
             OR COALESCE(f_fmb_sales_tender_dtls.venue_id, -1) = -1)
           AND f_fmb_sales_tender_dtls.ads_source = 'APPETIZE' :: character varying
           AND (f_fmb_sales_tender_dtls.transaction_type_fmb_misc_dim_id
             IN (
                    SELECT DISTINCT d_fmb_misc.fmb_misc_dim_id
                    FROM ads_main.d_fmb_misc
                    WHERE d_fmb_misc.fact_type = 'Appetize Order Transaction' :: character varying
                      AND d_fmb_misc.transaction_type = 'Refund' :: character varying))
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable Transaction Type' :: character varying                                         AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE (COALESCE(f_fmb_sales_tender_dtls.transaction_type_fmb_misc_dim_id, -1) = -1
             OR COALESCE(f_fmb_sales_tender_dtls.venue_id, -1) = -1)
           AND f_fmb_sales_tender_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                        AS table_name,
                'Unavailable Event' :: character varying                              AS check_type,
                COALESCE(f.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f.ads_source,
                count(1)
                                                                                      AS count,
                'Critical' :: character varying                                       AS severity,
                'No' :: character varying                                             AS hide_display_flag,
                case
                    when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                    when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                    else '' :: character varying end :: character varying             AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls f
         WHERE COALESCE(f.event_plan_id, -1) = -1
           AND f.tendered_date_id >= 20141231
           AND NOT (f.location_dim_id
             IN (
                        SELECT l.location_dim_id
                        FROM ads_main.d_location l
                        WHERE l.location_id = 619
                           OR l.location_id = 1010
                           OR l.location_id = 1011))
         GROUP BY f.ads_source, f.venue_id,
                  case
                      when f.venue_id = 798 and tendered_date_id = 20171007 then 'NY Comic Con'
                      when f.venue_id = 798 and tendered_date_id = 20180128 then 'Grammy''s'
                      else '' :: character varying end
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable Location' :: character varying                                                 AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE COALESCE(f_fmb_sales_tender_dtls.location_dim_id, -1) = -1
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable Tendered Date' :: character varying                                            AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE COALESCE(f_fmb_sales_tender_dtls.tendered_date_id, -1) = -1
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
             /*UNION ALL
             SELECT
               'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
               'Unavailable Void Reason' :: character varying                                              AS check_type,
               COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
               f_fmb_sales_tender_dtls.ads_source,
               count(1)
                                                                                                           AS count,
               'Minor' :: character varying                                                                AS severity,
               'No' :: character varying                                                                   AS hide_display_flag,
               '' :: character varying                                                                     AS reason_for_hiding
             FROM ads_main.f_fmb_sales_tender_dtls
             WHERE COALESCE(f_fmb_sales_tender_dtls.void_reason_dim_id, -1) = -1
                   AND f_fmb_sales_tender_dtls.ads_source <> 'APPETIZE' :: character varying
             GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
             */
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable FMB Order Level Misc dimension' :: character varying                           AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE COALESCE(f_fmb_sales_tender_dtls.order_fmb_misc_dim_id, -1) = -1
           AND f_fmb_sales_tender_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying                                              AS table_name,
                'Unavailable FMB Misc dimension' :: character varying                                       AS check_type,
                COALESCE(f_fmb_sales_tender_dtls.venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                f_fmb_sales_tender_dtls.ads_source,
                count(1)
                                                                                                            AS count,
                'Minor' :: character varying                                                                AS severity,
                'No' :: character varying                                                                   AS hide_display_flag,
                '' :: character varying                                                                     AS reason_for_hiding
         FROM ads_main.f_fmb_sales_tender_dtls
         WHERE COALESCE(f_fmb_sales_tender_dtls.fmb_misc_dim_id, -1) = -1
           AND f_fmb_sales_tender_dtls.ads_source = 'APPETIZE' :: character varying
         GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.venue_id
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying  AS table_name,
                'Duplicate Primary Key' :: character varying AS check_type,
                'N/A' :: character varying                   AS venue_id,
                'N/A' :: character varying                   AS ads_source,
                count(1)
                                                             AS count,
                'Critical' :: character varying              AS severity,
                'No' :: character varying                    AS hide_display_flag,
                '' :: character varying                      AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_hdr_dtls.ads_fmb_sales_hdr_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_hdr_dtls
                  GROUP BY f_fmb_sales_hdr_dtls.ads_fmb_sales_hdr_id
                  HAVING count(1) > 1) derived_table1
         GROUP BY 4, 3
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying AS table_name,
                'Duplicate Primary Key' :: character varying    AS check_type,
                'N/A' :: character varying                      AS venue_id,
                'N/A' :: character varying                      AS ads_source,
                count(1)
                                                                AS count,
                'Critical' :: character varying                 AS severity,
                'No' :: character varying                       AS hide_display_flag,
                '' :: character varying                         AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_product_dtls.ads_fmb_sales_product_detail_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_product_dtls
                  GROUP BY f_fmb_sales_product_dtls.ads_fmb_sales_product_detail_id
                  HAVING count(1) > 1) derived_table2
         GROUP BY 4, 3
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying AS table_name,
                'Duplicate Primary Key' :: character varying   AS check_type,
                'N/A' :: character varying                     AS venue_id,
                'N/A' :: character varying                     AS ads_source,
                count(1)
                                                               AS count,
                'Critical' :: character varying                AS severity,
                'No' :: character varying                      AS hide_display_flag,
                '' :: character varying                        AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_tender_dtls.ads_fmb_tender_detail_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_tender_dtls
                  GROUP BY f_fmb_sales_tender_dtls.ads_fmb_tender_detail_id
                  HAVING count(1) > 1) derived_table3
         GROUP BY 4, 3
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying   AS table_name,
                'Duplicate Business Key' :: character varying AS check_type,
                derived_table4.venue_id :: character varying  AS venue_id,
                derived_table4.ads_source,
                count(
                        DISTINCT derived_table4.transaction_data_id)
                                                              AS count,
                'Critical' :: character varying               AS severity,
                'No' :: character varying                     AS hide_display_flag,
                '' :: character varying                       AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_hdr_dtls.ads_source,
                         f_fmb_sales_hdr_dtls.venue_id,
                         f_fmb_sales_hdr_dtls.transaction_data_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_hdr_dtls
                  WHERE f_fmb_sales_hdr_dtls.ads_source = 'APPETIZE' :: character varying
                  GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.venue_id,
                           f_fmb_sales_hdr_dtls.transaction_data_id
                  HAVING count(1) > 1) derived_table4
         GROUP BY derived_table4.ads_source, derived_table4.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_hdr_dtls' :: character varying   AS table_name,
                'Duplicate Business Key' :: character varying AS check_type,
                derived_table5.venue_id,
                derived_table5.ads_source,
                count(
                        DISTINCT derived_table5.transaction_data_id)
                                                              AS count,
                'Critical' :: character varying               AS severity,
                'No' :: character varying                     AS hide_display_flag,
                '' :: character varying                       AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_hdr_dtls.ads_source,
                         'N/A' :: character varying AS venue_id,
                         f_fmb_sales_hdr_dtls.transaction_data_id,
                         count(1)
                                                    AS count
                  FROM ads_main.f_fmb_sales_hdr_dtls
                  WHERE f_fmb_sales_hdr_dtls.ads_source <> 'APPETIZE' :: character varying
                  GROUP BY f_fmb_sales_hdr_dtls.ads_source, f_fmb_sales_hdr_dtls.transaction_data_id
                  HAVING count(1) > 1) derived_table5
         GROUP BY derived_table5.ads_source, derived_table5.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying AS table_name,
                'Duplicate Business Key' :: character varying   AS check_type,
                derived_table6.venue_id :: character varying    AS venue_id,
                derived_table6.ads_source,
                count(
                        DISTINCT derived_table6.transaction_data_id)
                                                                AS count,
                'Critical' :: character varying                 AS severity,
                'No' :: character varying                       AS hide_display_flag,
                '' :: character varying                         AS reason_for_hiding
         FROM (
                  SELECT factp.ads_source,
                         factp.venue_id,
                         factp.transaction_data_id,
                         factp.product_sequence_id,
                         factp.transaction_type_fmb_misc_dim_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_product_dtls factp
                  WHERE factp.ads_source = 'APPETIZE' :: character varying
                  GROUP BY factp.ads_source, factp.venue_id, factp.transaction_data_id, factp.product_sequence_id,
                           factp.transaction_type_fmb_misc_dim_id
                  HAVING count(1) > 1) derived_table6
         GROUP BY derived_table6.ads_source, derived_table6.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying                 AS table_name,
                'Duplicate Business Key-verify with yunus' :: character varying AS check_type,
                derived_table7.venue_id,
                derived_table7.ads_source,
                count(
                        DISTINCT derived_table7.transaction_data_id)
                                                                                AS count,
                'Critical' :: character varying                                 AS severity,
                'Yes' :: character varying                                      AS hide_display_flag,
                '' :: character varying                                         AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_product_dtls.ads_source,
                         'N/A' :: character varying AS venue_id,
                         f_fmb_sales_product_dtls.transaction_data_id,
                         f_fmb_sales_product_dtls.product_sequence_id,
                         count(1)
                                                    AS count
                  FROM ads_main.f_fmb_sales_product_dtls
                  WHERE f_fmb_sales_product_dtls.ads_source <> 'APPETIZE' :: character varying
                  GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.transaction_data_id,
                           f_fmb_sales_product_dtls.product_sequence_id
                  HAVING count(1) > 1) derived_table7
         GROUP BY derived_table7.ads_source, derived_table7.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_product_dtls' :: character varying AS table_name,
                'Duplicate Business Key' :: character varying   AS check_type,
                derived_table8.venue_id,
                derived_table8.ads_source,
                count(
                        DISTINCT derived_table8.transaction_data_id)
                                                                AS count,
                'Critical' :: character varying                 AS severity,
                'No' :: character varying                       AS hide_display_flag,
                '' :: character varying                         AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_product_dtls.ads_source,
                         'N/A' :: character varying AS venue_id,
                         f_fmb_sales_product_dtls.transaction_data_id,
                         f_fmb_sales_product_dtls.product_sequence_id,
                         f_fmb_sales_product_dtls.product_dim_id,
                         count(1)
                                                    AS count
                  FROM ads_main.f_fmb_sales_product_dtls
                  WHERE f_fmb_sales_product_dtls.ads_source <> 'APPETIZE' :: character varying
                  GROUP BY f_fmb_sales_product_dtls.ads_source, f_fmb_sales_product_dtls.transaction_data_id,
                           f_fmb_sales_product_dtls.product_sequence_id, f_fmb_sales_product_dtls.product_dim_id
                  HAVING count(1) > 1) derived_table8
         GROUP BY derived_table8.ads_source, derived_table8.venue_id
         HAVING count(1) > 1
             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                --f_fmb_sales_tender_dtls		 
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying          AS table_name,
                'Duplicate Business Key - Payment' :: character varying AS check_type,
                derived_table9.venue_id :: character varying            AS venue_id,
                derived_table9.ads_source,
                count(
                        DISTINCT derived_table9.transaction_data_id)
                                                                        AS count,
                'Critical' :: character varying                         AS severity,
                'No' :: character varying                               AS hide_display_flag,
                '' :: character varying                                 AS reason_for_hiding
         FROM (
                  SELECT factt.ads_source,
                         factt.venue_id,
                         factt.transaction_data_id,
                         factt.tender_sequence_id,
                         m.transaction_type,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_tender_dtls factt
                           JOIN ads_main.d_fmb_misc m ON factt.transaction_type_fmb_misc_dim_id = m.fmb_misc_dim_id
                  WHERE factt.ads_source = 'APPETIZE' :: character varying
                    AND m.transaction_type = 'Payment' :: character varying
                  GROUP BY factt.ads_source, factt.venue_id, factt.transaction_data_id, factt.tender_sequence_id,
                           m.transaction_type
                  HAVING count(1) > 1) derived_table9
         GROUP BY derived_table9.ads_source, derived_table9.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying         AS table_name,
                'Duplicate Business Key - Refund' :: character varying AS check_type,
                derived_table10.venue_id :: character varying          AS venue_id,
                derived_table10.ads_source,
                count(
                        DISTINCT derived_table10.transaction_data_id)
                                                                       AS count,
                'Critical' :: character varying                        AS severity,
                'No' :: character varying                              AS hide_display_flag,
                '' :: character varying                                AS reason_for_hiding
         FROM (
                  SELECT factt.ads_source,
                         factt.venue_id,
                         factt.transaction_data_id,
                         factt.tender_sequence_id,
                         m.transaction_type,
                         factt.transaction_type_fmb_misc_dim_id,
                         factt.appetize_product_id,
                         count(1)
                             AS count
                  FROM ads_main.f_fmb_sales_tender_dtls factt
                           JOIN ads_main.d_fmb_misc m ON factt.transaction_type_fmb_misc_dim_id = m.fmb_misc_dim_id
                  WHERE factt.ads_source = 'APPETIZE' :: character varying
                    AND m.transaction_type = 'Refund' :: character varying
                  GROUP BY factt.ads_source, factt.venue_id, factt.transaction_data_id, factt.tender_sequence_id,
                           m.transaction_type, factt.transaction_type_fmb_misc_dim_id, factt.appetize_product_id
                  HAVING count(1) > 1) derived_table10
         GROUP BY derived_table10.ads_source, derived_table10.venue_id
         HAVING count(1) > 1
         UNION ALL
         SELECT 'f_fmb_sales_tender_dtls' :: character varying AS table_name,
                'Duplicate Business Key' :: character varying  AS check_type,
                derived_table11.venue_id,
                derived_table11.ads_source,
                count(
                        DISTINCT derived_table11.transaction_data_id)
                                                               AS count,
                'Critical' :: character varying                AS severity,
                'No' :: character varying                      AS hide_display_flag,
                '' :: character varying                        AS reason_for_hiding
         FROM (
                  SELECT f_fmb_sales_tender_dtls.ads_source,
                         'N/A' :: character varying AS venue_id,
                         f_fmb_sales_tender_dtls.transaction_data_id,
                         f_fmb_sales_tender_dtls.tender_sequence_id,
                         count(1)
                                                    AS count
                  FROM ads_main.f_fmb_sales_tender_dtls
                  WHERE f_fmb_sales_tender_dtls.ads_source <> 'APPETIZE' :: character varying
                  GROUP BY f_fmb_sales_tender_dtls.ads_source, f_fmb_sales_tender_dtls.transaction_data_id,
                           f_fmb_sales_tender_dtls.tender_sequence_id
                  HAVING count(1) > 1) derived_table11
         GROUP BY derived_table11.ads_source, derived_table11.venue_id
         HAVING count(1) > 1


             /********************************************************************************************************************************************************/
             /********************************************************************************************************************************************************/
                --fmb fact table comparison		 
         UNION ALL

         SELECT 'FMB_header_product' :: character varying AS table_name,
                check_type,
                venue_id,
                ads_source,
                count(transaction_data_id)
                                                          AS count,
                'Critical' :: character varying           AS severity,
                'No' :: character varying                 AS hide_display_flag,
                '' :: character varying                   AS reason_for_hiding
         FROM (
                  SELECT nvl(h.venue_id, p.venue_id)                       as venue_id,
                         nvl(h.ads_source, p.ads_source)                      ads_source,
                         nvl(h.transaction_data_id, p.transaction_data_id) as transaction_data_id,
                         'Measures mismatch - ' ||
                         case
                             when nvl(h.transaction_count, 0) <> nvl(p.transaction_count, 0)
                                 then ' transaction_count '
                             else '' end ||
                         case
                             when nvl(h.product_quantity, 0) <> nvl(p.product_quantity, 0)
                                 then ' quantity '
                             else '' end ||
                         case
                             when nvl(h.discount_amount, 0) <> nvl(p.discount_amount, 0)
                                 then ' discount '
                             else '' end ||
                         case
                             when nvl(h.tax_amount, 0) <> nvl(p.tax_amount, 0)
                                 then ' tax '
                             else '' end ||
                         case
                             when nvl(h.taxable_sales_amount, 0) <> nvl(p.taxable_sales_amount, 0)
                                 then ' taxable_sales_amount '
                             else '' end ||
                         case
                             when nvl(h.non_taxable_sales_amount, 0) <> nvl(p.non_taxable_sales_amount, 0)
                                 then ' non_taxable_sales_amount '
                             else '' end ||
                         case
                             when nvl(h.net_sales_amount, 0) <> nvl(p.net_sales_amount, 0)
                                 then ' net_sales_amount '
                             else '' end ||
                         case
                             when nvl(h.gross_sales_amount, 0) <> nvl(p.gross_sales_amount, 0)
                                 then ' gross_sales_amount '
                             else '' end                                   as check_type


                  from (
                           SELECT COALESCE(venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                                  ads_source,
                                  transaction_data_id,
                                  count(
                                          distinct
                                          transaction_data_id)                                        as transaction_count,
                                  sum(product_quantity)                                               as product_quantity,
                                  sum(discount_amount)                                                as discount_amount,
                                  sum(tax_amount)                                                     as tax_amount,
                                  sum(taxable_sales_amount)                                           as taxable_sales_amount,
                                  sum(
                                          non_taxable_sales_amount)                                   as non_taxable_sales_amount,
                                  sum(net_sales_amount)                                               as net_sales_amount,
                                  sum(gross_sales_amount)                                             as gross_sales_amount
                           FROM msgbiadb.ads_main.f_fmb_sales_hdr_dtls
                           group by ads_source, venue_id, transaction_data_id) h
                           full join
                       (
                           SELECT COALESCE(venue_id :: character varying, 'N/A' :: character varying) AS venue_id,
                                  ads_source,
                                  transaction_data_id,
                                  count(
                                          distinct
                                          transaction_data_id)                                        as transaction_count,
                                  sum(product_quantity)                                               as product_quantity,
                                  sum(discount_amount)                                                as discount_amount,
                                  sum(tax_amount)                                                     as tax_amount,
                                  sum(taxable_sales_amount)                                           as taxable_sales_amount,
                                  sum(non_taxable_sales_amount)                                       as non_taxable_sales_amount,
                                  sum(net_sales_amount)                                               as net_sales_amount,
                                  sum(gross_sales_amount)                                             as gross_sales_amount
                           FROM msgbiadb.ads_main.f_fmb_sales_product_dtls
                           group by ads_source, venue_id, transaction_data_id) p
                       on h.venue_id = p.venue_id
                           and h.ads_source = p.ads_source
                           and h.transaction_data_id = p.transaction_data_id
                  where (nvl(h.transaction_count, 0) <> nvl(p.transaction_count, 0)
                      OR
                         nvl(h.product_quantity, 0) <> nvl(p.product_quantity, 0)
                      OR
                         nvl(h.discount_amount, 0) <> nvl(p.discount_amount, 0)
                      OR
                         nvl(h.tax_amount, 0) <> nvl(p.tax_amount, 0)
                      OR
                         nvl(h.taxable_sales_amount, 0) <> nvl(p.taxable_sales_amount, 0)
                      OR
                         nvl(h.non_taxable_sales_amount, 0) <> nvl(p.non_taxable_sales_amount, 0)
                      OR
                         nvl(h.net_sales_amount, 0) <> nvl(p.net_sales_amount, 0)
                      OR
                         nvl(h.gross_sales_amount, 0) <> nvl(p.gross_sales_amount, 0)
                            )
              ) a
         GROUP BY ads_source, venue_id, check_type
         HAVING count(1) > 1

         /********************************************************************************************************************************************************/
         /********************************************************************************************************************************************************/


     ) a
WHERE hide_display_flag = 'No'


with no schema binding;

alter table v_monitoring_dashboard_sam
    owner to ads_main;

