create function f_remove_accents(str character varying) returns character varying
    stable
    language plpythonu
as
$$
          import unicodedata
          if not str:
            return None
          str = str.decode('utf-8')
          return unicodedata.normalize('NFKD', str).encode('ASCII', 'ignore')
$$;

