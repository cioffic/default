create or replace view ads_staging.avw_leagueapps_registrations
    -- drop table ads_staging.avw_leagueapps_registrations
as
select c.ads_source,
       a.site_id,
       c.site_name,
       userid::int                                                                               user_id,
       usertype                                                                                  user_type,
       role,
       invoiceid::int                                                                            invoice_id,
       registrationid::int                                                                    as registration_id,
       firstname                                                                                 first_name,
       lastname                                                                                  last_name,
       birthdate                                                                                 birthdate_epoch,
       TIMESTAMPTZ 'epoch' + a.birthdate::bigint / 1000 * interval '1 second'                 as birth_date,

       gender,
       zipcode                                                                                   zip_code,

       groupid                                                                                   group_id,
       groupname                                                                                 group_name,


       parentuserid::int                                                                         parent_user_id,
       parentfirstname                                                                           parent_first_name,
       parentlastname                                                                            parent_last_name,
       parentemail                                                                               parent_email,
       parentphone                                                                               parent_phone,

       programid::int                                                                            program_id,
       programname::varchar(255)                                                                 program_name,
       programstate::varchar(20)                                                                 program_state,
       programtype::varchar(20)                                                                  program_type,

       paymentstatus                                                                             payment_status,
       registrationstatus                                                                        registration_status,
       team,
       sportid::int                                                                              sport_id,
       sport,

       programstartdate                                                                          program_start_date_epoch,
       TIMESTAMPTZ 'epoch' + a.programstartdate::bigint / 1000 * interval '1 second'          as program_start_date,

       waiveracceptedtimestamp                                                                   waiver_accepted_timestamp_epoch,
       TIMESTAMPTZ 'epoch' +
       a.waiveracceptedtimestamp::bigint / 1000 * interval '1 second'                         as waiver_accepted_timestamp,

       case when price = '' then '0' else price end::numeric(12, 2)                              price,
       case when totalamountdue = '' then '0' else totalamountdue end::numeric(12, 2)            total_amount_due,
       case when amountpaid = '' then '0' else amountpaid end::numeric(12, 2)                    amount_paid,
       case when outstandingbalance = '' then '0' else outstandingbalance end::numeric(12, 2)    outstanding_balance,

       created                                                                                   created_epoch,
       TIMESTAMPTZ 'epoch' + a.created::bigint / 1000 * interval '1 second'                   as created,

       lastupdated                                                                               last_updated_epoch,
       TIMESTAMPTZ 'epoch' + a.lastupdated::bigint / 1000 * interval '1 second'               as last_updated,


--sitename,
       src_file_name,
       TIMESTAMPTZ 'epoch' + left(right(src_file_name, 14), 10)::bigint * interval '1 second' as load_datetime_gmt


from league_apps.leagueapps_registrations a
         inner join ext_staging.mpd_leagueapps_site c
                    on a.site_id = c.site_id

with no schema binding;

alter table avw_leagueapps_registrations
    owner to ads_staging;

