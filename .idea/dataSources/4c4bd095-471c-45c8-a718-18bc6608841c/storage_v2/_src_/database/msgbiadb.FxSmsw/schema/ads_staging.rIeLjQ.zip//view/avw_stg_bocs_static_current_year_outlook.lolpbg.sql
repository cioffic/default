create or replace view ads_staging.avw_stg_bocs_static_current_year_outlook as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file
from ext_staging.stg_bocs_static_current_year_outlook
with no schema binding;

alter table avw_stg_bocs_static_current_year_outlook
    owner to ads_staging;

