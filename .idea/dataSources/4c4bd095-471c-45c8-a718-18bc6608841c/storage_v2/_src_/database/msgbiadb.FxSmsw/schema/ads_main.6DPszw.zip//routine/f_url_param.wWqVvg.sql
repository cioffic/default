create function f_url_param(url character varying, param character varying) returns character varying
    stable
    language plpythonu
as
$$
          import urlparse
          if not url:
            return None
          try:
            u = urlparse.urlparse(url)
            return urlparse.parse_qs(u.query)[param][0]
          except KeyError:
            return None
$$;

