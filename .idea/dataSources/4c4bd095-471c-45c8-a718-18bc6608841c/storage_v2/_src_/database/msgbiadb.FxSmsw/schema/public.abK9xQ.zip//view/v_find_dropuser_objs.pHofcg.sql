create view v_find_dropuser_objs(objtype, objowner, userid, schemaname, objname, ddl) as
SELECT "owner".objtype, "owner".objowner, "owner".userid, "owner".schemaname, "owner".objname, "owner".ddl
FROM ((((SELECT 'Function'::character varying,
                pgu.usename,
                pgu.usesysid,
                nc.nspname,
                textin(regprocedureout(pproc.oid::regprocedure))::character varying AS textin,
                (((('alter function '::text || quote_ident(nc.nspname::text)) || '.'::text) ||
                  textin(regprocedureout(pproc.oid::regprocedure))) || ' owner to '::text)::character varying
         FROM pg_proc pproc,
              pg_user pgu,
              pg_namespace nc
         WHERE pproc.pronamespace = nc.oid
           AND pproc.proowner = pgu.usesysid
         UNION ALL
         SELECT 'Database'::character varying,
                pgu.usename,
                pgu.usesysid,
                NULL::name,
                pgd.datname,
                (('alter database '::text || quote_ident(pgd.datname::text)) || ' owner to '::text)::character varying
         FROM pg_database pgd,
              pg_user pgu
         WHERE pgd.datdba = pgu.usesysid)
        UNION ALL
        SELECT 'Schema'::character varying,
               pgu.usename,
               pgu.usesysid,
               NULL::name,
               pgn.nspname,
               (('alter schema '::text || quote_ident(pgn.nspname::text)) || ' owner to '::text)::character varying
        FROM pg_namespace pgn,
             pg_user pgu
        WHERE pgn.nspowner = pgu.usesysid)
       UNION ALL
       SELECT CASE
                  WHEN pgc.relkind = 'r'::"char" OR pgc.relkind IS NULL AND 'r' IS NULL THEN 'Table'::text
                  WHEN pgc.relkind = 'v'::"char" OR pgc.relkind IS NULL AND 'v' IS NULL THEN 'View'::text
                  ELSE NULL::text
                  END::character varying AS "case",
              pgu.usename,
              pgu.usesysid,
              nc.nspname,
              pgc.relname,
              (((('alter table '::text || quote_ident(nc.nspname::text)) || '.'::text) ||
                quote_ident(pgc.relname::text)) || ' owner to '::text)::character varying
       FROM pg_class pgc,
            pg_user pgu,
            pg_namespace nc
       WHERE pgc.relnamespace = nc.oid
         AND (pgc.relkind = 'r'::"char" OR pgc.relkind = 'v'::"char")
         AND pgu.usesysid = pgc.relowner
         AND nc.nspname !~~* 'pg_temp_%'::text)
      UNION ALL
      SELECT 'Library'::character varying,
             pgu.usename,
             pgu.usesysid,
             ''::name,
             pgl.name,
             'No DDL available for Python Library. You should DROP OR REPLACE the Python Library'::character varying
      FROM pg_library pgl,
           pg_user pgu
      WHERE pgl."owner" = pgu.usesysid) "owner"(objtype, objowner, userid, schemaname, objname, ddl)
WHERE "owner".userid > 1;

alter table v_find_dropuser_objs
    owner to msgadmin;

