create view f_vw_budget_forecast_event_kpis
            (ads_source, event_plan_id, event_day_id, scenario, ticket_product_description, finance_ticket_type,
             section, tickets_sold, tickets_total_revenue, tickets_total_gross_revenue, attendance_net_scan_count,
             attendance_ff_scan_count, fmb_food_beverage_revenue, fmb_fast_food_revenue, fmb_merchandise_revenue)
as
SELECT combine_total.ads_source,
       combine_total.event_plan_id,
       combine_total.event_day_id,
       combine_total.scenario,
       combine_total.ticket_product_description,
       combine_total.finance_ticket_type,
       combine_total.section,
       combine_total.tickets_sold,
       combine_total.tickets_total_revenue,
       combine_total.tickets_total_gross_revenue,
       combine_total.attendance_net_scan_count,
       combine_total.attendance_ff_scan_count,
       combine_total.fmb_food_beverage_revenue,
       combine_total.fmb_fast_food_revenue,
       combine_total.fmb_merchandise_revenue
FROM (SELECT tkt_total.ads_source,
             tkt_total.event_plan_id,
             tkt_total.event_day_id,
             tkt_total.scenario,
             tkt_total.ticket_product_description,
             tkt_total.finance_ticket_type,
             tkt_total.section,
             tkt_total.tickets_sold,
             tkt_total.tickets_total_revenue,
             tkt_total.tickets_total_gross_revenue,
             COALESCE(fmb_total.attendance_net_scan_count, 0::numeric::numeric(18, 0)) AS attendance_net_scan_count,
             COALESCE(fmb_total.attendance_ff_scan_count, 0::numeric::numeric(18, 0))  AS attendance_ff_scan_count,
             COALESCE(fmb_total.fmb_food_beverage_revenue, 0::numeric::numeric(18, 0)) AS fmb_food_beverage_revenue,
             COALESCE(fmb_total.fmb_fast_food_revenue, 0::numeric::numeric(18, 0))     AS fmb_fast_food_revenue,
             COALESCE(fmb_total.fmb_merchandise_revenue, 0::numeric::numeric(18, 0))   AS fmb_merchandise_revenue
      FROM (SELECT a.ads_source,
                   event_plan.event_plan_id,
                   to_char(event_plan.tm_event_date, 'yyyymmdd'::character varying::text)::integer AS event_day_id,
                   a.scenario,
                   'TOTAL'::character varying                                                      AS ticket_product_description,
                   'TOTAL'::character varying                                                      AS finance_ticket_type,
                   ''::character varying                                                           AS section,
                   sum(a.tickets_sold)                                                             AS tickets_sold,
                   sum(a.tickets_total_revenue)                                                    AS tickets_total_revenue,
                   sum(a.tickets_total_gross_revenue)                                              AS tickets_total_gross_revenue,
                   0                                                                               AS attendance_net_scan_count,
                   0                                                                               AS attendance_ff_scan_count,
                   0                                                                               AS fmb_food_beverage_revenue,
                   0                                                                               AS fmb_fast_food_revenue,
                   0                                                                               AS fmb_merchandise_revenue
            FROM ads_staging.stg_mpd_dashbrd_bdgt_fcst_tkts_dtls a
                     JOIN ads_main.d_event_plan event_plan ON event_plan.ads_source::text = a.ads_source::text AND
                                                              event_plan.tm_season_id = a.tm_season_id AND
                                                              event_plan.tm_event_id = a.tm_event_id AND
                                                              event_plan.tm_plan_event_id = -1
            GROUP BY a.ads_source, event_plan.event_plan_id,
                     to_char(event_plan.tm_event_date, 'yyyymmdd'::character varying::text)::integer,
                     a.scenario) tkt_total
               LEFT JOIN (SELECT a.ads_source,
                                 event_plan.event_plan_id,
                                 CASE
                                     WHEN ctr.counter = 1 THEN 'Budget'::character varying
                                     WHEN ctr.counter = 2 THEN 'Forecast'::character varying
                                     WHEN ctr.counter = 3 THEN 'Outlook'::character varying
                                     ELSE NULL::character varying
                                     END                    AS scenario,
                                 'TOTAL'::character varying AS ticket_product_description,
                                 'TOTAL'::character varying AS finance_ticket_type,
                                 ''::character varying      AS section,
                                 0                          AS tickets_sold,
                                 0                          AS tickets_total_revenue,
                                 0                          AS tickets_total_gross_revenue,
                                 CASE
                                     WHEN ctr.counter = 1 THEN a.budget_scan_count
                                     WHEN ctr.counter = 2 THEN a.forecast_scan_count
                                     WHEN ctr.counter = 3 THEN a.outlook_scan_count
                                     ELSE 0::numeric::numeric(18, 0)
                                     END                    AS attendance_net_scan_count,
                                 CASE
                                     WHEN ctr.counter = 1 THEN a.budget_fast_food_scan_count
                                     WHEN ctr.counter = 2 THEN 0::numeric::numeric(18, 0)
                                     WHEN ctr.counter = 3 THEN a.outlook_fast_food_scan_count
                                     ELSE 0::numeric::numeric(18, 0)
                                     END                    AS attendance_ff_scan_count,
                                 CASE
                                     WHEN ctr.counter = 1 THEN a.budget_fmb_food_beverage_revenue
                                     WHEN ctr.counter = 2 THEN 0::numeric::numeric(18, 0)
                                     WHEN ctr.counter = 3 THEN a.outlook_fmb_food_beverage_revenue
                                     ELSE 0::numeric::numeric(18, 0)
                                     END                    AS fmb_food_beverage_revenue,
                                 CASE
                                     WHEN ctr.counter = 1 THEN a.budget_fmb_fast_food_revenue
                                     WHEN ctr.counter = 2 THEN 0::numeric::numeric(18, 0)
                                     WHEN ctr.counter = 3 THEN a.outlook_fmb_fast_food_revenue
                                     ELSE 0::numeric::numeric(18, 0)
                                     END                    AS fmb_fast_food_revenue,
                                 CASE
                                     WHEN ctr.counter = 1 THEN a.budget_fmb_merchandise_revenue
                                     WHEN ctr.counter = 2 THEN 0::numeric::numeric(18, 0)
                                     WHEN ctr.counter = 3 THEN a.outlook_fmb_merchandise_revenue
                                     ELSE 0::numeric::numeric(18, 0)
                                     END                    AS fmb_merchandise_revenue
                          FROM ads_staging.stg_mpd_sports_tkt_dashbrd_bfo a
                                   JOIN ads_main.d_event_plan event_plan
                                        ON event_plan.ads_source::text = a.ads_source::text AND
                                           event_plan.tm_season_id = a.tm_season_id AND
                                           event_plan.tm_event_id = a.tm_event_id AND event_plan.tm_plan_event_id = -1
                                   JOIN ads_staging.dummy_counter ctr ON ctr.counter >= 1 AND ctr.counter <= 3) fmb_total
                         ON tkt_total.ads_source::text = fmb_total.ads_source::text AND
                            tkt_total.event_plan_id = fmb_total.event_plan_id AND
                            tkt_total.scenario::text = fmb_total.scenario::text AND
                            tkt_total.ticket_product_description::text =
                            fmb_total.ticket_product_description::text) combine_total
UNION ALL
SELECT tkt_base.ads_source,
       tkt_base.event_plan_id,
       tkt_base.event_day_id,
       tkt_base.scenario,
       tkt_base.ticket_product_description,
       tkt_base.finance_ticket_type,
       tkt_base.section,
       tkt_base.tickets_sold,
       tkt_base.tickets_total_revenue,
       tkt_base.tickets_total_gross_revenue,
       tkt_base.attendance_net_scan_count,
       tkt_base.attendance_ff_scan_count,
       tkt_base.fmb_food_beverage_revenue,
       tkt_base.fmb_fast_food_revenue,
       tkt_base.fmb_merchandise_revenue
FROM (SELECT a.ads_source,
             event_plan.event_plan_id,
             to_char(event_plan.tm_event_date, 'yyyymmdd'::character varying::text)::integer AS event_day_id,
             a.scenario,
             a.ticket_product_description,
             a.finance_ticket_type,
             a.section,
             a.tickets_sold,
             a.tickets_total_revenue,
             a.tickets_total_gross_revenue,
             0                                                                               AS attendance_net_scan_count,
             0                                                                               AS attendance_ff_scan_count,
             0                                                                               AS fmb_food_beverage_revenue,
             0                                                                               AS fmb_fast_food_revenue,
             0                                                                               AS fmb_merchandise_revenue
      FROM ads_staging.stg_mpd_dashbrd_bdgt_fcst_tkts_dtls a
               JOIN ads_main.d_event_plan event_plan
                    ON event_plan.ads_source::text = a.ads_source::text AND event_plan.tm_season_id = a.tm_season_id AND
                       event_plan.tm_event_id = a.tm_event_id AND event_plan.tm_plan_event_id = -1) tkt_base
ORDER BY 1, 5;

alter table f_vw_budget_forecast_event_kpis
    owner to ads_main;

