create view v_check_transaction_locks
            (system_ts, schemaname, tablename, databasename, transaction, pid, usename, mode, granted) as
SELECT 'now'::text::timestamp without time zone AS system_ts,
       btrim(n.nspname::text)                   AS schemaname,
       btrim(c.relname::text)                   AS tablename,
       btrim(l."database"::text)                AS databasename,
       l."transaction",
       l.pid,
       a.usename,
       l."mode",
       l.granted
FROM pg_locks l
         JOIN pg_class c ON c.oid = l.relation
         JOIN pg_namespace n ON n.oid = c.relnamespace
         JOIN pg_stat_activity a ON a.procpid = l.pid;

alter table v_check_transaction_locks
    owner to ads_mon;

