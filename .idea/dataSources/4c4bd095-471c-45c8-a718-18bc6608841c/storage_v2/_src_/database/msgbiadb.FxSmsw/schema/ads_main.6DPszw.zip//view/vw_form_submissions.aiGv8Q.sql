create view vw_form_submissions
            (submission_id, submission_date, submission_day_name, submission_day_name_abbrev,
             submission_weekday_indicator, submission_week_id, submission_week_end_date, submission_fiscal_year,
             submission_fiscal_quarter, submission_fiscal_year_month, submission_fiscal_month, customer_engagement_flag,
             last_engagement_date, exclude_flag, city, zip, county, state, country, neighborhood, borough, age, gender,
             estimated_household_income_range, marital_status, presence_of_children_age_0_3_flag,
             presence_of_children_age_4_6_flag, presence_of_children_age_7_9_flag, presence_of_children_age_10_12_flag,
             presence_of_children_age_13_15_flag, presence_of_children_age_16_18_flag, presence_of_children_flag,
             homeowner_flag, estimated_home_value_range, education_level, occupation, occupation_group,
             number_of_adults_in_household, mosaic_household, household_nba_enthusiast_flag,
             household_nhl_enthusiast_flag, household_cultural_arts_flag, household_sports_enthusiast_flag,
             household_christian_music_flag, household_classical_music_flag, household_country_music_flag,
             household_music_flag, household_oldies_music_flag, household_rock_music_flag, household_music_80s_flag,
             household_hip_hop_music_flag, household_alternative_music_flag, household_jazz_music_flag,
             household_pop_music_flag, wealth_investor_flag, estimated_net_assets_range, e_tech_group, form_name,
             form_create_date, form_url, form_inactive_flag, form_source, submission_count, marketing_business_unit)
as
SELECT fs.submission_id,
       fs.submission_timestamp                                                               AS submission_date,
       sd.day_name                                                                           AS submission_day_name,
       sd.day_name_abbrev                                                                    AS submission_day_name_abbrev,
       sd.weekday_indicator                                                                  AS submission_weekday_indicator,
       sd.week_id                                                                            AS submission_week_id,
       sd.week_end_date                                                                      AS submission_week_end_date,
       sd.fiscal_year                                                                        AS submission_fiscal_year,
       sd.fiscal_quarter                                                                     AS submission_fiscal_quarter,
       sd.fiscal_year_month                                                                  AS submission_fiscal_year_month,
       sd.fiscal_month                                                                       AS submission_fiscal_month,
       COALESCE(cm.customer_engagement_flag, 'UNKNOWN'::character varying)                   AS customer_engagement_flag,
       COALESCE(cm.last_engagement_date, '1900-01-01 00:00:00'::timestamp without time zone) AS last_engagement_date,
       COALESCE(cm.exclude_flag, 'UNKNOWN'::character varying)                               AS exclude_flag,
       CASE
           WHEN COALESCE(cm.city, ''::character varying)::text = ''::character varying::text AND
                COALESCE(fca.city, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE COALESCE(cm.city, fca.city)
           END                                                                               AS city,
       COALESCE(cm.zip, fca.zip)                                                             AS zip,
       CASE
           WHEN COALESCE(cm.county, ''::character varying)::text = ''::character varying::text OR
                COALESCE(cm.reporting_state_code, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying::text
           ELSE (cm.county::text || ', '::character varying::text) || cm.reporting_state_code::text
           END                                                                               AS county,
       COALESCE(cm.state, fca.state)                                                         AS state,
       COALESCE(cm.country, fca.country)                                                     AS country,
       CASE
           WHEN COALESCE(cm.neighborhood, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.neighborhood
           END                                                                               AS neighborhood,
       CASE
           WHEN COALESCE(cm.borough, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.borough
           END                                                                               AS borough,
       cm.age,
       CASE
           WHEN COALESCE(cm.gender, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.gender, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.gender
           END                                                                               AS gender,
       CASE
           WHEN COALESCE(cm.estimated_household_income_range, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.estimated_household_income_range, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.estimated_household_income_range
           END                                                                               AS estimated_household_income_range,
       CASE
           WHEN COALESCE(cm.marital_status, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.marital_status, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.marital_status
           END                                                                               AS marital_status,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_0_3_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_0_3_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_0_3_flag
           END::character varying(30)                                                        AS presence_of_children_age_0_3_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_4_6_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_4_6_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_4_6_flag
           END::character varying(30)                                                        AS presence_of_children_age_4_6_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_7_9_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_7_9_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_7_9_flag
           END::character varying(30)                                                        AS presence_of_children_age_7_9_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_10_12_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_10_12_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_10_12_flag
           END::character varying(30)                                                        AS presence_of_children_age_10_12_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_13_15_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_13_15_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_13_15_flag
           END::character varying(30)                                                        AS presence_of_children_age_13_15_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_age_16_18_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_age_16_18_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_age_16_18_flag
           END::character varying(30)                                                        AS presence_of_children_age_16_18_flag,
       CASE
           WHEN COALESCE(cm.presence_of_children_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.presence_of_children_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.presence_of_children_flag
           END::character varying(30)                                                        AS presence_of_children_flag,
       CASE
           WHEN COALESCE(cm.homeowner_flag, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.homeowner_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.homeowner_flag
           END::character varying(30)                                                        AS homeowner_flag,
       CASE
           WHEN COALESCE(cm.estimated_home_value_range, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.estimated_home_value_range, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.estimated_home_value_range
           END                                                                               AS estimated_home_value_range,
       CASE
           WHEN COALESCE(cm.education_level, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.education_level, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.education_level
           END                                                                               AS education_level,
       CASE
           WHEN COALESCE(cm.occupation, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.occupation, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.occupation
           END                                                                               AS occupation,
       CASE
           WHEN COALESCE(cm.occupation_group, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.occupation_group, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.occupation_group
           END                                                                               AS occupation_group,
       cm.number_of_adults_in_household,
       CASE
           WHEN COALESCE(cm.mosaic_household, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.mosaic_household, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.mosaic_household
           END                                                                               AS mosaic_household,
       CASE
           WHEN COALESCE(cm.household_nba_enthusiast_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_nba_enthusiast_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_nba_enthusiast_flag
           END                                                                               AS household_nba_enthusiast_flag,
       CASE
           WHEN COALESCE(cm.household_nhl_enthusiast_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_nhl_enthusiast_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_nhl_enthusiast_flag
           END                                                                               AS household_nhl_enthusiast_flag,
       CASE
           WHEN COALESCE(cm.household_cultural_arts_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_cultural_arts_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_cultural_arts_flag
           END                                                                               AS household_cultural_arts_flag,
       CASE
           WHEN COALESCE(cm.household_sports_enthusiast_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_sports_enthusiast_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_sports_enthusiast_flag
           END                                                                               AS household_sports_enthusiast_flag,
       CASE
           WHEN COALESCE(cm.household_christian_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_christian_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_christian_music_flag
           END                                                                               AS household_christian_music_flag,
       CASE
           WHEN COALESCE(cm.household_classical_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_classical_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_classical_music_flag
           END                                                                               AS household_classical_music_flag,
       CASE
           WHEN COALESCE(cm.household_country_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_country_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_country_music_flag
           END                                                                               AS household_country_music_flag,
       CASE
           WHEN COALESCE(cm.household_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_music_flag
           END                                                                               AS household_music_flag,
       CASE
           WHEN COALESCE(cm.household_oldies_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_oldies_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_oldies_music_flag
           END                                                                               AS household_oldies_music_flag,
       CASE
           WHEN COALESCE(cm.household_rock_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_rock_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_rock_music_flag
           END                                                                               AS household_rock_music_flag,
       CASE
           WHEN COALESCE(cm.household_music_80s_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_music_80s_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_music_80s_flag
           END                                                                               AS household_music_80s_flag,
       CASE
           WHEN COALESCE(cm.household_hip_hop_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_hip_hop_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_hip_hop_music_flag
           END                                                                               AS household_hip_hop_music_flag,
       CASE
           WHEN COALESCE(cm.household_alternative_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_alternative_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_alternative_music_flag
           END                                                                               AS household_alternative_music_flag,
       CASE
           WHEN COALESCE(cm.household_jazz_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_jazz_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_jazz_music_flag
           END                                                                               AS household_jazz_music_flag,
       CASE
           WHEN COALESCE(cm.household_pop_music_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.household_pop_music_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.household_pop_music_flag
           END                                                                               AS household_pop_music_flag,
       CASE
           WHEN COALESCE(cm.wealth_investor_flag, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.wealth_investor_flag, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.wealth_investor_flag
           END                                                                               AS wealth_investor_flag,
       CASE
           WHEN COALESCE(cm.estimated_net_assets_range, ''::character varying)::text =
                'ADS Unknown'::character varying::text OR
                COALESCE(cm.estimated_net_assets_range, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.estimated_net_assets_range
           END                                                                               AS estimated_net_assets_range,
       CASE
           WHEN COALESCE(cm.e_tech_group, ''::character varying)::text = 'ADS Unknown'::character varying::text OR
                COALESCE(cm.e_tech_group, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE cm.e_tech_group
           END                                                                               AS e_tech_group,
       f.form_name,
       f.form_created_timestamp                                                              AS form_create_date,
       f.url                                                                                 AS form_url,
       f.inactive                                                                            AS form_inactive_flag,
       f.ads_source                                                                          AS form_source,
       fs.submission_count,
       CASE
           WHEN COALESCE(f.marketing_business_unit, ''::character varying)::text = ''::character varying::text
               THEN 'Unknown'::character varying
           ELSE f.marketing_business_unit
           END                                                                               AS marketing_business_unit
FROM ads_main.f_form_submissions fs
         JOIN ads_main.d_form f ON fs.form_id = f.form_id
         JOIN ads_main.d_date sd ON fs.submission_day_id = sd.day_id
         JOIN ads_main.d_forms_customer_account fca ON fs.forms_customer_account_id = fca.forms_customer_account_id
         LEFT JOIN ads_main.d_customer_master cm ON fs.customer_master_dim_id = cm.customer_master_dim_id;

alter table vw_form_submissions
    owner to ads_main;

