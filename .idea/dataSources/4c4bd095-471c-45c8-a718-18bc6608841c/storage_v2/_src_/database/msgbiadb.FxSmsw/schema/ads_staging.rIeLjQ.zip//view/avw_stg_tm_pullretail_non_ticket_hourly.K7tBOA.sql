CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_pullretail_non_ticket_hourly
AS
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'MSG' as ads_source
from ext_staging.stg_crmapi_pullretail_non_ticket_hourly
with no schema binding;

alter table avw_stg_tm_pullretail_non_ticket_hourly
    owner to ads_staging;

