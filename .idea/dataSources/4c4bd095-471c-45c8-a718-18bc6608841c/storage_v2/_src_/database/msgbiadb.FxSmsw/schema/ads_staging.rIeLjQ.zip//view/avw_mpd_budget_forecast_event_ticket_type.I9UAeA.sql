create or replace view ads_staging.avw_mpd_budget_forecast_event_ticket_type as
(
select tm_season_year,
       tm_season_name,
       tm_event_name,
       tm_event_name_long,
       to_date(tm_event_date, 'MM/DD/YYYY')  as tm_event_date,
       to_date(week_end_date, 'MM/DD/YYYY')  as week_end_date,
       tm_event_time,
       ticket_type,
       event_business_unit,
       mpd_indy_rank,
       mpd_game_num,
       cast(budget_tickets_sold as int)      as budget_tickets_sold,
       cast(budget_tickets_revenue as float) as budget_revenue,
       show_week_num,
       venue,
       'MSG'                                 as ads_source,
       "$path"                               as ads_source_filename
from ext_staging.stg_budget_forecast_event_ticket_type
    )
with no schema binding;

alter table avw_mpd_budget_forecast_event_ticket_type
    owner to ads_staging;

