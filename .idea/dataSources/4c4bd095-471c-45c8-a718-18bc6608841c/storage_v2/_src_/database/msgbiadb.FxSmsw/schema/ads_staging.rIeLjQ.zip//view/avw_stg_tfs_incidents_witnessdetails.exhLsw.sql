create or replace view ads_staging.avw_stg_tfs_incidents_witnessdetails as
select a.id,
       a.witness_name,
       a.date_of_birth,
       a.phone_number,
       a.address,
       a.ticket,
       a.witness_details
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.witnessdetails a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_witnessdetails
    owner to ads_staging;

