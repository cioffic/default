CREATE or replace VIEW ads_staging.avw_stg_tm_host_events_source AS
select a.*,
       rank()
       over (
           partition by a.discovery_event_id
           order by a.pulldatetime desc ) as rnk
from ads_staging.avw_stg_tm_host_events as a
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_source
    owner to ads_staging;

