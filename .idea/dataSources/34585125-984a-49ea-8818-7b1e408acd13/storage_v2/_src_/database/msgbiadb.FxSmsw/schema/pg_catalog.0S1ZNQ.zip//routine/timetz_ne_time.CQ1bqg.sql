create function timetz_ne_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_ne_timetz($2, $1)
$$;

