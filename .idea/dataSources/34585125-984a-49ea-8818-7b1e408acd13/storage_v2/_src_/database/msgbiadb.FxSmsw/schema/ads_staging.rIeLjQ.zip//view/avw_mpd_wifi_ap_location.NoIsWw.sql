CREATE OR REPLACE VIEW ads_staging.avw_mpd_wifi_ap_location
AS

SELECT *
     , ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
FROM ext_staging.mpd_wifi_ap_location
WITH NO SCHEMA BINDING;

alter table avw_mpd_wifi_ap_location
    owner to ads_staging;

