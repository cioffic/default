create function regexp_count(text, text, integer) returns integer
    immutable
    language sql
as
$$
    select regexp_count($1, $2, $3, '')
$$;

comment on function regexp_count(text, text, integer) is 'return the number of matched regular expression';

