create function timetz_gt_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_lt_timetz($2, $1)
$$;

