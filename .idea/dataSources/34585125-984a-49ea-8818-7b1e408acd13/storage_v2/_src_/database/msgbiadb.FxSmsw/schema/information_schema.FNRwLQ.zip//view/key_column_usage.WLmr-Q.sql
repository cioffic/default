create view key_column_usage
            (constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name,
             column_name, ordinal_position)
as
SELECT current_database()::information_schema.sql_identifier AS constraint_catalog,
       nc.nspname::information_schema.sql_identifier         AS constraint_schema,
       c.conname::information_schema.sql_identifier          AS constraint_name,
       current_database()::information_schema.sql_identifier AS table_catalog,
       nr.nspname::information_schema.sql_identifier         AS table_schema,
       r.relname::information_schema.sql_identifier          AS table_name,
       a.attname::information_schema.sql_identifier          AS column_name,
       pos.n::information_schema.cardinal_number             AS ordinal_position
FROM pg_namespace nr,
     pg_class r,
     pg_attribute a,
     pg_namespace nc,
     pg_constraint c,
     pg_user u,
     information_schema._pg_keypositions() pos(n)
WHERE nr.oid = r.relnamespace
  AND r.oid = a.attrelid
  AND r.oid = c.conrelid
  AND nc.oid = c.connamespace
  AND c.conkey[pos.n] = a.attnum
  AND NOT a.attisdropped
  AND (c.contype = 'p'::"char" OR c.contype = 'u'::"char" OR c.contype = 'f'::"char")
  AND r.relkind = 'r'::"char"
  AND r.relowner = u.usesysid
  AND u.usename = "current_user"()::name;

alter table key_column_usage
    owner to rdsdb;

