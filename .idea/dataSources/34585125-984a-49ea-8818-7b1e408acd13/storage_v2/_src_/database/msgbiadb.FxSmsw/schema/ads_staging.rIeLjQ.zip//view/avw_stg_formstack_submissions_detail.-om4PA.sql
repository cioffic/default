create or replace view ads_staging.avw_stg_formstack_submissions_detail
as
select a.id,
       a."timestamp",
       a.user_agent,
       a.payment_status,
       a.form,
       a.latitude,
       a.longitude,
       a.pretty_field_id,
       data.field,
       data.value
from ext_staging.stg_formstack_submissions_detail a
         LEFT JOIN a.data as data
                   ON TRUE
with no schema binding;

alter table avw_stg_formstack_submissions_detail
    owner to ads_staging;

