create function cidr_gt(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_gt($1::inet, $2::inet)
$$;

