create function regexp_substr(text, text, integer, integer) returns text
    immutable
    language sql
as
$$
    select regexp_substr($1, $2, $3, $4, '')
$$;

