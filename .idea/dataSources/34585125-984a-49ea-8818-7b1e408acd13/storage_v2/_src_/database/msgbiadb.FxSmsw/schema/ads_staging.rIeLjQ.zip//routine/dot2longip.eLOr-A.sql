create function dot2longip(IP character varying) returns bigint
    stable
    language plpythonu
as
$$
import ipaddress
return int(ipaddress.IPv4Address(ip))

$$;

