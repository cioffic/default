create function fn_uuid() returns character varying
    volatile
    language plpythonu
as
$$
 import uuid
 return '77-'+uuid.uuid1().__str__()
$$;

