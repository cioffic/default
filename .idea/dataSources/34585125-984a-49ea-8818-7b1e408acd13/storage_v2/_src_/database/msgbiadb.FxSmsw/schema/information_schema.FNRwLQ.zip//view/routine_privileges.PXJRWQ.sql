create view routine_privileges
            (grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
             routine_name, privilege_type, is_grantable)
as
SELECT u_grantor.usename::information_schema.sql_identifier                                                  AS grantor,
       grantee.name::information_schema.sql_identifier                                                       AS grantee,
       current_database()::information_schema.sql_identifier                                                 AS specific_catalog,
       n.nspname::information_schema.sql_identifier                                                          AS specific_schema,
       ((p.proname::text || '_'::text) || p.oid::character varying::text)::information_schema.sql_identifier AS specific_name,
       current_database()::information_schema.sql_identifier                                                 AS routine_catalog,
       n.nspname::information_schema.sql_identifier                                                          AS routine_schema,
       p.proname::information_schema.sql_identifier                                                          AS routine_name,
       'EXECUTE'::information_schema.character_data::information_schema.character_data                       AS privilege_type,
       CASE
           WHEN aclcontains(p.proacl,
                            makeaclitem(grantee.usesysid, grantee.grosysid, u_grantor.usesysid, 'EXECUTE'::text, true))
               THEN 'YES'::text
           ELSE 'NO'::text
           END::information_schema.character_data                                                            AS is_grantable
FROM pg_proc p,
     pg_namespace n,
     pg_user u_grantor,
     ((SELECT pg_user.usesysid, 0, pg_user.usename
       FROM pg_user
       UNION ALL
       SELECT 0, pg_group.grosysid, pg_group.groname
       FROM pg_group)
      UNION ALL
      SELECT 0, 0, 'PUBLIC'::name) grantee(usesysid, grosysid, name)
WHERE p.pronamespace = n.oid
  AND aclcontains(p.proacl, makeaclitem(grantee.usesysid, grantee.grosysid, u_grantor.usesysid, 'EXECUTE'::text, false))
  AND (u_grantor.usename = "current_user"()::name OR grantee.name = "current_user"()::name OR
       grantee.name = 'PUBLIC'::name);

alter table routine_privileges
    owner to rdsdb;

