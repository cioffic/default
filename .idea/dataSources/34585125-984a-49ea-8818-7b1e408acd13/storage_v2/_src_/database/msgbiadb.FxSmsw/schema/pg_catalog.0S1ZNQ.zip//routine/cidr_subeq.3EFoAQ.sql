create function cidr_subeq(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_subeq($1::inet, $2::inet)
$$;

