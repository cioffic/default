create or replace view ads_staging.avw_stg_tfs_incidents_associatedpersons as
select a.id,
       a.firstname,
       a.lastname,
       a.middlename,
       a.guest_type_id,
       a.guest_type,
       a.date_of_birth,
       a.gender,
       a.race,
       a.height,
       a.weight,
       a.build,
       a.haircolor,
       a.eyecolor,
       a."marks/scars" as marks_scars,
       a.minor,
       a.occupation,
       a.phone,
       a.email,
       a.license,
       a.social,
       a.address,
       a.city,
       a.state,
       a.zip,
       a.notes,
       a.ticket,
       a.sectionid,
       a.sectionname,
       a.row,
       a.seat,
       a.resolutionname,
       a.parents_notified,
       a.who_notified_parents,
       a.how_person_involved,
       a.other_details
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.associatedpersons a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_associatedpersons
    owner to ads_staging;

