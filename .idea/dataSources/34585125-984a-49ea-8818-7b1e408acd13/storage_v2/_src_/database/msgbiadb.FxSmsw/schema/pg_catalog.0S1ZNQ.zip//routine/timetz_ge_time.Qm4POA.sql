create function timetz_ge_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_le_timetz($2, $1)
$$;

