create view f_ticket_sales_event_seat_active_sam_working
            (tickets_add_datetime, tickets_add_datehour, ticket_sale_report_date, ticket_transaction_date,
             manifest_seat_id, event_plan_id, customer_account_id, price_code_id, ticket_status_id, ticket_type_flag_id,
             ticket_type_desc_id, tm_order_id, tm_price_code, tm_acct_id, tickets_sold, tickets_discount_amount,
             tickets_surcharge_amount, tickets_purchase_price, tickets_retail_service_charge,
             tickets_retail_facility_fee, tickets_retail_face_value_tax, tickets_retail_face_value, tickets_pc_ticket,
             tickets_pc_tax, tickets_pc_licfee, tickets_pc_other_1, tickets_pc_other_2, tickets_total_net_revenue,
             tickets_total_gross_revenue, tickets_premium_charge, ads_source_file, ads_source, ads_dtm_created,
             ads_dtm_last_updated, credited_sales_account_rep_id, tickets_audit_price, tm_section_name, tm_row_name,
             tm_seat_num, ticket_came_from_code_id, ticket_seq_id, ticket_promo_code_id, ticket_ledger_id,
             ticket_disc_code, upd_user, add_user, renewal_ind, cum_tickets_sold, tickets_add_datetime_calc,
             latest_tickets_add_datetime, return_flag, current_ticket_holder)
as
SELECT main.tickets_add_datetime,
       main.tickets_add_datehour,
       main.ticket_sale_report_date,
       main.ticket_transaction_date,
       main.manifest_seat_id,
       main.event_plan_id,
       main.customer_account_id,
       main.price_code_id,
       main.ticket_status_id,
       main.ticket_type_flag_id,
       main.ticket_type_desc_id,
       main.tm_order_id,
       main.tm_price_code,
       main.tm_acct_id,
       main.tickets_sold,
       main.tickets_discount_amount,
       main.tickets_surcharge_amount,
       main.tickets_purchase_price,
       main.tickets_retail_service_charge,
       main.tickets_retail_facility_fee,
       main.tickets_retail_face_value_tax,
       main.tickets_retail_face_value,
       main.tickets_pc_ticket,
       main.tickets_pc_tax,
       main.tickets_pc_licfee,
       main.tickets_pc_other_1,
       main.tickets_pc_other_2,
       main.tickets_total_net_revenue,
       main.tickets_total_gross_revenue,
       main.tickets_premium_charge,
       main.ads_source_file,
       main.ads_source,
       main.ads_dtm_created,
       main.ads_dtm_last_updated,
       main.credited_sales_account_rep_id,
       main.tickets_audit_price,
       main.tm_section_name,
       main.tm_row_name,
       main.tm_seat_num,
       main.ticket_came_from_code_id,
       main.ticket_seq_id,
       main.ticket_promo_code_id,
       main.ticket_ledger_id,
       main.ticket_disc_code,
       main.upd_user,
       main.add_user,
       main.renewal_ind,
       main.cum_tickets_sold,
       main.tickets_add_datetime_calc,
       main.latest_tickets_add_datetime,
       CASE
           WHEN main.cum_tickets_sold <= 0 THEN 'Y'::text
           ELSE 'N'::text
           END AS return_flag,
       CASE
           WHEN main.cum_tickets_sold > 0 AND main.tickets_add_datetime_calc = main.latest_tickets_add_datetime THEN 'Y'::text
           ELSE 'N'::text
           END AS current_ticket_holder
FROM (SELECT f_ticket_sales_event_seat.tickets_add_datetime,
             f_ticket_sales_event_seat.tickets_add_datehour,
             f_ticket_sales_event_seat.ticket_sale_report_date,
             f_ticket_sales_event_seat.ticket_transaction_date,
             f_ticket_sales_event_seat.manifest_seat_id,
             f_ticket_sales_event_seat.event_plan_id,
             f_ticket_sales_event_seat.customer_account_id,
             f_ticket_sales_event_seat.price_code_id,
             f_ticket_sales_event_seat.ticket_status_id,
             f_ticket_sales_event_seat.ticket_type_flag_id,
             f_ticket_sales_event_seat.ticket_type_desc_id,
             f_ticket_sales_event_seat.tm_order_id,
             f_ticket_sales_event_seat.tm_price_code,
             f_ticket_sales_event_seat.tm_acct_id,
             f_ticket_sales_event_seat.tickets_sold,
             f_ticket_sales_event_seat.tickets_discount_amount,
             f_ticket_sales_event_seat.tickets_surcharge_amount,
             f_ticket_sales_event_seat.tickets_purchase_price,
             f_ticket_sales_event_seat.tickets_retail_service_charge,
             f_ticket_sales_event_seat.tickets_retail_facility_fee,
             f_ticket_sales_event_seat.tickets_retail_face_value_tax,
             f_ticket_sales_event_seat.tickets_retail_face_value,
             f_ticket_sales_event_seat.tickets_pc_ticket,
             f_ticket_sales_event_seat.tickets_pc_tax,
             f_ticket_sales_event_seat.tickets_pc_licfee,
             f_ticket_sales_event_seat.tickets_pc_other_1,
             f_ticket_sales_event_seat.tickets_pc_other_2,
             f_ticket_sales_event_seat.tickets_total_net_revenue,
             f_ticket_sales_event_seat.tickets_total_gross_revenue,
             f_ticket_sales_event_seat.tickets_premium_charge,
             f_ticket_sales_event_seat.ads_source_file,
             f_ticket_sales_event_seat.ads_source,
             f_ticket_sales_event_seat.ads_dtm_created,
             f_ticket_sales_event_seat.ads_dtm_last_updated,
             f_ticket_sales_event_seat.credited_sales_account_rep_id,
             f_ticket_sales_event_seat.tickets_audit_price,
             f_ticket_sales_event_seat.tm_section_name,
             f_ticket_sales_event_seat.tm_row_name,
             f_ticket_sales_event_seat.tm_seat_num,
             f_ticket_sales_event_seat.ticket_came_from_code_id,
             f_ticket_sales_event_seat.ticket_seq_id,
             f_ticket_sales_event_seat.ticket_promo_code_id,
             f_ticket_sales_event_seat.ticket_ledger_id,
             f_ticket_sales_event_seat.ticket_disc_code,
             f_ticket_sales_event_seat.upd_user,
             f_ticket_sales_event_seat.add_user,
             f_ticket_sales_event_seat.renewal_ind,
             sum(f_ticket_sales_event_seat.tickets_sold)
             OVER (
                 PARTITION BY
                     CASE
                         WHEN f_ticket_sales_event_seat.ads_source::text = 'MSG - RNT'::text THEN (
                                 "left"(f_ticket_sales_event_seat.tickets_add_datehour::text, 13) ||
                                 ':00:00'::text)::timestamp without time zone
                         ELSE f_ticket_sales_event_seat.tickets_add_datetime
                         END, f_ticket_sales_event_seat.event_plan_id, f_ticket_sales_event_seat.tm_section_name, f_ticket_sales_event_seat.tm_row_name, f_ticket_sales_event_seat.tm_seat_num
                 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS cum_tickets_sold,
             CASE
                 WHEN f_ticket_sales_event_seat.ads_source::text = 'MSG - RNT'::text THEN (
                         "left"(f_ticket_sales_event_seat.tickets_add_datehour::text, 13) ||
                         ':00:00'::text)::timestamp without time zone
                 ELSE f_ticket_sales_event_seat.tickets_add_datetime
                 END                                                       AS tickets_add_datetime_calc,
             CASE
                 WHEN f_ticket_sales_event_seat.ads_source::text = 'MSG - RNT'::text THEN (
                         ("max"("left"(f_ticket_sales_event_seat.tickets_add_datehour::text, 13))
                          OVER (
                              PARTITION BY f_ticket_sales_event_seat.event_plan_id, f_ticket_sales_event_seat.tm_section_name, f_ticket_sales_event_seat.tm_row_name, f_ticket_sales_event_seat.tm_seat_num
                              ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)) ||
                         ':00:00'::text)::timestamp without time zone
                 ELSE "max"(f_ticket_sales_event_seat.tickets_add_datetime)
                      OVER (
                          PARTITION BY f_ticket_sales_event_seat.event_plan_id, f_ticket_sales_event_seat.tm_section_name, f_ticket_sales_event_seat.tm_row_name, f_ticket_sales_event_seat.tm_seat_num
                          ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
                 END                                                       AS latest_tickets_add_datetime
      FROM ads_main.f_ticket_sales_event_seat) main;

alter table f_ticket_sales_event_seat_active_sam_working
    owner to ads_main;

