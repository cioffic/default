CREATE OR REPLACE VIEW ads_staging.avw_stg_sfmc_email_only_optins AS
SELECT lower(email_address)                                       email_address,
       md5(lower(email_address))                                  account_id,
       list_name,
       brand,
--to_date(nvl(optin_date, 'Jan 01 2016'), 'mon dd yyyy')
--nvl(optin_date, 'Jan 01 2016') new_date,
--case when length(optin_date) = 0 then 'Jan 01 2016'
--else optin_date end as new_date_1,
       to_timestamp(
               case
                   when optin_date = '<null>' then 'Jan 01 2016'
                   else optin_date end, 'mon dd yyyy hh24:mi') as optin_date,
       name_first,
       name_last,
       street_addr_1,
       street_addr_2,
       city,
       state,
       zip,
       ads_staging.f_s3_parse_athena_filename("$path")         as ads_source_file
FROM ext_staging.stg_sfmc_email_only_optins
    --where email_address = 'pholme@hhmetals.com'
--where substring(optin_date, 1,3)  not in ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
WITH NO SCHEMA BINDING;

alter table avw_stg_sfmc_email_only_optins
    owner to ads_staging;

