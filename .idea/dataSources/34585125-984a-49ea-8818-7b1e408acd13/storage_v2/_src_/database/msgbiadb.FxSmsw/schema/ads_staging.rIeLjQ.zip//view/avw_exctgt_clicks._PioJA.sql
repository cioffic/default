create or replace view ads_staging.avw_exctgt_clicks
as
select clientid,
       sendid,
       subscriberkey,
       emailaddress,
       subscriberid,
       listid,
       eventdate :: datetime,
       eventtype,
       sendurlid :: integer,
       urlid :: integer,
       url,
       alias,
       batchid :: integer,
       triggeredsendexternalkey,
       isunique,
       isuniqueforurl,
       ipaddress,
       country,
       region,
       city,
       latitude,
       longitude,
       metrocode,
       areacode,
       browser,
       emailclient,
       operatingsystem,
       device,
       ads_main.f_url_domain(url)                      as domain,
       ads_main.f_url_param(url, 'cmp')                as cmp,
       ads_main.f_url_param(url, 'camefrom')           as cfc,
       ads_main.f_url_param(url, 'brand')              as urlbrand,
       ads_main.f_parse_url(url, 'path')               as urlpath,
       case
           when split_part(ads_main.f_parse_url(url, 'path'), '/', 2) like '%artist%'
               then split_part(ads_main.f_parse_url(url, 'path'), '/', 4)
           when split_part(ads_main.f_parse_url(url, 'path'), '/', 3) like '%artist%'
               then split_part(ads_main.f_parse_url(url, 'path'), '/', 4)
           end                                         as artistid,
       case
           when split_part(ads_main.f_parse_url(url, 'path'), '/', 3) like '%event%'
               then split_part(ads_main.f_parse_url(url, 'path'), '/', 4)
           when split_part(ads_main.f_parse_url(url, 'path'), '/', 2) like '%event%'
               then split_part(ads_main.f_parse_url(url, 'path'), '/', 3)
           when lower(url) like '%mi_event_id%' then ads_main.f_url_param(url, 'mi_event_id')
           when lower(url) like '%tm_event_id%' then ads_main.f_url_param(url, 'tm_event_id')
           when position('/event/' in lower(ads_main.f_parse_url(url, 'path'))) > 0 then
               substring(lower(ads_main.f_parse_url(url, 'path')),
                         position('/event/' in lower(ads_main.f_parse_url(url, 'path'))) + 7, 16)
           when lower(url) like '%/event/%' then 'FINDME'
           else 'N/A'
           end                                         as ineteventid,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_clicks
with no schema binding;

alter table avw_exctgt_clicks
    owner to ads_staging;

