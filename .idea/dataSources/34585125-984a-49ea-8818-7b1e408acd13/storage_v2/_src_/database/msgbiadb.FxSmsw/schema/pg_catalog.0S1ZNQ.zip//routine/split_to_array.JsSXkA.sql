create function split_to_array(text) returns super
    immutable
    language sql
as
$$
    select split_to_array($1, ',')
$$;

