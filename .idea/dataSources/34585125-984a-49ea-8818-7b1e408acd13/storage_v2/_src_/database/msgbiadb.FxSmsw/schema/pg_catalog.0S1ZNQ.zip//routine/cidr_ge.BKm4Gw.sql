create function cidr_ge(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_ge($1::inet, $2::inet)
$$;

