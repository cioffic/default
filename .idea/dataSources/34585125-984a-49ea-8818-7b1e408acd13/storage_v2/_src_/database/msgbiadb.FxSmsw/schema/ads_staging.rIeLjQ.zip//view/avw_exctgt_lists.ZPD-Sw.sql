create or replace view ads_staging.avw_exctgt_lists
as
select clientid,
       listid,
       name,
       description,
       datecreated :: datetime,
       status,
       listtype,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_lists
with no schema binding;

alter table avw_exctgt_lists
    owner to ads_staging;

