create function timetz_cmp_time(time with time zone, time without time zone) returns integer
    stable
    language sql
as
$$
    select -time_cmp_timetz($2, $1)
$$;

