create function regexp_replace(text, text, text, integer) returns text
    immutable
    language sql
as
$$
    select regexp_replace($1, $2, $3, $4, '')
$$;

comment on function regexp_replace(text, text, text, integer) is 'replace all occurrences of regular expression in string';

