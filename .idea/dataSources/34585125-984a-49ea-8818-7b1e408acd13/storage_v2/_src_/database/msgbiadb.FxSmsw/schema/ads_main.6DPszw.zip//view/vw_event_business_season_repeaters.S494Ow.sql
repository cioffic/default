create view vw_event_business_season_repeaters
            (event_business_season, customer_master_index, tm_season_year, season_year_first_purchase_day_id,
             season_year_last_purchase_day_id, season_year_distinct_purchase_day_id_count, first_season_year,
             last_season_prior_to_current_season_year, number_of_prior_season_purchased_count, property_repeat_flag,
             city, county, reporting_state, reporting_country_group, distance, distance_category, exclude_flag, age,
             gender, estimated_household_income_range, marital_status, presence_of_children_flag,
             presence_of_children_age_0_3_flag, presence_of_children_age_4_6_flag, presence_of_children_age_7_9_flag,
             presence_of_children_age_10_12_flag, presence_of_children_age_13_15_flag,
             presence_of_children_age_16_18_flag, household_nba_enthusiast_flag, household_nhl_enthusiast_flag,
             household_sports_enthusiast_flag, homeowner_flag, education_level, occupation, occupation_group,
             number_of_adults_in_household, mosaic_household, estimated_net_assets_range, e_tech_group, tickets_sold,
             tickets_total_gross_revenue, tickets_total_net_revenue, individual_full_price_tickets_sold,
             individual_full_price_tickets_total_gross_revenue, individual_full_price_tickets_total_net_revenue,
             individual_discount_tickets_sold, individual_discount_tickets_total_gross_revenue,
             individual_discount_tickets_total_net_revenue)
as
((SELECT d_event_plan.event_business_unit AS                                                 event_business_season,
         d_customer_account.customer_master_index,
         d_event_plan.tm_season_year,
         min(f_ticket_sales_event_seat.ticket_sale_report_date) AS                           season_year_first_purchase_day_id,
         "max"(f_ticket_sales_event_seat.ticket_sale_report_date) AS                         season_year_last_purchase_day_id,
         count(DISTINCT f_ticket_sales_event_seat.ticket_sale_report_date) AS                season_year_distinct_purchase_day_id_count,
         min(d_event_plan.tm_season_year)
         OVER (
             PARTITION BY d_customer_account.customer_master_index
             ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS                    first_season_year,
         lead(d_event_plan.tm_season_year)
         OVER (
             PARTITION BY d_customer_account.customer_master_index
             ORDER BY d_event_plan.tm_season_year DESC) AS                                   last_season_prior_to_current_season_year,
         (pg_catalog.dense_rank()
          OVER (
              PARTITION BY d_customer_account.customer_master_index
              ORDER BY d_event_plan.tm_season_year)) -
         1 AS                                                                                number_of_prior_season_purchased_count,
         CASE
             WHEN (pg_catalog.dense_rank()
                   OVER (
                       PARTITION BY d_customer_account.customer_master_index
                       ORDER BY d_event_plan.tm_season_year)) = 1 THEN 'New'::text
             ELSE 'Repeat'::text
             END::character varying AS                                                       property_repeat_flag,
         d_customer_master.city,
         d_customer_master.county,
         d_customer_master.reporting_state,
         d_customer_master.reporting_country_group,
         CASE
             WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                        d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                 THEN NULL::double precision
             ELSE ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                        d_customer_master.latitude, d_customer_master.longitude)::double precision
             END AS                                                                          distance,
         CASE
             WHEN d_customer_master.reporting_country_group::text = 'United States of America'::text THEN
                 CASE
                     WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                         THEN 'US Unknown'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          50::double precision THEN 'Within 50 Miles'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          75::double precision THEN 'Between 51 and 75 Miles'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          300::double precision THEN 'Between 76 and 300 Miles'::text
                     ELSE 'Rest of United States'::text
                     END
             ELSE
                 CASE
                     WHEN COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <>
                          ''::text AND
                          COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <> 'Unknown'::text
                         THEN 'International'::text
                     ELSE 'Unknown'::text
                     END
             END::character varying AS                                                       distance_category,
         d_customer_master.exclude_flag,
         d_customer_master.age,
         d_customer_master.gender,
         d_customer_master.estimated_household_income_range,
         d_customer_master.marital_status,
         d_customer_master.presence_of_children_flag,
         d_customer_master.presence_of_children_age_0_3_flag,
         d_customer_master.presence_of_children_age_4_6_flag,
         d_customer_master.presence_of_children_age_7_9_flag,
         d_customer_master.presence_of_children_age_10_12_flag,
         d_customer_master.presence_of_children_age_13_15_flag,
         d_customer_master.presence_of_children_age_16_18_flag,
         d_customer_master.household_nba_enthusiast_flag,
         d_customer_master.household_nhl_enthusiast_flag,
         d_customer_master.household_sports_enthusiast_flag,
         d_customer_master.homeowner_flag,
         d_customer_master.education_level,
         d_customer_master.occupation,
         d_customer_master.occupation_group,
         d_customer_master.number_of_adults_in_household,
         d_customer_master.mosaic_household,
         d_customer_master.estimated_net_assets_range,
         d_customer_master.e_tech_group,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)) AS                         tickets_sold,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_total_gross_revenue,
                      0::numeric)) AS                                                        tickets_total_gross_revenue,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)) AS   tickets_total_net_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text
                         THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                     ELSE 0
                     END) AS                                                                 individual_full_price_tickets_sold,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_full_price_tickets_total_gross_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_full_price_tickets_total_net_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text
                         THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                     ELSE 0
                     END) AS                                                                 individual_discount_tickets_sold,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_discount_tickets_total_gross_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_discount_tickets_total_net_revenue
  FROM ads_main.f_ticket_sales_event_seat f_ticket_sales_event_seat
           LEFT JOIN ads_main.d_event_plan d_event_plan
                     ON f_ticket_sales_event_seat.event_plan_id = d_event_plan.event_plan_id
           LEFT JOIN ads_main.d_ticket_type_flags d_ticket_type_flags
                     ON f_ticket_sales_event_seat.ticket_type_flag_id = d_ticket_type_flags.ticket_type_flag_id
           LEFT JOIN ads_main.d_ticket_type_desc d_ticket_type_desc
                     ON f_ticket_sales_event_seat.ticket_type_desc_id = d_ticket_type_desc.ticket_type_desc_id
           LEFT JOIN ads_main.d_customer_account d_customer_account
                     ON d_customer_account.customer_account_id = f_ticket_sales_event_seat.customer_account_id
           LEFT JOIN ads_main.d_customer_master d_customer_master
                     ON d_customer_account.customer_master_index = d_customer_master.customer_master_index
  WHERE d_event_plan.event_business_unit::text = 'Christmas Spectacular'::text
    AND d_event_plan.report_event_flag::text = 'Y'::text
    AND (d_event_plan.tm_season_name::text = ANY
         (ARRAY['2015 RCCS 1st Half'::text, '2015 RCCS 2nd Half'::text, '2016 RCCS 1st Half'::text, '2016 RCCS 2nd Half'::text, '2017 RCCS 1st Half'::text, '2017 RCCS 2nd Half'::text, 'RCS 2018 RCCS 1st Half'::text, 'RCS 2018 RCCS 2nd Half'::text, 'RCS CSSR 1st Half 2019'::text, 'RCS CSSR 2nd Half 2019'::text, 'RCS CSSR 2020 1st Half'::text, 'RCS CSSR 2020 2nd Half'::text, 'RCS CSSR 2021 1st Half'::text, 'RCS CSSR 2021 2nd Half'::text]))
    AND d_ticket_type_desc.ticket_product_description::text = 'Individuals'::text
    AND COALESCE(d_customer_account.customer_master_index, -1) <> -1
    AND (d_event_plan.tm_season_year <> 2017 AND d_event_plan.tm_season_year <> 2018 OR
         d_event_plan.tm_season_year = 2017 AND d_ticket_type_desc.ticket_type_desc::text <> 'Trade Desk'::text AND
         d_customer_account.acct_type_desc::text <> 'Trade Desk'::text AND
         d_ticket_type_flags.ticket_retail_ticket_type::text <> 'J-TYPE'::text AND
         d_ticket_type_flags.ticket_retail_ticket_type::text <> 'M-TYPE'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%GBWAYIB%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%BTODAY%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTODAY1%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTODAY2%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTODAY3%'::text AND
         d_ticket_type_desc.house_seat_flag::text <> 'Y'::text AND
         d_ticket_type_flags.ticket_sell_location_name::text <> 'Broadway.com'::text OR
         d_event_plan.tm_season_year = 2018 AND d_ticket_type_desc.ticket_type_desc::text <> 'COMP'::text AND
         d_ticket_type_desc.ticket_product_description::text = 'Individuals'::text AND
         d_ticket_type_desc.ticket_type_desc::text <> 'Trade Desk'::text AND
         d_customer_account.acct_type_desc::text <> 'Trade Desk'::text AND
         d_ticket_type_flags.ticket_retail_ticket_type::text <> 'J-TYPE'::text AND
         d_ticket_type_flags.ticket_retail_ticket_type::text <> 'M-TYPE'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%KBWAYIB%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%BTDAY1%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTDAY2%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTDAY3%'::text AND
         d_ticket_type_flags.ticket_retail_qualifiers::text !~~ '%NTDAYCM%'::text AND
         d_ticket_type_desc.house_seat_flag::text <> 'Y'::text AND
         d_ticket_type_flags.ticket_sell_location_name::text <> 'Broadway.com'::text)
  GROUP BY d_event_plan.event_business_unit, d_customer_account.customer_master_index, d_event_plan.tm_season_year,
           d_customer_master.exclude_flag, d_customer_master.city, d_customer_master.county,
           d_customer_master.reporting_state, d_customer_master.reporting_country_group, d_event_plan.tm_arena_latitude,
           d_event_plan.tm_arena_longitude, d_customer_master.latitude, d_customer_master.longitude,
           d_customer_master.reporting_country_group, d_customer_master.age, d_customer_master.gender,
           d_customer_master.estimated_household_income_range, d_customer_master.marital_status,
           d_customer_master.presence_of_children_flag, d_customer_master.presence_of_children_age_0_3_flag,
           d_customer_master.presence_of_children_age_4_6_flag, d_customer_master.presence_of_children_age_7_9_flag,
           d_customer_master.presence_of_children_age_10_12_flag, d_customer_master.presence_of_children_age_13_15_flag,
           d_customer_master.presence_of_children_age_16_18_flag, d_customer_master.household_nba_enthusiast_flag,
           d_customer_master.household_nhl_enthusiast_flag, d_customer_master.household_sports_enthusiast_flag,
           d_customer_master.homeowner_flag, d_customer_master.education_level, d_customer_master.occupation,
           d_customer_master.occupation_group, d_customer_master.number_of_adults_in_household,
           d_customer_master.mosaic_household, d_customer_master.estimated_net_assets_range,
           d_customer_master.e_tech_group
  HAVING sum(f_ticket_sales_event_seat.tickets_sold) > 0
  UNION ALL
  SELECT d_event_plan.tm_season_name AS                                                      event_business_season,
         d_customer_account.customer_master_index,
         d_event_plan.tm_season_year,
         min(f_ticket_sales_event_seat.ticket_sale_report_date) AS                           season_year_first_purchase_day_id,
         "max"(f_ticket_sales_event_seat.ticket_sale_report_date) AS                         season_year_last_purchase_day_id,
         count(DISTINCT f_ticket_sales_event_seat.ticket_sale_report_date) AS                season_year_distinct_purchase_day_id_count,
         min(d_event_plan.tm_season_year)
         OVER (
             PARTITION BY d_customer_account.customer_master_index
             ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS                    first_season_year,
         lead(d_event_plan.tm_season_year)
         OVER (
             PARTITION BY d_customer_account.customer_master_index
             ORDER BY d_event_plan.tm_season_year DESC) AS                                   last_season_prior_to_current_season_year,
         (pg_catalog.dense_rank()
          OVER (
              PARTITION BY d_customer_account.customer_master_index
              ORDER BY d_event_plan.tm_season_year)) -
         1 AS                                                                                number_of_prior_season_purchased_count,
         'NA' AS                                                                             property_repeat_flag,
         d_customer_master.city,
         d_customer_master.county,
         d_customer_master.reporting_state,
         d_customer_master.reporting_country_group,
         CASE
             WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                        d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                 THEN NULL::double precision
             ELSE ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                        d_customer_master.latitude, d_customer_master.longitude)::double precision
             END AS                                                                          distance,
         CASE
             WHEN d_customer_master.reporting_country_group::text = 'United States of America'::text THEN
                 CASE
                     WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                         THEN 'US Unknown'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          50::double precision THEN 'Within 50 Miles'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          75::double precision THEN 'Between 51 and 75 Miles'::text
                     WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                      d_customer_master.latitude,
                                                      d_customer_master.longitude)::double precision, 0::numeric) <=
                          300::double precision THEN 'Between 76 and 300 Miles'::text
                     ELSE 'Rest of United States'::text
                     END
             ELSE
                 CASE
                     WHEN COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <>
                          ''::text AND
                          COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <> 'Unknown'::text
                         THEN 'International'::text
                     ELSE 'Unknown'::text
                     END
             END::character varying AS                                                       distance_category,
         d_customer_master.exclude_flag,
         d_customer_master.age,
         d_customer_master.gender,
         d_customer_master.estimated_household_income_range,
         d_customer_master.marital_status,
         d_customer_master.presence_of_children_flag,
         d_customer_master.presence_of_children_age_0_3_flag,
         d_customer_master.presence_of_children_age_4_6_flag,
         d_customer_master.presence_of_children_age_7_9_flag,
         d_customer_master.presence_of_children_age_10_12_flag,
         d_customer_master.presence_of_children_age_13_15_flag,
         d_customer_master.presence_of_children_age_16_18_flag,
         d_customer_master.household_nba_enthusiast_flag,
         d_customer_master.household_nhl_enthusiast_flag,
         d_customer_master.household_sports_enthusiast_flag,
         d_customer_master.homeowner_flag,
         d_customer_master.education_level,
         d_customer_master.occupation,
         d_customer_master.occupation_group,
         d_customer_master.number_of_adults_in_household,
         d_customer_master.mosaic_household,
         d_customer_master.estimated_net_assets_range,
         d_customer_master.e_tech_group,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)) AS                         tickets_sold,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_total_gross_revenue,
                      0::numeric)) AS                                                        tickets_total_gross_revenue,
         sum(COALESCE(f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)) AS   tickets_total_net_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text
                         THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                     ELSE 0
                     END) AS                                                                 individual_full_price_tickets_sold,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_full_price_tickets_total_gross_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_full_price_tickets_total_net_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text
                         THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                     ELSE 0
                     END) AS                                                                 individual_discount_tickets_sold,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_discount_tickets_total_gross_revenue,
         sum(
                 CASE
                     WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                             f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                     ELSE 0::numeric
                     END) AS                                                                 individual_discount_tickets_total_net_revenue
  FROM ads_main.f_ticket_sales_event_seat f_ticket_sales_event_seat
           LEFT JOIN ads_main.d_event_plan d_event_plan
                     ON f_ticket_sales_event_seat.event_plan_id = d_event_plan.event_plan_id
           LEFT JOIN ads_main.d_ticket_type_flags d_ticket_type_flags
                     ON f_ticket_sales_event_seat.ticket_type_flag_id = d_ticket_type_flags.ticket_type_flag_id
           LEFT JOIN ads_main.d_ticket_type_desc d_ticket_type_desc
                     ON f_ticket_sales_event_seat.ticket_type_desc_id = d_ticket_type_desc.ticket_type_desc_id
           LEFT JOIN ads_main.d_customer_account d_customer_account
                     ON d_customer_account.customer_account_id = f_ticket_sales_event_seat.customer_account_id
           LEFT JOIN ads_main.d_customer_master d_customer_master
                     ON d_customer_account.customer_master_index = d_customer_master.customer_master_index
  WHERE d_event_plan.event_business_unit::text = 'HOLIDAY FAMILY SHOWS'::text
    AND d_event_plan.tm_arena_name::text = 'HULU THEATER AT MSG'::text
    AND d_event_plan.report_event_flag::text = 'Y'::text
    AND d_ticket_type_desc.ticket_product_description::text = 'Individuals'::text
    AND COALESCE(d_customer_account.customer_master_index, -1) <> -1
    AND d_event_plan.tm_season_name::text <> '2017 ELF The Musical'::text
  GROUP BY d_event_plan.tm_season_name, d_customer_account.customer_master_index, d_event_plan.tm_season_year,
           d_customer_master.exclude_flag, d_customer_master.city, d_customer_master.county,
           d_customer_master.reporting_state, d_customer_master.reporting_country_group, d_event_plan.tm_arena_latitude,
           d_event_plan.tm_arena_longitude, d_customer_master.latitude, d_customer_master.longitude,
           d_customer_master.reporting_country_group, d_customer_master.age, d_customer_master.gender,
           d_customer_master.estimated_household_income_range, d_customer_master.marital_status,
           d_customer_master.presence_of_children_flag, d_customer_master.presence_of_children_age_0_3_flag,
           d_customer_master.presence_of_children_age_4_6_flag, d_customer_master.presence_of_children_age_7_9_flag,
           d_customer_master.presence_of_children_age_10_12_flag, d_customer_master.presence_of_children_age_13_15_flag,
           d_customer_master.presence_of_children_age_16_18_flag, d_customer_master.household_nba_enthusiast_flag,
           d_customer_master.household_nhl_enthusiast_flag, d_customer_master.household_sports_enthusiast_flag,
           d_customer_master.homeowner_flag, d_customer_master.education_level, d_customer_master.occupation,
           d_customer_master.occupation_group, d_customer_master.number_of_adults_in_household,
           d_customer_master.mosaic_household, d_customer_master.estimated_net_assets_range,
           d_customer_master.e_tech_group
  HAVING sum(f_ticket_sales_event_seat.tickets_sold) > 0)
 UNION ALL
 SELECT d_event_plan.event_business_unit                                                 AS event_business_season,
        d_customer_account.customer_master_index,
        d_event_plan.tm_season_year,
        min(f_ticket_sales_event_seat.ticket_sale_report_date)                           AS season_year_first_purchase_day_id,
        "max"(f_ticket_sales_event_seat.ticket_sale_report_date)                         AS season_year_last_purchase_day_id,
        count(DISTINCT f_ticket_sales_event_seat.ticket_sale_report_date)                AS season_year_distinct_purchase_day_id_count,
        min(d_event_plan.tm_season_year)
        OVER (
            PARTITION BY d_customer_account.customer_master_index
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)                    AS first_season_year,
        lead(d_event_plan.tm_season_year)
        OVER (
            PARTITION BY d_customer_account.customer_master_index
            ORDER BY d_event_plan.tm_season_year DESC)                                   AS last_season_prior_to_current_season_year,
        (pg_catalog.dense_rank()
         OVER (
             PARTITION BY d_customer_account.customer_master_index
             ORDER BY d_event_plan.tm_season_year)) -
        1                                                                                AS number_of_prior_season_purchased_count,
        CASE
            WHEN (pg_catalog.dense_rank()
                  OVER (
                      PARTITION BY d_customer_account.customer_master_index
                      ORDER BY d_event_plan.tm_season_year)) = 1 THEN 'New'::text
            ELSE 'Repeat'::text
            END::character varying                                                       AS property_repeat_flag,
        d_customer_master.city,
        d_customer_master.county,
        d_customer_master.reporting_state,
        d_customer_master.reporting_country_group,
        CASE
            WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                       d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                THEN NULL::double precision
            ELSE ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                       d_customer_master.latitude, d_customer_master.longitude)::double precision
            END                                                                          AS distance,
        CASE
            WHEN d_customer_master.reporting_country_group::text = 'United States of America'::text THEN
                CASE
                    WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                               d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                        THEN 'US Unknown'::text
                    WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                     d_customer_master.latitude,
                                                     d_customer_master.longitude)::double precision, 0::numeric) <=
                         50::double precision THEN 'Within 50 Miles'::text
                    WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                     d_customer_master.latitude,
                                                     d_customer_master.longitude)::double precision, 0::numeric) <=
                         75::double precision THEN 'Between 51 and 75 Miles'::text
                    WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                     d_customer_master.latitude,
                                                     d_customer_master.longitude)::double precision, 0::numeric) <=
                         300::double precision THEN 'Between 76 and 300 Miles'::text
                    ELSE 'Rest of United States'::text
                    END
            ELSE
                CASE
                    WHEN COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <>
                         ''::text AND
                         COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <> 'Unknown'::text
                        THEN 'International'::text
                    ELSE 'Unknown'::text
                    END
            END::character varying                                                       AS distance_category,
        d_customer_master.exclude_flag,
        d_customer_master.age,
        d_customer_master.gender,
        d_customer_master.estimated_household_income_range,
        d_customer_master.marital_status,
        d_customer_master.presence_of_children_flag,
        d_customer_master.presence_of_children_age_0_3_flag,
        d_customer_master.presence_of_children_age_4_6_flag,
        d_customer_master.presence_of_children_age_7_9_flag,
        d_customer_master.presence_of_children_age_10_12_flag,
        d_customer_master.presence_of_children_age_13_15_flag,
        d_customer_master.presence_of_children_age_16_18_flag,
        d_customer_master.household_nba_enthusiast_flag,
        d_customer_master.household_nhl_enthusiast_flag,
        d_customer_master.household_sports_enthusiast_flag,
        d_customer_master.homeowner_flag,
        d_customer_master.education_level,
        d_customer_master.occupation,
        d_customer_master.occupation_group,
        d_customer_master.number_of_adults_in_household,
        d_customer_master.mosaic_household,
        d_customer_master.estimated_net_assets_range,
        d_customer_master.e_tech_group,
        sum(COALESCE(f_ticket_sales_event_seat.tickets_sold, 0))                         AS tickets_sold,
        sum(COALESCE(f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)) AS tickets_total_gross_revenue,
        sum(COALESCE(f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric))   AS tickets_total_net_revenue,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text
                        THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                    ELSE 0
                    END)                                                                 AS individual_full_price_tickets_sold,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                            f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                    ELSE 0::numeric
                    END)                                                                 AS individual_full_price_tickets_total_gross_revenue,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                            f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                    ELSE 0::numeric
                    END)                                                                 AS individual_full_price_tickets_total_net_revenue,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text
                        THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                    ELSE 0
                    END)                                                                 AS individual_discount_tickets_sold,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                            f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                    ELSE 0::numeric
                    END)                                                                 AS individual_discount_tickets_total_gross_revenue,
        sum(
                CASE
                    WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                            f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                    ELSE 0::numeric
                    END)                                                                 AS individual_discount_tickets_total_net_revenue
 FROM ads_main.f_ticket_sales_event_seat f_ticket_sales_event_seat
          LEFT JOIN ads_main.d_event_plan d_event_plan
                    ON f_ticket_sales_event_seat.event_plan_id = d_event_plan.event_plan_id
          LEFT JOIN ads_main.d_ticket_type_flags d_ticket_type_flags
                    ON f_ticket_sales_event_seat.ticket_type_flag_id = d_ticket_type_flags.ticket_type_flag_id
          LEFT JOIN ads_main.d_ticket_type_desc d_ticket_type_desc
                    ON f_ticket_sales_event_seat.ticket_type_desc_id = d_ticket_type_desc.ticket_type_desc_id
          LEFT JOIN ads_main.d_customer_account d_customer_account
                    ON d_customer_account.customer_account_id = f_ticket_sales_event_seat.customer_account_id
          LEFT JOIN ads_main.d_customer_master d_customer_master
                    ON d_customer_account.customer_master_index = d_customer_master.customer_master_index
 WHERE d_event_plan.event_business_unit::text = 'RANGERS'::text
   AND d_event_plan.report_event_flag::text = 'Y'::text
   AND (d_event_plan.tm_season_name::text = '2015-16 New York Rangers'::text OR
        d_event_plan.tm_season_name::text = '2016-17 New York Rangers'::text OR
        d_event_plan.tm_season_name::text = '2017-18 New York Rangers'::text OR
        d_event_plan.tm_season_name::text = '2018-19 New York Rangers'::text OR
        d_event_plan.tm_season_name::text = 'RNG 2019-20 New York Rangers'::text OR
        d_event_plan.tm_season_name::text = 'RNG 2020-21 NYR CV19'::text OR
        d_event_plan.tm_season_name::text = 'RNG 2021-22 New York Rangers'::text)
   AND d_ticket_type_desc.ticket_product_description::text = 'Individuals'::text
   AND COALESCE(d_customer_account.customer_master_index, -1) <> -1
 GROUP BY d_event_plan.event_business_unit, d_customer_account.customer_master_index, d_event_plan.tm_season_year,
          d_customer_master.exclude_flag, d_customer_master.city, d_customer_master.county,
          d_customer_master.reporting_state, d_customer_master.reporting_country_group, d_event_plan.tm_arena_latitude,
          d_event_plan.tm_arena_longitude, d_customer_master.latitude, d_customer_master.longitude,
          d_customer_master.reporting_country_group, d_customer_master.age, d_customer_master.gender,
          d_customer_master.estimated_household_income_range, d_customer_master.marital_status,
          d_customer_master.presence_of_children_flag, d_customer_master.presence_of_children_age_0_3_flag,
          d_customer_master.presence_of_children_age_4_6_flag, d_customer_master.presence_of_children_age_7_9_flag,
          d_customer_master.presence_of_children_age_10_12_flag, d_customer_master.presence_of_children_age_13_15_flag,
          d_customer_master.presence_of_children_age_16_18_flag, d_customer_master.household_nba_enthusiast_flag,
          d_customer_master.household_nhl_enthusiast_flag, d_customer_master.household_sports_enthusiast_flag,
          d_customer_master.homeowner_flag, d_customer_master.education_level, d_customer_master.occupation,
          d_customer_master.occupation_group, d_customer_master.number_of_adults_in_household,
          d_customer_master.mosaic_household, d_customer_master.estimated_net_assets_range,
          d_customer_master.e_tech_group
 HAVING sum(f_ticket_sales_event_seat.tickets_sold) > 0)
UNION ALL
SELECT d_event_plan.event_business_unit                                                 AS event_business_season,
       d_customer_account.customer_master_index,
       d_event_plan.tm_season_year,
       min(f_ticket_sales_event_seat.ticket_sale_report_date)                           AS season_year_first_purchase_day_id,
       "max"(f_ticket_sales_event_seat.ticket_sale_report_date)                         AS season_year_last_purchase_day_id,
       count(DISTINCT f_ticket_sales_event_seat.ticket_sale_report_date)                AS season_year_distinct_purchase_day_id_count,
       min(d_event_plan.tm_season_year)
       OVER (
           PARTITION BY d_customer_account.customer_master_index
           ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)                    AS first_season_year,
       lead(d_event_plan.tm_season_year)
       OVER (
           PARTITION BY d_customer_account.customer_master_index
           ORDER BY d_event_plan.tm_season_year DESC)                                   AS last_season_prior_to_current_season_year,
       (pg_catalog.dense_rank()
        OVER (
            PARTITION BY d_customer_account.customer_master_index
            ORDER BY d_event_plan.tm_season_year)) -
       1                                                                                AS number_of_prior_season_purchased_count,
       CASE
           WHEN (pg_catalog.dense_rank()
                 OVER (
                     PARTITION BY d_customer_account.customer_master_index
                     ORDER BY d_event_plan.tm_season_year)) = 1 THEN 'New'::text
           ELSE 'Repeat'::text
           END::character varying                                                       AS property_repeat_flag,
       d_customer_master.city,
       d_customer_master.county,
       d_customer_master.reporting_state,
       d_customer_master.reporting_country_group,
       CASE
           WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                      d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
               THEN NULL::double precision
           ELSE ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                      d_customer_master.latitude, d_customer_master.longitude)::double precision
           END                                                                          AS distance,
       CASE
           WHEN d_customer_master.reporting_country_group::text = 'United States of America'::text THEN
               CASE
                   WHEN ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                              d_customer_master.latitude, d_customer_master.longitude)::text = ''::text
                       THEN 'US Unknown'::text
                   WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                    d_customer_master.latitude,
                                                    d_customer_master.longitude)::double precision, 0::numeric) <=
                        50::double precision THEN 'Within 50 Miles'::text
                   WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                    d_customer_master.latitude,
                                                    d_customer_master.longitude)::double precision, 0::numeric) <=
                        75::double precision THEN 'Between 51 and 75 Miles'::text
                   WHEN round(ads_main.geo_distance(d_event_plan.tm_arena_latitude, d_event_plan.tm_arena_longitude,
                                                    d_customer_master.latitude,
                                                    d_customer_master.longitude)::double precision, 0::numeric) <=
                        300::double precision THEN 'Between 76 and 300 Miles'::text
                   ELSE 'Rest of United States'::text
                   END
           ELSE
               CASE
                   WHEN COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <> ''::text AND
                        COALESCE(d_customer_master.reporting_country_group, ''::character varying)::text <> 'Unknown'::text
                       THEN 'International'::text
                   ELSE 'Unknown'::text
                   END
           END::character varying                                                       AS distance_category,
       d_customer_master.exclude_flag,
       d_customer_master.age,
       d_customer_master.gender,
       d_customer_master.estimated_household_income_range,
       d_customer_master.marital_status,
       d_customer_master.presence_of_children_flag,
       d_customer_master.presence_of_children_age_0_3_flag,
       d_customer_master.presence_of_children_age_4_6_flag,
       d_customer_master.presence_of_children_age_7_9_flag,
       d_customer_master.presence_of_children_age_10_12_flag,
       d_customer_master.presence_of_children_age_13_15_flag,
       d_customer_master.presence_of_children_age_16_18_flag,
       d_customer_master.household_nba_enthusiast_flag,
       d_customer_master.household_nhl_enthusiast_flag,
       d_customer_master.household_sports_enthusiast_flag,
       d_customer_master.homeowner_flag,
       d_customer_master.education_level,
       d_customer_master.occupation,
       d_customer_master.occupation_group,
       d_customer_master.number_of_adults_in_household,
       d_customer_master.mosaic_household,
       d_customer_master.estimated_net_assets_range,
       d_customer_master.e_tech_group,
       sum(COALESCE(f_ticket_sales_event_seat.tickets_sold, 0))                         AS tickets_sold,
       sum(COALESCE(f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)) AS tickets_total_gross_revenue,
       sum(COALESCE(f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric))   AS tickets_total_net_revenue,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text
                       THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                   ELSE 0
                   END)                                                                 AS individual_full_price_tickets_sold,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                           f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                   ELSE 0::numeric
                   END)                                                                 AS individual_full_price_tickets_total_gross_revenue,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Full Price'::text THEN COALESCE(
                           f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                   ELSE 0::numeric
                   END)                                                                 AS individual_full_price_tickets_total_net_revenue,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text
                       THEN COALESCE(f_ticket_sales_event_seat.tickets_sold, 0)
                   ELSE 0
                   END)                                                                 AS individual_discount_tickets_sold,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                           f_ticket_sales_event_seat.tickets_total_gross_revenue, 0::numeric)
                   ELSE 0::numeric
                   END)                                                                 AS individual_discount_tickets_total_gross_revenue,
       sum(
               CASE
                   WHEN d_ticket_type_desc.ticket_type_desc::text = 'Individual - Discount'::text THEN COALESCE(
                           f_ticket_sales_event_seat.tickets_total_net_revenue, 0::numeric)
                   ELSE 0::numeric
                   END)                                                                 AS individual_discount_tickets_total_net_revenue
FROM ads_main.f_ticket_sales_event_seat f_ticket_sales_event_seat
         LEFT JOIN ads_main.d_event_plan d_event_plan
                   ON f_ticket_sales_event_seat.event_plan_id = d_event_plan.event_plan_id
         LEFT JOIN ads_main.d_ticket_type_flags d_ticket_type_flags
                   ON f_ticket_sales_event_seat.ticket_type_flag_id = d_ticket_type_flags.ticket_type_flag_id
         LEFT JOIN ads_main.d_ticket_type_desc d_ticket_type_desc
                   ON f_ticket_sales_event_seat.ticket_type_desc_id = d_ticket_type_desc.ticket_type_desc_id
         LEFT JOIN ads_main.d_customer_account d_customer_account
                   ON d_customer_account.customer_account_id = f_ticket_sales_event_seat.customer_account_id
         LEFT JOIN ads_main.d_customer_master d_customer_master
                   ON d_customer_account.customer_master_index = d_customer_master.customer_master_index
WHERE d_event_plan.event_business_unit::text = 'KNICKS'::text
  AND d_event_plan.report_event_flag::text = 'Y'::text
  AND (d_event_plan.tm_season_name::text = '2015-16 New York Knicks'::text OR
       d_event_plan.tm_season_name::text = '2016-17 New York Knicks'::text OR
       d_event_plan.tm_season_name::text = '2017-18 New York Knicks'::text OR
       d_event_plan.tm_season_name::text = '2018-19 New York Knicks'::text OR
       d_event_plan.tm_season_name::text = 'KNK 2019-20 New York Knicks'::text OR
       d_event_plan.tm_season_name::text = 'KNK 2020-21 NYK CV19'::text OR
       d_event_plan.tm_season_name::text = 'KNK 2021-22 New York Knicks'::text)
  AND d_ticket_type_desc.ticket_product_description::text = 'Individuals'::text
  AND COALESCE(d_customer_account.customer_master_index, -1) <> -1
GROUP BY d_event_plan.event_business_unit, d_customer_account.customer_master_index, d_event_plan.tm_season_year,
         d_customer_master.exclude_flag, d_customer_master.city, d_customer_master.county,
         d_customer_master.reporting_state, d_customer_master.reporting_country_group, d_event_plan.tm_arena_latitude,
         d_event_plan.tm_arena_longitude, d_customer_master.latitude, d_customer_master.longitude,
         d_customer_master.reporting_country_group, d_customer_master.age, d_customer_master.gender,
         d_customer_master.estimated_household_income_range, d_customer_master.marital_status,
         d_customer_master.presence_of_children_flag, d_customer_master.presence_of_children_age_0_3_flag,
         d_customer_master.presence_of_children_age_4_6_flag, d_customer_master.presence_of_children_age_7_9_flag,
         d_customer_master.presence_of_children_age_10_12_flag, d_customer_master.presence_of_children_age_13_15_flag,
         d_customer_master.presence_of_children_age_16_18_flag, d_customer_master.household_nba_enthusiast_flag,
         d_customer_master.household_nhl_enthusiast_flag, d_customer_master.household_sports_enthusiast_flag,
         d_customer_master.homeowner_flag, d_customer_master.education_level, d_customer_master.occupation,
         d_customer_master.occupation_group, d_customer_master.number_of_adults_in_household,
         d_customer_master.mosaic_household, d_customer_master.estimated_net_assets_range,
         d_customer_master.e_tech_group
HAVING sum(f_ticket_sales_event_seat.tickets_sold) > 0;

alter table vw_event_business_season_repeaters
    owner to ads_main;

