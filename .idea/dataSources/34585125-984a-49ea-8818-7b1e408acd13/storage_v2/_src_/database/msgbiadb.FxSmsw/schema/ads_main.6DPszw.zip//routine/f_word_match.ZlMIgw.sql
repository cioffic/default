create function f_word_match(input_string character varying, pattern character varying) returns integer
    stable
    language plpythonu
as
$$
import re
regex =   pattern
if re.search(regex, re.escape(input_string)):
   match = re.search(regex,input_string)
   return 1
else:
   return 0
$$;

