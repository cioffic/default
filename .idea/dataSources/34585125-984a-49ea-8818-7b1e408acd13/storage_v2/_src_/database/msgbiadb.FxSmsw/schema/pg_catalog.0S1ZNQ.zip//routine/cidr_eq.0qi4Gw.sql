create function cidr_eq(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_eq($1::inet, $2::inet)
$$;

