CREATE or replace view ads_staging.avw_exctgt_sendjobs
as
select clientid,
       sendid,
       fromname,
       fromemail,
       schedtime :: datetime,
       senttime :: datetime,
       subject,
       emailname,
       triggeredsendexternalkey,
       senddefinitionexternalkey,
       jobstatus,
       previewurl,
       ismultipart,
       additional,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_sendjobs
with no schema binding;

alter table avw_exctgt_sendjobs
    owner to ads_staging;

