create or replace view ads_staging.avw_stg_tfs_incidents_resolutions as
select a.resolution_id,
       a.resolution_name,
       a.resolution_count
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.resolutions a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_resolutions
    owner to ads_staging;

