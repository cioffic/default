create view avw_api_vendor_reports
as
select status,
       id,
       venue_id,
       status_description,
       vendor_status,
       name,
       ext_vendor_id,
       pt_year,
       pt_month,
       pt_day
FROM appetize.api_vendor_reports
where pt_year = '2021'
  and pt_month = '02'
with no schema binding;

alter table avw_api_vendor_reports
    owner to ads_main;

