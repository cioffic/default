CREATE OR REPLACE view ads_staging.avw_mpd_experian_groups as

select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       group_type::VARCHAR(255),
       group_start::int,
       group_end::int,
       group_value::VARCHAR(255)

from ext_staging.mpd_experian_groups
with no schema binding;

alter table avw_mpd_experian_groups
    owner to ads_staging;

