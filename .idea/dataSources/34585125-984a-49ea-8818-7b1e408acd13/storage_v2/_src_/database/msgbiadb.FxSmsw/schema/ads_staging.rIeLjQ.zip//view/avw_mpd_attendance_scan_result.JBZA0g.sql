create or replace view ads_staging.avw_mpd_attendance_scan_result
as
select attendance_scan_result_code :: int,
       attendance_scan_result_desc
from ext_staging.mpd_attendance_scan_result
with no schema binding;

alter table avw_mpd_attendance_scan_result
    owner to ads_staging;

