create view check_constraints(constraint_catalog, constraint_schema, constraint_name, check_clause) as
SELECT current_database()::information_schema.sql_identifier                            AS constraint_catalog,
       rs.nspname::information_schema.sql_identifier                                    AS constraint_schema,
       con.conname::information_schema.sql_identifier                                   AS constraint_name,
       "substring"(pg_get_constraintdef(con.oid), 7)::information_schema.character_data AS check_clause
FROM pg_namespace rs,
     pg_constraint con
         LEFT JOIN pg_class c ON c.oid = con.conrelid
         LEFT JOIN pg_type t ON t.oid = con.contypid,
     pg_user u
WHERE rs.oid = con.connamespace
  AND u.usesysid = COALESCE(c.relowner, t.typowner)
  AND u.usename = "current_user"()::name
  AND con.contype = 'c'::"char";

alter table check_constraints
    owner to rdsdb;

