create function f_null_syns(a character varying) returns boolean
    stable
    language plpythonu
as
$$
    s = {"null", "invalid", "unknown", "n/a", "not applicable", "void", "nothing", "nonexistent", "null and void"}
    b = str(a).lower()
    return b in s
$$;

