create function substring(bit, integer) returns bit
    immutable
    language sql
as
$$
    select pg_catalog.substring($1, $2, -1)
$$;

comment on function substring(bit, integer) is 'return portion of bitstring';

