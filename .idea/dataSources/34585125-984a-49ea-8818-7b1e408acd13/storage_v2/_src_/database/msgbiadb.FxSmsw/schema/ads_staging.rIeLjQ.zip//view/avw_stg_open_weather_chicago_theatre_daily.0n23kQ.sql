CREATE OR REPLACE VIEW ads_staging.avw_stg_open_weather_chicago_theatre_daily
AS
Select *
From (
         Select timestamp 'epoch' + dt * interval '1 second'      AS                             dtime,
                timestamp 'epoch' + sunrise * interval '1 second' AS                             sunrise_dtime,
                timestamp 'epoch' + sunset * interval '1 second'                                 ASsunset_dtime,
                ((day - 273.15) * 1.8) + 32                       AS                             day,
                ((min - 273.15) * 1.8) + 32                       AS                             min,
                ((max - 273.15) * 1.8) + 32                       AS                             max,
                ((night - 273.15) * 1.8) + 32                     AS                             night,
                ((eve - 273.15) * 1.8) + 32                       AS                             eve,
                ((morn - 273.15) * 1.8) + 32                      AS                             morn,
                pressure,
                humidity,
                dew_point,
                wind_speed,
                wind_deg,
                id,
                main,
                description,
                icon,
                clouds,
                uvi,
                rain,
                ads_staging.f_s3_parse_athena_filename("$path")   as                             ads_source_file,
                'MSG'                                             as                             ads_source,
                max(ads_source_file)
                over (partition by cast((timestamp 'epoch' + dt * interval '1 second') as date)) last_reading_per_day
         from open_weather.open_weather_daily_reports
     ) der
Where der.last_reading_per_day = der.ads_source_file
with no schema binding;

alter table avw_stg_open_weather_chicago_theatre_daily
    owner to ads_staging;

