create or replace view ads_staging.avw_stg_tfs_incidents_customfields as
select a.custom_field_header,
       a.custom_field_name,
       a.custom_field_type,
       a.custom_field_value,
       a.custom_field_options
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.customfields a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_customfields
    owner to ads_staging;

