create or replace view ads_staging.avw_mpd_mktg_event_business_unit_to_be_deleted as

select distinct legacy_marketing_business_unit, event_business_unit
from ext_staging.mpd_mktg_legacy_current_business_unit a
         inner join ext_staging.mpd_mktg_event_business_unit b
                    on lower(a.current_marketing_business_unit) = lower(b.marketing_business_unit)
where event_business_unit != 'ALL'

UNION
select distinct legacy_marketing_business_unit, c.event_business_unit
from ext_staging.mpd_mktg_legacy_current_business_unit a
         inner join ext_staging.mpd_mktg_event_business_unit b
                    on lower(a.current_marketing_business_unit) = lower(b.marketing_business_unit)
         join ads_main.d_event_plan c on 1 = 1
where b.event_business_unit = 'ALL'
  and c.event_business_unit is not null
with no schema binding;

alter table avw_mpd_mktg_event_business_unit_to_be_deleted
    owner to ads_staging;

