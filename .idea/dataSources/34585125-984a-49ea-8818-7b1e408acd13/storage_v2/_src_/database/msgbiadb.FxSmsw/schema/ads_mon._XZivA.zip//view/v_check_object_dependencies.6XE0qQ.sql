create view v_check_object_dependencies
            (src_oid, src_schemaname, src_objectname, dependent_viewoid, dependent_schemaname, dependent_objectname) as
SELECT DISTINCT srcobj.oid     AS src_oid,
                srcnsp.nspname AS src_schemaname,
                srcobj.relname AS src_objectname,
                tgtobj.oid     AS dependent_viewoid,
                tgtnsp.nspname AS dependent_schemaname,
                tgtobj.relname AS dependent_objectname
FROM pg_class srcobj
         JOIN pg_depend srcdep ON srcobj.oid = srcdep.refobjid
         JOIN pg_depend tgtdep ON srcdep.objid = tgtdep.objid
         JOIN pg_class tgtobj ON tgtdep.refobjid = tgtobj.oid AND srcobj.oid <> tgtobj.oid
         LEFT JOIN pg_namespace srcnsp ON srcobj.relnamespace = srcnsp.oid
         LEFT JOIN pg_namespace tgtnsp ON tgtobj.relnamespace = tgtnsp.oid
WHERE tgtdep.deptype = 'i'::"char"
  AND tgtobj.relkind = 'v'::"char"
  AND (srcnsp.nspname = 'ads_main'::name OR srcnsp.nspname = 'ads_staging'::name OR srcnsp.nspname = 'ads_mon'::name)
ORDER BY srcnsp.nspname, srcobj.relname;

alter table v_check_object_dependencies
    owner to shahas;

