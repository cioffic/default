create or replace view ads_staging.avw_stg_spotify_charts as
select a.disc_number
     , a.duration_ms
     , a.episode
     , a.explicit
     , a.href
     , a.id
     , a.is_local
     , a.name
     , a.popularity
     , a.preview_url
     , a.track
     , a.track_number
     , a.type
     , a.uri
     , artists.name as artist
     , partition_0  as chart
-- ,ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file
from ext_staging.stg_spotify_chartssource a
         left join a.artists artists on true
with no schema binding;

alter table avw_stg_spotify_charts
    owner to ads_staging;

