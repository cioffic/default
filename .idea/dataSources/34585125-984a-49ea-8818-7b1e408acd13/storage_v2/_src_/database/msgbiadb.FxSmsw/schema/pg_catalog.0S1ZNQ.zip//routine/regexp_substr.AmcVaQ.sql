create function regexp_substr(text, text) returns text
    immutable
    language sql
as
$$
    select regexp_substr($1, $2, 1, 1, '')
$$;

comment on function regexp_substr(text, text) is 'extracts text matching regular expression';

