create view ads_staging.avw_kore_premiumdeal as
select *
from ext_staging.stg_kore_premiumdeal
with no schema binding;

alter table avw_kore_premiumdeal
    owner to ads_staging;

