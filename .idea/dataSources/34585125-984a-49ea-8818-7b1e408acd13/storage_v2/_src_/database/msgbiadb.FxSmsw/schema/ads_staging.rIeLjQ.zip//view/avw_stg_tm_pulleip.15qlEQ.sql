CREATE or replace VIEW ads_staging.avw_stg_tm_pulleip as
SELECT ads_staging.f_s3_parse_athena_filename("$path") ads_source_file,
       child_is_plan,
       event_Date,
       event_id,
       event_name,
       event_time,
       game_number,
       plan_event_id,
       plan_event_name,
       plan_group_id,
       plan_group_name,
       plan_total_events,
       plan_type,
       season_id,
       seq_num,
       team,
       tm_event_name,
       total_events
FROM ext_staging.stg_crmapi_pulleip
WHERE "$path" = (SELECT MAX("$path") FROM ext_staging.stg_crmapi_pulleip)
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_pulleip
    owner to ads_staging;

