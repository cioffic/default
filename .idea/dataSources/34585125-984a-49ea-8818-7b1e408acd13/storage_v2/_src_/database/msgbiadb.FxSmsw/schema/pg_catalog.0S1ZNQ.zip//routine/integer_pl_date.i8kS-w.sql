create function integer_pl_date(integer, date) returns date
    immutable
    language sql
as
$$
    select $2 + $1
$$;

