create view ads_staging.avw_kore_premiumdeallocation as
select *
from ext_staging.stg_kore_premiumdeallocation
with no schema binding;

alter table avw_kore_premiumdeallocation
    owner to ads_staging;

