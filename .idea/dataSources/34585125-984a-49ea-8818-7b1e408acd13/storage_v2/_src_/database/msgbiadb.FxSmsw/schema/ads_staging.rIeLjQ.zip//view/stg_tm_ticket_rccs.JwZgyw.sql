CREATE VIEW ads_staging.stg_tm_ticket_rccs AS
SELECT *
FROM ext_staging.stg_tm_ticket_rccs
WITH NO SCHEMA BINDING;

alter table stg_tm_ticket_rccs
    owner to ads_main;

