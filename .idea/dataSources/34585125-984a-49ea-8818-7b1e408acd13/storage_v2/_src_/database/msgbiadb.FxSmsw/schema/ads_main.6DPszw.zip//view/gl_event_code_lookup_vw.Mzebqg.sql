create view gl_event_code_lookup_vw
            (cstm_src_filename, cstm_incremental_full_load_flg, cstm_source, cstm_load_timestamp, cstm_processed_flag,
             cstm_feed_version, cstm_line_number, cstm_ads_uuid, tmeventcode, pl_entity, bs_entity, def, dept, acct,
             venue, evt_type, event, perf, prog, int, dr, cr, descr, event_date)
as
SELECT a.cstm_src_filename,
       a.cstm_incremental_full_load_flg,
       a.cstm_source,
       a.cstm_load_timestamp,
       a.cstm_processed_flag,
       a.cstm_feed_version,
       a.cstm_line_number,
       a.cstm_ads_uuid,
       a.tmeventcode,
       a.pl_entity,
       a.bs_entity,
       a.def,
       a.dept,
       a.acct,
       a.venue,
       a.evt_type,
       a.event,
       a.perf,
       a.prog,
       a."int",
       a.dr,
       a.cr,
       a.descr,
       a.event_date
FROM (SELECT stg_gl_event_code_lookup.tmeventcode,
             stg_gl_event_code_lookup.event,
             stg_gl_event_code_lookup.perf,
             "max"(stg_gl_event_code_lookup.cstm_src_filename::text) AS max_cstm_src_filename
      FROM ads_staging.stg_gl_event_code_lookup
      GROUP BY stg_gl_event_code_lookup.tmeventcode, stg_gl_event_code_lookup.event,
               stg_gl_event_code_lookup.perf) max_filename
         JOIN ads_staging.stg_gl_event_code_lookup a
              ON a.tmeventcode::text = max_filename.tmeventcode::text AND a.event::text = max_filename.event::text AND
                 a.perf::text = max_filename.perf::text AND
                 a.cstm_src_filename::text = max_filename.max_cstm_src_filename;

alter table gl_event_code_lookup_vw
    owner to ads_main;

