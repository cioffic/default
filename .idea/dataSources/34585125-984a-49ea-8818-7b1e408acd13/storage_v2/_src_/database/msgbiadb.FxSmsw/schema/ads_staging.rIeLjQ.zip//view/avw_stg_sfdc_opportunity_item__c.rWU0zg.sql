create or replace view ads_staging.avw_stg_sfdc_opportunity_item__c
as
SELECT *
FROM ext_staging.stg_sfdc_opportunity_item__c
with no schema binding;

alter table avw_stg_sfdc_opportunity_item__c
    owner to ads_staging;

