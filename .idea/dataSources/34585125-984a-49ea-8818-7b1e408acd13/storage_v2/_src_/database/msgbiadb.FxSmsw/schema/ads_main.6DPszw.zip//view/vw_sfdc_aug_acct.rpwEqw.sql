create view vw_sfdc_aug_acct
            (acct_id, dynamics_acct_id, contact_id, is_person_acct, record_type_name, owner_id, owner_name, acct_name,
             first_name, last_name, acct_flag, primary_archtics_id, acct_industry, mp_acct_status, customer_type,
             customer_subtype, job_title, number_of_employees, phone_number, email, street, city, state, zipcode,
             country, parent_acct_name, parent_acct_id, parent_acct_dynamics_acct_id, parent_acct_flag,
             parent_acct_mp_acct_status, parent_acct_budget, parent_acct_customer_type, parent_acct_customer_subtype,
             parent_acct_annual_revenue, parent_acct_number_of_employees, last_contacted, last_contacted_by)
as
SELECT DISTINCT a.id                                    AS acct_id,
                a.account_legacy_dynamics_id__c         AS dynamics_acct_id,
                a.personcontactid                       AS contact_id,
                a.ispersonaccount                       AS is_person_acct,
                rt.name                                 AS record_type_name,
                a.ownerid                               AS owner_id,
                tou.name                                AS owner_name,
                a.name                                  AS acct_name,
                a.firstname                             AS first_name,
                a.lastname                              AS last_name,
                a.account_flag__c                       AS acct_flag,
                a.koreps__primary_ticketing_account__pc AS primary_archtics_id,
                a.koreps__sponsorshipindustry__c        AS acct_industry,
                a.mp_account_status__c                  AS mp_acct_status,
                a."type"                                AS customer_type,
                a.sub_type__c                           AS customer_subtype,
                a.job_title__pc                         AS job_title,
                a.number_of_employees__c                AS number_of_employees,
                CASE
                    WHEN a.phone IS NOT NULL AND a.phone::text <> 'na'::text AND a.phone::text <> 'n/a'::text AND
                         a.phone::text <> 'INVALID FORMAT'::text THEN a.phone
                    WHEN a.personmobilephone IS NOT NULL AND a.personmobilephone::text <> 'na'::text AND
                         a.personmobilephone::text <> 'n/a'::text AND a.personmobilephone::text <> 'INVALID FORMAT'::text
                        THEN a.personmobilephone
                    WHEN a.personhomephone IS NOT NULL AND a.personhomephone::text <> 'na'::text AND
                         a.personhomephone::text <> 'n/a'::text AND a.personhomephone::text <> 'INVALID FORMAT'::text
                        THEN a.personhomephone
                    ELSE NULL::character varying
                    END                                 AS phone_number,
                CASE
                    WHEN a.personemail IS NOT NULL THEN a.personemail
                    WHEN a.secondary_email__pc IS NOT NULL THEN a.secondary_email__pc
                    WHEN a.other_email__pc IS NOT NULL THEN a.other_email__pc
                    ELSE NULL::character varying
                    END                                 AS email,
                CASE
                    WHEN a.ispersonaccount = true THEN a.personmailingstreet
                    ELSE a.billingstreet
                    END                                 AS street,
                CASE
                    WHEN a.ispersonaccount = true THEN a.personmailingcity
                    ELSE a.billingcity
                    END                                 AS city,
                CASE
                    WHEN a.ispersonaccount = true THEN a.personmailingstate
                    ELSE a.billingstate
                    END                                 AS state,
                CASE
                    WHEN a.ispersonaccount = true THEN a.personmailingpostalcode
                    ELSE a.billingpostalcode
                    END                                 AS zipcode,
                CASE
                    WHEN a.ispersonaccount = true THEN a.personmailingcountry
                    ELSE a.billingcountry
                    END                                 AS country,
                pa.name                                 AS parent_acct_name,
                pa.id                                   AS parent_acct_id,
                pa.account_legacy_dynamics_id__c        AS parent_acct_dynamics_acct_id,
                pa.account_flag__c                      AS parent_acct_flag,
                pa.mp_account_status__c                 AS parent_acct_mp_acct_status,
                pa.budget__c                            AS parent_acct_budget,
                pa."type"                               AS parent_acct_customer_type,
                pa.sub_type__c                          AS parent_acct_customer_subtype,
                pa.annualrevenue                        AS parent_acct_annual_revenue,
                pa.number_of_employees__c               AS parent_acct_number_of_employees,
                a.last_contacted__c                     AS last_contacted,
                a.last_contacted_by__c                  AS last_contacted_by
FROM ads_main.sfdc_account a
         LEFT JOIN ads_main.sfdc_koreps__industry__c i ON a.koreps__sponsorshipindustry__c::text = i.id::text
         LEFT JOIN ads_main.sfdc_accountcontactrelation acr ON a.personcontactid::text = acr.contactid::text
         LEFT JOIN ads_main.sfdc_account pa ON acr.accountid::text = pa.id::text
         LEFT JOIN ads_main.sfdc_recordtype rt ON a.recordtypeid::text = rt.id::text
         LEFT JOIN ads_main.sfdc_user tou ON a.ownerid::text = tou.id::text
WHERE a.isdeleted = false;

alter table vw_sfdc_aug_acct
    owner to ads_main;

