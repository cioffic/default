CREATE VIEW ads_staging.mpd_knicks_rangers_budget_fmb_scan AS
SELECT *
FROM ext_staging.mpd_knicks_rangers_budget_fmb_scan
WITH NO SCHEMA BINDING;

alter table mpd_knicks_rangers_budget_fmb_scan
    owner to ads_staging;

