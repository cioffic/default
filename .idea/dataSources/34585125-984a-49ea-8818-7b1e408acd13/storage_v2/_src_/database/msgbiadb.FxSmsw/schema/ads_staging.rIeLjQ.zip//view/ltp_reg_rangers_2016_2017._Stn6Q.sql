create or replace view ads_staging.ltp_reg_rangers_2016_2017
as
select *,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file
--, 'EATEC' as ads_source 
from ext_staging.ltp_reg_rangers_2016_2017
with no schema binding;

alter table ltp_reg_rangers_2016_2017
    owner to ads_staging;

