create view applicable_roles(grantee, role_name, is_grantable) as
SELECT "current_user"()::information_schema.sql_identifier                        AS grantee,
       g.groname::information_schema.sql_identifier                               AS role_name,
       'NO'::information_schema.character_data::information_schema.character_data AS is_grantable
FROM pg_group g,
     pg_user u
WHERE (u.usesysid = ANY (g.grolist))
  AND u.usename = "current_user"()::name;

alter table applicable_roles
    owner to rdsdb;

