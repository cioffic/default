create or replace view ads_staging.avw_mpd_budget_forecast_season_ticket_type as
(
select season_year,
       season_code,
       event_business_unit,
       to_date(week_ending, 'MM/DD/YYYY') as week_ending,
       ticket_type,
       cast(budget_tickets_sold as float)    budget_tickets_sold,
       cast(budget_tickets_revenue as float) budget_tickets_revenue,
       ads_source,
       venue,
       "$path"                            as ads_source_filename
from ext_staging.stg_budget_forecast_season_ticket_type
where season_code is not null
  and ticket_type <> 'Individual'
    )
with no schema binding;

alter table avw_mpd_budget_forecast_season_ticket_type
    owner to ads_staging;

