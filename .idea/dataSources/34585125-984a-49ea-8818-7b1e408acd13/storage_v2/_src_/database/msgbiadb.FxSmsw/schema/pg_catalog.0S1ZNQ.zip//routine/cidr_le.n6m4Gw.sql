create function cidr_le(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_le($1::inet, $2::inet)
$$;

