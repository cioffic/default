CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_pullcust_hourly
AS
select acct_type_desc
     , add_user
     , add_date
     , birth_date
     , replace(city, 'u0000', '')                      as city
     , replace(company_name, 'u0000', '')              as company_name
     , replace(country, 'u0000', '')                   as country
     , replace(email_addr, 'u0000', '')                as email_addr
     , ext_system1_id
     , ext_system2_id
     , fan_loyalty_id
     , gender
     , industry
     , replace(maiden_name, 'u0000', '')               as maiden_name
     , marital_status
     , replace(name_first, 'u0000', '')                as name_first
     , replace(name_last, 'u0000', '')                 as name_last
     , replace(name_title, 'u0000', '')                as name_title
     , replace(name_mi, 'u0000', '')                   as name_mi
     , old_acct_id
     , other_info_1
     , other_info_10
     , other_info_2
     , other_info_3
     , other_info_4
     , other_info_5
     , other_info_6
     , other_info_7
     , other_info_8
     , other_info_9
     , pin
     , replace(phone_day, 'u0000', '')                 as phone_day
     , replace(phone_eve, 'u0000', '')                 as phone_eve
     , replace(phone_fax, 'u0000', '')                 as phone_fax
     , primary_code
     , rec_status
     , relationship_type
     , replace(state, 'u0000', '')                     as state
     , sic_code
     , sic_name
     , since_date
     , source
     , source_desc
     , source_name
     , source_list_name
     , replace(street_addr_1, 'u0000', '')             as street_addr_1
     , replace(street_addr_2, 'u0000', '')             as street_addr_2
     , upd_user
     , upd_date
     , replace(zip, 'u0000', '')                       as zip
     , account_manager_access
     , account_nick_name
     , acct_id
     , acct_rep_name
     , acct_rep_num
     , admin_donation
     , admin_event_info
     , admin_invoice
     , admin_other
     , admin_rofr
     , cust_name_id
     , replace(email_addr2, 'u0000', '')               as email_addr2
     , household_id
     , main_acct_id_ind
     , name_type
     , other_info_11
     , other_info_12
     , other_info_13
     , other_info_14
     , other_info_15
     , other_info_16
     , other_info_17
     , other_info_18
     , other_info_19
     , other_info_20
     , replace(phone_cell, 'u0000', '')                as phone_cell
     , pk_id
     , points
     , points_itd
     , points_ytd
     , priority
     , replace(salutation, 'u0000', '')                as salutation
     , seq_num
     , replace(solicit_addr, 'u0000', '')              as solicit_addr
     , replace(solicit_email, 'u0000', '')             as solicit_email
     , replace(solicit_phone_cell, 'u0000', '')        as solicit_phone_cell
     , replace(solicit_phone_day, 'u0000', '')         as solicit_phone_day
     , replace(solicit_phone_eve, 'u0000', '')         as solicit_phone_eve
     , replace(solicit_phone_fax, 'u0000', '')         as solicit_phone_fax
     , "tag"                                           as tag1
     , ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file
     , 'MSG'                                           as ads_source
from ext_staging.stg_tm_pullcust_hourly
with no schema binding;

alter table avw_stg_tm_pullcust_hourly
    owner to ads_main;

