create or replace view ads_main.avw_legends_merch_orders as
select a.processed_at                order_processed_at
     , a.name                        order_name
     , a.number                      order_number
     , a.financial_status            order_financial_status
     , b.fulfillable_quantity        line_items_fulfillable_quantity
     , b.quantity                    line_items_quantity
     , b.sku                         line_items_sku
     , b.title                       line_items_title
     , b.variant_id                  line_items_variant_id
     , b.variant_title               line_items_variant_title
     , b.name                        line_items_name
     , b.price                       line_items_price
     , b.total_discount              line_items_total_discount
     , c.price                       line_items_tax_line_price
     , pt_year || pt_month || pt_day ads_source_file
from legends_merch.orders a
         left join a.line_items b on true
         left join b.tax_lines c on true
with no schema binding;

alter table avw_legends_merch_orders
    owner to etluser;

