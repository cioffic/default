create view ads_staging.zz_temp_full_file_update as
select *, "tag" as tag1, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'MSG' as ads_source
from ext_staging.zz_temp_full_file_update
        with
            no schema binding;

alter table zz_temp_full_file_update
    owner to ads_staging;

