CREATE OR REPLACE view ads_staging.avw_medallia_outgoing_rccs AS
select "$path":: VARCHAR(255)                                                as file_path
     , RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name
     , Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate
     , event_inventory_id::VARCHAR(255)
     , attraction_name::VARCHAR(255)
     , name_first::VARCHAR(40)
     , name_last::VARCHAR(80)
     , email_address::VARCHAR(100)
     , actual_tm_acct_id::VARCHAR(100)
     , actual_tm_order_id::VARCHAR(100)
     , x_number::VARCHAR(100)
     , ticket_type::VARCHAR(100)
     , tm_section_name::VARCHAR(6)
     , tm_row_name::VARCHAR(4)
     , tm_seat_num::int
     , ttl_tickets_at_cust_level::VARCHAR(100)
     , interaction_source::VARCHAR(100)
     , transaction_amount::VARCHAR(100)
     , city::VARCHAR(100)
     , state::VARCHAR(100)
     , zip::VARCHAR(100)
     , country::VARCHAR(100)
     , phone_day::VARCHAR(100)
     , employee_recognition_cmt_yn::VARCHAR(1)
     , digital_projection_cmt_yn::VARCHAR(1)
     , food_beverage_cmt_yn::VARCHAR(1)
     , merchandise_cmt_yn::VARCHAR(1)
     , navigation_cmt_yn::VARCHAR(1)
     , weekend_flag::VARCHAR(1)


from ext_staging.stg_medallia_outgoing_rccs
where "$path":: VARCHAR(255) not like '%testrun%'
with no schema binding;

alter table avw_medallia_outgoing_rccs
    owner to ads_staging;

