create view vw_stm_plans_customer
            (acct_type, customer_master_index, name_first, name_last, name_full, email_address, street_addr_1,
             street_addr_2, city, state, zip, country, knicks_plan_flag, rangers_plan_flag, liberty_plan_flag,
             rccs_flag, nydma_flag, engagement_filter_flag, rnk)
as
SELECT a.acct_type,
       a.customer_master_index,
       a.name_first,
       a.name_last,
       a.name_full,
       a.email_address,
       a.street_addr_1,
       a.street_addr_2,
       a.city,
       a.state,
       a.zip,
       a.country,
       a.knicks_plan_flag,
       a.rangers_plan_flag,
       a.liberty_plan_flag,
       a.rccs_flag,
       a.nydma_flag,
       a.engagement_filter_flag,
       a.rnk
FROM (SELECT a.acct_type,
             a.customer_master_index,
             a.name_first,
             a.name_last,
             a.name_full,
             a.email_address,
             a.street_addr_1,
             a.street_addr_2,
             a.city,
             a.state,
             a.zip,
             a.country,
             a.knicks_plan_flag,
             a.rangers_plan_flag,
             a.liberty_plan_flag,
             a.rccs_flag,
             a.nydma_flag,
             a.engagement_filter_flag,
             pg_catalog.row_number()
             OVER (
                 PARTITION BY a.customer_master_index
                 ORDER BY a.rccs_flag, a.knicks_plan_flag, a.rangers_plan_flag, a.liberty_plan_flag DESC) AS rnk
      FROM ads_staging.vw_stm_plans_customer a) a
WHERE a.rnk = 1;

alter table vw_stm_plans_customer
    owner to ads_main;

