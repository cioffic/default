create function cidr_ne(cidr, cidr) returns boolean
    immutable
    language sql
as
$$
    select network_ne($1::inet, $2::inet)
$$;

