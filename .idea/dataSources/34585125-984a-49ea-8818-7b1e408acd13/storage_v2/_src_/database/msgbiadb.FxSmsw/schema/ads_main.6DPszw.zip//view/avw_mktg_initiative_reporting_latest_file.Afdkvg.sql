CREATE OR REPLACE VIEW ads_main.avw_mktg_initiative_reporting_latest_file AS


SELECT year::int                                                           AS year,
       month_number::int                                                   AS month_number,
       week_number::int                                                    AS week_number,
       week_starting::date                                                 AS week_starting,
--week_ending::date AS 
       week_ending,
       media::varchar(255)                                                 AS media,
       media_category::varchar(255)                                        AS media_category,
       devices::varchar(255)                                               AS devices,
       tactic::varchar(255)                                                AS tactic,
       segment::varchar(255)                                               AS segment,
       area::varchar(255)                                                  AS area,
       creative_concept::varchar(255)                                      AS creative_concept,
       unit_size::varchar(255)                                             AS unit_size,
       campaign_name::varchar(255)                                         AS campaign_name,
       impressions::int                                                    AS impressions,
       clicks::int                                                         AS clicks,
       spend::decimal(30, 4)                                               AS spend,
       video_impressions::decimal(30, 4)::int                              AS video_impressions,
       date::date                                                          AS date,
       campaign::varchar(255)                                              AS campaign,
       campaign_id::decimal(30, 4)::int                                    AS campaign_id,
       publisher::varchar(255)                                             AS publisher,
       site_id::decimal(30, 4)::int                                        AS site_id,
       site_social::varchar(255)                                           AS site_social,
       placement::varchar(255)                                             AS placement,
       placement_id::decimal(30, 4)::int                                   AS placement_id,
       dcm_imps::int                                                       AS dcm_imps,
       dcm_clicks::int                                                     AS dcm_clicks,
       dcm_spend::decimal(30, 4)                                           AS dcm_spend,
       viewable_impressions::int                                           AS viewable_impressions,
       eligible_impressions::int                                           AS eligible_impressions,
       viewable_impression_distribution::decimal(30, 4)                    AS viewable_impression_distribution,
       percent_viewable_impressions::decimal(30, 4)                        AS percent_viewable_impressions,
       video_views::decimal(30, 4)::int                                    AS video_views,
       sales::decimal(30, 4)                                               AS sales,
       revenue::decimal(30, 4)                                             AS revenue,
--ticket_quantity::int AS 
       ticket_quantity,
--clickable_impressions::int AS 
       clickable_impressions,
       placement_1::varchar(255)                                           AS placement_1,
       placement_2::varchar(255)                                           AS placement_2,
       placement_3::varchar(255)                                           AS placement_3,
       placement_4::varchar(255)                                           AS placement_4,
       placement_5::varchar(255)                                           AS placement_5,
       placement_6::varchar(255)                                           AS placement_6,
       placement_7::varchar(255)                                           AS placement_7,
       placement_8::varchar(255)                                           AS placement_8,
       placement_9::varchar(255)                                           AS placement_9,
       placement_10::varchar(255)                                          AS placement_10,
       placement_11::varchar(255)                                          AS placement_11,
       placement_12::varchar(255)                                          AS placement_12,
       placement_13::varchar(255)                                          AS placement_13,
       placement_14::varchar(255)                                          AS placement_14,
       placement_15::varchar(255)                                          AS placement_15,
       placement_16::varchar(255)                                          AS placement_16,
       placement_17::varchar(255)                                          AS placement_17,
       placement_18::varchar(255)                                          AS placement_18,
       concert_creative_1::varchar(255)                                    AS concert_creative_1,
       concert_creative_2::varchar(255)                                    AS concert_creative_2,
       right("$path", position('/' in reverse("$path")) - 1)::varchar(255) as file_name
FROM ext_staging.stg_mktg_initiative_reporting
where file_name = 'MSG INI Weekly Reporting - 2018.09.09.csv'
with no schema binding;

alter table avw_mktg_initiative_reporting_latest_file
    owner to ads_main;

