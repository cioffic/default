create view v_generate_user_grant_revoke_ddl
            (objowner, schemaname, objname, objtype, grantor, grantee, ddltype, grantseq, objseq, ddl, colname) as
(SELECT objprivs.objowner,
        objprivs.schemaname,
        objprivs.objname,
        objprivs.objtype,
        objprivs.grantor,
        objprivs.grantee,
        'grant'::character varying                                  AS ddltype,
        objprivs.grantseq,
        CASE
            WHEN objprivs.objtype::text = 'database'::text OR objprivs.objtype IS NULL AND 'database' IS NULL THEN 0
            WHEN objprivs.objtype::text = 'schema'::text OR objprivs.objtype IS NULL AND 'schema' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'language'::text OR objprivs.objtype IS NULL AND 'language' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'table'::text OR objprivs.objtype IS NULL AND 'table' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'view'::text OR objprivs.objtype IS NULL AND 'view' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'column'::text OR objprivs.objtype IS NULL AND 'column' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'function'::text OR objprivs.objtype IS NULL AND 'function' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'procedure'::text OR objprivs.objtype IS NULL AND 'procedure' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'default acl'::text OR objprivs.objtype IS NULL AND 'default acl' IS NULL
                THEN 3
            ELSE NULL::integer
            END                                                     AS objseq,
        ((
                 CASE
                     WHEN objprivs.grantor::bpchar <> "current_user"() AND objprivs.grantor::text <> 'rdsdb'::text AND
                          objprivs.objtype::text <> 'default acl'::text THEN
                             ('SET SESSION AUTHORIZATION '::text || quote_ident(objprivs.grantor::text)) || ';'::text
                     ELSE ''::text
                     END::character varying(4000)::text ||
                 CASE
                     WHEN objprivs.privilege::text = 'arwdRxt'::text OR objprivs.privilege::text = 'a*r*w*d*R*x*t*'::text
                         THEN ((((
                                         CASE
                                             WHEN objprivs.objtype::text = 'default acl'::text THEN
                                                     ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                      quote_ident(objprivs.grantor::text)) || COALESCE(
                                                                 (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                 ' '::text, ' '::text)
                                             ELSE ''::text
                                             END::character varying(4000)::text || 'GRANT ALL on '::text) ||
                                 objprivs.fullobjname::text) || ' to '::text) || objprivs.splitgrantee::text) ||
                              CASE
                                  WHEN objprivs.privilege::text = 'a*r*w*d*R*x*t*'::text THEN ' with grant option;'::text
                                  ELSE ';'::text
                                  END::character varying(4000)::text
                     WHEN objprivs.privilege::text = 'UC'::text OR objprivs.privilege::text = 'U*C*'::text THEN ((((((
                                                                                                                             CASE
                                                                                                                                 WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                                     THEN
                                                                                                                                         ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                                          quote_ident(objprivs.grantor::text)) ||
                                                                                                                                         COALESCE(
                                                                                                                                                     (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                     ' '::text,
                                                                                                                                                     ' '::text)
                                                                                                                                 ELSE ''::text
                                                                                                                                 END::character varying(4000)::text ||
                                                                                                                             'GRANT ALL on '::text) ||
                                                                                                                     objprivs.objtype::text) ||
                                                                                                                    ' '::text) ||
                                                                                                                   objprivs.fullobjname::text) ||
                                                                                                                  ' to '::text) ||
                                                                                                                 objprivs.splitgrantee::text) ||
                                                                                                                CASE
                                                                                                                    WHEN objprivs.privilege::text = 'U*C*'::text
                                                                                                                        THEN ' with grant option;'::text
                                                                                                                    ELSE ';'::text
                                                                                                                    END::character varying(4000)::text
                     WHEN objprivs.privilege::text = 'CT'::text OR objprivs.privilege::text = 'U*C*'::text THEN ((((((
                                                                                                                             CASE
                                                                                                                                 WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                                     THEN
                                                                                                                                         ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                                          quote_ident(objprivs.grantor::text)) ||
                                                                                                                                         COALESCE(
                                                                                                                                                     (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                     ' '::text,
                                                                                                                                                     ' '::text)
                                                                                                                                 ELSE ''::text
                                                                                                                                 END::character varying(4000)::text ||
                                                                                                                             'GRANT ALL on '::text) ||
                                                                                                                     objprivs.objtype::text) ||
                                                                                                                    ' '::text) ||
                                                                                                                   objprivs.fullobjname::text) ||
                                                                                                                  ' to '::text) ||
                                                                                                                 objprivs.splitgrantee::text) ||
                                                                                                                CASE
                                                                                                                    WHEN objprivs.privilege::text = 'C*T*'::text
                                                                                                                        THEN ' with grant option;'::text
                                                                                                                    ELSE ';'::text
                                                                                                                    END::character varying(4000)::text
                     ELSE (((((((((
                                          CASE
                                              WHEN charindex('a'::text, objprivs.privilege::text) > 0 THEN ((((
                                                                                                                      CASE
                                                                                                                          WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                              THEN
                                                                                                                                  ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                                   quote_ident(objprivs.grantor::text)) ||
                                                                                                                                  COALESCE(
                                                                                                                                              (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                              ' '::text,
                                                                                                                                              ' '::text)
                                                                                                                          ELSE ''::text
                                                                                                                          END::character varying(4000)::text ||
                                                                                                                      'GRANT INSERT on '::text) ||
                                                                                                              objprivs.fullobjname::text) ||
                                                                                                             ' to '::text) ||
                                                                                                            objprivs.splitgrantee::text) ||
                                                                                                           CASE
                                                                                                               WHEN charindex('a*'::text, objprivs.privilege::text) > 0
                                                                                                                   THEN ' with grant option;'::text
                                                                                                               ELSE ';'::text
                                                                                                               END::character varying(4000)::text
                                              ELSE ''::text
                                              END::character varying(4000)::text ||
                                          CASE
                                              WHEN charindex('r'::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                                        CASE
                                                                                                                            WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                                THEN
                                                                                                                                    ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                                     quote_ident(objprivs.grantor::text)) ||
                                                                                                                                    COALESCE(
                                                                                                                                                (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                                ' '::text,
                                                                                                                                                ' '::text)
                                                                                                                            ELSE ''::text
                                                                                                                            END::character varying(4000)::text ||
                                                                                                                        'GRANT SELECT '::text) ||
                                                                                                                CASE
                                                                                                                    WHEN objprivs.objtype::text = 'column'::text
                                                                                                                        THEN ('('::text || objprivs.colname::text) || ')'::text
                                                                                                                    ELSE ''::text
                                                                                                                    END::character varying::text) ||
                                                                                                               ' on '::text) ||
                                                                                                              objprivs.fullobjname::text) ||
                                                                                                             ' to '::text) ||
                                                                                                            objprivs.splitgrantee::text) ||
                                                                                                           CASE
                                                                                                               WHEN charindex('r*'::text, objprivs.privilege::text) > 0
                                                                                                                   THEN ' with grant option;'::text
                                                                                                               ELSE ';'::text
                                                                                                               END::character varying(4000)::text
                                              ELSE ''::text
                                              END::character varying(4000)::text) ||
                                  CASE
                                      WHEN charindex('w'::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                                CASE
                                                                                                                    WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                        THEN
                                                                                                                            ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                             quote_ident(objprivs.grantor::text)) ||
                                                                                                                            COALESCE(
                                                                                                                                        (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                        ' '::text,
                                                                                                                                        ' '::text)
                                                                                                                    ELSE ''::text
                                                                                                                    END::character varying(4000)::text ||
                                                                                                                'GRANT UPDATE '::text) ||
                                                                                                        CASE
                                                                                                            WHEN objprivs.objtype::text = 'column'::text
                                                                                                                THEN ('('::text || objprivs.colname::text) || ')'::text
                                                                                                            ELSE ''::text
                                                                                                            END::character varying::text) ||
                                                                                                       ' on '::text) ||
                                                                                                      objprivs.fullobjname::text) ||
                                                                                                     ' to '::text) ||
                                                                                                    objprivs.splitgrantee::text) ||
                                                                                                   CASE
                                                                                                       WHEN charindex('w*'::text, objprivs.privilege::text) > 0
                                                                                                           THEN ' with grant option;'::text
                                                                                                       ELSE ';'::text
                                                                                                       END::character varying(4000)::text
                                      ELSE ''::text
                                      END::character varying(4000)::text) ||
                                 CASE
                                     WHEN charindex('d'::text, objprivs.privilege::text) > 0 THEN ((((
                                                                                                             CASE
                                                                                                                 WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                     THEN
                                                                                                                         ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                          quote_ident(objprivs.grantor::text)) ||
                                                                                                                         COALESCE(
                                                                                                                                     (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                     ' '::text,
                                                                                                                                     ' '::text)
                                                                                                                 ELSE ''::text
                                                                                                                 END::character varying(4000)::text ||
                                                                                                             'GRANT DELETE on '::text) ||
                                                                                                     objprivs.fullobjname::text) ||
                                                                                                    ' to '::text) ||
                                                                                                   objprivs.splitgrantee::text) ||
                                                                                                  CASE
                                                                                                      WHEN charindex('d*'::text, objprivs.privilege::text) > 0
                                                                                                          THEN ' with grant option;'::text
                                                                                                      ELSE ';'::text
                                                                                                      END::character varying(4000)::text
                                     ELSE ''::text
                                     END::character varying(4000)::text) ||
                                CASE
                                    WHEN charindex('R'::text, objprivs.privilege::text) > 0 THEN ((((
                                                                                                            CASE
                                                                                                                WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                    THEN
                                                                                                                        ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                         quote_ident(objprivs.grantor::text)) ||
                                                                                                                        COALESCE(
                                                                                                                                    (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                    ' '::text,
                                                                                                                                    ' '::text)
                                                                                                                ELSE ''::text
                                                                                                                END::character varying(4000)::text ||
                                                                                                            'GRANT RULE on '::text) ||
                                                                                                    objprivs.fullobjname::text) ||
                                                                                                   ' to '::text) ||
                                                                                                  objprivs.splitgrantee::text) ||
                                                                                                 CASE
                                                                                                     WHEN charindex('R*'::text, objprivs.privilege::text) > 0
                                                                                                         THEN ' with grant option;'::text
                                                                                                     ELSE ';'::text
                                                                                                     END::character varying(4000)::text
                                    ELSE ''::text
                                    END::character varying(4000)::text) ||
                               CASE
                                   WHEN charindex('x'::text, objprivs.privilege::text) > 0 THEN ((((
                                                                                                           CASE
                                                                                                               WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                   THEN
                                                                                                                       ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                        quote_ident(objprivs.grantor::text)) ||
                                                                                                                       COALESCE(
                                                                                                                                   (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                   ' '::text,
                                                                                                                                   ' '::text)
                                                                                                               ELSE ''::text
                                                                                                               END::character varying(4000)::text ||
                                                                                                           'GRANT REFERENCES on '::text) ||
                                                                                                   objprivs.fullobjname::text) ||
                                                                                                  ' to '::text) ||
                                                                                                 objprivs.splitgrantee::text) ||
                                                                                                CASE
                                                                                                    WHEN charindex('x*'::text, objprivs.privilege::text) > 0
                                                                                                        THEN ' with grant option;'::text
                                                                                                    ELSE ';'::text
                                                                                                    END::character varying(4000)::text
                                   ELSE ''::text
                                   END::character varying(4000)::text) ||
                              CASE
                                  WHEN charindex('t'::text, objprivs.privilege::text) > 0 THEN ((((
                                                                                                          CASE
                                                                                                              WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                  THEN
                                                                                                                      ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                       quote_ident(objprivs.grantor::text)) ||
                                                                                                                      COALESCE(
                                                                                                                                  (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                  ' '::text,
                                                                                                                                  ' '::text)
                                                                                                              ELSE ''::text
                                                                                                              END::character varying(4000)::text ||
                                                                                                          'GRANT TRIGGER on '::text) ||
                                                                                                  objprivs.fullobjname::text) ||
                                                                                                 ' to '::text) ||
                                                                                                objprivs.splitgrantee::text) ||
                                                                                               CASE
                                                                                                   WHEN charindex('t*'::text, objprivs.privilege::text) > 0
                                                                                                       THEN ' with grant option;'::text
                                                                                                   ELSE ';'::text
                                                                                                   END::character varying(4000)::text
                                  ELSE ''::text
                                  END::character varying(4000)::text) ||
                             CASE
                                 WHEN charindex('U'::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                           CASE
                                                                                                               WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                   THEN
                                                                                                                       ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                        quote_ident(objprivs.grantor::text)) ||
                                                                                                                       COALESCE(
                                                                                                                                   (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                   ' '::text,
                                                                                                                                   ' '::text)
                                                                                                               ELSE ''::text
                                                                                                               END::character varying(4000)::text ||
                                                                                                           'GRANT USAGE on '::text) ||
                                                                                                   objprivs.objtype::text) ||
                                                                                                  ' '::text) ||
                                                                                                 objprivs.fullobjname::text) ||
                                                                                                ' to '::text) ||
                                                                                               objprivs.splitgrantee::text) ||
                                                                                              CASE
                                                                                                  WHEN charindex('U*'::text, objprivs.privilege::text) > 0
                                                                                                      THEN ' with grant option;'::text
                                                                                                  ELSE ';'::text
                                                                                                  END::character varying(4000)::text
                                 ELSE ''::text
                                 END::character varying(4000)::text) ||
                            CASE
                                WHEN charindex('C'::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                          CASE
                                                                                                              WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                  THEN
                                                                                                                      ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                       quote_ident(objprivs.grantor::text)) ||
                                                                                                                      COALESCE(
                                                                                                                                  (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                  ' '::text,
                                                                                                                                  ' '::text)
                                                                                                              ELSE ''::text
                                                                                                              END::character varying(4000)::text ||
                                                                                                          'GRANT CREATE on '::text) ||
                                                                                                  objprivs.objtype::text) ||
                                                                                                 ' '::text) ||
                                                                                                objprivs.fullobjname::text) ||
                                                                                               ' to '::text) ||
                                                                                              objprivs.splitgrantee::text) ||
                                                                                             CASE
                                                                                                 WHEN charindex('C*'::text, objprivs.privilege::text) > 0
                                                                                                     THEN ' with grant option;'::text
                                                                                                 ELSE ';'::text
                                                                                                 END::character varying(4000)::text
                                ELSE ''::text
                                END::character varying(4000)::text) ||
                           CASE
                               WHEN charindex('T'::text, objprivs.privilege::text) > 0 THEN ((((((
                                                                                                         CASE
                                                                                                             WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                                 THEN
                                                                                                                     ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                      quote_ident(objprivs.grantor::text)) ||
                                                                                                                     COALESCE(
                                                                                                                                 (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                                 ' '::text,
                                                                                                                                 ' '::text)
                                                                                                             ELSE ''::text
                                                                                                             END::character varying(4000)::text ||
                                                                                                         'GRANT TEMP on '::text) ||
                                                                                                 objprivs.objtype::text) ||
                                                                                                ' '::text) ||
                                                                                               objprivs.fullobjname::text) ||
                                                                                              ' to '::text) ||
                                                                                             objprivs.splitgrantee::text) ||
                                                                                            CASE
                                                                                                WHEN charindex('T*'::text, objprivs.privilege::text) > 0
                                                                                                    THEN ' with grant option;'::text
                                                                                                ELSE ';'::text
                                                                                                END::character varying(4000)::text
                               ELSE ''::text
                               END::character varying(4000)::text) ||
                          CASE
                              WHEN charindex('X'::text, objprivs.privilege::text) > 0 THEN (((((
                                                                                                       CASE
                                                                                                           WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                               THEN
                                                                                                                   ('ALTER DEFAULT PRIVILEGES for user '::text ||
                                                                                                                    quote_ident(objprivs.grantor::text)) ||
                                                                                                                   COALESCE(
                                                                                                                               (' in schema '::text || quote_ident(objprivs.schemaname::text)) ||
                                                                                                                               ' '::text,
                                                                                                                               ' '::text)
                                                                                                           ELSE ''::text
                                                                                                           END::character varying(4000)::text ||
                                                                                                       'GRANT EXECUTE on '::text) ||
                                                                                               CASE
                                                                                                   WHEN objprivs.objtype::text = 'default acl'::text
                                                                                                       THEN ''::text
                                                                                                   ELSE objprivs.objtype::text || ' '::text
                                                                                                   END::character varying(4000)::text) ||
                                                                                              objprivs.fullobjname::text) ||
                                                                                             ' to '::text) ||
                                                                                            objprivs.splitgrantee::text) ||
                                                                                           CASE
                                                                                               WHEN charindex('X*'::text, objprivs.privilege::text) > 0
                                                                                                   THEN ' with grant option;'::text
                                                                                               ELSE ';'::text
                                                                                               END::character varying(4000)::text
                              ELSE ''::text
                              END::character varying(4000)::text
                     END::character varying(4000)::text) ||
         CASE
             WHEN objprivs.grantor::bpchar <> "current_user"() AND objprivs.grantor::text <> 'rdsdb'::text AND
                  objprivs.objtype::text <> 'default acl'::text THEN 'RESET SESSION AUTHORIZATION;'::text
             ELSE ''::text
             END::character varying(4000)::text)::character varying AS ddl,
        objprivs.colname
 FROM (SELECT derived_table1.objowner,
              derived_table1.schemaname,
              derived_table1.objname,
              derived_table1.objtype,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text THEN 'PUBLIC'::text
                  ELSE translate(btrim(split_part(derived_table1.aclstring::text, '='::text, 1)), '"'::text, ''::text)
                  END::character varying              AS grantee,
              translate(btrim(split_part(derived_table1.aclstring::text, '/'::text, 2)), '"'::text,
                        ''::text)::character varying  AS grantor,
              btrim(split_part(split_part(derived_table1.aclstring::text, '='::text, 2), '/'::text,
                               1))::character varying AS privilege,
              CASE
                  WHEN derived_table1.objtype::text = 'default acl'::text THEN derived_table1.objname::text
                  WHEN (derived_table1.objtype::text = 'procedure'::text OR
                        derived_table1.objtype::text = 'function'::text) AND
                       regexp_instr(derived_table1.objname::text, derived_table1.schemaname::text) > 0
                      THEN derived_table1.objname::text
                  WHEN derived_table1.objtype::text = 'procedure'::text OR
                       derived_table1.objtype::text = 'function'::text OR derived_table1.objtype::text = 'column'::text
                      THEN (quote_ident(derived_table1.schemaname::text) || '.'::text) || derived_table1.objname::text
                  ELSE COALESCE((quote_ident(derived_table1.schemaname::text) || '.'::text) ||
                                quote_ident(derived_table1.objname::text), quote_ident(derived_table1.objname::text))
                  END::character varying              AS fullobjname,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text THEN 'PUBLIC'::text
                  ELSE btrim(split_part(derived_table1.aclstring::text, '='::text, 1))
                  END::character varying              AS splitgrantee,
              derived_table1.grantseq,
              derived_table1.colname
       FROM ((((((SELECT pg_get_userbyid(b.relowner)::character varying                                              AS objowner,
                         btrim(c.nspname::text)::character varying                                                   AS schemaname,
                         b.relname::character varying                                                                AS objname,
                         CASE
                             WHEN b.relkind = 'r'::"char" THEN 'table'::text
                             ELSE 'view'::text
                             END::character varying                                                                  AS objtype,
                         btrim(split_part(array_to_string(b.relacl, ','::text), ','::text,
                                          ns.n))::character varying                                                  AS aclstring,
                         ns.n                                                                                        AS grantseq,
                         NULL::character varying                                                                     AS colname
                  FROM (SELECT pg_class.oid, generate_series(1, array_upper(pg_class.relacl, 1)) AS n
                        FROM pg_class) ns
                           JOIN pg_class b ON b.oid = ns.oid AND ns.n <= array_upper(b.relacl, 1)
                           JOIN pg_namespace c ON b.relnamespace = c.oid
                  WHERE b.relkind = 'r'::"char"
                     OR b.relkind = 'v'::"char"
                  UNION ALL
                  SELECT pg_get_userbyid(c.relowner)::character varying                                              AS objowner,
                         btrim(d.nspname::text)::character varying                                                   AS schemaname,
                         c.relname::character varying                                                                AS objname,
                         'column'::character varying                                                                 AS objtype,
                         btrim(split_part(array_to_string(b.attacl, ','::text), ','::text,
                                          ns.n))::character varying                                                  AS aclstring,
                         ns.n                                                                                        AS grantseq,
                         b.attname::character varying                                                                AS colname
                  FROM (SELECT pg_attribute_info.attrelid,
                               generate_series(1, array_upper(pg_attribute_info.attacl, 1)) AS n
                        FROM pg_attribute_info) ns
                           JOIN pg_attribute_info b ON b.attrelid = ns.attrelid AND ns.n <= array_upper(b.attacl, 1)
                           JOIN pg_class c ON b.attrelid = c.oid
                           JOIN pg_namespace d ON c.relnamespace = d.oid
                  WHERE c.relkind = 'r'::"char"
                     OR c.relkind = 'v'::"char")
                 UNION ALL
                 SELECT pg_get_userbyid(b.nspowner)::character varying AS objowner,
                        NULL::character varying AS                        schemaname,
                        b.nspname::character varying AS                   objname,
                        'schema'::character varying AS                    objtype,
                        btrim(split_part(array_to_string(b.nspacl, ','::text), ','::text,
                                         ns.n))::character varying AS     aclstring,
                        ns.n AS                                           grantseq,
                        NULL::character varying AS                        colname
                 FROM (SELECT pg_namespace.oid, generate_series(1, array_upper(pg_namespace.nspacl, 1)) AS n
                       FROM pg_namespace) ns
                          JOIN pg_namespace b ON b.oid = ns.oid AND ns.n <= array_upper(b.nspacl, 1))
                UNION ALL
                SELECT pg_get_userbyid(b.datdba)::character varying AS objowner,
                       NULL::character varying AS                      schemaname,
                       b.datname::character varying AS                 objname,
                       'database'::character varying AS                objtype,
                       btrim(split_part(array_to_string(b.datacl, ','::text), ','::text,
                                        ns.n))::character varying AS   aclstring,
                       ns.n AS                                         grantseq,
                       NULL::character varying AS                      colname
                FROM (SELECT pg_database.oid, generate_series(1, array_upper(pg_database.datacl, 1)) AS n
                      FROM pg_database) ns
                         JOIN pg_database b ON b.oid = ns.oid AND ns.n <= array_upper(b.datacl, 1))
               UNION ALL
               SELECT pg_get_userbyid(b.proowner)::character varying AS                  objowner,
                      btrim(c.nspname::text)::character varying AS                       schemaname,
                      textin(regprocedureout(b.oid::regprocedure))::character varying AS objname,
                      CASE
                          WHEN b.prorettype = 0::oid OR b.prorettype IS NULL AND 0 IS NULL THEN 'procedure'::text
                          ELSE 'function'::text
                          END::character varying AS                                      objtype,
                      btrim(split_part(array_to_string(b.proacl, ','::text), ','::text,
                                       ns.n))::character varying AS                      aclstring,
                      ns.n AS                                                            grantseq,
                      NULL::character varying AS                                         colname
               FROM (SELECT pg_proc.oid, generate_series(1, array_upper(pg_proc.proacl, 1)) AS n
                     FROM pg_proc) ns
                        JOIN pg_proc b ON b.oid = ns.oid AND ns.n <= array_upper(b.proacl, 1)
                        JOIN pg_namespace c ON b.pronamespace = c.oid)
              UNION ALL
              SELECT NULL::character varying AS                    objowner,
                     NULL::character varying AS                    schemaname,
                     b.lanname::character varying AS               objname,
                     'language'::character varying AS              objtype,
                     btrim(split_part(array_to_string(b.lanacl, ','::text), ','::text,
                                      ns.n))::character varying AS aclstring,
                     ns.n AS                                       grantseq,
                     NULL::character varying AS                    colname
              FROM (SELECT pg_language.oid, generate_series(1, array_upper(pg_language.lanacl, 1)) AS n
                    FROM pg_language) ns
                       JOIN pg_language b ON b.oid = ns.oid AND ns.n <= array_upper(b.lanacl, 1))
             UNION ALL
             SELECT pg_get_userbyid(b.defacluser)::character varying AS objowner,
                    btrim(c.nspname::text)::character varying AS        schemaname,
                    CASE
                        WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL THEN 'tables'::text
                        WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL THEN 'functions'::text
                        WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL THEN 'procedures'::text
                        ELSE NULL::text
                        END::character varying AS                       objname,
                    'default acl'::character varying AS                 objtype,
                    btrim(split_part(array_to_string(b.defaclacl, ','::text), ','::text,
                                     ns.n))::character varying AS       aclstring,
                    ns.n AS                                             grantseq,
                    NULL::character varying AS                          colname
             FROM (SELECT pg_default_acl.oid, generate_series(1, array_upper(pg_default_acl.defaclacl, 1)) AS n
                   FROM pg_default_acl) ns
                      JOIN pg_default_acl b ON b.oid = ns.oid AND ns.n <= array_upper(b.defaclacl, 1)
                      LEFT JOIN pg_namespace c ON b.defaclnamespace = c.oid) derived_table1
       WHERE split_part(derived_table1.aclstring::text, '='::text, 1) <>
             split_part(derived_table1.aclstring::text, '/'::text, 2)
         AND split_part(derived_table1.aclstring::text, '='::text, 1) <> 'rdsdb'::text
         AND NOT (split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text AND
                  split_part(derived_table1.aclstring::text, '/'::text, 2) = 'rdsdb'::text)) objprivs
 UNION ALL
 SELECT objprivs.objowner,
        objprivs.schemaname,
        objprivs.objname,
        objprivs.objtype,
        objprivs.grantor,
        objprivs.grantee,
        'revoke'::character varying                                 AS ddltype,
        objprivs.grantseq,
        CASE
            WHEN objprivs.objtype::text = 'default acl'::text OR objprivs.objtype IS NULL AND 'default acl' IS NULL
                THEN 0
            WHEN objprivs.objtype::text = 'function'::text OR objprivs.objtype IS NULL AND 'function' IS NULL THEN 0
            WHEN objprivs.objtype::text = 'procedure'::text OR objprivs.objtype IS NULL AND 'procedure' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'table'::text OR objprivs.objtype IS NULL AND 'table' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'view'::text OR objprivs.objtype IS NULL AND 'view' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'column'::text OR objprivs.objtype IS NULL AND 'column' IS NULL THEN 1
            WHEN objprivs.objtype::text = 'schema'::text OR objprivs.objtype IS NULL AND 'schema' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'language'::text OR objprivs.objtype IS NULL AND 'language' IS NULL THEN 2
            WHEN objprivs.objtype::text = 'database'::text OR objprivs.objtype IS NULL AND 'database' IS NULL THEN 3
            ELSE NULL::integer
            END                                                     AS objseq,
        ((
                 CASE
                     WHEN objprivs.grantor::bpchar <> "current_user"() AND objprivs.grantor::text <> 'rdsdb'::text AND
                          objprivs.objtype::text <> 'default acl'::text AND objprivs.grantor::text <> objprivs.objowner::text
                         THEN ('SET SESSION AUTHORIZATION '::text || quote_ident(objprivs.grantor::text)) || ';'::text
                     ELSE ''::text
                     END::character varying(4000)::text ||
                 CASE
                     WHEN objprivs.objtype::text = 'default acl'::text THEN
                             (((((('ALTER DEFAULT PRIVILEGES for user '::text || quote_ident(objprivs.grantor::text)) ||
                                  COALESCE((' in schema '::text || quote_ident(objprivs.schemaname::text)) || ' '::text,
                                           ' '::text)) || 'REVOKE ALL on '::text) || objprivs.fullobjname::text) ||
                               ' FROM '::text) || objprivs.splitgrantee::text) || ';'::text
                     ELSE (((('REVOKE ALL on '::text ||
                              CASE
                                  WHEN objprivs.objtype::text = 'table'::text OR
                                       objprivs.objtype::text = 'view'::text OR objprivs.objtype::text = 'column'::text
                                      THEN ''::text
                                  ELSE objprivs.objtype::text || ' '::text
                                  END::character varying(4000)::text) || objprivs.fullobjname::text) ||
                            ' FROM '::text) || objprivs.splitgrantee::text) || ';'::text
                     END::character varying(4000)::text) ||
         CASE
             WHEN objprivs.grantor::bpchar <> "current_user"() AND objprivs.grantor::text <> 'rdsdb'::text AND
                  objprivs.objtype::text <> 'default acl'::text AND objprivs.grantor::text <> objprivs.objowner::text
                 THEN 'RESET SESSION AUTHORIZATION;'::text
             ELSE ''::text
             END::character varying(4000)::text)::character varying AS ddl,
        objprivs.colname
 FROM (SELECT derived_table1.objowner,
              derived_table1.schemaname,
              derived_table1.objname,
              derived_table1.objtype,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text THEN 'PUBLIC'::text
                  ELSE translate(btrim(split_part(derived_table1.aclstring::text, '='::text, 1)), '"'::text, ''::text)
                  END::character varying              AS grantee,
              translate(btrim(split_part(derived_table1.aclstring::text, '/'::text, 2)), '"'::text,
                        ''::text)::character varying  AS grantor,
              btrim(split_part(split_part(derived_table1.aclstring::text, '='::text, 2), '/'::text,
                               1))::character varying AS privilege,
              CASE
                  WHEN derived_table1.objtype::text = 'default acl'::text THEN derived_table1.objname::text
                  WHEN (derived_table1.objtype::text = 'procedure'::text OR
                        derived_table1.objtype::text = 'function'::text) AND
                       regexp_instr(derived_table1.objname::text, derived_table1.schemaname::text) > 0
                      THEN derived_table1.objname::text
                  WHEN derived_table1.objtype::text = 'procedure'::text OR
                       derived_table1.objtype::text = 'function'::text OR derived_table1.objtype::text = 'column'::text
                      THEN (quote_ident(derived_table1.schemaname::text) || '.'::text) || derived_table1.objname::text
                  ELSE COALESCE((quote_ident(derived_table1.schemaname::text) || '.'::text) ||
                                quote_ident(derived_table1.objname::text), quote_ident(derived_table1.objname::text))
                  END::character varying              AS fullobjname,
              CASE
                  WHEN split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text THEN 'PUBLIC'::text
                  ELSE btrim(split_part(derived_table1.aclstring::text, '='::text, 1))
                  END::character varying              AS splitgrantee,
              derived_table1.grantseq,
              derived_table1.colname
       FROM ((((((SELECT pg_get_userbyid(b.relowner)::character varying                                              AS objowner,
                         btrim(c.nspname::text)::character varying                                                   AS schemaname,
                         b.relname::character varying                                                                AS objname,
                         CASE
                             WHEN b.relkind = 'r'::"char" THEN 'table'::text
                             ELSE 'view'::text
                             END::character varying                                                                  AS objtype,
                         btrim(split_part(array_to_string(b.relacl, ','::text), ','::text,
                                          ns.n))::character varying                                                  AS aclstring,
                         ns.n                                                                                        AS grantseq,
                         NULL::character varying                                                                     AS colname
                  FROM (SELECT pg_class.oid, generate_series(1, array_upper(pg_class.relacl, 1)) AS n
                        FROM pg_class) ns
                           JOIN pg_class b ON b.oid = ns.oid AND ns.n <= array_upper(b.relacl, 1)
                           JOIN pg_namespace c ON b.relnamespace = c.oid
                  WHERE b.relkind = 'r'::"char"
                     OR b.relkind = 'v'::"char"
                  UNION ALL
                  SELECT pg_get_userbyid(c.relowner)::character varying                                              AS objowner,
                         btrim(d.nspname::text)::character varying                                                   AS schemaname,
                         c.relname::character varying                                                                AS objname,
                         'column'::character varying                                                                 AS objtype,
                         btrim(split_part(array_to_string(b.attacl, ','::text), ','::text,
                                          ns.n))::character varying                                                  AS aclstring,
                         ns.n                                                                                        AS grantseq,
                         b.attname::character varying                                                                AS colname
                  FROM (SELECT pg_attribute_info.attrelid,
                               generate_series(1, array_upper(pg_attribute_info.attacl, 1)) AS n
                        FROM pg_attribute_info) ns
                           JOIN pg_attribute_info b ON b.attrelid = ns.attrelid AND ns.n <= array_upper(b.attacl, 1)
                           JOIN pg_class c ON b.attrelid = c.oid
                           JOIN pg_namespace d ON c.relnamespace = d.oid
                  WHERE c.relkind = 'r'::"char"
                     OR c.relkind = 'v'::"char")
                 UNION ALL
                 SELECT pg_get_userbyid(b.nspowner)::character varying AS objowner,
                        NULL::character varying AS                        schemaname,
                        b.nspname::character varying AS                   objname,
                        'schema'::character varying AS                    objtype,
                        btrim(split_part(array_to_string(b.nspacl, ','::text), ','::text,
                                         ns.n))::character varying AS     aclstring,
                        ns.n AS                                           grantseq,
                        NULL::character varying AS                        colname
                 FROM (SELECT pg_namespace.oid, generate_series(1, array_upper(pg_namespace.nspacl, 1)) AS n
                       FROM pg_namespace) ns
                          JOIN pg_namespace b ON b.oid = ns.oid AND ns.n <= array_upper(b.nspacl, 1))
                UNION ALL
                SELECT pg_get_userbyid(b.datdba)::character varying AS objowner,
                       NULL::character varying AS                      schemaname,
                       b.datname::character varying AS                 objname,
                       'database'::character varying AS                objtype,
                       btrim(split_part(array_to_string(b.datacl, ','::text), ','::text,
                                        ns.n))::character varying AS   aclstring,
                       ns.n AS                                         grantseq,
                       NULL::character varying AS                      colname
                FROM (SELECT pg_database.oid, generate_series(1, array_upper(pg_database.datacl, 1)) AS n
                      FROM pg_database) ns
                         JOIN pg_database b ON b.oid = ns.oid AND ns.n <= array_upper(b.datacl, 1))
               UNION ALL
               SELECT pg_get_userbyid(b.proowner)::character varying AS                  objowner,
                      btrim(c.nspname::text)::character varying AS                       schemaname,
                      textin(regprocedureout(b.oid::regprocedure))::character varying AS objname,
                      CASE
                          WHEN b.prorettype = 0::oid OR b.prorettype IS NULL AND 0 IS NULL THEN 'procedure'::text
                          ELSE 'function'::text
                          END::character varying AS                                      objtype,
                      btrim(split_part(array_to_string(b.proacl, ','::text), ','::text,
                                       ns.n))::character varying AS                      aclstring,
                      ns.n AS                                                            grantseq,
                      NULL::character varying AS                                         colname
               FROM (SELECT pg_proc.oid, generate_series(1, array_upper(pg_proc.proacl, 1)) AS n
                     FROM pg_proc) ns
                        JOIN pg_proc b ON b.oid = ns.oid AND ns.n <= array_upper(b.proacl, 1)
                        JOIN pg_namespace c ON b.pronamespace = c.oid)
              UNION ALL
              SELECT NULL::character varying AS                    objowner,
                     NULL::character varying AS                    schemaname,
                     b.lanname::character varying AS               objname,
                     'language'::character varying AS              objtype,
                     btrim(split_part(array_to_string(b.lanacl, ','::text), ','::text,
                                      ns.n))::character varying AS aclstring,
                     ns.n AS                                       grantseq,
                     NULL::character varying AS                    colname
              FROM (SELECT pg_language.oid, generate_series(1, array_upper(pg_language.lanacl, 1)) AS n
                    FROM pg_language) ns
                       JOIN pg_language b ON b.oid = ns.oid AND ns.n <= array_upper(b.lanacl, 1))
             UNION ALL
             SELECT pg_get_userbyid(b.defacluser)::character varying AS objowner,
                    btrim(c.nspname::text)::character varying AS        schemaname,
                    CASE
                        WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL THEN 'tables'::text
                        WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL THEN 'functions'::text
                        WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL THEN 'procedures'::text
                        ELSE NULL::text
                        END::character varying AS                       objname,
                    'default acl'::character varying AS                 objtype,
                    btrim(split_part(array_to_string(b.defaclacl, ','::text), ','::text,
                                     ns.n))::character varying AS       aclstring,
                    ns.n AS                                             grantseq,
                    NULL::character varying AS                          colname
             FROM (SELECT pg_default_acl.oid, generate_series(1, array_upper(pg_default_acl.defaclacl, 1)) AS n
                   FROM pg_default_acl) ns
                      JOIN pg_default_acl b ON b.oid = ns.oid AND ns.n <= array_upper(b.defaclacl, 1)
                      LEFT JOIN pg_namespace c ON b.defaclnamespace = c.oid) derived_table1
       WHERE split_part(derived_table1.aclstring::text, '='::text, 1) <>
             split_part(derived_table1.aclstring::text, '/'::text, 2)
         AND split_part(derived_table1.aclstring::text, '='::text, 1) <> 'rdsdb'::text
         AND NOT (split_part(derived_table1.aclstring::text, '='::text, 1) = ''::text AND
                  split_part(derived_table1.aclstring::text, '/'::text, 2) = 'rdsdb'::text)) objprivs
 WHERE NOT (objprivs.objtype::text = 'default acl'::text AND objprivs.grantee::text = 'PUBLIC'::text AND
            objprivs.objname::text = 'functions'::text))
UNION ALL
SELECT NULL::character varying                                     AS objowner,
       NULL::character varying                                     AS schemaname,
       CASE
           WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL THEN 'tables'::text
           WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL THEN 'functions'::text
           WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL THEN 'procedures'::text
           ELSE NULL::text
           END::character varying                                  AS objname,
       'default acl'::character varying                            AS objtype,
       pg_get_userbyid(b.defacluser)::character varying            AS grantor,
       NULL::character varying                                     AS grantee,
       'revoke'::character varying                                 AS ddltype,
       5                                                           AS grantseq,
       5                                                           AS objseq,
       (((((('ALTER DEFAULT PRIVILEGES for user '::text || quote_ident(pg_get_userbyid(b.defacluser)::text)) ||
            ' GRANT ALL on '::text) ||
           CASE
               WHEN b.defaclobjtype = 'r'::"char" OR b.defaclobjtype IS NULL AND 'r' IS NULL THEN 'tables'::text
               WHEN b.defaclobjtype = 'f'::"char" OR b.defaclobjtype IS NULL AND 'f' IS NULL THEN 'functions'::text
               WHEN b.defaclobjtype = 'p'::"char" OR b.defaclobjtype IS NULL AND 'p' IS NULL THEN 'procedures'::text
               ELSE NULL::text
               END) || ' TO '::text) || quote_ident(pg_get_userbyid(b.defacluser)::text)) ||
        CASE
            WHEN b.defaclobjtype = 'f'::"char" THEN ', PUBLIC;'::text
            ELSE ';'::text
            END::character varying(4000)::text)::character varying AS ddl,
       NULL::character varying                                     AS colname
FROM pg_default_acl b
WHERE b.defaclacl = '{}'::aclitem[]
   OR b.defaclnamespace = 0::oid AND b.defaclobjtype = 'f'::"char";

alter table v_generate_user_grant_revoke_ddl
    owner to msgadmin;

