create function timetz_lt_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_gt_timetz($2, $1)
$$;

