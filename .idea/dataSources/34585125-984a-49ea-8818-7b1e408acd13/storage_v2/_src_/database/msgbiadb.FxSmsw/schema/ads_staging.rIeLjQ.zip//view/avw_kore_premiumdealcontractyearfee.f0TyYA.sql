create view ads_staging.avw_kore_premiumdealcontractyearfee as
select *
from ext_staging.stg_kore_premiumdealcontractyearfee
with no schema binding;

alter table avw_kore_premiumdealcontractyearfee
    owner to ads_staging;

