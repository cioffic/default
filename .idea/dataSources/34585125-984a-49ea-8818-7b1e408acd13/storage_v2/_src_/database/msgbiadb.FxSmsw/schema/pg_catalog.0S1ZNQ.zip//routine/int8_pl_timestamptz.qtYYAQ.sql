create function int8_pl_timestamptz(bigint, timestamp with time zone) returns timestamp with time zone
    immutable
    language sql
as
$$
    select $2 + $1
$$;

