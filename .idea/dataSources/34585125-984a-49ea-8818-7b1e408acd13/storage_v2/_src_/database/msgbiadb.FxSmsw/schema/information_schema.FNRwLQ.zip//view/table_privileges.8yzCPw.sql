create view table_privileges
            (grantor, grantee, table_catalog, table_schema, table_name, privilege_type, is_grantable, with_hierarchy) as
SELECT u_grantor.usename::information_schema.sql_identifier                       AS grantor,
       grantee.name::information_schema.sql_identifier                            AS grantee,
       current_database()::information_schema.sql_identifier                      AS table_catalog,
       nc.nspname::information_schema.sql_identifier                              AS table_schema,
       c.relname::information_schema.sql_identifier                               AS table_name,
       pr."type"::information_schema.character_data                               AS privilege_type,
       CASE
           WHEN aclcontains(c.relacl,
                            makeaclitem(grantee.usesysid, grantee.grosysid, u_grantor.usesysid, pr."type"::text, true))
               THEN 'YES'::text
           ELSE 'NO'::text
           END::information_schema.character_data                                 AS is_grantable,
       'NO'::information_schema.character_data::information_schema.character_data AS with_hierarchy
FROM pg_class c,
     pg_namespace nc,
     pg_user u_grantor,
     ((SELECT pg_user.usesysid, 0, pg_user.usename
       FROM pg_user
       UNION ALL
       SELECT 0, pg_group.grosysid, pg_group.groname
       FROM pg_group)
      UNION ALL
      SELECT 0, 0, 'PUBLIC'::name) grantee(usesysid, grosysid, name),
     ((((((SELECT 'SELECT'::character varying
           UNION ALL
           SELECT 'DELETE'::character varying)
          UNION ALL
          SELECT 'INSERT'::character varying)
         UNION ALL
         SELECT 'UPDATE'::character varying)
        UNION ALL
        SELECT 'REFERENCES'::character varying)
       UNION ALL
       SELECT 'RULE'::character varying)
      UNION ALL
      SELECT 'TRIGGER'::character varying) pr("type")
WHERE c.relnamespace = nc.oid
  AND (c.relkind = 'r'::"char" OR c.relkind = 'v'::"char")
  AND aclcontains(c.relacl, makeaclitem(grantee.usesysid, grantee.grosysid, u_grantor.usesysid, pr."type"::text, false))
  AND (u_grantor.usename = "current_user"()::name OR grantee.name = "current_user"()::name OR
       grantee.name = 'PUBLIC'::name);

alter table table_privileges
    owner to rdsdb;

