CREATE OR replace VIEW ads_main.vw_ticket_sales_event_seat_demo
AS
SELECT
    ---Keys
--		CASE
--		WHEN COALESCE( b.customer_master_index,-1) =-1 THEN
--		  email_address
--		  ELSE COALESCE( b.customer_master_index,-1)::varchar(100)
--		END
--		AS customer_key,
    a.customer_master_index,
    tm_acct_id,

    --General attributes
    a.name_last,
    a.name_first,
    email_address,
    acct_type_desc,
    company_name,
    high_volume_buyer_flag,
    b.season_ticket_member_flag,


    --demo
    CASE
        WHEN nvl(gender, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE gender
        END::varchar(30)                                                   gender,
    age,
--		CASE 
--			WHEN b.age<17 THEN 'POST-MILLENNIALS /Gen Z (1-16)'
--    		WHEN b.age>16  and b.age<37 THEN 'THE MILLENNIALS /Gen Y (17-36)'  
--		    WHEN b.age>36  and b.age<53 THEN 'GenX (37-52)'
--		    WHEN b.age>52  and b.age<72 THEN 'THE BABY BOOMERS (53-71)' 
--		    WHEN b.age>71  and b.age<91 THEN 'THE SILENT GENERATION (72-90)'    
--		    WHEN b.age>90  THEN 'THE GREATEST GENERATION (91+)'
--		    ELSE 'Unknown'
--		END::varchar(255) AS generation,
    CASE
        WHEN nvl(experian_dtm_last_updated, '1900-01-01 00:00:00') = '1900-01-01 00:00:00'
            THEN 'UNKNOWN'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 2013 and 2025
            THEN 'Gen Alpha (2013 - 2025)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1995 and 2012
            THEN 'POST-MILLENNIALS iGen/Gen Z (1995 - 2012)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1981 and 1994
            THEN 'THE MILLENNIALS /Gen Y (1981 - 1994)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1965 and 1980
            THEN 'GenX (1965 - 1980)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1946 and 1964
            THEN 'THE BABY BOOMERS (1946 - 1964)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1928 and 1945
            THEN 'THE SILENT GENERATION (1928 -1945)'
        WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int < 1928
            THEN 'THE GREATEST GENERATION " ( prior 1927)'
        ELSE 'UNKNOWN'
        END::varchar(255)                                               AS generation,

    CASE
        WHEN nvl(estimated_household_income_range, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE estimated_household_income_range
        END::varchar(30)                                                   estimated_household_income_range,
    CASE
        WHEN nvl(occupation, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE occupation
        END::varchar(100)                                                  occupation,
    CASE
        WHEN nvl(education_level, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE education_level
        END::varchar(100)                                                  education_level,
    CASE
        WHEN nvl(estimated_net_assets_range, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE estimated_net_assets_range
        END::varchar(30)                                                   estimated_net_assets_range,
    CASE
        WHEN nvl(marital_status, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE marital_status
        END::varchar(30)                                                   marital_status,
    CASE
        WHEN nvl(presence_of_children_age_0_3_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_0_3_flag
        END::varchar(30)                                                   presence_of_children_age_0_3_flag,
    CASE
        WHEN nvl(presence_of_children_age_4_6_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_4_6_flag
        END::varchar(30)                                                   presence_of_children_age_4_6_flag,
    CASE
        WHEN nvl(presence_of_children_age_7_9_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_7_9_flag
        END::varchar(30)                                                   presence_of_children_age_7_9_flag,
    CASE
        WHEN nvl(presence_of_children_age_10_12_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_10_12_flag
        END::varchar(30)                                                   presence_of_children_age_10_12_flag,
    CASE
        WHEN nvl(presence_of_children_age_13_15_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_13_15_flag
        END::varchar(30)                                                   presence_of_children_age_13_15_flag,
    CASE
        WHEN nvl(presence_of_children_age_16_18_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_age_16_18_flag
        END::varchar(30)                                                   presence_of_children_age_16_18_flag,
    CASE
        WHEN nvl(presence_of_children_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE presence_of_children_flag
        END::varchar(30)                                                   presence_of_children_flag,
    number_of_adults_in_household,
    CASE
        WHEN nvl(e_tech_group, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE e_tech_group
        END::varchar(100)                                                  e_tech_group,
    CASE
        WHEN nvl(preferred_language, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE preferred_language
        END::varchar(100)                                                  preferred_language,
    CASE
        WHEN nvl(mosaic_household, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE mosaic_household
        END::varchar(100)                                                  mosaic_household,
    CASE
        WHEN nvl(homeowner_flag, '') IN ('ADS Unknown', 'Unknown', '')
            THEN 'Unknown'
        ELSE homeowner_flag
        END::varchar(30)                                                   homeowner_flag,

    --geo
    county,
    nvl((b.county || ', ' || b.reporting_state_code), '')::varchar(200) as reporting_county_state_code,
    b.city,
    state_code,
    upper(b.state)::varchar(100)                                        AS state,
    country_code,
    substring(b.zip, 1, 5)::varchar(100)                                AS zip,
    upper(b.country)::varchar(100)                                      AS country,
    CASE
        WHEN NVL(latitude, '') = ''
            THEN NULL::float
        ELSE latitude::float
        END                                                                customer_latitude, --cast to float
    CASE
        WHEN NVL(longitude, '') = ''
            THEN NULL::float
        ELSE longitude::float
        END                                                                custmer_longitude, --cast to float
    neighborhood,
    borough,
    reporting_country_code,
    reporting_country,
    reporting_country_group,
    reporting_state_code,
    reporting_state,


    --event 
    a.inet_event_id,
    tm_event_status,
    tm_primary_act,
    a.tm_season_year,
    event_business_unit,
    --tm_event_date , 
    a.tm_event_time,
    tm_event_type,
    mpd_game_num,
    tm_major_category,
    tm_minor_category,
    tm_event_name_long,
    a.tm_event_name,
    tm_event_genre                                                      AS event_genre,
    report_event_flag,
    a.tm_season_name,
    tm_arena_name,
    tm_arena_venue_zip,
    tm_arena_longitude                                                  AS venue_longitude,
    tm_arena_latitude                                                   AS venue_latitude,


    --ads_source,
    CASE
        WHEN b.reporting_country_group = 'United States of America'
            THEN CASE
                     WHEN ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude, longitude) = ''
                         THEN 'US Unknown'
                     WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                      longitude)::float, 0) <= 50
                         THEN 'Within 50 Miles'
                     WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                      longitude)::float, 0) <= 75
                         THEN 'Between 51 and 75 Miles'
                     WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                      longitude)::float, 0) <= 300
                         THEN 'Between 76 and 300 Miles'
                     ELSE 'Rest of United States'
            END
        ELSE CASE
                 WHEN nvl(b.reporting_country_group, '') not in ('', 'Unknown')
                     THEN 'International'
            --							WHEN ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude,latitude, longitude) ='' 
--							THEN 'Unknown'
                 ELSE 'Unknown'
            END
        END::varchar(100)                                               as distance_category,
    --ticket type
    ticket_retail_qualifiers,
    house_seat_flag,
    ticket_group_flag,
    ticket_retail_ticket_type,
    ticket_sell_location_name,
    ticket_type_desc,
    a.ticket_product_description,
    ticket_sell_location_group,

    --event date
    eventdt.fiscal_year                                                    event_date_fiscal_year,
    eventdt.month_name                                                     event_date_month_name,
    eventdt.weekday_indicator                                              event_date_weekday_indicator,
    eventdt.day_in_month                                                   event_date_day_in_month,
    eventdt.week_end_date                                               AS event_date_weekend_date,
    eventdt.week_id                                                     AS event_date_week_id,
    eventdt.full_date                                                   AS event_date,
    eventdt.day_in_year                                                 AS event_date_day_in_year,


    --sales date
    ticket_sale_report_date                                             AS ticket_sales_day_id,
    dt.fiscal_year                                                         ticket_sales_fiscal_year,
    dt.month_name                                                          ticket_sales_month_name,
    dt.weekday_indicator                                                   ticket_sales_weekday_indicator,
    dt.day_in_month                                                        ticket_sales_day_in_month,
    dt.week_end_date                                                    AS ticket_sales_weekend_date,
    dt.week_id                                                          AS ticket_sales_week_id,
    dt.full_date                                                        AS ticket_sales_date,
    dt.day_in_year                                                      AS ticket_sale_day_in_year,
    CASE
        WHEN dt.fiscal_month < currdt.fiscal_month THEN
            'Y'
        WHEN dt.fiscal_month = currdt.fiscal_month
            AND
             extract(day FROM dt.full_date) <= extract(day FROM currdt.full_date) THEN
            'Y'
        ELSE 'N'
        END::varchar(1)                                                 AS ytd_flag,
    MIN(dt.full_date) OVER (PARTITION BY a.customer_master_index)       AS customer_first_purchase_date,
    MAX(dt.full_date) OVER (PARTITION BY a.customer_master_index)       AS customer_last_purchase_date,

    --for both sales date and event date add following
    --fiscal year,
    --month
    --weekend
    --day_in_week


    --excludes
    b.exclude_flag,
--		acct_type_exclusion_exclude_flag, 
--		event_business_unit_exclusion_exclude_fla, 
--		purch_evt_9plus_tix_exclude_flag, 
--		purch_evtdt_2plus_evts_exclude_flag, 
--		purch_evtslsdt_9plus_tix_exclude_flag, 
--		purch_mmyy_18plus_tix_exclude_flag, 
--		purch_mmyy_9plus_evts_exclude_flag, 
--		high_volume_buyer_exception_exclude_flag, 
--		resale_evtdt_2plus_evt_exclude_flag, 
--		resale_evtid_evtdt_9plus_tix_exclude_flag, 
--		resale_postdt_2plus_evt_exclude_flag, 
--		resale_postmmyy_18plus_tix_exclude_flag, 
--		resale_postmmyy_9plus_evts_exclude_flag, 
--		
--		CASE
--			WHEN ticket_retail_ticket_type= 'G-TYPE'  AND   event_business_unit<>'RANGERS' THEN  'Y'
--			WHEN ticket_retail_ticket_type= 'G-TYPE'  AND   event_business_unit<>'KNICKS' THEN   'Y'
--			WHEN ticket_group_flag='Y' THEN 'Y' 
--			WHEN house_seat_flag='Y' THEN  'Y'
--			WHEN upper (ticket_type_desc) NOT LIKE '%INDI%' THEN   'Y'
--			ELSE 'N'
--		END::varchar(1) AS ticket_type_excludes, 
    CASE
        WHEN nvl(a.ticket_type_desc, '') != 'COMP'
            AND nvl(a.ticket_type_desc, '') != 'Trade Desk'
            AND nvl(a.ticket_product_description, '') = 'Individuals'
            AND nvl(a.ticket_retail_ticket_type, '') NOT IN ('J-TYPE', 'M-TYPE') --As per Cindy exclude all J-TYPEs
            AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%KBWAYIB%' --As per Cindy exclude
            AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%BTDAY1%' --As per Cindy exclude
            AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAY2%' --As per Cindy exclude
            AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAY3%' --As per Cindy exclude
            AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAYCM%' --As per Cindy exclude
            AND nvl(a.house_seat_flag, '') != 'Y' --As per Cindy exclude house seats
            AND nvl(a.tm_price_code, '') NOT LIKE '_G%' -- AS per Eric H
            AND nvl(a.credited_sales_rep_full_name, '') NOT LIKE '%Group%' -- AS per Eric H
            AND nvl(a.msg_departmentname, '') NOT LIKE '%Group%' -- AS per Eric H
            AND upper(nvl(a.ticket_sell_location_name, '')) != 'BROADWAY.COM'
            THEN 'Y'
        ELSE 'N'
        END::varchar(1)                                                 as ticket_type_excludes,

    CASE
        WHEN COALESCE(b.season_ticket_member_flag, 'N') = 'N'
            AND COALESCE(high_volume_buyer_flag, 'N') = 'N'
            AND upper(nvl(acct_type_desc, 'NA')) = 'PERSONAL'
            AND UPPER(NVL(acct_type_desc, 'NA')) NOT LIKE '%TEST%'
            THEN 'Y'
        ELSE 'N'
        END::varchar(1)                                                 AS acct_type_excludes,

--		CASE
--			WHEN (
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TEST%'  OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TICK%'  OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GROUP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%INTERNAL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%FINAN%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MEDIA%SALE%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%VISIT%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CVC%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CAST%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%VIP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CELEB%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%PRESS%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%SCHOOL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%LEAGUE%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CAMP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GOVER%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%PARTNER%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GROUP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GS %' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GS:%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TICKET:%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TIX%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%AGENCY%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TOUR%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MSG%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%SPONSOR%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%EMPL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MARKET%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TEAM%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%OFFICE%'  ) OR
--			  upper(a.name_last) = 'SAMPERI'   OR
--			  upper(a.name_last) = 'RASMUSSEN'   OR
--			  upper(company_name) LIKE '%EVENTELL%' THEN   'Y'
--			  ELSE 'N'
--		END
--		acct_type_excludes,  

    nvl(pc.price_code_section, 'NA')                                    as price_code_section,
    --measures
    SUM(COALESCE(tickets_sold, 0))                                      as tickets_sold,
    SUM(COALESCE(tickets_total_revenue, 0))                             as tickets_total_revenue
FROM ads_main.t_ticket_sales_event_seat a
         LEFT JOIN ads_main.d_price_code pc
                   ON CASE
                          WHEN a.tm_price_code LIKE '%*' THEN SUBSTRING(a.tm_price_code, 1, 1)
                          ELSE a.tm_price_code END = pc.tm_price_code
                       AND a.tm_event_name = pc.tm_event_name
                       AND pc.ads_active_flag = 'Y'
                       AND a.tm_season_name = pc.tm_season_name
         JOIN (
    SELECT inet_event_id,
           tm_section_name,
           tm_row_name,
           tm_seat_num,
           customer_master_index
    FROM ads_main.t_ticket_sales_event_seat
    GROUP BY inet_event_id,
             tm_section_name,
             tm_row_name,
             tm_seat_num,
             customer_master_index
    HAVING sum(tickets_sold) > 0
) d
              ON a.inet_event_id = d.inet_event_id
                  AND a.tm_section_name = d.tm_section_name
                  AND a.tm_row_name = d.tm_row_name
                  AND a.tm_seat_num = d.tm_seat_num
                  AND a.customer_master_index = d.customer_master_index
         JOIN ads_main.d_date dt ON ticket_sale_report_date = dt.day_id
         JOIN ads_main.d_date currdt ON currdt.full_date = CURRENT_DATE - 1
         JOIN ads_main.d_date eventdt ON eventdt.full_date = a.tm_event_date
--LEFT JOIN ads_staging.tmp_bulk_cust_partner_broker_pivot c on a.customer_master_index = c.customer_master_index
         LEFT JOIN ads_main.d_customer_master b ON a.customer_master_index = b.customer_master_index
WHERE nvl(tm_comp_name, '') = 'Not Comp'
  AND UPPER(COALESCE(event_business_unit, 'NA')) NOT IN ('MSG - MISC', 'SUITES', 'LIBERTY', 'NA')
  AND report_event_flag = 'Y'
  AND upper(nvl(acct_type_desc, '')) not like '%TEST%'
  AND nvl(a.tm_event_name, '') not like 'EVENT_%'
  AND nvl(a.tm_event_name, '') NOT IN ('NYKAUTO', 'NYRAUTO', 'NYRDEP', 'NYKDEP', 'RGD', 'KGD', 'RGDL', 'KGDL')

--make sure there are no repeates - section 3 from Irina's document
  AND a.tm_acct_id not in (-1, -2)
  AND nvl(a.customer_master_index, -1) != -1
  AND upper(nvl(a.name_last, '')) != 'TRADEDESK'
  AND upper(nvl(a.email_address, '')) not like '%AUTOPROCESSOR%'--------------------->
  AND a.email_address is NOT NULL
  AND upper(nvl(a.name_last, '')) != 'SAMPERI'
  AND upper(nvl(a.name_last, '')) != 'RASMUSSEN'
  AND upper(nvl(a.company_name, '')) NOT LIKE '%EVENTELL%'
  AND nvl(a.name_last, '') not LIKE 'Zz%'

  -----------------
  AND upper(a.tm_event_status) not like '%CANCEL%'
-----------------
GROUP BY
          ---Keys
--		CASE
--		WHEN COALESCE( a.customer_master_index,-1) =-1 THEN
--		  email_address
--		  ELSE COALESCE( a.customer_master_index,-1)::varchar(100)
--		END
--		,
          a.customer_master_index,
          tm_acct_id,

          --General attributes
          a.name_last,
          a.name_first,
          email_address,
          acct_type_desc,
          company_name,
          high_volume_buyer_flag,
          b.season_ticket_member_flag,

          --demo
          CASE
              WHEN nvl(gender, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE gender
              END,
          age,
          CASE
              WHEN nvl(experian_dtm_last_updated, '1900-01-01 00:00:00') = '1900-01-01 00:00:00'
                  THEN 'UNKNOWN'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 2013 and 2025
                  THEN 'Gen Alpha (2013 - 2025)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1995 and 2012
                  THEN 'POST-MILLENNIALS iGen/Gen Z (1995 - 2012)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1981 and 1994
                  THEN 'THE MILLENNIALS /Gen Y (1981 - 1994)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1965 and 1980
                  THEN 'GenX (1965 - 1980)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1946 and 1964
                  THEN 'THE BABY BOOMERS (1946 - 1964)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int BETWEEN 1928 and 1945
                  THEN 'THE SILENT GENERATION (1928 -1945)'
              WHEN TO_CHAR(DATEADD(year, age * -1, experian_dtm_last_updated), 'YYYY')::int < 1928
                  THEN 'THE GREATEST GENERATION " ( prior 1927)'
              ELSE 'UNKNOWN'
              END::varchar(255),
          CASE
              WHEN nvl(estimated_household_income_range, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE estimated_household_income_range
              END,
          CASE
              WHEN nvl(occupation, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE occupation
              END,
          CASE
              WHEN nvl(education_level, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE education_level
              END,


          CASE
              WHEN nvl(marital_status, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE marital_status
              END,
          CASE
              WHEN nvl(presence_of_children_age_0_3_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_0_3_flag
              END,
          CASE
              WHEN nvl(presence_of_children_age_4_6_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_4_6_flag
              END,
          CASE
              WHEN nvl(presence_of_children_age_7_9_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_7_9_flag
              END,
          CASE
              WHEN nvl(presence_of_children_age_10_12_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_10_12_flag
              END,
          CASE
              WHEN nvl(presence_of_children_age_13_15_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_13_15_flag
              END,
          CASE
              WHEN nvl(presence_of_children_age_16_18_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_age_16_18_flag
              END,
          CASE
              WHEN nvl(presence_of_children_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE presence_of_children_flag
              END,
          number_of_adults_in_household,

          CASE
              WHEN nvl(estimated_net_assets_range, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE estimated_net_assets_range
              END,
          CASE
              WHEN nvl(e_tech_group, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE e_tech_group
              END,
          CASE
              WHEN nvl(preferred_language, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE preferred_language
              END,
          CASE
              WHEN nvl(mosaic_household, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE mosaic_household
              END,
          CASE
              WHEN nvl(homeowner_flag, '') IN ('ADS Unknown', 'Unknown', '')
                  THEN 'Unknown'
              ELSE homeowner_flag
              END,

          --geo
          county,
          nvl((b.county || ', ' || b.reporting_state_code), ''),
          b.city,
          state_code,
          upper(b.state),
          country_code,
          substring(b.zip, 1, 5),
          upper(b.country),
          CASE
              WHEN NVL(latitude, '') = ''
                  THEN NULL::float
              ELSE latitude::float
              END,
          CASE
              WHEN NVL(longitude, '') = ''
                  THEN NULL::float
              ELSE longitude::float
              END,
          neighborhood,
          borough,
          reporting_country_code,
          reporting_country,
          reporting_country_group,
          reporting_state_code,
          reporting_state,


          --event 
          a.inet_event_id,
          tm_event_status,
          tm_primary_act,
          a.tm_season_year,
          event_business_unit,
          --tm_event_date , 
          a.tm_event_time,
          tm_event_type,
          mpd_game_num,
          tm_major_category,
          tm_minor_category,
          tm_event_name_long,
          a.tm_event_name,
          tm_event_genre,
          report_event_flag,
          a.tm_season_name,
          tm_arena_name,
          tm_arena_venue_zip,
          tm_arena_longitude,
          tm_arena_latitude,


          --ads_source,
          CASE
              WHEN b.reporting_country_group = 'United States of America'
                  THEN CASE
                           WHEN ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude, longitude) = ''
                               THEN 'US Unknown'
                           WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                            longitude)::float, 0) <= 50
                               THEN 'Within 50 Miles'
                           WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                            longitude)::float, 0) <= 75
                               THEN 'Between 51 and 75 Miles'
                           WHEN round(ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude, latitude,
                                                            longitude)::float, 0) <= 300
                               THEN 'Between 76 and 300 Miles'
                           ELSE 'Rest of United States'
                  END
              ELSE CASE
                       WHEN nvl(b.reporting_country_group, '') not in ('', 'Unknown')
                           THEN 'International'
                  --							WHEN ads_main.geo_distance(tm_arena_latitude, tm_arena_longitude,latitude, longitude) ='' 
--							THEN 'Unknown'
                       ELSE 'Unknown'
                  END
              END,
          --ticket type
          ticket_retail_qualifiers,
          house_seat_flag,
          ticket_group_flag,
          ticket_retail_ticket_type,
          ticket_sell_location_name,
          ticket_type_desc,
          a.ticket_product_description,
          ticket_sell_location_group,

          --event date
          eventdt.fiscal_year,
          eventdt.month_name,
          eventdt.weekday_indicator,
          eventdt.day_in_month,
          eventdt.week_end_date,
          eventdt.week_id,
          eventdt.full_date,
          eventdt.day_in_year,

          --sales date
          ticket_sale_report_date,
          dt.fiscal_year,
          dt.month_name,
          dt.weekday_indicator,
          dt.day_in_month,
          dt.week_end_date,
          dt.week_id,
          dt.full_date,
          dt.day_in_year,
          CASE
              WHEN dt.fiscal_month < currdt.fiscal_month THEN
                  'Y'
              WHEN dt.fiscal_month = currdt.fiscal_month
                  AND
                   extract(day FROM dt.full_date) <= extract(day FROM currdt.full_date) THEN
                  'Y'
              ELSE 'N'
              END
        ,

          --excludes
          b.exclude_flag,
--		acct_type_exclusion_exclude_flag, 
--		event_business_unit_exclusion_exclude_flag, 
--		purch_evt_9plus_tix_exclude_flag, 
--		purch_evtdt_2plus_evts_exclude_flag, 
--		purch_evtslsdt_9plus_tix_exclude_flag, 
--		purch_mmyy_18plus_tix_exclude_flag, 
--		purch_mmyy_9plus_evts_exclude_flag, 
--		high_volume_buyer_exception_exclude_flag, 
--		resale_evtdt_2plus_evt_exclude_flag, 
--		resale_evtid_evtdt_9plus_tix_exclude_flag, 
--		resale_postdt_2plus_evt_exclude_flag, 
--		resale_postmmyy_18plus_tix_exclude_flag, 
--		resale_postmmyy_9plus_evts_exclude_flag, 
          CASE
              WHEN nvl(a.ticket_type_desc, '') != 'COMP'
                  AND nvl(a.ticket_type_desc, '') != 'Trade Desk'
                  AND nvl(a.ticket_product_description, '') = 'Individuals'
                  AND
                   nvl(a.ticket_retail_ticket_type, '') NOT IN ('J-TYPE', 'M-TYPE') --As per Cindy exclude all J-TYPEs
                  AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%KBWAYIB%' --As per Cindy exclude
                  AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%BTDAY1%' --As per Cindy exclude
                  AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAY2%' --As per Cindy exclude
                  AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAY3%' --As per Cindy exclude
                  AND nvl(a.ticket_retail_qualifiers, '') NOT LIKE '%NTDAYCM%' --As per Cindy exclude
                  AND nvl(a.house_seat_flag, '') != 'Y' --As per Cindy exclude house seats
                  AND nvl(a.tm_price_code, '') NOT LIKE '_G%' -- AS per Eric H
                  AND nvl(a.credited_sales_rep_full_name, '') NOT LIKE '%Group%' -- AS per Eric H
                  AND nvl(a.msg_departmentname, '') NOT LIKE '%Group%' -- AS per Eric H
                  AND upper(nvl(a.ticket_sell_location_name, '')) != 'BROADWAY.COM'
                  THEN 'Y'
              ELSE 'N'
              END,

--		CASE
--			WHEN ticket_retail_ticket_type= 'G-TYPE'  AND   event_business_unit<>'RANGERS' THEN  'Y'
--			WHEN ticket_retail_ticket_type= 'G-TYPE'  AND   event_business_unit<>'KNICKS' THEN   'Y'
--			WHEN ticket_group_flag='Y' THEN 'Y' 
--			WHEN house_seat_flag='Y' THEN  'Y'
--			WHEN upper (ticket_type_desc) NOT LIKE '%INDI%' THEN   'Y'
--			ELSE 'N'
--		END , 
          CASE
              WHEN COALESCE(b.season_ticket_member_flag, 'N') = 'N'
                  AND COALESCE(high_volume_buyer_flag, 'N') = 'N'
                  AND upper(nvl(acct_type_desc, 'NA')) = 'PERSONAL'
                  AND UPPER(NVL(acct_type_desc, 'NA')) NOT LIKE '%TEST%'
                  THEN 'Y'
              ELSE 'N'
              END
--		CASE
--			WHEN (
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TEST%'  OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TICK%'  OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GROUP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%INTERNAL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%FINAN%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MEDIA%SALE%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%VISIT%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CVC%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CAST%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%VIP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CELEB%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%PRESS%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%SCHOOL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%LEAGUE%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%CAMP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GOVER%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%PARTNER%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GROUP%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GS %' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%GS:%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TICKET:%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TIX%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%AGENCY%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TOUR%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MSG%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%SPONSOR%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%EMPL%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%MARKET%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%TEAM%' OR
--				    upper (COALESCE(acct_type_desc, 'NA')) LIKE '%OFFICE%'  ) OR
--			  upper(a.name_last) = 'SAMPERI'   OR
--			  upper(a.name_last) = 'RASMUSSEN'   OR
--			  upper(company_name) LIKE '%EVENTELL%' THEN   'Y'
--			  ELSE 'N'
--		END
--		acct_type_excludes,  
        , nvl(pc.price_code_section, 'NA')
    --dependencies - after ticket sales and customer jobs at 8:30 or 9 am
--get a tableau command from irina for separating this extract

with no schema binding;

alter table vw_ticket_sales_event_seat_demo
    owner to ads_main;

