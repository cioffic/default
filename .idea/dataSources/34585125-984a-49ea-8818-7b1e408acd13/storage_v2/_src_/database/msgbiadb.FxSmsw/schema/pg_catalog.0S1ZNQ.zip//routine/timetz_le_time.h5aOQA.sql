create function timetz_le_time(time with time zone, time without time zone) returns boolean
    stable
    language sql
as
$$
    select time_ge_timetz($2, $1)
$$;

