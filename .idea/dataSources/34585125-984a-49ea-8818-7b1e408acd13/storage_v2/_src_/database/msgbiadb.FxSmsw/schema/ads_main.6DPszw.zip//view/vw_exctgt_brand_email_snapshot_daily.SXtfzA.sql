create view vw_exctgt_brand_email_snapshot_daily
            (inception_day_id, inception_date, inception_date_fiscal_year, inception_date_month_name,
             inception_date_fiscal_month, inception_date_month_end_flag, exctgt_brand,
             email_database_opening_email_count, email_database_closing_email_count, email_database_new_email_count,
             email_database_lost_email_count, email_database_change_email_count,
             email_database_engaged_opening_email_count, email_database_engaged_closing_email_count,
             email_database_engaged_change_email_count, email_database_unengaged_opening_email_count,
             email_database_unengaged_closing_email_count, email_database_unengaged_change_email_count)
as
SELECT f.inception_day_id,
       id.full_date    AS inception_date,
       id.fiscal_year  AS inception_date_fiscal_year,
       id.month_name   AS inception_date_month_name,
       id.fiscal_month AS inception_date_fiscal_month,
       CASE
           WHEN id.full_date = last_day(id.full_date::timestamp without time zone) THEN 'Y'::character varying
           ELSE 'N'::character varying
           END         AS inception_date_month_end_flag,
       b.exctgt_brand,
       f.email_database_opening_email_count,
       f.email_database_closing_email_count,
       f.email_database_new_email_count,
       f.email_database_lost_email_count,
       f.email_database_change_email_count,
       f.email_database_engaged_opening_email_count,
       f.email_database_engaged_closing_email_count,
       f.email_database_engaged_change_email_count,
       f.email_database_unengaged_opening_email_count,
       f.email_database_unengaged_closing_email_count,
       f.email_database_unengaged_change_email_count
FROM ads_main.f_exctgt_brand_email_snapshot_daily f
         JOIN ads_main.d_exctgt_brand b ON f.brand_id = b.brand_id
         JOIN ads_main.d_date id ON f.inception_day_id = id.day_id;

alter table vw_exctgt_brand_email_snapshot_daily
    owner to ads_main;

