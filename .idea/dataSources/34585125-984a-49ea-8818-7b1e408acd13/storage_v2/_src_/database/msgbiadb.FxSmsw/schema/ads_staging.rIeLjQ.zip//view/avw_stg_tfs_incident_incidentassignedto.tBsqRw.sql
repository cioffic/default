create or replace view ads_staging.avw_stg_tfs_incident_incidentassignedto as
select s.id,
       a.assigned_to_user_id,
       a.assigned_to_user_name
from ext_staging.stg_tfs_incidents as s
         inner join s.incidentassignedto a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incident_incidentassignedto
    owner to ads_staging;

