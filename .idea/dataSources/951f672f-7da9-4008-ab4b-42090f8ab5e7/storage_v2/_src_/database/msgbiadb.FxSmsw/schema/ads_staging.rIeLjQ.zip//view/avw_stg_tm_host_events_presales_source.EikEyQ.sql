CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_host_events_presales_source AS
SELECT --e._embedded.pulldatetime,
       events.id              discovery_event_id,
       presales.name          presale_name,
       presales.startDateTime presale_startdatetime,
       presales.endDateTime   presale_enddatetime,
       e.pt_year              pt_year,
       e.pt_month             pt_month,
       e.pt_day               pt_day
FROM ticketmaster.discoveryapi_events_search e
         LEFT JOIN e._embedded.events events
                   ON TRUE
         LEFT JOIN events.sales.presales presales
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_host_events_presales_source
    owner to ads_staging;

