create or replace view ads_staging.stg_scorecard_knowledge_check
as
select personnumber                                    as EmployeeId,
       instancesubmitteddate::timestamp                as InstanceSumbittedDate,
       instancename                                    as InstanceName,
       instancestatus                                  as InstanceStatus,
       instancescore                                   as InstanceScore,
       instancetotalpossiblescore                      as InstanceTotalPossibleScore,
       worklocationname,
       ads_staging.f_s3_parse_athena_filename("$path") as file_name
from athena_schema.stg_scorecard_knowledge_check
with no schema binding;

alter table stg_scorecard_knowledge_check
    owner to ads_staging;

