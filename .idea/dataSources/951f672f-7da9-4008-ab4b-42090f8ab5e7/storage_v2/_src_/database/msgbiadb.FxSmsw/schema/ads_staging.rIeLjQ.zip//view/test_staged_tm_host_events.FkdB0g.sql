CREATE VIEW ads_staging.test_staged_tm_host_events AS
SELECT SUBSTRING(events.url, LENGTH(events.url) - POSITION('/' IN REVERSE(events.url)) + 2,
                 LENGTH(events.url)) inet_event_id
FROM ext_staging.tm_host_eventsstaged e
         LEFT JOIN e._embedded.events events
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table test_staged_tm_host_events
    owner to ads_staging;

