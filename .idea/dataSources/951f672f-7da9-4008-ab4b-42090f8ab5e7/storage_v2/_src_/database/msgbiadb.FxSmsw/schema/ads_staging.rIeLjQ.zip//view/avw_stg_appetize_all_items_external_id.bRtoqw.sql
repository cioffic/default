CREATE OR replace VIEW ads_staging.avw_stg_appetize_all_items_external_id AS
SELECT a.id,
       external_id.id                      external_id,
       external_id.code                    external_id_code,
       external_id.codetype                external_id_code_type,
       external_id.iscorporateatvenuelevel external_id_is_corporate_at_venue_level,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day

FROM appetize.api_all_items_report a
         LEFT JOIN a.externalid external_id
                   ON TRUE
WITH no SCHEMA binding;

alter table avw_stg_appetize_all_items_external_id
    owner to ads_staging;

