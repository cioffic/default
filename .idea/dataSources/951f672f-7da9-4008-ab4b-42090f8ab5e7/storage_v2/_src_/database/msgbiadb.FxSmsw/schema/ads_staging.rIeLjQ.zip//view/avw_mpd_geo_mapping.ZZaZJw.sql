CREATE OR REPLACE view ads_staging.avw_mpd_geo_mapping
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       right('00000' || zip, 5):: VARCHAR(255)                                  zip,
       latitude:: VARCHAR(255),
       longitude:: VARCHAR(255),
       city:: VARCHAR(255),
       state_code:: VARCHAR(255),
       country_code:: VARCHAR(255),
       county_name:: VARCHAR(255),
       msa:: VARCHAR(255),
       areacode:: VARCHAR(255),
       areacodes:: VARCHAR(255),
       timezone:: VARCHAR(255),
       gmt_offset:: VARCHAR(255),
       po_name:: VARCHAR(255),
       neighborhood:: VARCHAR(255),
       nvl(borough, ''):: VARCHAR(255)                                       as borough

FROM ext_staging.mpd_geo_mapping
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_mapping
    owner to ads_staging;

