CREATE OR replace VIEW ads_staging.avw_stg_appetize_vendor_report_groups AS
SELECT a.id    as vendor_id,
       vg.id   as vendor_group_id,
       vg.name as vendor_group_name,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day

FROM appetize.api_vendor_reports a
         LEFT JOIN a.groups vg
                   ON TRUE
WITH no SCHEMA binding;

alter table avw_stg_appetize_vendor_report_groups
    owner to ads_staging;

