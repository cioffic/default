create or replace view ads_staging.avw_stg_formio_forms_distinct
as
select *
from (
         select source,
                created_date :: datetime,
                business_unit,
                'FORMIO'                                                           as ads_source,
                ads_staging.f_s3_parse_athena_filename("$path")                    as ads_source_file,
                row_number() over (partition by source order by created_date desc) as rank
         from ext_staging.stg_formio_forms
     )
where rank = 1
with no schema binding;

alter table avw_stg_formio_forms_distinct
    owner to ads_staging;

