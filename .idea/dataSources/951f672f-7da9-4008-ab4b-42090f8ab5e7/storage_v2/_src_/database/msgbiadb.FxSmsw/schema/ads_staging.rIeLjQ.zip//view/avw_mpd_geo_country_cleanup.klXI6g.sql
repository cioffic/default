CREATE OR REPLACE view ads_staging.avw_mpd_geo_country_cleanup
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       country_name_impure :: VARCHAR(255)                                      country_name,
       country_code :: VARCHAR(255)
FROM ext_staging.mpd_geo_country_cleanup
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_country_cleanup
    owner to ads_staging;

