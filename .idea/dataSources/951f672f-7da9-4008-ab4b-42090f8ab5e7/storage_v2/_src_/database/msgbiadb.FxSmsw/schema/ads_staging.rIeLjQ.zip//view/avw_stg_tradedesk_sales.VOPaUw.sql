create or replace view ads_staging.avw_stg_tradedesk_sales as
(
select status,
       invoice_date,
       invoice_time,
       home,
       event_datetime1                                               as event_date_time_1,
       event_datetime2                                               as event_date_time_2,
       section,
       row,
       beg_seat                                                         begin_seat,
       end_seat,
       qty,
       msg_rev_per_ticket                                            as msg_revenue_per_ticket,
       msg_total_revenue,
       msg_reporting_rev_per_ticket,
       msg_reporting_revenue,
       customer,
       daysout,
       pricecode,
       pricelevel,
       event_code                                                    AS "event code",
       grade,
       (TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2, 1, 5) + '-' + substring(event_date_time_1, 5, 3) + '-' +
                                  lpad(substring(event_date_time_1, 9, 2), 2, '0') + ' ' +
                                  trim(lpad(substring(event_date_time_2, 7, 5), 5, '0')) + ':00' + ' ' +
                                  substring(event_date_time_2, 12), 'YYYY-MON-DD HH12:MI:SS PM'),
                     'YYYY-MM-DD HH24:MI:SS'))                       as event_date,
       trim(substring(TO_TIMESTAMP(TO_TIMESTAMP(Substring(event_date_time_2, 1, 5) + '-' +
                                                substring(event_date_time_1, 5, 3) + '-' +
                                                lpad(substring(event_date_time_1, 9, 2), 2, '0') + ' ' +
                                                trim(lpad(substring(event_date_time_2, 7, 5), 5, '0')) + ':00' + ' ' +
                                                substring(event_date_time_2, 12), 'YYYY-MON-DD HH12:MI:SS PM'),
                                   'YYYY-MM-DD HH24:MI:SS'), 12, 8)) AS event_time,
       'TRADEDESK'                                                   as cstm_source,
       split_part("$path", '/', 6)                                   as cstm_src_filename
from ext_staging.stg_tradedesk_sales a
where status <> '------'
    )
with no schema binding;

alter table avw_stg_tradedesk_sales
    owner to ads_staging;

