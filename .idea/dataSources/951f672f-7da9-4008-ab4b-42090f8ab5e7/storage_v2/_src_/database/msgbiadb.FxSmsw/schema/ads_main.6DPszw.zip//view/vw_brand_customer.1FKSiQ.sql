CREATE OR REPLACE VIEW ads_main.vw_brand_customer AS
WITH max_load_date AS
         (
             SELECT
                 --20200212::int as load_date
                 MAX(substring("$path" :: VARCHAR(255), position('.' IN "$path" :: VARCHAR(255)) - 8, 8)::int) load_date
             FROM ext_staging.stg_subscribers_by_brand
         ),
     inception_date AS
         (
             SELECT lower(exctgt_subscriber_email_address)                                                             AS email_address,
                    exctgt_subscriber_date_created                                                                     as inception_date,
                    ROW_NUMBER()
                    OVER (PARTITION BY lower(exctgt_subscriber_email_address) ORDER BY exctgt_subscriber_date_created) as row_num
             FROM msgbiadb.ads_main.d_exctgt_subscribers
             WHERE exctgt_subscriber_business_unit_name = 'Madison Square Garden (MSG)'
         ),
     engagement AS
         (
             SELECT DISTINCT lower(email_address) email_address
             FROM ads_main.d_customer_master
                      INNER JOIN ads_main.d_customer_account
                                 ON d_customer_master.customer_master_index =
                                    d_customer_account.customer_master_index
             WHERE customer_engagement_flag = 'Y'
         )

SELECT
--		"$path" :: VARCHAR(255)
--         AS
--	        ads_source_file_path,
substring("$path" :: VARCHAR(255), position('.' IN "$path" :: VARCHAR(255)) - 8, 8)::int
                                                                                                                  AS load_date,

mid::int                                                                                                          as brand_id,
brand::varchar(100),
CASE
    WHEN nvl(es.inception_date, '2018-12-31') <= '2018-12-31' THEN '2018-12-31'
    ELSE es.inception_date END::date                                                                              as msg_inception_date, -- Per Irina, this date will be used as a staring point of our customer data for this requirement
fiscal_year                                                                                                       as msg_inception_date_fiscal_year,
month_name                                                                                                        as msg_inception_date_month_name,
lower(sb.email_address)::varchar(100)                                                                                email_address,
1::int                                                                                                            as total_customer_count,
CASE WHEN e.email_address IS NOT NULL THEN 1 ELSE 0 END::int                                                         engaged_customer_count,
CASE WHEN e.email_address IS NOT NULL THEN 0 ELSE 1 END::int                                                         non_engaged_customer_count
FROM ext_staging.stg_subscribers_by_brand sb
         INNER JOIN max_load_date mld
                    ON substring("$path" :: VARCHAR(255), position('.' IN "$path" :: VARCHAR(255)) - 8, 8)::int =
                       mld.load_date
         LEFT JOIN inception_date es on lower(sb.email_address) = es.email_address and es.row_num = 1
         LEFT JOIN ads_main.d_date dt on CASE
                                             WHEN nvl(es.inception_date, '2018-12-31') <= '2018-12-31' THEN '2018-12-31'
                                             ELSE es.inception_date END::date =
                                         dt.full_date -- Per Irina, this date will be used as a staring point of our customer data for this requirement
         LEFT JOIN engagement e
                   ON lower(sb.email_address) = e.email_address

WHERE mid::int IS NOT NULL
  AND brand IS NOT NULL
  AND sb.email_address is NOT NULL

WITH NO SCHEMA BINDING;

alter table vw_brand_customer
    owner to ads_main;

