CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_extension AS
SELECT a.order_id,
       a.promo.id             promo_id,
       a.promo.code           promo_code,
       a.attributes.taxexemptorder,
       a.customer.id          customer_id,
       a.customer.name        customer_name,
       a.customer.email       customer_email,
       a.customer.mobile      customer_mobile,
       a.customer.level       customer_level,
       a.customer.section     customer_section,
       a.customer.row         customer_row,
       a.customer.seat        customer_seat,
       a.customer.loyalty_id  customer_loyalty_id,
       a.employee.id          employee_id,
       a.employee.external_id employee_external_id,
       a.employee.employee_name,
       a.employee.device_name,
       a.pt_venue_id,
       a.pt_year,
       a.pt_month,
       a.pt_day


FROM appetize.api_orders_report a
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_extension
    owner to ads_staging;

