create function geo_distance(orig_lat_in character varying, orig_long_in character varying, dest_lat_in character varying, dest_long_in character varying) returns character varying
    stable
    language plpythonu
as
$$
  import math
  r = 3959
  if orig_lat_in==None or orig_long_in==None or dest_lat_in==None or dest_long_in==None or orig_lat_in=='' or orig_long_in=='' or dest_lat_in=='' or dest_long_in=='':
  	d=''
  else:	
	  orig_lat=float(orig_lat_in)
	  orig_long=float(orig_long_in)
	  dest_lat=float(dest_lat_in)
	  dest_long=float(dest_long_in)
	  phi_orig = math.radians(orig_lat)
	  phi_dest = math.radians(dest_lat)
	  delta_lat = math.radians(dest_lat - orig_lat)
	  delta_long = math.radians(dest_long - orig_long)
	  a = math.sin(delta_lat/2) * math.sin(delta_lat/2) + math.cos(phi_orig) \
		  * math.cos(phi_dest) * math.sin(delta_long/2) * math.sin(delta_long/2)
	  c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
	  d = str(r * c)
  return d
$$;

