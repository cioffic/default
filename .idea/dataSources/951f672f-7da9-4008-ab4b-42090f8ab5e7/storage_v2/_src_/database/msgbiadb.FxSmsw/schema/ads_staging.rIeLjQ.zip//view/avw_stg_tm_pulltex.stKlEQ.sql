create view ads_staging.avw_stg_tm_pulltex as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'MSG' as ads_source
from ext_staging.stg_tm_pulltex
with no schema binding;

alter table avw_stg_tm_pulltex
    owner to ads_staging;

