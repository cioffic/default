create or replace view ads_staging.avw_stg_tradedesk_sales_t as
(
select status,
       invoice_date,
       invoice_time,
       home,
       event_datetime1             as event_date_time_1,
       event_datetime2             as event_date_time_2,
       section,
       row,
       beg_seat                       begin_seat,
       end_seat,
       qty,
       msg_rev_per_ticket          as msg_revenue_per_ticket,
       msg_total_revenue,
       msg_reporting_rev_per_ticket,
       msg_reporting_revenue,
       customer,
       daysout,
       pricecode,
       pricelevel,
       event_code                  AS "event code",
       grade,
       'TRADEDESK'                 as cstm_source,
       split_part("$path", '/', 6) as cstm_src_filename
from ext_staging.stg_tradedesk_sales a
where status <> '------'
    )
with no schema binding;

alter table avw_stg_tradedesk_sales_t
    owner to ads_staging;

