create view ads_staging.zz_sj_avw_rangers_sl as
select *
from ext_staging.zz_sj_rangers_sl
with no schema binding;

alter table zz_sj_avw_rangers_sl
    owner to ads_main;

