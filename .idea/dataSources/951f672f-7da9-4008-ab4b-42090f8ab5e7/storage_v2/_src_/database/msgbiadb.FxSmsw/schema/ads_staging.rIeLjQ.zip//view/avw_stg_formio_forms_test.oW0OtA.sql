create or replace view ads_staging.avw_stg_formio_forms_test
as
select firstname,
       lastname,
       email,
       phonenumber,
       zipcode,
       created_date :: datetime                                                                                   as created_date,
       source,
       md5(nvl(firstname, '') || nvl(lastname, '') || nvl(email, '') || nvl(phonenumber, '') ||
           nvl(zipcode, ''))                                                                                      as acct_id,
       md5(nvl(firstname, '') || nvl(lastname, '') || nvl(email, '') || nvl(phonenumber, '') || nvl(zipcode, '') ||
           created_date)                                                                                          as submission_id,
       ads_staging.f_s3_parse_athena_filename("$path")                                                            as ads_source_file,
       'FORMIO'                                                                                                   as ads_source
from ext_staging.stg_formio_forms
with no schema binding;

alter table avw_stg_formio_forms_test
    owner to ads_staging;

