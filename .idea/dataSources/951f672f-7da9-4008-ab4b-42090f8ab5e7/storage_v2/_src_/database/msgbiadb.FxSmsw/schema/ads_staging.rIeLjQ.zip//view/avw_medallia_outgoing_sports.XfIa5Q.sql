CREATE OR REPLACE view ads_staging.avw_medallia_outgoing_sports AS
select "$path":: VARCHAR(255)                                                as file_path
     , RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name
     , Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate
     , event_inventory_id::VARCHAR(255)
     , name_first::VARCHAR(40)
     , name_last::VARCHAR(80)
     , email_address::VARCHAR(100)
     , actual_tm_acct_id::int
     , actual_tm_order_id::int
     , acct_status::VARCHAR(20)
     , acct_type_desc::VARCHAR(80)
     , ticket_type_price_level::VARCHAR(100)
     , tm_price_code_desc::VARCHAR(50)
     , tm_section_name::VARCHAR(6)
     , tm_row_name::VARCHAR(4)
     , tm_seat_num::int
     , tm_rep_full_name::VARCHAR(250)
     , tm_rep_email_addr::VARCHAR(100)
     , total_games_attended::int
     , next_season_renewal_flag::VARCHAR(30)
     , tenure_start_date::date
     , attraction_name::VARCHAR(255)
     , phone_day::VARCHAR(25)
     , mpd_opponent::VARCHAR(255)
     , merchandise_cmt_yn::VARCHAR(30)
     , food_beverage_cmt_yn::VARCHAR(30)
     , weekend_flag::int

from ext_staging.stg_medallia_outgoing_sports
where "$path":: VARCHAR(255) not like '%testrun%'
with no schema binding;

alter table avw_medallia_outgoing_sports
    owner to ads_staging;

