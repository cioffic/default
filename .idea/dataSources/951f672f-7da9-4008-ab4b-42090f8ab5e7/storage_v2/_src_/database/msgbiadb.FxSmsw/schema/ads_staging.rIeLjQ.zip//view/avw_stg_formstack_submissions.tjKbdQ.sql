create or replace view ads_staging.avw_stg_formstack_submissions
    ---create table ads_staging.avw_stg_formstack_submissions
as
select id,
       "timestamp",
       user_agent,
       payment_status,
       latitude,
       longitude,
       read,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'FORMSTACK'                                     as ads_source
from ext_staging.stg_formstack_submissions
with no schema binding;

alter table avw_stg_formstack_submissions
    owner to ads_staging;

