CREATE OR replace VIEW ads_staging.avw_stg_appetize_all_items_report_category_groups_level_2 AS
SELECT a.id,
       category_groups_level_2.id                    category_groups_level_2_id,
       category_groups_level_2.display_name          category_groups_level_2_display_name,
       category_groups_level_2.receipttrailermessage category_groups_level_2_receipt_trailer_message,
       category_groups_level_2.sort_order            category_groups_level_2_sort_order,
       category_groups_level_2.nonrefundable         category_groups_level_2_non_refundable,
       category_groups_level_2.buttontextcolor       category_groups_level_2_button_text_color,
       category_groups_level_2.buttonbgcolor         category_groups_level_2_button_bg_color,
       category_groups_level_2.image                 category_groups_level_2_image,
       category_groups_level_2.image_full_res        category_groups_level_2_image_full_res,
       category_groups_level_2.quantityrequired      category_groups_level_2_quantity_required,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day

FROM appetize.api_all_items_report a
         LEFT JOIN a.category_groups_level_2 category_groups_level_2
                   ON TRUE
WITH no SCHEMA binding;

alter table avw_stg_appetize_all_items_report_category_groups_level_2
    owner to ads_staging;

