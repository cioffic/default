create or replace view ads_staging.avw_exctgt_invalid_emails
as
select email_address,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
from ext_staging.stg_exact_target_invalid_emails
with no schema binding;

alter table avw_exctgt_invalid_emails
    owner to ads_staging;

