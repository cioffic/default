create view ads_staging.tp_test_et_clicks
as
select *
from ext_staging.stg_et_bia_clicks_test
with no schema binding;

alter table tp_test_et_clicks
    owner to ads_staging;

