CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_items AS
SELECT a.order_id,
       a.order_date,
       items.id                    item_id,
       items.originalorderid       original_order_id,
       items.sku,
       items.unspscexternalcode    unspsc_external_code,
       items.recipeid              recipe_id,
       items.departmentdescription department_description,
       items.departmentid          department_id,
       items.tipeligible           tip_eligible,
       items.external_id,
       items.unique_id,
       items.name,
       items.locationproductname   location_product_name,
       items.externalclass         external_class,
       items.cost,
       items.original_cost,
       items.discount,
--	discounts_applied=[{id=1646,name=30% Employee Discount,	amount=9.00}],
       items.promo_code,
       items.promo.id              item_promo_id,
       items.promo.code            item_promo_code,
       items.type,
       items.row_id,
       items.quantity,
       items.add_price_override,
       items.refund_item_quantity,
       items.refund_item_cost,
       items.refund_status,
       items.istaxable             is_taxable,
       items.istaxexempt           is_tax_exempt,
       items.tax,
       items.shippingitemref       shipping_item_ref,
       items.inclusive_tax_amount,
--	taxes=[{name=4-Merch Over 110,	value_type=PERCENT,	tax=1.71,extendedtax=1.71,	taxtype=INCLUSIVE,	taxgroupname=null,	taxexternalid=4:1}],
       items.locationkey           location_key,
       items.item_group,
       items.item_group_2,
       items.item_group_3,
       items.totalamount           total_amount,
--	rawitem=[],
       items.is_weight_item,
       items.netweight             net_weight
       --additional_items=[]
FROM appetize.api_orders_report a
         LEFT JOIN a.items items
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_items
    owner to ads_staging;

