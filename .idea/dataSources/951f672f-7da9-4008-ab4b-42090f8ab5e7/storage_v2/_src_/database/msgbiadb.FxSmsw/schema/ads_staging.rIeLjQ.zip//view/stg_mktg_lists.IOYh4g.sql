CREATE VIEW ads_staging.stg_mktg_lists AS
SELECT "$path" file_name,
       *
FROM ext_staging.stg_mktg_lists
WITH NO SCHEMA BINDING;

alter table stg_mktg_lists
    owner to ads_staging;

