CREATE OR replace VIEW ads_staging.avw_stg_appetize_order_report_payments AS
SELECT a.order_id,
       a.order_date,
       payments.payment_index,
       payments.payment_type,
       payments.payment_type_name,
       payments.secondary_payment_type,
       payments.subpayment_type,
       payments.payment_status,
       payments.payment_info,
       payments.payment_amount,
       payments.transaction_id,
       payments.voucher_code,
       payments.house_account_id,
       payments.tip,
       payments.fee,
       payments.tax,
       payments.promo_id,
       payments.last4,
       payments.is_card_present,
       payments.offline,
       payments.card_type,
       payments.authorization_code,
       payments.classification,
       --externaldata=[],
       payments.feeextended fee_extended,
       payments.tendered_amount,
       payments.change_amount
FROM appetize.api_orders_report a
         LEFT JOIN a.payments payments
                   ON TRUE
WITH NO SCHEMA binding;

alter table avw_stg_appetize_order_report_payments
    owner to ads_staging;

