CREATE OR REPLACE VIEW ads_staging.avw_api_events_report AS
SELECT event_id,
       event_name,
       event_type_id,
       event_type,
       engagement_state,
       engagement_city,
       feld_adjustment_description,
       engagement_international,
       venue_name,
       distance,
       date,
       time::varchar(20),
       venue_id,
       orders_start,
       orders_end,
       start_time,
       end_time,
       seatgeek_event_status,
       weather,
       event_expected_attendance,
       event_actual_attendance,
       expected_ticket_sales,
       actual_ticket_sales,
       feld_adjustment_amount,
       tour,
       --ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file ,
       pt_venue_id,
       pt_year,
       pt_month,
       pt_day
FROM appetize.api_events_report
--WHERE ads_staging.f_s3_parse_athena_filename("$path")=(SELECT MAX(ads_staging.f_s3_parse_athena_filename("$path")) FROM appetize.api_events_report)
        WITH NO SCHEMA binding;

alter table avw_api_events_report
    owner to ads_staging;

