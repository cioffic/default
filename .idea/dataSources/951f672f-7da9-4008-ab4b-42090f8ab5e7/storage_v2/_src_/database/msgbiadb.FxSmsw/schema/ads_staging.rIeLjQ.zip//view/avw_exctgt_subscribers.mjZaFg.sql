create or replace view ads_staging.avw_exctgt_subscribers
as
select clientid,
       subscriberkey,
       emailaddress,
       subscriberid,
       status,
       dateheld :: datetime,
       datecreated :: datetime,
       dateunsubscribed :: datetime,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_subscribers
with no schema binding;

alter table avw_exctgt_subscribers
    owner to ads_staging;

