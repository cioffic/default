create view ads_staging.avw_stg_tm_pullprice_code as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'MSG' as ads_source
from ext_staging.stg_tm_pullprice_code
with no schema binding;

alter table avw_stg_tm_pullprice_code
    owner to ads_main;

