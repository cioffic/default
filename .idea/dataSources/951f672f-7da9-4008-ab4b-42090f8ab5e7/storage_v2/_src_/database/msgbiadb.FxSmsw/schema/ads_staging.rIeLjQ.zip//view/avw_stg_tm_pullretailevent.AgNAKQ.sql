CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_pullretailevent as
SELECT attraction_id,
       attraction_name,
       event_date,
       event_time,
       host_event_code,
       host_event_id,
       host_name,
       major_category_id,
       major_category_name,
       minor_category_id,
       minor_category_name,
       primary_act,
       primary_act_id,
       retail_event_id,
       secondary_act,
       secondary_act_id,
       seq_num,
       venue_id,
       venue_name
FROM (
         SELECT attraction_id,
                attraction_name,
                event_date,
                event_time,
                host_event_code,
                host_event_id,
                host_name,
                major_category_id,
                major_category_name,
                minor_category_id,
                minor_category_name,
                primary_act,
                primary_act_id,
                retail_event_id,
                secondary_act,
                secondary_act_id,
                seq_num,
                venue_id,
                venue_name,
                row_number() OVER (PARTITION BY host_event_id ORDER BY retail_event_id DESC) rnk
         FROM ticketmaster.daily_crmapi_pullretail_event
         WHERE pt_year || pt_month || pt_day =
               (SELECT MAX(pt_year || pt_month || pt_day) FROM ticketmaster.daily_crmapi_pullretail_event)
     )
WHERE rnk = 1
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_pullretailevent
    owner to ads_staging;

