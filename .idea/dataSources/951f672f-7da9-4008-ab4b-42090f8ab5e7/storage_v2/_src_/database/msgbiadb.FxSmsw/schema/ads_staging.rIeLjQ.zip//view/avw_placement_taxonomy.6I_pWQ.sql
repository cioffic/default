create or replace view ads_staging.avw_placement_taxonomy
as
select placement_id,
       placement,
       devices,
       tactic,
       segment,
       unit_size,
       creative,
       impressions,
       clicks,
       spend,
       video_impressions,
       dcm_clicks,
       dcm_spend,
       viewable_impressions,
       eligible_impressions,
       viewable_impression_distribution,
       pc_viewable_impressions,
       video_views,
       sales,
       revenue,
       ticket_quantity,
       clickable_impressions,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
from ext_staging.stg_cssr_media_perf
with no schema binding;

alter table avw_placement_taxonomy
    owner to ads_staging;

