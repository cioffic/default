create view ads_staging.avw_zz_sj_rangers_sl as
select *
from ext_staging.zz_sj_rangers_sl
with no schema binding;

alter table avw_zz_sj_rangers_sl
    owner to ads_staging;

