create or replace view ads_staging.avw_eatec_zetup05 as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'EATEC' as ads_source
from ext_staging.stg_eatec_zetup05
with no schema binding;

alter table avw_eatec_zetup05
    owner to ads_staging;

