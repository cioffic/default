create or replace view ads_staging.avw_stg_tm_cn_questionresponses as
select source,
       acct_id,
       name_last_first_mi,
       question_id,
       question_title,
       response,
       invoice_id,
       order_num,
       add_datetime :: datetime,
       add_user,
       name_type,
       owner_name,
       owner_name_full,
       privacy_restrict,
       privacy_opt_out,
       privacy_restrict_upd_datetime,
       privacy_opt_out_upd_datetime,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'MSG'                                           as ads_source
from ext_staging.stg_tm_cn_questionresponses
where add_datetime :: datetime >= '2019-01-01 00:00:00'
with no schema binding;

alter table avw_stg_tm_cn_questionresponses
    owner to ads_staging;

