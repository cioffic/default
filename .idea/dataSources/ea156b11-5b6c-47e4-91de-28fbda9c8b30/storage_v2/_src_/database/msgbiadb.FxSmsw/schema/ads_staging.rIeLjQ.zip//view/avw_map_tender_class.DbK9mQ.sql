create view ads_staging.avw_map_tender_class
as
select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       tender_class_name_id::int,
       tender_name::varchar(100),
       ads_source::varchar(100),
       tender_class_name::varchar(100),
       metadata::varchar(255),
       created_at::timestamp,
       updated_at::timestamp
from ext_staging.map_tender_class
with no schema binding;

alter table avw_map_tender_class
    owner to ads_staging;

