create or replace view ads_staging.avw_stg_tm_host_audit
as
select "system",
       hexvaxevid,
       evcode,
       eventname,
       majorcategory,
       minorcategory,
       actname,
       secondactname,
       venuename,
       epdate :: timestamp,
       eptime,
       sdate :: timestamp,
       optype,
       pricelevelid,
       pricelevelname,
       tickettypeid,
       tickettypename,
       qualifierstring,
       auditentry,
       seriesmaster,
       dailytickets,
       totaltickets,
       soldfacevalue,
       servicecharge,
       facilityfee,
       servicetax,
       vattax,
       adultprice,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       "system"                                        AS ads_source
from ext_staging.stg_tm_host_audit
with no schema binding;

alter table avw_stg_tm_host_audit
    owner to ads_staging;

