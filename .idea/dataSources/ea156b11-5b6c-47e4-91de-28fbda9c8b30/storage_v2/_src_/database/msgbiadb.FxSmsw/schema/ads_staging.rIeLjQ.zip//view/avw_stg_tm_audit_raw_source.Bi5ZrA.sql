create or replace view ads_staging.avw_stg_tm_audit_raw_source as
(
select audit.audit_datetime,
       audit.add_usr,
       audit.amount,
       audit.calc_amount,
       audit.calc_num_seats,
       audit.class_id,
       audit.class_name,
       audit.comp_code,
       audit.comp_name,
       audit.disc_amount,
       audit.disc_code,
       audit.disc_level,
       audit.disc_name,
       audit.dist_status,
       case
           when audit.disc_level LIKE 'DIST%' and audit.source_system = 'T'
               then substring(split_part(audit.disc_level, ' ', 2), 1, 1) || '-TYPE'
           when audit.disc_level LIKE 'DIST%' and nvl(audit.source_system, 'A') = 'A'
               then split_part(audit.disc_level, ' ', 2)
           else 'NA' end as retail_type,
       case
           when audit.disc_level LIKE 'DIST%' then (substring(split_part(audit.disc_level, ' ', 3), 2))
           else 'NA' end as retail_qualifier,
--case when audit.disc_level LIKE 'DIST%' then replace(substring (split_part(disc_level,' ',3),  2 ),']','') else 'NA' end as retail_qualifier,
       audit.eip_pricing_used,
       audit.event_id,
       audit.event_name,
       audit.event_sort,
       audit.export_datetime,
       audit.fse,
       audit.group_flag,
       audit.include_in_report,
       audit.kill,
       audit.num_seats,
       audit.orig_disc_amount,
       audit.orig_price_code,
       audit.orig_surchg_amount,
       audit.paid,
       audit.pc_1,
       audit.pc_23,
       cast(audit.pc_licfee as float),
       cast(audit.pc_other1 as float),
       cast(audit.pc_other2 as float),
       cast(audit.pc_other3 as float),
       audit.pc_other4,
       audit.pc_other5,
       audit.pc_other6,
       audit.pc_other7,
       audit.pc_other8,
       cast(audit.pc_tax as float),
       audit.pc_template_id,
       audit.pc_ticket,
       audit.period,
       audit.pk_seq_id,
       audit.plan_event_id,
       audit.plan_event_name,
       audit.plan_name,
       audit.price,
       audit.price_code,
       audit.price_code_desc,
       audit.pricing_method,
       cast(audit.purchase_price as float),
       audit.seat_status,
       audit.sell_location,
       audit.sell_location_id,
       audit.sell_location_name,
       audit.seq_num,
       audit.source_system,
       audit.sum_pc_licfee,
       audit.sum_pc_other1,
       audit.sum_pc_other2,
       audit.sum_pc_other3,
       audit.sum_pc_other4,
       audit.sum_pc_other5,
       audit.sum_pc_other6,
       audit.sum_pc_other7,
       audit.sum_pc_other8,
       audit.sum_pc_tax,
       audit.sum_pc_ticket,
       audit.summary_disc_level,
       cast(audit.surchg_amount as float),
       audit.surchg_code,
       audit.surchg_name,
       audit.ticket_type_code,
       audit.tm_event_name,
       audit.tm_price_level,
       ((cast(audit.purchase_price as float) -
         (cast(audit.pc_tax as float) + cast(audit.pc_other1 as float) + cast(audit.pc_other2 as float)
             + cast(audit.pc_other3 as float) +
          case when audit.source_system = 'A' then cast(audit.pc_licfee as float) else 0 end +
          cast(audit.surchg_amount as float))))
                         as tm_pc_ticket,
       audit.load_date
--ads_staging.f_s3_parse_athena_filename("$path") as ads_source_filename
--max()OVER(PARTITION BY TO_CHAR(TO_TIMESTAMP(audit.LOAD_DATE , 'YYYY-MM-DD HH24:MI:SS'),'YYYMMDD') ORDER BY TO_TIMESTAMP(audit.LOAD_DATE , 'YYYY-MM-DD HH24:MI:SS') DESC) max_RANK
FROM ext_staging.stg_tm_audit_source a
         left join a.core audit
                   on TRUE
    )
with no schema binding;

alter table avw_stg_tm_audit_raw_source
    owner to ads_staging;

