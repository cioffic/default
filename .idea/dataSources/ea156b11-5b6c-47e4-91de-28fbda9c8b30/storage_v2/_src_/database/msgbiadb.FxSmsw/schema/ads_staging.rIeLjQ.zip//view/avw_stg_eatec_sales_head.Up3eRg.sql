CREATE OR REPLACE view ads_staging.avw_stg_eatec_sales_head AS
select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       intnum::int                                                           as intnum,
       location::int                                                         as location,
       meal::int                                                             as meal,
       postdate::timestamp                                                   as postdate,
       covers::int                                                           as covers,
       checks::int                                                           as checks,
       source::int                                                           as source,
       typetotals:: VARCHAR(255)                                             as typetotals,
       taxtotals:: VARCHAR(255)                                              as taxtotals,
       mediatotals:: VARCHAR(255)                                            as mediatotals,
       ref:: VARCHAR(255)                                                    as ref,
       remark:: VARCHAR(255)                                                 as remark,
       enteredon::datetime                                                   as enteredon,
       enteredby:: VARCHAR(255)                                              as enteredby,
       valued::numeric(30, 4)                                                as valued,
       onhand::numeric(30, 4)                                                as onhand,
       intransit::numeric(30, 4)                                             as intransit,
       transrecvd::numeric(30, 4)                                            as transrecvd,
       rollover::numeric(30, 4)                                              as rollover,
       misc1::int                                                            as misc1,
       misc2::int                                                            as misc2,
       misc3::int                                                            as misc3,
       misc4::int                                                            as misc4,
       misc5::int                                                            as misc5,
       misc6::int                                                            as misc6,
       drate::numeric(30, 4)                                                 as drate,
       plannum::int                                                          as plannum


from ext_staging.stg_eatec_sales_head
with no schema binding;

alter table avw_stg_eatec_sales_head
    owner to ads_staging;

