CREATE VIEW ads_staging.avw_stg_event_engine_genres AS
SELECT e.id,
       e.name,
       g.name genre_name
FROM msg_digital.eventengine_events e
         LEFT JOIN e.genres g
                   ON TRUE
WITH NO SCHEMA BINDING;

alter table avw_stg_event_engine_genres
    owner to msgadmin;

