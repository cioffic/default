create view ads_staging.avw_stg_mags_stream_summary
as
select *, ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file
from ext_staging.stg_mags_stream
where msg_type in ('OFF', 'S')
with no schema binding;

alter table avw_stg_mags_stream_summary
    owner to ads_staging;

