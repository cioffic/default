CREATE OR REPLACE view ads_staging.avw_mpd_experian_mappings as

select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       mapping_type::VARCHAR(255),
       code::VARCHAR(255),
       description::VARCHAR(255),
       definition::VARCHAR(255)

from ext_staging.mpd_experian_mappings
with no schema binding;

alter table avw_mpd_experian_mappings
    owner to ads_staging;

