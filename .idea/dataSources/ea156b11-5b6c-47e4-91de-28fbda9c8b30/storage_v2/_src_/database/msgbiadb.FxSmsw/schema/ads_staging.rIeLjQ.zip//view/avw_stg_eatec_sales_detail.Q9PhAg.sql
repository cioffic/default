CREATE OR REPLACE VIEW ads_staging.avw_stg_eatec_sales_detail as
select "$path":: VARCHAR(255)                                                as file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) as file_name,
       Regexp_substr("$path", '[0123456789]{8}')::int                        as loaddate,
       intnum::int                                                           as intnum,
       item::int                                                             as item,
       location::int                                                         as location,
       meal::int                                                             as meal,
       postdate::timestamp                                                   as postdate,
       qty::int                                                              as qty,
       valued::numeric(30, 4)                                                as valued,
       cost::numeric(30, 4)                                                  as cost,
       source::int                                                           as source,
       dbclass::int                                                          as dbclass,
       linkitem::varchar(255)                                                as linkitem,
       linkqty::int                                                          as linkqty,
       linkunit::int                                                         as linkunit,
       ref::varchar(255)                                                     as ref,
       remark::varchar(255)                                                  as remark,
       dummyindx::int                                                        as dummyindx,
       taxvalue::numeric(30, 4)                                              as taxvalue,
       checknumber::varchar(255)                                             as checknumber,
       royaltyrate::numeric(30, 4)                                           as royaltyrate


from ext_staging.stg_eatec_sales_detail
with no schema binding;

alter table avw_stg_eatec_sales_detail
    owner to ads_staging;

