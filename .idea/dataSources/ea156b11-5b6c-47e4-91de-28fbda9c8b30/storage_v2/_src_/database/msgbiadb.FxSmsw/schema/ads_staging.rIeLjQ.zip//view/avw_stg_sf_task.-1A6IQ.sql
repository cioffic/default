create view ads_staging.avw_stg_sf_task as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'SFDC' as ads_source
from ext_staging.stg_sf_task
with no schema binding;

alter table avw_stg_sf_task
    owner to ads_staging;

