CREATE VIEW ads_staging.avw_tableau_email_groups AS
SELECT SUBSTRING(ads_staging.f_s3_parse_athena_filename("$path"), 1,
                 CHARINDEX('.', ads_staging.f_s3_parse_athena_filename("$path")) - 1) as email_group_name,
       *
FROM ext_staging.tableau_email_groups
WITH NO SCHEMA BINDING;

alter table avw_tableau_email_groups
    owner to ads_main;

