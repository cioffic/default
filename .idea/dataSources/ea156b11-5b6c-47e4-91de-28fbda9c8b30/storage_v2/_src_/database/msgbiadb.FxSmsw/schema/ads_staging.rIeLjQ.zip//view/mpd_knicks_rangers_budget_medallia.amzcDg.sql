CREATE VIEW ads_staging.mpd_knicks_rangers_budget_medallia
AS
SELECT *
FROM ext_staging.mpd_knicks_rangers_budget_medallia
WITH NO SCHEMA BINDING;

alter table mpd_knicks_rangers_budget_medallia
    owner to ads_staging;

