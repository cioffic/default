create or replace view ads_staging.avw_map_fmb_targets as
(
select fb_transaction_and_attendee_projections_id,
       tm_event_name,
       tm_event_date,
       cast(fb_trx_per_attendee as float) as fb_trx_per_attendee,
       cast(fb_per_cap as float)          as fb_per_cap,
       cast(basket_size as float)         as basket_size,
       metadata,
       created_at,
       updated_at,
       username
from ext_staging.map_fmb_targets a
    )
with no schema binding;

alter table avw_map_fmb_targets
    owner to ads_staging;

