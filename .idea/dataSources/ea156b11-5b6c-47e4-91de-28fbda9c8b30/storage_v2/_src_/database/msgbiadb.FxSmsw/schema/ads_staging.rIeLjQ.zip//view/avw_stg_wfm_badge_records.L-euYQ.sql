create view ads_staging.avw_stg_wfm_badge_records
as
select name,
       regexp_replace(case when display_employee = '' then null else display_employee end, '[^0-9]+',
                      '') :: INT                       as display_employee,
       job_code,
       job_class,
       badge_no,
       effective_start,
       effective_end,
       group_name,
       status,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       (row_number()
        over (
            partition by display_employee
            order by "$path" desc, (case
                                        when status = 'Active'
                                            then 1
                                        else 2 end),
                badge_no desc ))                       as seq_num
from ext_staging.stg_wfm_badge_records a
with no schema binding;

alter table avw_stg_wfm_badge_records
    owner to ads_staging;

