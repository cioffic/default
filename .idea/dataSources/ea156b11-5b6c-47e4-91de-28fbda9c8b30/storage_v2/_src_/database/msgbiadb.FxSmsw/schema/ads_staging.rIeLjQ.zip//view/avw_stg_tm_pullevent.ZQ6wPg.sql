CREATE OR REPLACE VIEW ads_staging.avw_stg_tm_pullevent as
SELECT ads_staging.f_s3_parse_athena_filename("$path") ads_source_file,
       Add_date,
       Arena_name,
       Barcode_Status,
       Dsps_allowed,
       Enabled,
       Event_Type,
       cast(Event_id as varchar)                       Event_id,
       Event_sort,
       FSE,
       Game_Number,
       Major_Category,
       MaxEventDate,
       Min_events,
       Minor_Category,
       Org_Name,
       PLAN,
       Print_Ticket_Ind,
       Returnable,
       Season_name,
       Team,
       Tm_event_name,
       Upd_date,
       Upd_user,
       dw_event_id,
       event_date,
       event_day,
       event_name,
       event_name_long,
       event_report_group,
       event_time,
       exchange_price_opt,
       plan_Type,
       plan_abv,
       season_id,
       seq_num,
       total_events
FROM ext_staging.stg_crmapi_pullevent
WHERE "$path" = (SELECT MAX("$path") FROM ext_staging.stg_crmapi_pullevent)
  and arena_name != 'Shell events'
  and upper(event_name_long) not like '%SHELL EVENT%'
WITH NO SCHEMA BINDING;

alter table avw_stg_tm_pullevent
    owner to ads_staging;

