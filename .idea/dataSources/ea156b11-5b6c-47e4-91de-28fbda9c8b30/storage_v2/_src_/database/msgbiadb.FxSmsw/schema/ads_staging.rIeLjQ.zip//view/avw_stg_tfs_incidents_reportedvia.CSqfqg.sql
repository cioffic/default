create or replace view ads_staging.avw_stg_tfs_incidents_reportedvia as
select a.id,
       a.reported_via_name
from ext_staging.stg_tfs_incidents_detail as s
         inner join s.reportedvia a on true
WITH NO SCHEMA BINDING;

alter table avw_stg_tfs_incidents_reportedvia
    owner to ads_staging;

