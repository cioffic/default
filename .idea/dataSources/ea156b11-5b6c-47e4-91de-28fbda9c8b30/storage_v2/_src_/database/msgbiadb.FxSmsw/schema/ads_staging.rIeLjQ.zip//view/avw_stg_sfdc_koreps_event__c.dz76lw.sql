create or replace view ads_staging.avw_stg_sfdc_koreps_event__c as
select *
from ext_staging.stg_sfdc_koreps__event__c
with no schema binding;

alter table avw_stg_sfdc_koreps_event__c
    owner to ads_staging;

