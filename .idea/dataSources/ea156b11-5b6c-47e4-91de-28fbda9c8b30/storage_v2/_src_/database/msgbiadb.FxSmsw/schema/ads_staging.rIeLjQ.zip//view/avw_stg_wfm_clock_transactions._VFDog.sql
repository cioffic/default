create view ads_staging.avw_stg_wfm_clock_transactions
as
select timestamp::date::varchar                        as timestamp
     , timezone
     , badge_no
     , display_employee
     , action
     , device_id
     , device
     , score
     , assignment
     , data
     , pay_code
     , first_name
     , last_name
     , ads_staging.f_s3_parse_athena_filename("$path") as filename
from ext_staging.stg_wfm_clock_transactions
with no schema binding;

alter table avw_stg_wfm_clock_transactions
    owner to ads_staging;

