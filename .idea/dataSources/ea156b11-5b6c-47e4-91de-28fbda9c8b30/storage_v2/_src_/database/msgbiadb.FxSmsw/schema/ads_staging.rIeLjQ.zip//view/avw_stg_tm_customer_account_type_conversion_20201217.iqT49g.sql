CREATE or replace view ads_staging.avw_stg_tm_customer_account_type_conversion_20201217
as
select *
from ext_staging.stg_tm_customer_account_type_conversion_20201217
with no schema binding;

alter table avw_stg_tm_customer_account_type_conversion_20201217
    owner to ads_staging;

