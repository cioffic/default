create view ads_staging.avw_kore_externalsystemtocontact as
select *
from ext_staging.stg_kore_externalsystemtocontact
with no schema binding;

alter table avw_kore_externalsystemtocontact
    owner to ads_staging;

