CREATE OR REPLACE VIEW ads_staging.avw_stg_open_weather_msg_arena_hourly
AS
Select timestamp 'epoch' + dt * interval '1 second'    AS dtime,
       ((temp - 273.15) * 1.8) + 32                    AS temp,
       ((feels_like - 273.15) * 1.8) + 32              AS feels_like,
       pressure,
       humidity,
       dew_point,
       clouds,
       wind_speed,
       wind_deg,
       id,
       main,
       description,
       icon,
       1                                                  h,
       ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file,
       'MSG'                                           as ads_source
from open_weather.open_weather_hourly_reports_6c16e4c7b5801350413ae786bffaf90d
with no schema binding;

alter table avw_stg_open_weather_msg_arena_hourly
    owner to ads_staging;

