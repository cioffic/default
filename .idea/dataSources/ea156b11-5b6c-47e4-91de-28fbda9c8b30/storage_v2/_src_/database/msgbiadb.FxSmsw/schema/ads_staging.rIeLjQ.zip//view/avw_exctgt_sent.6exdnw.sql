create or replace view ads_staging.avw_exctgt_sent
as
select clientid,
       sendid,
       subscriberkey,
       emailaddress,
       subscriberid,
       listid,
       case
           when nvl(eventdate, '') <> '' THEN
               eventdate :: datetime
           else null::datetime
           end                                         as eventdate,
       case
           when nvl(eventdate, '') <> '' THEN
                       left(split_part(eventdate, '/', 3), 4) || right('0' || split_part(eventdate, '/', 1), 2) ||
                       right('0' || split_part(eventdate, '/', 2), 2)
           ELSE NULL END::int                          as eventdayid,
       eventtype,
       batchid :: integer,
       triggeredsendexternalkey,
       campaignid,
       ads_staging.f_s3_parse_athena_filename("$path") AS ads_source_file,
       'EXACT TARGET'                                  AS ads_source
from ext_staging.stg_et_bia_sent
with no schema binding;

alter table avw_exctgt_sent
    owner to ads_staging;

