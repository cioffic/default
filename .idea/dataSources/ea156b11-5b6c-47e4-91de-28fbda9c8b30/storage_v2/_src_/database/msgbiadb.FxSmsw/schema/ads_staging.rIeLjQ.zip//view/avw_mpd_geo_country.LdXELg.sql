CREATE OR REPLACE view ads_staging.avw_mpd_geo_country
AS
SELECT "$path" :: VARCHAR(255)
                                                                             AS
                                                                                ads_source_file_path,
       RIGHT("$path", Position('/' IN Reverse("$path")) - 1) :: VARCHAR(255) AS ads_source_file,
       country_code :: VARCHAR(255),
       country_name :: VARCHAR(255),
       reporting_country_name :: VARCHAR(255),
       reporting_country_group :: VARCHAR(255)

FROM ext_staging.mpd_geo_country
WITH NO SCHEMA BINDING;

alter table avw_mpd_geo_country
    owner to ads_staging;

