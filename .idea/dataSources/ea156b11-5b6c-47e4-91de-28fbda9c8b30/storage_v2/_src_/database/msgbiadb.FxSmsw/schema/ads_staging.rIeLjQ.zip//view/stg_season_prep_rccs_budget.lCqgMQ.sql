create or replace view ads_staging.stg_season_prep_rccs_budget
as
select season,
       week_ending :: DATE,
       finance_ticket_type,
       reporting_ticket_type,
       case
           when tickets_sold = '-' then 0 :: FLOAT
           else
               nvl(replace(tickets_sold, ',', ''), '0') :: FLOAT end    as tickets_sold,
       case
           when tickets_revenue = '-' then 0 :: FLOAT
           else
               nvl(replace(tickets_revenue, ',', ''), '0') :: FLOAT end as tickets_revenue,
       db,
       season_code
from ext_staging.stg_season_prep_rccs_budget
with no schema binding;

alter table stg_season_prep_rccs_budget
    owner to ads_staging;

