CREATE OR REPLACE VIEW ads_staging.avw_stg_mag_stream_report_boe AS
SELECT CASE
           WHEN b.COUNTER_FLAG = 'RESET' THEN 0
           WHEN coalesce(prev_counter, '0') = '0' and coalesce(last_counter, '0') = '0' THEN 0
           WHEN RESET_DTM LIKE 'FIRST_REC%' THEN last_counter - 1
           ELSE coalesce(last_counter, '0') - coalesce(prev_counter, '0')
           END                                                                           passage_inc_value,
       CASE
           WHEN b.COUNTER_FLAG = 'RESET' THEN 0
           WHEN coalesce(prev_alarm_counter, '0') = '0' and coalesce(last_alarm_counter, '0') = '0' THEN 0
           WHEN RESET_DTM LIKE 'FIRST_REC%' THEN last_alarm_counter - 1
           ELSE coalesce(last_alarm_counter, '0') - coalesce(prev_alarm_counter, '0')
           END                                                                           alarm_inc_value,
       datediff(second, prev_created_datetime, created_datetime)                         seconds_delta,
       coalesce(b.RESET_DTM, lag(RESET_DTM, 1 IGNORE NULLS)
                             over (partition by ipaddress order by created_datetime)) as prev_RESET_DTM,
       b.*
FROM (
         SELECT cast(lag(lcounter, 1 IGNORE NULLS)
                     over (partition by ipaddress order by utc_created_datetime ) as integer)                                as prev_counter,       --previous counter value
                cast(coalesce(a.lcounter, lag(lcounter ignore nulls)
                                          over (partition by ipaddress order by utc_created_datetime asc )) as integer)      as Last_counter,--in case current counter is null use prev value
                CASE
                    WHEN coalesce(a.lcounter, lag(lcounter ignore nulls)
                                              over (partition by ipaddress order by utc_created_datetime asc )) =
                         '000000'
                        AND
                         lag(lcounter, 1 IGNORE NULLS) over (partition by ipaddress order by utc_created_datetime ) <>
                         '000000' --When current counter value is 0 and previous value is not 0 then it is a restet
                        THEN 'RESET'
                    WHEN coalesce(a.lcounter, lag(lcounter ignore nulls)
                                              over (partition by ipaddress order by utc_created_datetime asc )) <
                         lag(lcounter, 1 IGNORE NULLS) over (partition by ipaddress order by utc_created_datetime )
                        THEN 'REV' --If the current counter value is less than the previous value then it is a reverse
                    else 'FWD'
                    END                                                                                                      as COUNTER_FLAG,
                CASE
                    WHEN coalesce(a.lcounter, lag(lcounter ignore nulls)
                                              over (partition by ipaddress order by utc_created_datetime asc )) =
                         '000000'
                        AND
                         lag(lcounter, 1 IGNORE NULLS) over (partition by ipaddress order by utc_created_datetime ) <>
                         '000000' THEN 'RESET_' || utc_created_datetime --Capture timestamp of the reset
                    WHEN row_number() OVER (partition by ipaddress order by utc_created_datetime ) = 1
                        THEN 'FIRST_REC_' || utc_created_datetime --Tag the first record of the window
                    END                                                                                                      as RESET_DTM,
                --
                cast(lag(alarm_counter, 1 IGNORE NULLS)
                     over (partition by ipaddress order by utc_created_datetime ) as integer)                                as prev_alarm_counter, --previous counter value
                cast(coalesce(a.alarm_counter, lag(alarm_counter ignore nulls)
                                               over (partition by ipaddress order by utc_created_datetime asc )) as integer) as Last_alarm_counter,--in case current counter is null use prev value
                lag(created_datetime, 1 IGNORE NULLS)
                over (partition by ipaddress order by utc_created_datetime )::timestamp                                      as prev_created_datetime,
                a.*
         FROM (SELECT a.ipaddress,
                      a.created_datetime                                                  utc_created_datetime,
                      convert_timezone('America/New_York', a.created_datetime::timestamp) created_datetime,
                      a.msg_type,
                      a.model_name,
                      a.serial_number,
                      a.version,
                      a.program,
                      CASE real_alarm_percentage
                          WHEN '00' THEN 'Bidirectional'
                          WHEN '01' THEN 'Fwd. Only'
                          WHEN '02' THEN 'Rev. Only'
                          WHEN '03' THEN 'Subtract Rev.'
                          END                                                             Count_direction_Config,
                      CASE
                          WHEN alarm_counter = '' THEN NULL
                          ELSE alarm_counter
                          END as                                                          alarm_counter,
                      CASE
                          WHEN counter = '' THEN NULL
                          ELSE counter
                          END as                                                          lCounter,
                      b.location_name,
                      b.group_name,
                      b.mag_id,
                      a.mag_year,
                      a.mag_month,
                      a.mag_day,
                      a.ads_source_file,
                      c.tm_event_date,
                      c.tm_event_time,
                      c.tm_event_name_long
               FROM ads_staging.avw_stg_mags_stream_summary a
                        JOIN ext_staging.stg_mags_mapping b
                             ON a.ipaddress = b.ip_address
                        LEFT JOIN ads_main.d_event_plan c
                                  ON c.tm_season_name = 'RNG 2019-20 New York Rangers'
                                      AND c.tm_plan_event_id = -1
                                      AND convert_timezone('America/New_York', a.created_datetime::timestamp) BETWEEN
                                             (to_char(tm_event_date, 'yyyy-mm-dd') || ' ' || tm_event_time)::timestamp -
                                             INTERVAL '1 HOUR' AND
                                             (to_char(tm_event_date, 'yyyy-mm-dd') || ' ' || tm_event_time)::timestamp +
                                             INTERVAL '4 HOURS'
               WHERE msg_type in ('S')
                 AND mag_year = '2020'
                 AND mag_month = '10'
                 AND mag_day >= 15
                  --AND a.ipaddress='10.202.205.18'
              ) a
     ) b
WITH NO SCHEMA BINDING;

alter table avw_stg_mag_stream_report_boe
    owner to ads_staging;

