create or replace view ads_staging.avw_stg_twentyfour_seven_events as
select *, ads_staging.f_s3_parse_athena_filename("$path") as ads_source_file, 'TWENTYFOURSEVEN' as ads_source
from ext_staging.stg_twentyfour_seven_events
with no schema binding;

alter table avw_stg_twentyfour_seven_events
    owner to ads_main;

